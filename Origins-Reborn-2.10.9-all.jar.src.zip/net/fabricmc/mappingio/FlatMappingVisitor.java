/*     */ package net.fabricmc.mappingio;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import net.fabricmc.mappingio.adapter.FlatAsRegularMappingVisitor;
/*     */ import net.fabricmc.mappingio.adapter.RegularAsFlatMappingVisitor;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface FlatMappingVisitor
/*     */ {
/*     */   default Set<MappingFlag> getFlags() {
/*  33 */     return MappingFlag.NONE;
/*     */   }
/*     */   
/*     */   default void reset() {
/*  37 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean visitHeader() throws IOException {
/*  46 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void visitNamespaces(String paramString, List<String> paramList) throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   default void visitMetadata(String key, @Nullable String value) throws IOException {}
/*     */ 
/*     */   
/*     */   default boolean visitContent() throws IOException {
/*  59 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean visitClass(String paramString, @Nullable String[] paramArrayOfString) throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   void visitClassComment(String paramString1, @Nullable String[] paramArrayOfString, String paramString2) throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   boolean visitField(String paramString1, String paramString2, @Nullable String paramString3, @Nullable String[] paramArrayOfString1, @Nullable String[] paramArrayOfString2, @Nullable String[] paramArrayOfString3) throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   void visitFieldComment(String paramString1, String paramString2, @Nullable String paramString3, @Nullable String[] paramArrayOfString1, @Nullable String[] paramArrayOfString2, @Nullable String[] paramArrayOfString3, String paramString4) throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   boolean visitMethod(String paramString1, String paramString2, @Nullable String paramString3, @Nullable String[] paramArrayOfString1, @Nullable String[] paramArrayOfString2, @Nullable String[] paramArrayOfString3) throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   void visitMethodComment(String paramString1, String paramString2, @Nullable String paramString3, @Nullable String[] paramArrayOfString1, @Nullable String[] paramArrayOfString2, @Nullable String[] paramArrayOfString3, String paramString4) throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   boolean visitMethodArg(String paramString1, String paramString2, @Nullable String paramString3, int paramInt1, int paramInt2, @Nullable String paramString4, @Nullable String[] paramArrayOfString1, @Nullable String[] paramArrayOfString2, @Nullable String[] paramArrayOfString3, String[] paramArrayOfString4) throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   void visitMethodArgComment(String paramString1, String paramString2, @Nullable String paramString3, int paramInt1, int paramInt2, @Nullable String paramString4, @Nullable String[] paramArrayOfString1, @Nullable String[] paramArrayOfString2, @Nullable String[] paramArrayOfString3, @Nullable String[] paramArrayOfString4, String paramString5) throws IOException;
/*     */ 
/*     */   
/*     */   boolean visitMethodVar(String paramString1, String paramString2, @Nullable String paramString3, int paramInt1, int paramInt2, int paramInt3, int paramInt4, @Nullable String paramString4, @Nullable String[] paramArrayOfString1, @Nullable String[] paramArrayOfString2, @Nullable String[] paramArrayOfString3, String[] paramArrayOfString4) throws IOException;
/*     */ 
/*     */   
/*     */   void visitMethodVarComment(String paramString1, String paramString2, @Nullable String paramString3, int paramInt1, int paramInt2, int paramInt3, int paramInt4, @Nullable String paramString4, @Nullable String[] paramArrayOfString1, @Nullable String[] paramArrayOfString2, @Nullable String[] paramArrayOfString3, @Nullable String[] paramArrayOfString4, String paramString5) throws IOException;
/*     */ 
/*     */   
/*     */   default boolean visitEnd() throws IOException {
/* 102 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   default MappingVisitor asRegularVisitor() {
/* 108 */     return (MappingVisitor)new FlatAsRegularMappingVisitor(this);
/*     */   }
/*     */   
/*     */   static FlatMappingVisitor fromRegularVisitor(MappingVisitor visitor) {
/* 112 */     return (FlatMappingVisitor)new RegularAsFlatMappingVisitor(visitor);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean visitField(String srcClsName, String srcName, @Nullable String srcDesc, String[] dstNames) throws IOException {
/* 118 */     Objects.requireNonNull(dstNames);
/* 119 */     return visitField(srcClsName, srcName, srcDesc, (String[])null, dstNames, (String[])null);
/*     */   }
/*     */   
/*     */   default boolean visitMethod(String srcClsName, String srcName, @Nullable String srcDesc, String[] dstNames) throws IOException {
/* 123 */     Objects.requireNonNull(dstNames);
/* 124 */     return visitMethod(srcClsName, srcName, srcDesc, (String[])null, dstNames, (String[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean visitMethodArg(String srcClsName, String srcMethodName, @Nullable String srcMethodDesc, int argPosition, int lvIndex, @Nullable String srcName, String[] dstNames) throws IOException {
/* 130 */     Objects.requireNonNull(dstNames);
/* 131 */     return visitMethodArg(srcClsName, srcMethodName, srcMethodDesc, argPosition, lvIndex, srcName, (String[])null, (String[])null, (String[])null, dstNames);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean visitMethodVar(String srcClsName, String srcMethodName, @Nullable String srcMethodDesc, int lvtRowIndex, int lvIndex, int startOpIdx, int endOpIdx, @Nullable String srcName, String[] dstNames) throws IOException {
/* 140 */     Objects.requireNonNull(dstNames);
/* 141 */     return visitMethodVar(srcClsName, srcMethodName, srcMethodDesc, lvtRowIndex, lvIndex, startOpIdx, endOpIdx, srcName, (String[])null, (String[])null, (String[])null, dstNames);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean visitClass(String srcName, String dstName) throws IOException {
/* 150 */     return visitClass(srcName, MappingUtil.toArray(dstName));
/*     */   }
/*     */   
/*     */   default void visitClassComment(String srcName, String comment) throws IOException {
/* 154 */     visitClassComment(srcName, (String)null, comment);
/*     */   }
/*     */   
/*     */   default void visitClassComment(String srcName, @Nullable String dstName, String comment) throws IOException {
/* 158 */     visitClassComment(srcName, MappingUtil.toArray(dstName), comment);
/*     */   }
/*     */ 
/*     */   
/*     */   default boolean visitField(String srcClsName, String srcName, @Nullable String srcDesc, String dstName) throws IOException {
/* 163 */     return visitField(srcClsName, srcName, srcDesc, (String)null, dstName, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean visitField(String srcClsName, String srcName, @Nullable String srcDesc, @Nullable String dstClsName, String dstName, @Nullable String dstDesc) throws IOException {
/* 169 */     return visitField(srcClsName, srcName, srcDesc, 
/* 170 */         MappingUtil.toArray(dstClsName), MappingUtil.toArray(dstName), MappingUtil.toArray(dstDesc));
/*     */   }
/*     */ 
/*     */   
/*     */   default void visitFieldComment(String srcClsName, String srcName, @Nullable String srcDesc, String comment) throws IOException {
/* 175 */     visitFieldComment(srcClsName, srcName, srcDesc, (String)null, (String)null, (String)null, comment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void visitFieldComment(String srcClsName, String srcName, @Nullable String srcDesc, @Nullable String dstClsName, @Nullable String dstName, @Nullable String dstDesc, String comment) throws IOException {
/* 183 */     visitFieldComment(srcClsName, srcName, srcDesc, 
/* 184 */         MappingUtil.toArray(dstClsName), MappingUtil.toArray(dstName), MappingUtil.toArray(dstDesc), comment);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean visitMethod(String srcClsName, String srcName, @Nullable String srcDesc, String dstName) throws IOException {
/* 190 */     return visitMethod(srcClsName, srcName, srcDesc, (String)null, dstName, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean visitMethod(String srcClsName, String srcName, @Nullable String srcDesc, @Nullable String dstClsName, String dstName, @Nullable String dstDesc) throws IOException {
/* 196 */     return visitMethod(srcClsName, srcName, srcDesc, 
/* 197 */         MappingUtil.toArray(dstClsName), MappingUtil.toArray(dstName), MappingUtil.toArray(dstDesc));
/*     */   }
/*     */ 
/*     */   
/*     */   default void visitMethodComment(String srcClsName, String srcName, @Nullable String srcDesc, String comment) throws IOException {
/* 202 */     visitMethodComment(srcClsName, srcName, srcDesc, (String)null, (String)null, (String)null, comment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void visitMethodComment(String srcClsName, String srcName, @Nullable String srcDesc, @Nullable String dstClsName, @Nullable String dstName, @Nullable String dstDesc, String comment) throws IOException {
/* 210 */     visitMethodComment(srcClsName, srcName, srcDesc, 
/* 211 */         MappingUtil.toArray(dstClsName), MappingUtil.toArray(dstName), MappingUtil.toArray(dstDesc), comment);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean visitMethodArg(String srcClsName, String srcMethodName, @Nullable String srcMethodDesc, int argPosition, int lvIndex, @Nullable String srcName, String dstName) throws IOException {
/* 217 */     return visitMethodArg(srcClsName, srcMethodName, srcMethodDesc, argPosition, lvIndex, srcName, (String)null, (String)null, (String)null, dstName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean visitMethodArg(String srcClsName, String srcMethodName, @Nullable String srcMethodDesc, int argPosition, int lvIndex, @Nullable String srcName, @Nullable String dstClsName, @Nullable String dstMethodName, @Nullable String dstMethodDesc, String dstName) throws IOException {
/* 226 */     return visitMethodArg(srcClsName, srcMethodName, srcMethodDesc, argPosition, lvIndex, srcName, 
/*     */         
/* 228 */         MappingUtil.toArray(dstClsName), MappingUtil.toArray(dstMethodName), MappingUtil.toArray(dstMethodDesc), MappingUtil.toArray(dstName));
/*     */   }
/*     */ 
/*     */   
/*     */   default void visitMethodArgComment(String srcClsName, String srcMethodName, @Nullable String srcMethodDesc, int argPosition, int lvIndex, @Nullable String srcName, String comment) throws IOException {
/* 233 */     visitMethodArgComment(srcClsName, srcMethodName, srcMethodDesc, argPosition, lvIndex, srcName, (String)null, (String)null, (String)null, (String)null, comment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void visitMethodArgComment(String srcClsName, String srcMethodName, @Nullable String srcMethodDesc, int argPosition, int lvIndex, @Nullable String srcName, @Nullable String dstClsName, @Nullable String dstMethodName, @Nullable String dstMethodDesc, @Nullable String dstName, String comment) throws IOException {
/* 244 */     visitMethodArgComment(srcClsName, srcMethodName, srcMethodDesc, argPosition, lvIndex, srcName, 
/* 245 */         MappingUtil.toArray(dstClsName), MappingUtil.toArray(dstMethodName), MappingUtil.toArray(dstMethodDesc), MappingUtil.toArray(dstName), comment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean visitMethodVar(String srcClsName, String srcMethodName, @Nullable String srcMethodDesc, int lvtRowIndex, int lvIndex, int startOpIdx, int endOpIdx, @Nullable String srcName, String dstName) throws IOException {
/* 252 */     return visitMethodVar(srcClsName, srcMethodName, srcMethodDesc, lvtRowIndex, lvIndex, startOpIdx, endOpIdx, srcName, (String)null, (String)null, (String)null, dstName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean visitMethodVar(String srcClsName, String srcMethodName, @Nullable String srcMethodDesc, int lvtRowIndex, int lvIndex, int startOpIdx, int endOpIdx, @Nullable String srcName, @Nullable String dstClsName, @Nullable String dstMethodName, @Nullable String dstMethodDesc, String dstName) throws IOException {
/* 261 */     return visitMethodVar(srcClsName, srcMethodName, srcMethodDesc, lvtRowIndex, lvIndex, startOpIdx, endOpIdx, srcName, 
/*     */         
/* 263 */         MappingUtil.toArray(dstClsName), MappingUtil.toArray(dstMethodName), MappingUtil.toArray(dstMethodDesc), MappingUtil.toArray(dstName));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   default void visitMethodVarComment(String srcClsName, String srcMethodName, @Nullable String srcMethodDesc, int lvtRowIndex, int lvIndex, int startOpIdx, int endOpIdx, @Nullable String srcName, String comment) throws IOException {
/* 269 */     visitMethodVarComment(srcClsName, srcMethodName, srcMethodDesc, lvtRowIndex, lvIndex, startOpIdx, endOpIdx, srcName, (String)null, (String)null, (String)null, (String)null, comment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void visitMethodVarComment(String srcClsName, String srcMethodName, @Nullable String srcMethodDesc, int lvtRowIndex, int lvIndex, int startOpIdx, int endOpIdx, @Nullable String srcName, @Nullable String dstClsName, @Nullable String dstMethodName, @Nullable String dstMethodDesc, @Nullable String dstName, String comment) throws IOException {
/* 279 */     visitMethodVarComment(srcClsName, srcMethodName, srcMethodDesc, lvtRowIndex, lvIndex, startOpIdx, endOpIdx, srcName, 
/*     */         
/* 281 */         MappingUtil.toArray(dstClsName), MappingUtil.toArray(dstMethodName), MappingUtil.toArray(dstMethodDesc), MappingUtil.toArray(dstName), comment);
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\fabricmc\mappingio\FlatMappingVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */