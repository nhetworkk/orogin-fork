/*     */ package net.fabricmc.mappingio;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface MappingVisitor
/*     */ {
/*     */   default Set<MappingFlag> getFlags() {
/*  53 */     return MappingFlag.NONE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void reset() {
/*  60 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean visitHeader() throws IOException {
/*  69 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void visitNamespaces(String paramString, List<String> paramList) throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   default void visitMetadata(String key, @Nullable String value) throws IOException {}
/*     */ 
/*     */   
/*     */   default boolean visitContent() throws IOException {
/*  82 */     return true;
/*     */   }
/*     */   
/*     */   boolean visitClass(String paramString) throws IOException;
/*     */   
/*     */   boolean visitField(String paramString1, @Nullable String paramString2) throws IOException;
/*     */   
/*     */   boolean visitMethod(String paramString1, @Nullable String paramString2) throws IOException;
/*     */   
/*     */   boolean visitMethodArg(int paramInt1, int paramInt2, @Nullable String paramString) throws IOException;
/*     */   
/*     */   boolean visitMethodVar(int paramInt1, int paramInt2, int paramInt3, int paramInt4, @Nullable String paramString) throws IOException;
/*     */   
/*     */   default boolean visitEnd() throws IOException {
/*  96 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void visitDstName(MappedElementKind paramMappedElementKind, int paramInt, String paramString) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void visitDstDesc(MappedElementKind targetKind, int namespace, String desc) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean visitElementContent(MappedElementKind targetKind) throws IOException {
/* 120 */     return true;
/*     */   }
/*     */   
/*     */   void visitComment(MappedElementKind paramMappedElementKind, String paramString) throws IOException;
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\fabricmc\mappingio\MappingVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */