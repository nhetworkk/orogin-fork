/*     */ package net.fabricmc.mappingio.format.enigma;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ import net.fabricmc.mappingio.MappedElementKind;
/*     */ import net.fabricmc.mappingio.MappingFlag;
/*     */ import net.fabricmc.mappingio.MappingVisitor;
/*     */ import net.fabricmc.mappingio.format.ColumnFileReader;
/*     */ import net.fabricmc.mappingio.tree.MappingTree;
/*     */ import net.fabricmc.mappingio.tree.MemoryMappingTree;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EnigmaFileReader
/*     */ {
/*     */   public static void read(Reader reader, MappingVisitor visitor) throws IOException {
/*  37 */     read(reader, "source", "target", visitor);
/*     */   }
/*     */   
/*     */   public static void read(Reader reader, String sourceNs, String targetNs, MappingVisitor visitor) throws IOException {
/*  41 */     read(new ColumnFileReader(reader, ' '), sourceNs, targetNs, visitor);
/*     */   }
/*     */   public static void read(ColumnFileReader reader, String sourceNs, String targetNs, MappingVisitor visitor) throws IOException {
/*     */     MemoryMappingTree memoryMappingTree;
/*  45 */     Set<MappingFlag> flags = visitor.getFlags();
/*  46 */     MappingVisitor parentVisitor = null;
/*     */     
/*  48 */     if (flags.contains(MappingFlag.NEEDS_ELEMENT_UNIQUENESS) || flags.contains(MappingFlag.NEEDS_MULTIPLE_PASSES)) {
/*  49 */       parentVisitor = visitor;
/*  50 */       memoryMappingTree = new MemoryMappingTree();
/*     */     } 
/*     */     
/*  53 */     if (memoryMappingTree.visitHeader()) {
/*  54 */       memoryMappingTree.visitNamespaces(sourceNs, Collections.singletonList(targetNs));
/*     */     }
/*     */     
/*  57 */     if (memoryMappingTree.visitContent()) {
/*  58 */       StringBuilder commentSb = new StringBuilder(200);
/*  59 */       MemoryMappingTree memoryMappingTree1 = memoryMappingTree;
/*     */       
/*     */       do {
/*  62 */         if (!reader.nextCol("CLASS"))
/*  63 */           continue;  readClass(reader, 0, null, null, commentSb, (MappingVisitor)memoryMappingTree1);
/*     */       }
/*  65 */       while (reader.nextLine(0));
/*     */     } 
/*     */     
/*  68 */     if (memoryMappingTree.visitEnd() && parentVisitor == null)
/*     */       return; 
/*  70 */     if (parentVisitor == null) {
/*  71 */       throw new IllegalStateException("repeated visitation requested without NEEDS_MULTIPLE_PASSES");
/*     */     }
/*     */     
/*  74 */     if (parentVisitor != null) {
/*  75 */       ((MappingTree)memoryMappingTree).accept(parentVisitor);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void readClass(ColumnFileReader reader, int indent, String outerSrcClass, String outerDstClass, StringBuilder commentSb, MappingVisitor visitor) throws IOException {
/*  80 */     String srcInnerName = reader.nextCol();
/*  81 */     if (srcInnerName == null || srcInnerName.isEmpty()) throw new IOException("missing class-name-a in line " + reader.getLineNumber());
/*     */     
/*  83 */     String srcName = srcInnerName;
/*     */     
/*  85 */     if (outerSrcClass != null && srcInnerName.indexOf('$') < 0) {
/*  86 */       srcName = String.format("%s$%s", new Object[] { outerSrcClass, srcInnerName });
/*     */     }
/*     */     
/*  89 */     String dstInnerName = reader.nextCol();
/*  90 */     String dstName = dstInnerName;
/*     */ 
/*     */     
/*  93 */     if (outerDstClass != null || (dstInnerName != null && outerSrcClass != null)) {
/*     */       
/*  95 */       if (dstInnerName == null) dstInnerName = srcInnerName; 
/*  96 */       if (outerDstClass == null) outerDstClass = outerSrcClass;
/*     */       
/*  98 */       dstName = String.format("%s$%s", new Object[] { outerDstClass, dstInnerName });
/*     */     } 
/*     */     
/* 101 */     readClassBody(reader, indent, srcName, dstName, commentSb, visitor);
/*     */   }
/*     */   
/*     */   private static void readClassBody(ColumnFileReader reader, int indent, String srcClass, String dstClass, StringBuilder commentSb, MappingVisitor visitor) throws IOException {
/* 105 */     boolean visited = false;
/* 106 */     int state = 0;
/*     */     
/* 108 */     while (reader.nextLine(indent + 1)) {
/*     */ 
/*     */       
/* 111 */       if (reader.nextCol("CLASS")) {
/* 112 */         if (!visited || commentSb.length() > 0) {
/* 113 */           visitClass(srcClass, dstClass, state, commentSb, visitor);
/* 114 */           visited = true;
/*     */         } 
/*     */         
/* 117 */         readClass(reader, indent + 1, srcClass, dstClass, commentSb, visitor);
/* 118 */         state = 0; continue;
/* 119 */       }  if (reader.nextCol("COMMENT")) {
/* 120 */         readComment(reader, commentSb); continue;
/* 121 */       }  boolean isMethod; if ((isMethod = reader.nextCol("METHOD")) || reader.nextCol("FIELD")) {
/* 122 */         String dstName; state = visitClass(srcClass, dstClass, state, commentSb, visitor);
/* 123 */         visited = true;
/* 124 */         if (state < 0)
/*     */           continue; 
/* 126 */         String srcName = reader.nextCol();
/* 127 */         if (srcName == null || srcName.isEmpty()) throw new IOException("missing field-name-a in line " + reader.getLineNumber());
/*     */         
/* 129 */         String dstNameOrSrcDesc = reader.nextCol();
/* 130 */         if (dstNameOrSrcDesc == null || dstNameOrSrcDesc.isEmpty()) throw new IOException("missing field-desc-b in line " + reader.getLineNumber());
/*     */         
/* 132 */         String srcDesc = reader.nextCol();
/*     */ 
/*     */         
/* 135 */         if (srcDesc == null) {
/* 136 */           dstName = null;
/* 137 */           srcDesc = dstNameOrSrcDesc;
/*     */         } else {
/* 139 */           dstName = dstNameOrSrcDesc;
/*     */         } 
/*     */         
/* 142 */         if (isMethod && visitor.visitMethod(srcName, srcDesc)) {
/* 143 */           if (dstName != null && !dstName.isEmpty()) visitor.visitDstName(MappedElementKind.METHOD, 0, dstName); 
/* 144 */           readMethod(reader, indent, commentSb, visitor); continue;
/* 145 */         }  if (!isMethod && visitor.visitField(srcName, srcDesc)) {
/* 146 */           if (dstName != null && !dstName.isEmpty()) visitor.visitDstName(MappedElementKind.FIELD, 0, dstName); 
/* 147 */           readElement(reader, MappedElementKind.FIELD, indent, commentSb, visitor);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 152 */     if (!visited || commentSb.length() > 0) {
/* 153 */       visitClass(srcClass, dstClass, state, commentSb, visitor);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int visitClass(String srcClass, String dstClass, int state, StringBuilder commentSb, MappingVisitor visitor) throws IOException {
/* 163 */     if (state == 0) {
/* 164 */       boolean visitContent = visitor.visitClass(srcClass);
/*     */       
/* 166 */       if (visitContent) {
/* 167 */         if (dstClass != null && !dstClass.isEmpty()) visitor.visitDstName(MappedElementKind.CLASS, 0, dstClass); 
/* 168 */         visitContent = visitor.visitElementContent(MappedElementKind.CLASS);
/*     */       } 
/*     */       
/* 171 */       state = visitContent ? 1 : -1;
/*     */       
/* 173 */       if (commentSb.length() > 0) {
/* 174 */         if (state > 0) visitor.visitComment(MappedElementKind.CLASS, commentSb.toString());
/*     */         
/* 176 */         commentSb.setLength(0);
/*     */       } 
/*     */     } 
/*     */     
/* 180 */     return state;
/*     */   }
/*     */   
/*     */   private static void readMethod(ColumnFileReader reader, int indent, StringBuilder commentSb, MappingVisitor visitor) throws IOException {
/* 184 */     if (!visitor.visitElementContent(MappedElementKind.METHOD))
/*     */       return; 
/* 186 */     while (reader.nextLine(indent + 2)) {
/* 187 */       if (reader.nextCol("COMMENT")) {
/* 188 */         readComment(reader, commentSb); continue;
/*     */       } 
/* 190 */       submitComment(MappedElementKind.METHOD, commentSb, visitor);
/*     */       
/* 192 */       if (reader.nextCol("ARG")) {
/* 193 */         int lvIndex = reader.nextIntCol();
/* 194 */         if (lvIndex < 0) throw new IOException("missing/invalid parameter lv-index in line " + reader.getLineNumber());
/*     */         
/* 196 */         if (visitor.visitMethodArg(-1, lvIndex, null)) {
/* 197 */           String dstName = reader.nextCol();
/* 198 */           if (dstName != null && !dstName.isEmpty()) visitor.visitDstName(MappedElementKind.METHOD_ARG, 0, dstName);
/*     */           
/* 200 */           readElement(reader, MappedElementKind.METHOD_ARG, indent, commentSb, visitor);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 206 */     submitComment(MappedElementKind.METHOD, commentSb, visitor);
/*     */   }
/*     */   
/*     */   private static void readElement(ColumnFileReader reader, MappedElementKind kind, int indent, StringBuilder commentSb, MappingVisitor visitor) throws IOException {
/* 210 */     if (!visitor.visitElementContent(kind))
/*     */       return; 
/* 212 */     while (reader.nextLine(indent + kind.level + 1)) {
/* 213 */       if (reader.nextCol("COMMENT")) {
/* 214 */         readComment(reader, commentSb);
/*     */       }
/*     */     } 
/*     */     
/* 218 */     submitComment(kind, commentSb, visitor);
/*     */   }
/*     */   
/*     */   private static void readComment(ColumnFileReader reader, StringBuilder commentSb) throws IOException {
/* 222 */     if (commentSb.length() > 0) commentSb.append('\n');
/*     */     
/* 224 */     String comment = reader.nextCols(true);
/*     */     
/* 226 */     if (comment != null) {
/* 227 */       commentSb.append(comment);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void submitComment(MappedElementKind kind, StringBuilder commentSb, MappingVisitor visitor) throws IOException {
/* 232 */     if (commentSb.length() == 0)
/*     */       return; 
/* 234 */     visitor.visitComment(kind, commentSb.toString());
/* 235 */     commentSb.setLength(0);
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\fabricmc\mappingio\format\enigma\EnigmaFileReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */