/*     */ package net.fabricmc.mappingio.format.srg;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ import net.fabricmc.mappingio.MappedElementKind;
/*     */ import net.fabricmc.mappingio.MappingFlag;
/*     */ import net.fabricmc.mappingio.MappingVisitor;
/*     */ import net.fabricmc.mappingio.format.ColumnFileReader;
/*     */ import net.fabricmc.mappingio.format.MappingFormat;
/*     */ import net.fabricmc.mappingio.tree.MappingTree;
/*     */ import net.fabricmc.mappingio.tree.MemoryMappingTree;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SrgFileReader
/*     */ {
/*     */   public static void read(Reader reader, MappingVisitor visitor) throws IOException {
/*  38 */     read(reader, "source", "target", visitor);
/*     */   }
/*     */   
/*     */   public static void read(Reader reader, String sourceNs, String targetNs, MappingVisitor visitor) throws IOException {
/*  42 */     read(new ColumnFileReader(reader, ' '), sourceNs, targetNs, visitor);
/*     */   }
/*     */   private static void read(ColumnFileReader reader, String sourceNs, String targetNs, MappingVisitor visitor) throws IOException {
/*     */     MemoryMappingTree memoryMappingTree;
/*  46 */     Set<MappingFlag> flags = visitor.getFlags();
/*  47 */     MappingVisitor parentVisitor = null;
/*  48 */     MappingFormat format = MappingFormat.SRG_FILE;
/*     */     
/*  50 */     if (flags.contains(MappingFlag.NEEDS_ELEMENT_UNIQUENESS)) {
/*  51 */       parentVisitor = visitor;
/*  52 */       memoryMappingTree = new MemoryMappingTree();
/*  53 */     } else if (flags.contains(MappingFlag.NEEDS_MULTIPLE_PASSES)) {
/*  54 */       reader.mark();
/*     */     } 
/*     */     
/*     */     while (true) {
/*  58 */       boolean visitHeader = memoryMappingTree.visitHeader();
/*     */       
/*  60 */       if (visitHeader) {
/*  61 */         memoryMappingTree.visitNamespaces(sourceNs, Collections.singletonList(targetNs));
/*     */       }
/*     */       
/*  64 */       if (memoryMappingTree.visitContent()) {
/*  65 */         String lastClass = null;
/*  66 */         boolean visitLastClass = false;
/*     */ 
/*     */ 
/*     */         
/*     */         do {
/*  71 */           if (reader.nextCol("CL:"))
/*  72 */           { String srcName = reader.nextCol();
/*  73 */             if (srcName == null || srcName.isEmpty()) throw new IOException("missing class-name-a in line " + reader.getLineNumber());
/*     */             
/*  75 */             if (!srcName.equals(lastClass)) {
/*  76 */               lastClass = srcName;
/*  77 */               visitLastClass = memoryMappingTree.visitClass(srcName);
/*     */               
/*  79 */               if (visitLastClass) {
/*  80 */                 String dstName = reader.nextCol();
/*  81 */                 if (dstName == null || dstName.isEmpty()) throw new IOException("missing class-name-b in line " + reader.getLineNumber());
/*     */                 
/*  83 */                 memoryMappingTree.visitDstName(MappedElementKind.CLASS, 0, dstName);
/*  84 */                 visitLastClass = memoryMappingTree.visitElementContent(MappedElementKind.CLASS);
/*     */               } 
/*     */             }  }
/*  87 */           else { boolean isMethod; if ((isMethod = reader.nextCol("MD:")) || reader.nextCol("FD:")) {
/*  88 */               String srcDesc, dstName, dstDesc, src = reader.nextCol();
/*  89 */               if (src == null) throw new IOException("missing class/name a in line " + reader.getLineNumber());
/*     */               
/*  91 */               int srcSepPos = src.lastIndexOf('/');
/*  92 */               if (srcSepPos <= 0 || srcSepPos == src.length() - 1) throw new IOException("invalid class/name a in line " + reader.getLineNumber());
/*     */               
/*  94 */               String[] cols = new String[3];
/*     */               
/*  96 */               for (int i = 0; i < 3; i++) {
/*  97 */                 cols[i] = reader.nextCol();
/*     */               }
/*     */               
/* 100 */               if (!isMethod && cols[1] != null && cols[2] != null) format = MappingFormat.XSRG_FILE;
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 105 */               if (isMethod || format == MappingFormat.XSRG_FILE) {
/* 106 */                 srcDesc = cols[0];
/* 107 */                 if (srcDesc == null || srcDesc.isEmpty()) throw new IOException("missing desc a in line " + reader.getLineNumber()); 
/* 108 */                 dstName = cols[1];
/* 109 */                 dstDesc = cols[2];
/* 110 */                 if (dstDesc == null || dstDesc.isEmpty()) throw new IOException("missing desc b in line " + reader.getLineNumber()); 
/*     */               } else {
/* 112 */                 srcDesc = null;
/* 113 */                 dstName = cols[0];
/* 114 */                 dstDesc = null;
/*     */               } 
/*     */               
/* 117 */               if (dstName == null) throw new IOException("missing class/name b in line " + reader.getLineNumber());
/*     */               
/* 119 */               int dstSepPos = dstName.lastIndexOf('/');
/* 120 */               if (dstSepPos <= 0 || dstSepPos == dstName.length() - 1) throw new IOException("invalid class/name b in line " + reader.getLineNumber());
/*     */               
/* 122 */               String srcOwner = src.substring(0, srcSepPos);
/*     */               
/* 124 */               if (!srcOwner.equals(lastClass)) {
/* 125 */                 lastClass = srcOwner;
/* 126 */                 visitLastClass = memoryMappingTree.visitClass(srcOwner);
/*     */                 
/* 128 */                 if (visitLastClass) {
/* 129 */                   memoryMappingTree.visitDstName(MappedElementKind.CLASS, 0, dstName.substring(0, dstSepPos));
/* 130 */                   visitLastClass = memoryMappingTree.visitElementContent(MappedElementKind.CLASS);
/*     */                 } 
/*     */               } 
/*     */               
/* 134 */               if (visitLastClass) {
/* 135 */                 String srcName = src.substring(srcSepPos + 1);
/*     */                 
/* 137 */                 if ((isMethod && memoryMappingTree.visitMethod(srcName, srcDesc)) || (!isMethod && memoryMappingTree
/* 138 */                   .visitField(srcName, srcDesc)))
/* 139 */                 { MappedElementKind kind = isMethod ? MappedElementKind.METHOD : MappedElementKind.FIELD;
/* 140 */                   memoryMappingTree.visitDstName(kind, 0, dstName.substring(dstSepPos + 1));
/* 141 */                   memoryMappingTree.visitDstDesc(kind, 0, dstDesc);
/* 142 */                   memoryMappingTree.visitElementContent(kind); } 
/*     */               } 
/*     */             }  }
/*     */         
/* 146 */         } while (reader.nextLine(0));
/*     */       } 
/*     */       
/* 149 */       if (memoryMappingTree.visitEnd())
/*     */         break; 
/* 151 */       reader.reset();
/*     */     } 
/*     */     
/* 154 */     if (parentVisitor != null)
/* 155 */       ((MappingTree)memoryMappingTree).accept(parentVisitor); 
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\fabricmc\mappingio\format\srg\SrgFileReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */