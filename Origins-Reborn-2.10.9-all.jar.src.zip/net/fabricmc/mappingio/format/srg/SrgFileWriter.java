/*     */ package net.fabricmc.mappingio.format.srg;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.EnumSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import net.fabricmc.mappingio.MappedElementKind;
/*     */ import net.fabricmc.mappingio.MappingFlag;
/*     */ import net.fabricmc.mappingio.MappingWriter;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SrgFileWriter
/*     */   implements MappingWriter
/*     */ {
/*     */   public SrgFileWriter(Writer writer, boolean xsrg) {
/*  33 */     this.writer = writer;
/*  34 */     this.xsrg = xsrg;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  39 */     this.writer.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<MappingFlag> getFlags() {
/*  44 */     return this.xsrg ? xsrgFlags : srgFlags;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitNamespaces(String srcNamespace, List<String> dstNamespaces) throws IOException {}
/*     */ 
/*     */   
/*     */   public boolean visitClass(String srcName) throws IOException {
/*  53 */     this.classSrcName = srcName;
/*  54 */     this.classDstName = null;
/*     */     
/*  56 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitField(String srcName, @Nullable String srcDesc) throws IOException {
/*  61 */     this.memberSrcName = srcName;
/*  62 */     this.memberSrcDesc = srcDesc;
/*  63 */     this.memberDstName = null;
/*  64 */     this.memberDstDesc = null;
/*     */     
/*  66 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitMethod(String srcName, @Nullable String srcDesc) throws IOException {
/*  71 */     this.memberSrcName = srcName;
/*  72 */     this.memberSrcDesc = srcDesc;
/*  73 */     this.memberDstName = null;
/*  74 */     this.memberDstDesc = null;
/*     */     
/*  76 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitMethodArg(int argPosition, int lvIndex, @Nullable String srcName) throws IOException {
/*  81 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitMethodVar(int lvtRowIndex, int lvIndex, int startOpIdx, int endOpIdx, @Nullable String srcName) throws IOException {
/*  86 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitDstName(MappedElementKind targetKind, int namespace, String name) {
/*  91 */     if (namespace != 0)
/*     */       return; 
/*  93 */     switch (targetKind) {
/*     */       case CLASS:
/*  95 */         this.classDstName = name;
/*     */         break;
/*     */       case FIELD:
/*     */       case METHOD:
/*  99 */         this.memberDstName = name;
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitDstDesc(MappedElementKind targetKind, int namespace, String desc) throws IOException {
/* 108 */     if (namespace != 0)
/*     */       return; 
/* 110 */     this.memberDstDesc = desc;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitElementContent(MappedElementKind targetKind) throws IOException {
/* 115 */     switch (targetKind) {
/*     */       case CLASS:
/* 117 */         if (this.classDstName == null) return true; 
/* 118 */         write("CL: ");
/*     */         break;
/*     */       case FIELD:
/* 121 */         if (this.memberDstName == null) return false; 
/* 122 */         write("FD: ");
/*     */         break;
/*     */       case METHOD:
/* 125 */         if (this.memberDstName == null || this.memberDstDesc == null) return false; 
/* 126 */         write("MD: ");
/*     */         break;
/*     */       default:
/* 129 */         throw new IllegalStateException("unexpected invocation for " + targetKind);
/*     */     } 
/*     */     
/* 132 */     write(this.classSrcName);
/*     */     
/* 134 */     if (targetKind != MappedElementKind.CLASS) {
/* 135 */       write("/");
/* 136 */       write(this.memberSrcName);
/*     */       
/* 138 */       if (targetKind == MappedElementKind.METHOD || this.xsrg) {
/* 139 */         write(" ");
/* 140 */         write(this.memberSrcDesc);
/*     */       } 
/*     */     } 
/*     */     
/* 144 */     write(" ");
/* 145 */     if (this.classDstName == null) this.classDstName = this.classSrcName; 
/* 146 */     write(this.classDstName);
/*     */     
/* 148 */     if (targetKind != MappedElementKind.CLASS) {
/* 149 */       write("/");
/* 150 */       write(this.memberDstName);
/*     */       
/* 152 */       if (targetKind == MappedElementKind.METHOD || this.xsrg) {
/* 153 */         write(" ");
/* 154 */         write(this.memberDstDesc);
/*     */       } 
/*     */     } 
/*     */     
/* 158 */     writeLn();
/*     */     
/* 160 */     return (targetKind == MappedElementKind.CLASS);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitComment(MappedElementKind targetKind, String comment) throws IOException {}
/*     */ 
/*     */   
/*     */   private void write(String str) throws IOException {
/* 169 */     this.writer.write(str);
/*     */   }
/*     */   
/*     */   private void writeLn() throws IOException {
/* 173 */     this.writer.write(10);
/*     */   }
/*     */   
/* 176 */   private static final Set<MappingFlag> srgFlags = EnumSet.of(MappingFlag.NEEDS_SRC_METHOD_DESC, MappingFlag.NEEDS_DST_METHOD_DESC);
/*     */ 
/*     */ 
/*     */   
/* 180 */   private static final Set<MappingFlag> xsrgFlags = EnumSet.copyOf(srgFlags); static {
/* 181 */     xsrgFlags.add(MappingFlag.NEEDS_SRC_FIELD_DESC);
/* 182 */     xsrgFlags.add(MappingFlag.NEEDS_DST_FIELD_DESC);
/*     */   }
/*     */   
/*     */   private final Writer writer;
/*     */   private final boolean xsrg;
/*     */   private String classSrcName;
/*     */   private String memberSrcName;
/*     */   private String memberSrcDesc;
/*     */   private String classDstName;
/*     */   private String memberDstName;
/*     */   private String memberDstDesc;
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\fabricmc\mappingio\format\srg\SrgFileWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */