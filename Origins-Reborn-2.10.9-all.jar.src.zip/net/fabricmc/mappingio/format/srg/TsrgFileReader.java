/*     */ package net.fabricmc.mappingio.format.srg;
/*     */ 
/*     */ import java.io.CharArrayReader;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import net.fabricmc.mappingio.MappedElementKind;
/*     */ import net.fabricmc.mappingio.MappingFlag;
/*     */ import net.fabricmc.mappingio.MappingVisitor;
/*     */ import net.fabricmc.mappingio.format.ColumnFileReader;
/*     */ import net.fabricmc.mappingio.format.MappingFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TsrgFileReader
/*     */ {
/*     */   public static List<String> getNamespaces(Reader reader) throws IOException {
/*  39 */     return getNamespaces(new ColumnFileReader(reader, ' '));
/*     */   }
/*     */   
/*     */   private static List<String> getNamespaces(ColumnFileReader reader) throws IOException {
/*  43 */     if (reader.nextCol("tsrg2")) {
/*  44 */       List<String> ret = new ArrayList<>();
/*     */       
/*     */       String ns;
/*  47 */       while ((ns = reader.nextCol()) != null) {
/*  48 */         ret.add(ns);
/*     */       }
/*     */       
/*  51 */       return ret;
/*     */     } 
/*  53 */     return Arrays.asList(new String[] { "source", "target" });
/*     */   }
/*     */ 
/*     */   
/*     */   public static void read(Reader reader, MappingVisitor visitor) throws IOException {
/*  58 */     read(reader, "source", "target", visitor);
/*     */   } public static void read(Reader r, String sourceNs, String targetNs, MappingVisitor visitor) throws IOException {
/*     */     ColumnFileReader reader;
/*     */     String srcNamespace;
/*     */     List<String> dstNamespaces;
/*  63 */     CharArrayReader parentReader = null;
/*     */     
/*  65 */     if (visitor.getFlags().contains(MappingFlag.NEEDS_MULTIPLE_PASSES)) {
/*  66 */       char[] buffer = new char[100000];
/*  67 */       int pos = 0;
/*     */       
/*     */       int len;
/*  70 */       while ((len = r.read(buffer, pos, buffer.length - pos)) >= 0) {
/*  71 */         pos += len;
/*  72 */         if (pos == buffer.length) buffer = Arrays.copyOf(buffer, buffer.length * 2);
/*     */       
/*     */       } 
/*  75 */       parentReader = new CharArrayReader(buffer, 0, pos);
/*  76 */       reader = new ColumnFileReader(parentReader, ' ');
/*     */     } else {
/*  78 */       reader = new ColumnFileReader(r, ' ');
/*     */     } 
/*     */     
/*  81 */     MappingFormat format = MappingFormat.TSRG_FILE;
/*  82 */     if (reader.nextCol("tsrg2")) format = MappingFormat.TSRG_2_FILE;
/*     */ 
/*     */ 
/*     */     
/*  86 */     if (format == MappingFormat.TSRG_2_FILE) {
/*  87 */       srcNamespace = reader.nextCol();
/*  88 */       dstNamespaces = new ArrayList<>();
/*     */       
/*     */       String dstNamespace;
/*  91 */       while ((dstNamespace = reader.nextCol()) != null) {
/*  92 */         dstNamespaces.add(dstNamespace);
/*     */       }
/*     */       
/*  95 */       reader.nextLine(0);
/*     */     } else {
/*  97 */       srcNamespace = sourceNs;
/*  98 */       dstNamespaces = Collections.singletonList(targetNs);
/*     */     } 
/*     */     
/* 101 */     int dstNsCount = dstNamespaces.size();
/* 102 */     List<String> nameTmp = (dstNamespaces.size() > 1) ? new ArrayList<>(dstNamespaces.size() - 1) : null;
/*     */     
/*     */     while (true) {
/* 105 */       boolean visitHeader = visitor.visitHeader();
/*     */       
/* 107 */       if (visitHeader) {
/* 108 */         visitor.visitNamespaces(srcNamespace, dstNamespaces);
/*     */       }
/*     */       
/* 111 */       if (visitor.visitContent()) {
/* 112 */         String lastClass = null;
/* 113 */         boolean visitLastClass = false;
/*     */         
/*     */         do {
/* 116 */           if (reader.hasExtraIndents())
/* 117 */             continue;  reader.mark();
/* 118 */           String line = reader.nextCols(false);
/* 119 */           if (line == null && reader.isAtEof())
/* 120 */             continue;  reader.reset();
/* 121 */           String[] parts = line.split("((?<= )|(?= ))");
/*     */           
/* 123 */           if (format != MappingFormat.TSRG_2_FILE && parts.length >= 4 && !parts[3].startsWith("#")) {
/* 124 */             format = MappingFormat.CSRG_FILE;
/* 125 */             String clsName = parts[0];
/* 126 */             if (clsName.isEmpty()) throw new IOException("missing class-name-a in line " + reader.getLineNumber());
/*     */             
/* 128 */             if (!clsName.equals(lastClass)) {
/* 129 */               lastClass = clsName;
/* 130 */               visitLastClass = (visitor.visitClass(clsName) && visitor.visitElementContent(MappedElementKind.CLASS));
/*     */             } 
/*     */             
/* 133 */             if (visitLastClass)
/*     */             {
/*     */               
/* 136 */               if (parts.length >= 6 && !parts[5].startsWith("#")) {
/* 137 */                 String dstName = (parts.length == 6) ? null : parts[6];
/*     */                 
/* 139 */                 if (dstName == null || dstName.isEmpty() || dstName.startsWith("#")) {
/* 140 */                   throw new IOException("missing method-name-b in line " + reader.getLineNumber());
/*     */                 }
/*     */                 
/* 143 */                 if (visitor.visitMethod(parts[2], parts[4])) {
/* 144 */                   visitor.visitDstName(MappedElementKind.METHOD, 0, dstName);
/*     */                 
/*     */                 }
/*     */               }
/* 148 */               else if (parts.length >= 4) {
/* 149 */                 String dstName = (parts.length == 4) ? null : parts[4];
/*     */                 
/* 151 */                 if (dstName == null || dstName.isEmpty() || dstName.startsWith("#")) {
/* 152 */                   throw new IOException("missing field-name-b in line " + reader.getLineNumber());
/*     */                 }
/*     */                 
/* 155 */                 if (visitor.visitField(parts[2], null)) {
/* 156 */                   visitor.visitDstName(MappedElementKind.FIELD, 0, dstName);
/*     */                 
/*     */                 }
/*     */               }
/*     */               else {
/*     */                 
/* 162 */                 throw new IllegalStateException("invalid CSRG line: " + line);
/*     */               }  } 
/*     */           } else {
/* 165 */             String srcName = reader.nextCol();
/* 166 */             if (srcName != null && !srcName.endsWith("/")) {
/* 167 */               if (srcName.isEmpty()) throw new IOException("missing class-name-a in line " + reader.getLineNumber());
/*     */               
/* 169 */               if (!srcName.equals(lastClass))
/* 170 */               { lastClass = srcName;
/* 171 */                 visitLastClass = visitor.visitClass(srcName);
/*     */                 
/* 173 */                 if (visitLastClass)
/* 174 */                   visitLastClass = readClass(reader, (format == MappingFormat.TSRG_2_FILE), dstNsCount, nameTmp, visitor);  } 
/*     */             } 
/*     */           } 
/* 177 */         } while (reader.nextLine(0));
/*     */       } 
/*     */       
/* 180 */       if (visitor.visitEnd())
/*     */         break; 
/* 182 */       if (parentReader == null) {
/* 183 */         throw new IllegalStateException("repeated visitation requested without NEEDS_MULTIPLE_PASSES");
/*     */       }
/* 185 */       parentReader.reset();
/* 186 */       reader = new ColumnFileReader(parentReader, ' ');
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean readClass(ColumnFileReader reader, boolean isTsrg2, int dstNsCount, List<String> nameTmp, MappingVisitor visitor) throws IOException {
/* 192 */     readDstNames(reader, MappedElementKind.CLASS, 0, dstNsCount, visitor);
/* 193 */     if (!visitor.visitElementContent(MappedElementKind.CLASS)) return false;
/*     */     
/* 195 */     while (reader.nextLine(1)) {
/* 196 */       int offset; String desc; if (reader.hasExtraIndents())
/*     */         continue; 
/* 198 */       String srcName = reader.nextCol();
/* 199 */       if (srcName == null || srcName.isEmpty()) throw new IOException("missing name-a in line " + reader.getLineNumber());
/*     */       
/* 201 */       String arg = reader.nextCol();
/* 202 */       if (arg == null) throw new IOException("missing desc/name-b in line " + reader.getLineNumber());
/*     */       
/* 204 */       if (arg.startsWith("(")) {
/* 205 */         if (visitor.visitMethod(srcName, arg))
/* 206 */           readMethod(reader, dstNsCount, visitor);  continue;
/*     */       } 
/* 208 */       if (!isTsrg2) {
/* 209 */         if (visitor.visitField(srcName, null)) {
/* 210 */           if (arg.isEmpty()) throw new IOException("missing field-name-b in line " + reader.getLineNumber()); 
/* 211 */           visitor.visitDstName(MappedElementKind.FIELD, 0, arg);
/* 212 */           readElement(reader, MappedElementKind.FIELD, 1, dstNsCount, visitor);
/*     */         }  continue;
/*     */       } 
/* 215 */       for (int i = 0; i < dstNsCount - 1; i++) {
/* 216 */         String name = reader.nextCol();
/* 217 */         if (name == null) throw new IOException("missing name columns in line " + reader.getLineNumber()); 
/* 218 */         if (name.isEmpty()) throw new IOException("missing destination name in line " + reader.getLineNumber()); 
/* 219 */         nameTmp.add(name);
/*     */       } 
/*     */       
/* 222 */       String lastName = reader.nextCol();
/*     */ 
/*     */ 
/*     */       
/* 226 */       if (lastName == null) {
/* 227 */         offset = 1;
/* 228 */         desc = null;
/*     */       } else {
/* 230 */         offset = 0;
/* 231 */         desc = arg;
/* 232 */         if (desc.isEmpty()) throw new IOException("empty field desc in line " + reader.getLineNumber());
/*     */       
/*     */       } 
/* 235 */       if (visitor.visitField(srcName, desc)) {
/*     */         
/* 237 */         if (lastName == null && !arg.isEmpty()) visitor.visitDstName(MappedElementKind.FIELD, 0, arg);
/*     */ 
/*     */         
/* 240 */         for (int j = 0; j < dstNsCount - 1; j++) {
/* 241 */           String name = nameTmp.get(j);
/* 242 */           if (!name.isEmpty()) visitor.visitDstName(MappedElementKind.FIELD, j + offset, name);
/*     */         
/*     */         } 
/*     */         
/* 246 */         if (lastName != null && !lastName.isEmpty()) visitor.visitDstName(MappedElementKind.FIELD, dstNsCount - 1, lastName);
/*     */         
/* 248 */         visitor.visitElementContent(MappedElementKind.FIELD);
/*     */       } 
/*     */       
/* 251 */       if (nameTmp != null) nameTmp.clear();
/*     */     
/*     */     } 
/*     */     
/* 255 */     return true;
/*     */   }
/*     */   
/*     */   private static void readMethod(ColumnFileReader reader, int dstNsCount, MappingVisitor visitor) throws IOException {
/* 259 */     readDstNames(reader, MappedElementKind.METHOD, 0, dstNsCount, visitor);
/* 260 */     if (!visitor.visitElementContent(MappedElementKind.METHOD))
/*     */       return; 
/* 262 */     while (reader.nextLine(2)) {
/* 263 */       if (reader.hasExtraIndents())
/*     */         continue; 
/* 265 */       if (reader.nextCol("static")) {
/*     */         continue;
/*     */       }
/* 268 */       int lvIndex = reader.nextIntCol();
/* 269 */       if (lvIndex < 0) throw new IOException("missing/invalid parameter lv-index in line " + reader.getLineNumber());
/*     */       
/* 271 */       String srcName = reader.nextCol();
/* 272 */       if (srcName == null) throw new IOException("missing var-name-a column in line " + reader.getLineNumber()); 
/* 273 */       if (srcName.isEmpty()) srcName = null;
/*     */       
/* 275 */       if (visitor.visitMethodArg(-1, lvIndex, srcName)) {
/* 276 */         readElement(reader, MappedElementKind.METHOD_ARG, 0, dstNsCount, visitor);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void readElement(ColumnFileReader reader, MappedElementKind kind, int dstNsOffset, int dstNsCount, MappingVisitor visitor) throws IOException {
/* 283 */     readDstNames(reader, kind, dstNsOffset, dstNsCount, visitor);
/* 284 */     visitor.visitElementContent(kind);
/*     */   }
/*     */   
/*     */   private static void readDstNames(ColumnFileReader reader, MappedElementKind subjectKind, int dstNsOffset, int dstNsCount, MappingVisitor visitor) throws IOException {
/* 288 */     for (int dstNs = dstNsOffset; dstNs < dstNsCount; dstNs++) {
/* 289 */       String name = reader.nextCol();
/*     */       
/* 291 */       if (name == null) throw new IOException("missing name columns in line " + reader.getLineNumber()); 
/* 292 */       if (name.isEmpty()) throw new IOException("missing destination name in line " + reader.getLineNumber());
/*     */       
/* 294 */       visitor.visitDstName(subjectKind, dstNs, name);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\fabricmc\mappingio\format\srg\TsrgFileReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */