/*     */ package net.fabricmc.mappingio.format.proguard;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.CharArrayReader;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import net.fabricmc.mappingio.MappedElementKind;
/*     */ import net.fabricmc.mappingio.MappingFlag;
/*     */ import net.fabricmc.mappingio.MappingVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ProGuardFileReader
/*     */ {
/*     */   public static void read(Reader reader, MappingVisitor visitor) throws IOException {
/*  36 */     read(reader, "source", "target", visitor);
/*     */   }
/*     */   
/*     */   public static void read(Reader reader, String sourceNs, String targetNs, MappingVisitor visitor) throws IOException {
/*  40 */     BufferedReader br = (reader instanceof BufferedReader) ? (BufferedReader)reader : new BufferedReader(reader);
/*     */     
/*  42 */     read(br, sourceNs, targetNs, visitor);
/*     */   }
/*     */   
/*     */   private static void read(BufferedReader reader, String sourceNs, String targetNs, MappingVisitor visitor) throws IOException {
/*  46 */     CharArrayReader parentReader = null;
/*     */     
/*  48 */     if (visitor.getFlags().contains(MappingFlag.NEEDS_MULTIPLE_PASSES)) {
/*  49 */       char[] buffer = new char[100000];
/*  50 */       int pos = 0;
/*     */       
/*     */       int len;
/*  53 */       while ((len = reader.read(buffer, pos, buffer.length - pos)) >= 0) {
/*  54 */         pos += len;
/*     */         
/*  56 */         if (pos == buffer.length) buffer = Arrays.copyOf(buffer, buffer.length * 2);
/*     */       
/*     */       } 
/*  59 */       parentReader = new CharArrayReader(buffer, 0, pos);
/*  60 */       reader = new BufferedReader(parentReader);
/*     */     } 
/*     */     
/*  63 */     StringBuilder tmp = null;
/*     */     
/*     */     while (true) {
/*  66 */       boolean visitHeader = visitor.visitHeader();
/*     */       
/*  68 */       if (visitHeader) {
/*  69 */         visitor.visitNamespaces(sourceNs, Collections.singletonList(targetNs));
/*     */       }
/*     */       
/*  72 */       if (visitor.visitContent()) {
/*  73 */         if (tmp == null) tmp = new StringBuilder();
/*     */ 
/*     */         
/*  76 */         boolean visitClass = false;
/*     */         String line;
/*  78 */         while ((line = reader.readLine()) != null) {
/*  79 */           line = line.trim();
/*  80 */           if (line.isEmpty() || line.startsWith("#"))
/*     */             continue; 
/*  82 */           if (line.endsWith(":")) {
/*  83 */             int pos = line.indexOf(" -> ");
/*  84 */             if (pos < 0) throw new IOException("invalid proguard line (invalid separator): " + line); 
/*  85 */             if (pos == 0) throw new IOException("invalid proguard line (empty src class): " + line); 
/*  86 */             if (pos + 4 + 1 >= line.length()) throw new IOException("invalid proguard line (empty dst class): " + line);
/*     */             
/*  88 */             String name = line.substring(0, pos).replace('.', '/');
/*  89 */             visitClass = visitor.visitClass(name);
/*     */             
/*  91 */             if (visitClass) {
/*  92 */               String mappedName = line.substring(pos + 4, line.length() - 1).replace('.', '/');
/*  93 */               visitor.visitDstName(MappedElementKind.CLASS, 0, mappedName);
/*  94 */               visitClass = visitor.visitElementContent(MappedElementKind.CLASS);
/*     */             }  continue;
/*  96 */           }  if (visitClass) {
/*  97 */             String retType, parts[] = line.split(" ");
/*     */             
/*  99 */             if (parts.length != 4) throw new IOException("invalid proguard line (extra columns): " + line); 
/* 100 */             if (parts[0].isEmpty()) throw new IOException("invalid proguard line (empty type): " + line); 
/* 101 */             if (parts[1].isEmpty()) throw new IOException("invalid proguard line (empty src member): " + line); 
/* 102 */             if (!parts[2].equals("->")) throw new IOException("invalid proguard line (invalid separator): " + line); 
/* 103 */             if (parts[3].isEmpty()) throw new IOException("invalid proguard line (empty dst member): " + line);
/*     */             
/* 105 */             if (parts[1].indexOf('(') < 0) {
/* 106 */               String name = parts[1];
/* 107 */               String desc = pgTypeToAsm(parts[0], tmp);
/*     */               
/* 109 */               if (visitor.visitField(name, desc)) {
/* 110 */                 String mappedName = parts[3];
/* 111 */                 visitor.visitDstName(MappedElementKind.FIELD, 0, mappedName);
/* 112 */                 visitor.visitElementContent(MappedElementKind.FIELD);
/*     */               } 
/*     */               continue;
/*     */             } 
/* 116 */             String part0 = parts[0];
/* 117 */             int pos = part0.indexOf(':');
/*     */ 
/*     */ 
/*     */             
/* 121 */             if (pos == -1) {
/* 122 */               retType = part0;
/*     */             } else {
/* 124 */               int pos2 = part0.indexOf(':', pos + 1);
/* 125 */               assert pos2 != -1;
/*     */               
/* 127 */               retType = part0.substring(pos2 + 1);
/*     */             } 
/*     */ 
/*     */             
/* 131 */             String part1 = parts[1];
/* 132 */             pos = part1.indexOf('(');
/* 133 */             int pos3 = part1.indexOf(')', pos + 1);
/* 134 */             assert pos3 != -1;
/*     */             
/* 136 */             if (part1.lastIndexOf('.', pos - 1) < 0 && part1.length() == pos3 + 1) {
/* 137 */               String name = part1.substring(0, pos);
/* 138 */               String argDesc = part1.substring(pos, pos3 + 1);
/* 139 */               String desc = pgDescToAsm(argDesc, retType, tmp);
/*     */               
/* 141 */               if (visitor.visitMethod(name, desc)) {
/* 142 */                 String mappedName = parts[3];
/* 143 */                 visitor.visitDstName(MappedElementKind.METHOD, 0, mappedName);
/* 144 */                 visitor.visitElementContent(MappedElementKind.METHOD);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 152 */       if (visitor.visitEnd())
/*     */         break; 
/* 154 */       if (parentReader == null) {
/* 155 */         throw new IllegalStateException("repeated visitation requested without NEEDS_MULTIPLE_PASSES");
/*     */       }
/* 157 */       parentReader.reset();
/* 158 */       reader = new BufferedReader(parentReader);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static String pgDescToAsm(String pgArgDesc, String pgRetType, StringBuilder tmp) {
/* 164 */     tmp.setLength(0);
/* 165 */     tmp.append('(');
/*     */     
/* 167 */     if (pgArgDesc.length() > 2) {
/* 168 */       int startPos = 1;
/* 169 */       boolean abort = false;
/*     */       
/*     */       do {
/* 172 */         int endPos = pgArgDesc.indexOf(',', startPos);
/*     */         
/* 174 */         if (endPos < 0) {
/* 175 */           endPos = pgArgDesc.length() - 1;
/* 176 */           abort = true;
/*     */         } 
/*     */         
/* 179 */         appendPgTypeToAsm(pgArgDesc.substring(startPos, endPos), tmp);
/* 180 */         startPos = endPos + 1;
/* 181 */       } while (!abort);
/*     */     } 
/*     */     
/* 184 */     tmp.append(')');
/* 185 */     if (pgRetType != null) appendPgTypeToAsm(pgRetType, tmp);
/*     */     
/* 187 */     return tmp.toString();
/*     */   }
/*     */   
/*     */   private static String pgTypeToAsm(String type, StringBuilder tmp) {
/* 191 */     tmp.setLength(0);
/* 192 */     appendPgTypeToAsm(type, tmp);
/*     */     
/* 194 */     return tmp.toString();
/*     */   }
/*     */   
/*     */   private static void appendPgTypeToAsm(String type, StringBuilder out) {
/* 198 */     assert !type.isEmpty();
/*     */     
/* 200 */     int arrayStart = type.indexOf('[');
/*     */     
/* 202 */     if (arrayStart != -1) {
/* 203 */       assert type.substring(arrayStart).matches("(\\[\\])+");
/*     */       
/* 205 */       int arrayDimensions = (type.length() - arrayStart) / 2;
/*     */       
/* 207 */       for (int i = 0; i < arrayDimensions; i++) {
/* 208 */         out.append('[');
/*     */       }
/*     */       
/* 211 */       type = type.substring(0, arrayStart);
/*     */     } 
/*     */     
/* 214 */     switch (type) { case "void":
/* 215 */         out.append('V'); return;
/* 216 */       case "boolean": out.append('Z'); return;
/* 217 */       case "char": out.append('C'); return;
/* 218 */       case "byte": out.append('B'); return;
/* 219 */       case "short": out.append('S'); return;
/* 220 */       case "int": out.append('I'); return;
/* 221 */       case "float": out.append('F'); return;
/* 222 */       case "long": out.append('J'); return;
/* 223 */       case "double": out.append('D'); return; }
/*     */     
/* 225 */     out.append('L');
/* 226 */     out.append(type.replace('.', '/'));
/* 227 */     out.append(';');
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\fabricmc\mappingio\format\proguard\ProGuardFileReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */