/*     */ package net.fabricmc.mappingio.format.proguard;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import net.fabricmc.mappingio.MappedElementKind;
/*     */ import net.fabricmc.mappingio.MappingWriter;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.objectweb.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ProGuardFileWriter
/*     */   implements MappingWriter
/*     */ {
/*     */   private final Writer writer;
/*  40 */   private int dstNamespace = -1;
/*     */ 
/*     */ 
/*     */   
/*     */   private final String dstNamespaceString;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProGuardFileWriter(Writer writer) {
/*  50 */     this(writer, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProGuardFileWriter(Writer writer, int dstNamespace) {
/*  60 */     this.writer = Objects.<Writer>requireNonNull(writer, "writer cannot be null");
/*  61 */     this.dstNamespace = dstNamespace;
/*  62 */     this.dstNamespaceString = null;
/*     */     
/*  64 */     if (dstNamespace < 0) {
/*  65 */       throw new IllegalArgumentException("Namespace must be non-negative, found " + dstNamespace);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProGuardFileWriter(Writer writer, String dstNamespace) {
/*  76 */     this.writer = Objects.<Writer>requireNonNull(writer, "writer cannot be null");
/*  77 */     this.dstNamespaceString = Objects.<String>requireNonNull(dstNamespace, "namespace cannot be null");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  87 */     this.writer.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitNamespaces(String srcNamespace, List<String> dstNamespaces) throws IOException {
/*  92 */     if (this.dstNamespaceString != null) {
/*  93 */       this.dstNamespace = dstNamespaces.indexOf(this.dstNamespaceString);
/*     */       
/*  95 */       if (this.dstNamespace == -1) {
/*  96 */         throw new RuntimeException("Invalid destination namespace '" + this.dstNamespaceString + "' not in [" + String.join(", ", dstNamespaces) + ']');
/*     */       }
/*     */     } 
/*     */     
/* 100 */     if (this.dstNamespace >= dstNamespaces.size()) {
/* 101 */       throw new IndexOutOfBoundsException("Namespace " + this.dstNamespace + " doesn't exist in [" + String.join(", ", dstNamespaces) + ']');
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitClass(String srcName) throws IOException {
/* 107 */     this.writer.write(toJavaClassName(srcName));
/* 108 */     writeArrow();
/* 109 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitField(String srcName, @Nullable String srcDesc) throws IOException {
/* 114 */     writeIndent();
/* 115 */     this.writer.write(toJavaType(srcDesc));
/* 116 */     this.writer.write(32);
/* 117 */     this.writer.write(srcName);
/* 118 */     writeArrow();
/* 119 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitMethod(String srcName, @Nullable String srcDesc) throws IOException {
/* 124 */     Type type = Type.getMethodType(srcDesc);
/* 125 */     writeIndent();
/* 126 */     this.writer.write(toJavaType(type.getReturnType().getDescriptor()));
/* 127 */     this.writer.write(32);
/* 128 */     this.writer.write(srcName);
/* 129 */     this.writer.write(40);
/* 130 */     Type[] args = type.getArgumentTypes();
/*     */     
/* 132 */     for (int i = 0; i < args.length; i++) {
/* 133 */       if (i > 0) {
/* 134 */         this.writer.write(44);
/*     */       }
/*     */       
/* 137 */       this.writer.write(toJavaType(args[i].getDescriptor()));
/*     */     } 
/*     */     
/* 140 */     this.writer.write(41);
/* 141 */     writeArrow();
/* 142 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean visitMethodArg(int argPosition, int lvIndex, @Nullable String srcName) throws IOException {
/* 148 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean visitMethodVar(int lvtRowIndex, int lvIndex, int startOpIdx, int endOpIdx, @Nullable String srcName) throws IOException {
/* 154 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitDstName(MappedElementKind targetKind, int namespace, String name) throws IOException {
/* 159 */     if (this.dstNamespace != namespace) {
/*     */       return;
/*     */     }
/*     */     
/* 163 */     if (targetKind == MappedElementKind.CLASS) {
/* 164 */       this.writer.write(toJavaClassName(name));
/* 165 */       this.writer.write(58);
/*     */     } else {
/* 167 */       this.writer.write(name);
/*     */     } 
/*     */     
/* 170 */     this.writer.write(10);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitComment(MappedElementKind targetKind, String comment) throws IOException {}
/*     */ 
/*     */   
/*     */   private void writeArrow() throws IOException {
/* 179 */     this.writer.write(" -> ");
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeIndent() throws IOException {
/* 184 */     this.writer.write("    ");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String toJavaClassName(String name) {
/* 192 */     return name.replace('/', '.');
/*     */   }
/*     */   
/*     */   private static String toJavaType(String descriptor) {
/* 196 */     StringBuilder result = new StringBuilder();
/* 197 */     int arrayLevel = 0;
/*     */     
/* 199 */     for (int i = 0; i < descriptor.length(); i++) {
/* 200 */       switch (descriptor.charAt(i)) { case '[':
/* 201 */           arrayLevel++; break;
/* 202 */         case 'B': result.append("byte"); break;
/* 203 */         case 'S': result.append("short"); break;
/* 204 */         case 'I': result.append("int"); break;
/* 205 */         case 'J': result.append("long"); break;
/* 206 */         case 'F': result.append("float"); break;
/* 207 */         case 'D': result.append("double"); break;
/* 208 */         case 'C': result.append("char"); break;
/* 209 */         case 'Z': result.append("boolean"); break;
/* 210 */         case 'V': result.append("void"); break;
/*     */         case 'L':
/* 212 */           while (i + 1 < descriptor.length()) {
/* 213 */             char c = descriptor.charAt(++i);
/*     */             
/* 215 */             if (c == '/') {
/* 216 */               result.append('.'); continue;
/* 217 */             }  if (c == ';') {
/*     */               break;
/*     */             }
/* 220 */             result.append(c);
/*     */           } 
/*     */           break;
/*     */         
/*     */         default:
/* 225 */           throw new IllegalArgumentException("Unknown character in descriptor: " + descriptor.charAt(i)); }
/*     */ 
/*     */ 
/*     */     
/*     */     } 
/* 230 */     while (arrayLevel > 0) {
/* 231 */       result.append("[]");
/* 232 */       arrayLevel--;
/*     */     } 
/*     */     
/* 235 */     return result.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\fabricmc\mappingio\format\proguard\ProGuardFileWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */