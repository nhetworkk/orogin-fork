/*     */ package net.fabricmc.mappingio.format.tiny;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import net.fabricmc.mappingio.MappedElementKind;
/*     */ import net.fabricmc.mappingio.MappingFlag;
/*     */ import net.fabricmc.mappingio.MappingVisitor;
/*     */ import net.fabricmc.mappingio.format.ColumnFileReader;
/*     */ import net.fabricmc.mappingio.tree.MappingTree;
/*     */ import net.fabricmc.mappingio.tree.MemoryMappingTree;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Tiny1FileReader
/*     */ {
/*     */   static final String nextIntermediaryClassProperty = "next-intermediary-class";
/*     */   static final String nextIntermediaryFieldProperty = "next-intermediary-field";
/*     */   static final String nextIntermediaryMethodProperty = "next-intermediary-method";
/*     */   
/*     */   public static List<String> getNamespaces(Reader reader) throws IOException {
/*  37 */     return getNamespaces(new ColumnFileReader(reader, '\t'));
/*     */   }
/*     */   
/*     */   private static List<String> getNamespaces(ColumnFileReader reader) throws IOException {
/*  41 */     if (!reader.nextCol("v1")) {
/*  42 */       throw new IOException("invalid/unsupported tiny file: no tiny 1 header");
/*     */     }
/*     */     
/*  45 */     List<String> ret = new ArrayList<>();
/*     */     
/*     */     String ns;
/*  48 */     while ((ns = reader.nextCol()) != null) {
/*  49 */       ret.add(ns);
/*     */     }
/*     */     
/*  52 */     return ret;
/*     */   }
/*     */   
/*     */   public static void read(Reader reader, MappingVisitor visitor) throws IOException {
/*  56 */     read(new ColumnFileReader(reader, '\t'), visitor);
/*     */   }
/*     */   private static void read(ColumnFileReader reader, MappingVisitor visitor) throws IOException {
/*     */     MemoryMappingTree memoryMappingTree;
/*  60 */     if (!reader.nextCol("v1")) {
/*  61 */       throw new IOException("invalid/unsupported tiny file: no tiny 1 header");
/*     */     }
/*     */     
/*  64 */     String srcNamespace = reader.nextCol();
/*  65 */     List<String> dstNamespaces = new ArrayList<>();
/*     */     
/*     */     String dstNamespace;
/*  68 */     while ((dstNamespace = reader.nextCol()) != null) {
/*  69 */       dstNamespaces.add(dstNamespace);
/*     */     }
/*     */     
/*  72 */     int dstNsCount = dstNamespaces.size();
/*  73 */     Set<MappingFlag> flags = visitor.getFlags();
/*  74 */     MappingVisitor parentVisitor = null;
/*     */     
/*  76 */     if (flags.contains(MappingFlag.NEEDS_ELEMENT_UNIQUENESS) || flags.contains(MappingFlag.NEEDS_HEADER_METADATA)) {
/*  77 */       parentVisitor = visitor;
/*  78 */       memoryMappingTree = new MemoryMappingTree();
/*  79 */     } else if (flags.contains(MappingFlag.NEEDS_MULTIPLE_PASSES)) {
/*  80 */       reader.mark();
/*     */     } 
/*     */     
/*     */     while (true) {
/*  84 */       boolean visitHeader = memoryMappingTree.visitHeader();
/*     */       
/*  86 */       if (visitHeader) {
/*  87 */         memoryMappingTree.visitNamespaces(srcNamespace, dstNamespaces);
/*     */       }
/*     */       
/*  90 */       if (memoryMappingTree.visitContent()) {
/*  91 */         String lastClass = null;
/*  92 */         boolean lastClassDstNamed = false;
/*  93 */         boolean visitLastClass = false;
/*     */         
/*  95 */         while (reader.nextLine(0)) {
/*     */ 
/*     */           
/*  98 */           if (reader.nextCol("CLASS")) {
/*  99 */             String srcName = reader.nextCol();
/* 100 */             if (srcName == null || srcName.isEmpty()) throw new IOException("missing class-name-a in line " + reader.getLineNumber());
/*     */             
/* 102 */             if (!lastClassDstNamed || !srcName.equals(lastClass)) {
/* 103 */               lastClass = srcName;
/* 104 */               lastClassDstNamed = true;
/* 105 */               visitLastClass = memoryMappingTree.visitClass(srcName);
/*     */               
/* 107 */               if (visitLastClass) {
/* 108 */                 readDstNames(reader, MappedElementKind.CLASS, dstNsCount, (MappingVisitor)memoryMappingTree);
/* 109 */                 visitLastClass = memoryMappingTree.visitElementContent(MappedElementKind.CLASS);
/*     */               } 
/*     */             }  continue;
/* 112 */           }  boolean isMethod; if ((isMethod = reader.nextCol("METHOD")) || reader.nextCol("FIELD")) {
/* 113 */             String srcOwner = reader.nextCol();
/* 114 */             if (srcOwner == null || srcOwner.isEmpty()) throw new IOException("missing class-name-a in line " + reader.getLineNumber());
/*     */             
/* 116 */             if (!srcOwner.equals(lastClass)) {
/* 117 */               lastClass = srcOwner;
/* 118 */               lastClassDstNamed = false;
/* 119 */               visitLastClass = (memoryMappingTree.visitClass(srcOwner) && memoryMappingTree.visitElementContent(MappedElementKind.CLASS));
/*     */             } 
/*     */             
/* 122 */             if (visitLastClass) {
/* 123 */               String srcDesc = reader.nextCol();
/* 124 */               if (srcDesc == null || srcDesc.isEmpty()) throw new IOException("missing desc-a in line " + reader.getLineNumber()); 
/* 125 */               String srcName = reader.nextCol();
/* 126 */               if (srcName == null || srcName.isEmpty()) throw new IOException("missing name-a in line " + reader.getLineNumber());
/*     */               
/* 128 */               if ((isMethod && memoryMappingTree.visitMethod(srcName, srcDesc)) || (!isMethod && memoryMappingTree
/* 129 */                 .visitField(srcName, srcDesc))) {
/* 130 */                 MappedElementKind kind = isMethod ? MappedElementKind.METHOD : MappedElementKind.FIELD;
/* 131 */                 readDstNames(reader, kind, dstNsCount, (MappingVisitor)memoryMappingTree);
/* 132 */                 memoryMappingTree.visitElementContent(kind);
/*     */               } 
/*     */             }  continue;
/*     */           } 
/* 136 */           String line = reader.nextCol();
/* 137 */           String prefix = "# INTERMEDIARY-COUNTER ";
/*     */           
/*     */           String[] parts;
/* 140 */           if (line.startsWith("# INTERMEDIARY-COUNTER ") && (
/* 141 */             parts = line.substring("# INTERMEDIARY-COUNTER ".length()).split(" ")).length == 2) {
/* 142 */             String property = null;
/*     */             
/* 144 */             switch (parts[0]) {
/*     */               case "class":
/* 146 */                 property = "next-intermediary-class";
/*     */                 break;
/*     */               case "field":
/* 149 */                 property = "next-intermediary-field";
/*     */                 break;
/*     */               case "method":
/* 152 */                 property = "next-intermediary-method";
/*     */                 break;
/*     */             } 
/*     */             
/* 156 */             if (property != null) {
/* 157 */               memoryMappingTree.visitMetadata(property, parts[1]);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 164 */       if (memoryMappingTree.visitEnd())
/*     */         break; 
/* 166 */       reader.reset();
/*     */     } 
/*     */     
/* 169 */     if (parentVisitor != null) {
/* 170 */       ((MappingTree)memoryMappingTree).accept(parentVisitor);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void readDstNames(ColumnFileReader reader, MappedElementKind subjectKind, int dstNsCount, MappingVisitor visitor) throws IOException {
/* 175 */     for (int dstNs = 0; dstNs < dstNsCount; dstNs++) {
/* 176 */       String name = reader.nextCol();
/* 177 */       if (name == null) throw new IOException("missing name columns in line " + reader.getLineNumber());
/*     */       
/* 179 */       if (!name.isEmpty()) visitor.visitDstName(subjectKind, dstNs, name); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\fabricmc\mappingio\format\tiny\Tiny1FileReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */