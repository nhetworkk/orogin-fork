/*     */ package net.fabricmc.mappingio.format.tiny;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.fabricmc.mappingio.MappedElementKind;
/*     */ import net.fabricmc.mappingio.MappingFlag;
/*     */ import net.fabricmc.mappingio.MappingVisitor;
/*     */ import net.fabricmc.mappingio.format.ColumnFileReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Tiny2FileReader
/*     */ {
/*     */   public static List<String> getNamespaces(Reader reader) throws IOException {
/*  34 */     return getNamespaces(new ColumnFileReader(reader, '\t'));
/*     */   }
/*     */   
/*     */   private static List<String> getNamespaces(ColumnFileReader reader) throws IOException {
/*  38 */     if (!reader.nextCol("tiny") || reader
/*  39 */       .nextIntCol() != 2 || reader
/*  40 */       .nextIntCol() < 0) {
/*  41 */       throw new IOException("invalid/unsupported tiny file: no tiny 2 header");
/*     */     }
/*     */     
/*  44 */     List<String> ret = new ArrayList<>();
/*     */     
/*     */     String ns;
/*  47 */     while ((ns = reader.nextCol()) != null) {
/*  48 */       ret.add(ns);
/*     */     }
/*     */     
/*  51 */     return ret;
/*     */   }
/*     */   
/*     */   public static void read(Reader reader, MappingVisitor visitor) throws IOException {
/*  55 */     read(new ColumnFileReader(reader, '\t'), visitor);
/*     */   }
/*     */   
/*     */   private static void read(ColumnFileReader reader, MappingVisitor visitor) throws IOException {
/*  59 */     if (!reader.nextCol("tiny") || reader
/*  60 */       .nextIntCol() != 2 || reader
/*  61 */       .nextIntCol() < 0) {
/*  62 */       throw new IOException("invalid/unsupported tiny file: no tiny 2 header");
/*     */     }
/*     */     
/*  65 */     String srcNamespace = reader.nextCol();
/*  66 */     List<String> dstNamespaces = new ArrayList<>();
/*     */     
/*     */     String dstNamespace;
/*  69 */     while ((dstNamespace = reader.nextCol()) != null) {
/*  70 */       dstNamespaces.add(dstNamespace);
/*     */     }
/*     */     
/*  73 */     int dstNsCount = dstNamespaces.size();
/*     */     
/*  75 */     if (visitor.getFlags().contains(MappingFlag.NEEDS_MULTIPLE_PASSES)) {
/*  76 */       reader.mark();
/*     */     }
/*     */     
/*  79 */     boolean firstIteration = true;
/*  80 */     boolean escapeNames = false;
/*     */     
/*     */     while (true) {
/*  83 */       boolean visitHeader = visitor.visitHeader();
/*     */       
/*  85 */       if (visitHeader) {
/*  86 */         visitor.visitNamespaces(srcNamespace, dstNamespaces);
/*     */       }
/*     */       
/*  89 */       if (visitHeader || firstIteration) {
/*  90 */         while (reader.nextLine(1)) {
/*  91 */           if (!visitHeader) {
/*  92 */             if (!escapeNames && reader.nextCol("escaped-names"))
/*  93 */               escapeNames = true; 
/*     */             continue;
/*     */           } 
/*  96 */           String key = reader.nextCol();
/*  97 */           if (key == null) throw new IOException("missing property key in line " + reader.getLineNumber()); 
/*  98 */           String value = reader.nextEscapedCol();
/*     */           
/* 100 */           if (key.equals("escaped-names")) {
/* 101 */             escapeNames = true;
/*     */           }
/*     */           
/* 104 */           visitor.visitMetadata(key, value);
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 109 */       if (visitor.visitContent()) {
/* 110 */         while (reader.nextLine(0)) {
/* 111 */           if (reader.nextCol("c")) {
/* 112 */             String srcName = reader.nextCol(escapeNames);
/* 113 */             if (srcName == null || srcName.isEmpty()) throw new IOException("missing class-name-a in line " + reader.getLineNumber());
/*     */             
/* 115 */             if (visitor.visitClass(srcName)) {
/* 116 */               readClass(reader, dstNsCount, escapeNames, visitor);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       }
/*     */       
/* 122 */       if (visitor.visitEnd())
/*     */         break; 
/* 124 */       reader.reset();
/* 125 */       firstIteration = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void readClass(ColumnFileReader reader, int dstNsCount, boolean escapeNames, MappingVisitor visitor) throws IOException {
/* 130 */     readDstNames(reader, MappedElementKind.CLASS, dstNsCount, escapeNames, visitor);
/* 131 */     if (!visitor.visitElementContent(MappedElementKind.CLASS))
/*     */       return; 
/* 133 */     while (reader.nextLine(1)) {
/* 134 */       if (reader.nextCol("f")) {
/* 135 */         String srcDesc = reader.nextCol(escapeNames);
/* 136 */         if (srcDesc == null || srcDesc.isEmpty()) throw new IOException("missing field-desc-a in line " + reader.getLineNumber()); 
/* 137 */         String srcName = reader.nextCol(escapeNames);
/* 138 */         if (srcName == null || srcName.isEmpty()) throw new IOException("missing field-name-a in line " + reader.getLineNumber());
/*     */         
/* 140 */         if (visitor.visitField(srcName, srcDesc))
/* 141 */           readElement(reader, MappedElementKind.FIELD, dstNsCount, escapeNames, visitor);  continue;
/*     */       } 
/* 143 */       if (reader.nextCol("m")) {
/* 144 */         String srcDesc = reader.nextCol(escapeNames);
/* 145 */         if (srcDesc == null || srcDesc.isEmpty()) throw new IOException("missing method-desc-a in line " + reader.getLineNumber()); 
/* 146 */         String srcName = reader.nextCol(escapeNames);
/* 147 */         if (srcName == null || srcName.isEmpty()) throw new IOException("missing method-name-a in line " + reader.getLineNumber());
/*     */         
/* 149 */         if (visitor.visitMethod(srcName, srcDesc))
/* 150 */           readMethod(reader, dstNsCount, escapeNames, visitor);  continue;
/*     */       } 
/* 152 */       if (reader.nextCol("c")) {
/* 153 */         readComment(reader, MappedElementKind.CLASS, visitor);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void readMethod(ColumnFileReader reader, int dstNsCount, boolean escapeNames, MappingVisitor visitor) throws IOException {
/* 159 */     readDstNames(reader, MappedElementKind.METHOD, dstNsCount, escapeNames, visitor);
/* 160 */     if (!visitor.visitElementContent(MappedElementKind.METHOD))
/*     */       return; 
/* 162 */     while (reader.nextLine(2)) {
/* 163 */       if (reader.nextCol("p")) {
/* 164 */         int lvIndex = reader.nextIntCol();
/* 165 */         if (lvIndex < 0) throw new IOException("missing/invalid parameter lv-index in line " + reader.getLineNumber()); 
/* 166 */         String srcName = reader.nextCol(escapeNames);
/* 167 */         if (srcName == null) throw new IOException("missing var-name-a column in line " + reader.getLineNumber()); 
/* 168 */         if (srcName.isEmpty()) srcName = null;
/*     */         
/* 170 */         if (visitor.visitMethodArg(-1, lvIndex, srcName))
/* 171 */           readElement(reader, MappedElementKind.METHOD_ARG, dstNsCount, escapeNames, visitor);  continue;
/*     */       } 
/* 173 */       if (reader.nextCol("v")) {
/* 174 */         int lvIndex = reader.nextIntCol();
/* 175 */         if (lvIndex < 0) throw new IOException("missing/invalid variable lv-index in line " + reader.getLineNumber()); 
/* 176 */         int startOpIdx = reader.nextIntCol();
/* 177 */         if (startOpIdx < 0) throw new IOException("missing/invalid variable lv-start-offset in line " + reader.getLineNumber()); 
/* 178 */         int lvtRowIndex = reader.nextIntCol();
/* 179 */         String srcName = reader.nextCol(escapeNames);
/* 180 */         if (srcName == null) throw new IOException("missing var-name-a column in line " + reader.getLineNumber()); 
/* 181 */         if (srcName.isEmpty()) srcName = null;
/*     */         
/* 183 */         if (visitor.visitMethodVar(lvtRowIndex, lvIndex, startOpIdx, -1, srcName))
/* 184 */           readElement(reader, MappedElementKind.METHOD_VAR, dstNsCount, escapeNames, visitor);  continue;
/*     */       } 
/* 186 */       if (reader.nextCol("c")) {
/* 187 */         readComment(reader, MappedElementKind.METHOD, visitor);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void readElement(ColumnFileReader reader, MappedElementKind kind, int dstNsCount, boolean escapeNames, MappingVisitor visitor) throws IOException {
/* 193 */     readDstNames(reader, kind, dstNsCount, escapeNames, visitor);
/* 194 */     if (!visitor.visitElementContent(kind))
/*     */       return; 
/* 196 */     while (reader.nextLine(kind.level + 1)) {
/* 197 */       if (reader.nextCol("c")) {
/* 198 */         readComment(reader, kind, visitor);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void readComment(ColumnFileReader reader, MappedElementKind subjectKind, MappingVisitor visitor) throws IOException {
/* 204 */     String comment = reader.nextEscapedCol();
/* 205 */     if (comment == null) throw new IOException("missing comment in line " + reader.getLineNumber());
/*     */     
/* 207 */     visitor.visitComment(subjectKind, comment);
/*     */   }
/*     */   
/*     */   private static void readDstNames(ColumnFileReader reader, MappedElementKind subjectKind, int dstNsCount, boolean escapeNames, MappingVisitor visitor) throws IOException {
/* 211 */     for (int dstNs = 0; dstNs < dstNsCount; dstNs++) {
/* 212 */       String name = reader.nextCol(escapeNames);
/* 213 */       if (name == null) throw new IOException("missing name columns in line " + reader.getLineNumber());
/*     */       
/* 215 */       if (!name.isEmpty()) visitor.visitDstName(subjectKind, dstNs, name); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\fabricmc\mappingio\format\tiny\Tiny2FileReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */