/*     */ package net.fabricmc.mappingio.format.tiny;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.Arrays;
/*     */ import java.util.EnumSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import net.fabricmc.mappingio.MappedElementKind;
/*     */ import net.fabricmc.mappingio.MappingFlag;
/*     */ import net.fabricmc.mappingio.MappingWriter;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Tiny2FileWriter
/*     */   implements MappingWriter
/*     */ {
/*     */   public Tiny2FileWriter(Writer writer, boolean escapeNames) {
/*  34 */     this.writer = writer;
/*  35 */     this.escapeNames = escapeNames;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  40 */     this.writer.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<MappingFlag> getFlags() {
/*  45 */     return flags;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitNamespaces(String srcNamespace, List<String> dstNamespaces) throws IOException {
/*  50 */     this.dstNames = new String[dstNamespaces.size()];
/*     */     
/*  52 */     write("tiny\t2\t0\t");
/*  53 */     write(srcNamespace);
/*     */     
/*  55 */     for (String dstNamespace : dstNamespaces) {
/*  56 */       writeTab();
/*  57 */       write(dstNamespace);
/*     */     } 
/*     */     
/*  60 */     writeLn();
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitMetadata(String key, @Nullable String value) throws IOException {
/*  65 */     if (key.equals("escaped-names")) {
/*  66 */       this.escapeNames = true;
/*  67 */       this.wroteEscapedNamesProperty = true;
/*     */     } 
/*     */     
/*  70 */     writeTab();
/*  71 */     write(key);
/*     */     
/*  73 */     if (value != null) {
/*  74 */       writeTab();
/*  75 */       write(value);
/*     */     } 
/*     */     
/*  78 */     writeLn();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitContent() throws IOException {
/*  83 */     if (this.escapeNames && !this.wroteEscapedNamesProperty) {
/*  84 */       write("\t");
/*  85 */       write("escaped-names");
/*  86 */       writeLn();
/*     */     } 
/*     */     
/*  89 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitClass(String srcName) throws IOException {
/*  94 */     write("c\t");
/*  95 */     writeName(srcName);
/*     */     
/*  97 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitField(String srcName, @Nullable String srcDesc) throws IOException {
/* 102 */     write("\tf\t");
/* 103 */     writeName(srcDesc);
/* 104 */     writeTab();
/* 105 */     writeName(srcName);
/*     */     
/* 107 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitMethod(String srcName, @Nullable String srcDesc) throws IOException {
/* 112 */     write("\tm\t");
/* 113 */     writeName(srcDesc);
/* 114 */     writeTab();
/* 115 */     writeName(srcName);
/*     */     
/* 117 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitMethodArg(int argPosition, int lvIndex, @Nullable String srcName) throws IOException {
/* 122 */     write("\t\tp\t");
/* 123 */     write(lvIndex);
/* 124 */     writeTab();
/* 125 */     if (srcName != null) writeName(srcName);
/*     */     
/* 127 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitMethodVar(int lvtRowIndex, int lvIndex, int startOpIdx, int endOpIdx, @Nullable String srcName) throws IOException {
/* 132 */     write("\t\tv\t");
/* 133 */     write(lvIndex);
/* 134 */     writeTab();
/* 135 */     write(startOpIdx);
/* 136 */     writeTab();
/* 137 */     write(Math.max(lvtRowIndex, -1));
/* 138 */     writeTab();
/* 139 */     if (srcName != null) writeName(srcName);
/*     */     
/* 141 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitDstName(MappedElementKind targetKind, int namespace, String name) {
/* 146 */     this.dstNames[namespace] = name;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitElementContent(MappedElementKind targetKind) throws IOException {
/* 151 */     for (String dstName : this.dstNames) {
/* 152 */       writeTab();
/* 153 */       if (dstName != null) writeName(dstName);
/*     */     
/*     */     } 
/* 156 */     writeLn();
/*     */     
/* 158 */     Arrays.fill((Object[])this.dstNames, (Object)null);
/*     */     
/* 160 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitComment(MappedElementKind targetKind, String comment) throws IOException {
/* 165 */     writeTabs(targetKind.level);
/* 166 */     write("\tc\t");
/* 167 */     writeEscaped(comment);
/* 168 */     writeLn();
/*     */   }
/*     */   
/*     */   private void write(String str) throws IOException {
/* 172 */     this.writer.write(str);
/*     */   }
/*     */   
/*     */   private void write(int i) throws IOException {
/* 176 */     write(Integer.toString(i));
/*     */   }
/*     */   
/*     */   private void writeEscaped(String str) throws IOException {
/* 180 */     Tiny2Util.writeEscaped(str, this.writer);
/*     */   }
/*     */   
/*     */   private void writeName(String str) throws IOException {
/* 184 */     if (this.escapeNames) {
/* 185 */       writeEscaped(str);
/*     */     } else {
/* 187 */       write(str);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeLn() throws IOException {
/* 192 */     this.writer.write(10);
/*     */   }
/*     */   
/*     */   private void writeTab() throws IOException {
/* 196 */     this.writer.write(9);
/*     */   }
/*     */   
/*     */   private void writeTabs(int count) throws IOException {
/* 200 */     for (int i = 0; i < count; i++) {
/* 201 */       this.writer.write(9);
/*     */     }
/*     */   }
/*     */   
/* 205 */   private static final Set<MappingFlag> flags = EnumSet.of(MappingFlag.NEEDS_HEADER_METADATA, MappingFlag.NEEDS_METADATA_UNIQUENESS, MappingFlag.NEEDS_ELEMENT_UNIQUENESS, MappingFlag.NEEDS_SRC_FIELD_DESC, MappingFlag.NEEDS_SRC_METHOD_DESC);
/*     */   private final Writer writer;
/*     */   private boolean escapeNames;
/*     */   private boolean wroteEscapedNamesProperty;
/*     */   private String[] dstNames;
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\fabricmc\mappingio\format\tiny\Tiny2FileWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */