/*     */ package net.fabricmc.mappingio.format.tiny;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.Arrays;
/*     */ import java.util.EnumSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import net.fabricmc.mappingio.MappedElementKind;
/*     */ import net.fabricmc.mappingio.MappingFlag;
/*     */ import net.fabricmc.mappingio.MappingWriter;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Tiny1FileWriter
/*     */   implements MappingWriter
/*     */ {
/*     */   public Tiny1FileWriter(Writer writer) {
/*  34 */     this.writer = writer;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  39 */     this.writer.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<MappingFlag> getFlags() {
/*  44 */     return flags;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitNamespaces(String srcNamespace, List<String> dstNamespaces) throws IOException {
/*  49 */     this.dstNames = new String[dstNamespaces.size()];
/*     */     
/*  51 */     write("v1\t");
/*  52 */     write(srcNamespace);
/*     */     
/*  54 */     for (String dstNamespace : dstNamespaces) {
/*  55 */       writeTab();
/*  56 */       write(dstNamespace);
/*     */     } 
/*     */     
/*  59 */     writeLn();
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitMetadata(String key, @Nullable String value) throws IOException {
/*  64 */     switch (key) {
/*     */       case "next-intermediary-class":
/*     */       case "next-intermediary-field":
/*     */       case "next-intermediary-method":
/*  68 */         write("# INTERMEDIARY-COUNTER ");
/*     */         
/*  70 */         switch (key) {
/*     */           case "next-intermediary-class":
/*  72 */             write("class");
/*     */             break;
/*     */           case "next-intermediary-field":
/*  75 */             write("field");
/*     */             break;
/*     */           case "next-intermediary-method":
/*  78 */             write("method");
/*     */             break;
/*     */           default:
/*  81 */             throw new IllegalStateException();
/*     */         } 
/*     */         
/*  84 */         write(" ");
/*  85 */         write(value);
/*  86 */         writeLn();
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean visitClass(String srcName) throws IOException {
/*  92 */     this.classSrcName = srcName;
/*     */     
/*  94 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitField(String srcName, @Nullable String srcDesc) throws IOException {
/*  99 */     this.memberSrcName = srcName;
/* 100 */     this.memberSrcDesc = srcDesc;
/*     */     
/* 102 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitMethod(String srcName, @Nullable String srcDesc) throws IOException {
/* 107 */     this.memberSrcName = srcName;
/* 108 */     this.memberSrcDesc = srcDesc;
/*     */     
/* 110 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitMethodArg(int argPosition, int lvIndex, @Nullable String srcName) throws IOException {
/* 115 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitMethodVar(int lvtRowIndex, int lvIndex, int startOpIdx, int endOpIdx, @Nullable String srcName) throws IOException {
/* 120 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitDstName(MappedElementKind targetKind, int namespace, String name) {
/* 125 */     this.dstNames[namespace] = name;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean visitElementContent(MappedElementKind targetKind) throws IOException {
/* 131 */     boolean found = false;
/*     */     
/* 133 */     for (String dstName : this.dstNames) {
/* 134 */       if (dstName != null) {
/* 135 */         found = true;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 140 */     if (!found) return true;
/*     */     
/* 142 */     switch (targetKind) {
/*     */       case CLASS:
/* 144 */         write("CLASS");
/*     */         break;
/*     */       case FIELD:
/* 147 */         write("FIELD");
/*     */         break;
/*     */       case METHOD:
/* 150 */         write("METHOD");
/*     */         break;
/*     */       default:
/* 153 */         throw new IllegalStateException("unexpected invocation for " + targetKind);
/*     */     } 
/*     */     
/* 156 */     writeTab();
/* 157 */     write(this.classSrcName);
/*     */     
/* 159 */     if (targetKind != MappedElementKind.CLASS) {
/* 160 */       writeTab();
/* 161 */       write(this.memberSrcDesc);
/* 162 */       writeTab();
/* 163 */       write(this.memberSrcName);
/*     */     } 
/*     */     
/* 166 */     for (String dstName : this.dstNames) {
/* 167 */       writeTab();
/* 168 */       if (dstName != null) write(dstName);
/*     */     
/*     */     } 
/* 171 */     writeLn();
/*     */     
/* 173 */     Arrays.fill((Object[])this.dstNames, (Object)null);
/*     */     
/* 175 */     return (targetKind == MappedElementKind.CLASS);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitComment(MappedElementKind targetKind, String comment) throws IOException {}
/*     */ 
/*     */   
/*     */   private void write(String str) throws IOException {
/* 184 */     this.writer.write(str);
/*     */   }
/*     */   
/*     */   private void writeLn() throws IOException {
/* 188 */     this.writer.write(10);
/*     */   }
/*     */   
/*     */   private void writeTab() throws IOException {
/* 192 */     this.writer.write(9);
/*     */   }
/*     */   
/* 195 */   private static final Set<MappingFlag> flags = EnumSet.of(MappingFlag.NEEDS_SRC_FIELD_DESC, MappingFlag.NEEDS_SRC_METHOD_DESC);
/*     */   private final Writer writer;
/*     */   private String classSrcName;
/*     */   private String memberSrcName;
/*     */   private String memberSrcDesc;
/*     */   private String[] dstNames;
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\fabricmc\mappingio\format\tiny\Tiny1FileWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */