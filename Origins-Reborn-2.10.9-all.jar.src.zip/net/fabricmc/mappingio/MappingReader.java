/*     */ package net.fabricmc.mappingio;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import net.fabricmc.mappingio.format.MappingFormat;
/*     */ import net.fabricmc.mappingio.format.enigma.EnigmaDirReader;
/*     */ import net.fabricmc.mappingio.format.enigma.EnigmaFileReader;
/*     */ import net.fabricmc.mappingio.format.proguard.ProGuardFileReader;
/*     */ import net.fabricmc.mappingio.format.srg.SrgFileReader;
/*     */ import net.fabricmc.mappingio.format.srg.TsrgFileReader;
/*     */ import net.fabricmc.mappingio.format.tiny.Tiny1FileReader;
/*     */ import net.fabricmc.mappingio.format.tiny.Tiny2FileReader;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MappingReader
/*     */ {
/*     */   private static final int DETECT_HEADER_LEN = 4096;
/*     */   
/*     */   @Nullable
/*     */   public static MappingFormat detectFormat(Path file) throws IOException {
/*  46 */     if (Files.isDirectory(file, new java.nio.file.LinkOption[0])) {
/*  47 */       return MappingFormat.ENIGMA_DIR;
/*     */     }
/*  49 */     Reader reader = new InputStreamReader(Files.newInputStream(file, new java.nio.file.OpenOption[0]), StandardCharsets.UTF_8); 
/*  50 */     try { MappingFormat mappingFormat = detectFormat(reader);
/*  51 */       reader.close(); return mappingFormat; }
/*     */     catch (Throwable throwable) { try {
/*     */         reader.close();
/*     */       } catch (Throwable throwable1) {
/*     */         throwable.addSuppressed(throwable1);
/*     */       }  throw throwable; }
/*  57 */      } @Nullable public static MappingFormat detectFormat(Reader reader) throws IOException { char[] buffer = new char[4096];
/*  58 */     int pos = 0;
/*     */ 
/*     */ 
/*     */     
/*  62 */     BufferedReader br = (reader instanceof BufferedReader) ? (BufferedReader)reader : new BufferedReader(reader);
/*     */     
/*  64 */     br.mark(4096);
/*     */     int len;
/*  66 */     while (pos < buffer.length && (
/*  67 */       len = br.read(buffer, pos, buffer.length - pos)) >= 0) {
/*  68 */       pos += len;
/*     */     }
/*     */     
/*  71 */     br.reset();
/*  72 */     if (pos < 3) return null;
/*     */     
/*  74 */     switch (String.valueOf(buffer, 0, 3)) {
/*     */       case "v1\t":
/*  76 */         return MappingFormat.TINY_FILE;
/*     */       case "tin":
/*  78 */         return MappingFormat.TINY_2_FILE;
/*     */       case "tsr":
/*  80 */         return MappingFormat.TSRG_2_FILE;
/*     */       case "CLA":
/*  82 */         return MappingFormat.ENIGMA_FILE;
/*     */       case "PK:":
/*     */       case "CL:":
/*     */       case "MD:":
/*     */       case "FD:":
/*  87 */         return detectSrgOrXsrg(br);
/*     */     } 
/*     */     
/*  90 */     String headerStr = String.valueOf(buffer, 0, pos);
/*     */     
/*  92 */     if (headerStr.contains(" -> "))
/*  93 */       return MappingFormat.PROGUARD_FILE; 
/*  94 */     if (headerStr.contains("\n\t")) {
/*  95 */       return MappingFormat.TSRG_FILE;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 100 */     return null; }
/*     */ 
/*     */ 
/*     */   
/*     */   private static MappingFormat detectSrgOrXsrg(BufferedReader reader) throws IOException {
/*     */     String line;
/* 106 */     while ((line = reader.readLine()) != null) {
/* 107 */       if (line.startsWith("FD:")) {
/* 108 */         String[] parts = line.split(" ");
/*     */         
/* 110 */         if (parts.length >= 5) {
/* 111 */           if (isEmptyOrStartsWithHash(parts[3]) || isEmptyOrStartsWithHash(parts[4])) {
/*     */             continue;
/*     */           }
/*     */           
/* 115 */           return MappingFormat.XSRG_FILE;
/*     */         } 
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     
/* 122 */     return MappingFormat.SRG_FILE;
/*     */   }
/*     */   
/*     */   private static boolean isEmptyOrStartsWithHash(String string) {
/* 126 */     if (string.isEmpty() || string.startsWith("#")) return true; 
/* 127 */     return false;
/*     */   }
/*     */   
/*     */   public static List<String> getNamespaces(Path file) throws IOException {
/* 131 */     return getNamespaces(file, (MappingFormat)null);
/*     */   }
/*     */   
/*     */   public static List<String> getNamespaces(Path file, MappingFormat format) throws IOException {
/* 135 */     if (format == null) {
/* 136 */       format = detectFormat(file);
/* 137 */       if (format == null) throw new IOException("invalid/unsupported mapping format");
/*     */     
/*     */     } 
/* 140 */     if (format.hasNamespaces) {
/* 141 */       Reader reader = Files.newBufferedReader(file); 
/* 142 */       try { List<String> list = getNamespaces(reader, format);
/* 143 */         if (reader != null) reader.close();  return list; } catch (Throwable throwable) { if (reader != null)
/*     */           try { reader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; } 
/* 145 */     }  return Arrays.asList(new String[] { "source", "target" });
/*     */   }
/*     */ 
/*     */   
/*     */   public static List<String> getNamespaces(Reader reader) throws IOException {
/* 150 */     return getNamespaces(reader, (MappingFormat)null);
/*     */   }
/*     */   
/*     */   public static List<String> getNamespaces(Reader reader, MappingFormat format) throws IOException {
/* 154 */     if (format == null) {
/* 155 */       if (!reader.markSupported()) reader = new BufferedReader(reader); 
/* 156 */       reader.mark(4096);
/* 157 */       format = detectFormat(reader);
/* 158 */       reader.reset();
/* 159 */       if (format == null) throw new IOException("invalid/unsupported mapping format");
/*     */     
/*     */     } 
/* 162 */     if (format.hasNamespaces) {
/* 163 */       checkReaderCompatible(format);
/*     */       
/* 165 */       switch (format) {
/*     */         case TINY_FILE:
/* 167 */           return Tiny1FileReader.getNamespaces(reader);
/*     */         case TINY_2_FILE:
/* 169 */           return Tiny2FileReader.getNamespaces(reader);
/*     */         case TSRG_2_FILE:
/* 171 */           return TsrgFileReader.getNamespaces(reader);
/*     */       } 
/* 173 */       throw new IllegalStateException();
/*     */     } 
/*     */     
/* 176 */     return Arrays.asList(new String[] { "source", "target" });
/*     */   }
/*     */ 
/*     */   
/*     */   public static void read(Path file, MappingVisitor visitor) throws IOException {
/* 181 */     read(file, (MappingFormat)null, visitor);
/*     */   }
/*     */   
/*     */   public static void read(Path file, MappingFormat format, MappingVisitor visitor) throws IOException {
/* 185 */     if (format == null) {
/* 186 */       format = detectFormat(file);
/* 187 */       if (format == null) throw new IOException("invalid/unsupported mapping format");
/*     */     
/*     */     } 
/* 190 */     if (format.hasSingleFile())
/* 191 */     { Reader reader = Files.newBufferedReader(file); 
/* 192 */       try { read(reader, format, visitor);
/* 193 */         if (reader != null) reader.close();  } catch (Throwable throwable) { if (reader != null)
/*     */           try { reader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  }
/* 195 */     else { switch (format) {
/*     */         case ENIGMA_DIR:
/* 197 */           EnigmaDirReader.read(file, visitor);
/*     */           return;
/*     */       } 
/* 200 */       throw new IllegalStateException(); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public static void read(Reader reader, MappingVisitor visitor) throws IOException {
/* 206 */     read(reader, (MappingFormat)null, visitor);
/*     */   }
/*     */   
/*     */   public static void read(Reader reader, MappingFormat format, MappingVisitor visitor) throws IOException {
/* 210 */     if (format == null) {
/* 211 */       if (!reader.markSupported()) reader = new BufferedReader(reader); 
/* 212 */       reader.mark(4096);
/* 213 */       format = detectFormat(reader);
/* 214 */       reader.reset();
/* 215 */       if (format == null) throw new IOException("invalid/unsupported mapping format");
/*     */     
/*     */     } 
/* 218 */     checkReaderCompatible(format);
/*     */     
/* 220 */     switch (format) {
/*     */       case TINY_FILE:
/* 222 */         Tiny1FileReader.read(reader, visitor);
/*     */         return;
/*     */       case TINY_2_FILE:
/* 225 */         Tiny2FileReader.read(reader, visitor);
/*     */         return;
/*     */       case ENIGMA_FILE:
/* 228 */         EnigmaFileReader.read(reader, visitor);
/*     */         return;
/*     */       case SRG_FILE:
/*     */       case XSRG_FILE:
/* 232 */         SrgFileReader.read(reader, visitor);
/*     */         return;
/*     */       case TSRG_2_FILE:
/*     */       case CSRG_FILE:
/*     */       case TSRG_FILE:
/* 237 */         TsrgFileReader.read(reader, visitor);
/*     */         return;
/*     */       case PROGUARD_FILE:
/* 240 */         ProGuardFileReader.read(reader, visitor);
/*     */         return;
/*     */     } 
/* 243 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   
/*     */   private static void checkReaderCompatible(MappingFormat format) throws IOException {
/* 248 */     if (!format.hasSingleFile())
/* 249 */       throw new IOException("can't read mapping format " + format.name + " using a Reader, use the Path based API"); 
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\fabricmc\mappingio\MappingReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */