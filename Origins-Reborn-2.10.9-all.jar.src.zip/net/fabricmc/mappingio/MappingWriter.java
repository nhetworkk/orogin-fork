/*    */ package net.fabricmc.mappingio;
/*    */ 
/*    */ import java.io.Closeable;
/*    */ import java.io.IOException;
/*    */ import java.io.Writer;
/*    */ import java.nio.file.Files;
/*    */ import java.nio.file.Path;
/*    */ import net.fabricmc.mappingio.format.MappingFormat;
/*    */ import net.fabricmc.mappingio.format.enigma.EnigmaDirWriter;
/*    */ import net.fabricmc.mappingio.format.enigma.EnigmaFileWriter;
/*    */ import net.fabricmc.mappingio.format.proguard.ProGuardFileWriter;
/*    */ import net.fabricmc.mappingio.format.srg.SrgFileWriter;
/*    */ import net.fabricmc.mappingio.format.tiny.Tiny1FileWriter;
/*    */ import net.fabricmc.mappingio.format.tiny.Tiny2FileWriter;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface MappingWriter
/*    */   extends Closeable, MappingVisitor
/*    */ {
/*    */   @Nullable
/*    */   static MappingWriter create(Path file, MappingFormat format) throws IOException {
/* 38 */     if (format.hasSingleFile()) {
/* 39 */       return create(Files.newBufferedWriter(file, new java.nio.file.OpenOption[0]), format);
/*    */     }
/* 41 */     switch (format) { case ENIGMA_DIR:
/* 42 */         return (MappingWriter)new EnigmaDirWriter(file, true); }
/* 43 */      return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   static MappingWriter create(Writer writer, MappingFormat format) throws IOException {
/* 50 */     if (!format.hasSingleFile()) throw new IllegalArgumentException("format " + format + " is not applicable to a single writer");
/*    */     
/* 52 */     switch (format) { case TINY_FILE:
/* 53 */         return (MappingWriter)new Tiny1FileWriter(writer);
/* 54 */       case TINY_2_FILE: return (MappingWriter)new Tiny2FileWriter(writer, false);
/* 55 */       case ENIGMA_FILE: return (MappingWriter)new EnigmaFileWriter(writer);
/* 56 */       case SRG_FILE: return (MappingWriter)new SrgFileWriter(writer, false);
/* 57 */       case XSRG_FILE: return (MappingWriter)new SrgFileWriter(writer, true);
/* 58 */       case PROGUARD_FILE: return (MappingWriter)new ProGuardFileWriter(writer); }
/* 59 */      return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   default boolean visitEnd() throws IOException {
/* 65 */     close();
/* 66 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\fabricmc\mappingio\MappingWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */