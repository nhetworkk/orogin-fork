package net.fabricmc.mappingio.tree;

import net.fabricmc.mappingio.MappingVisitor;

public interface VisitableMappingTree extends MappingTree, MappingVisitor {}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\fabricmc\mappingio\tree\VisitableMappingTree.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */