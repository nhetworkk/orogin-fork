/*     */ package net.fabricmc.mappingio.tree;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class VisitOrder
/*     */ {
/*     */   private Comparator<MappingTreeView.ClassMappingView> classComparator;
/*     */   private Comparator<MappingTreeView.FieldMappingView> fieldComparator;
/*     */   private Comparator<MappingTreeView.MethodMappingView> methodComparator;
/*     */   private Comparator<MappingTreeView.MethodArgMappingView> methodArgComparator;
/*     */   private Comparator<MappingTreeView.MethodVarMappingView> methodVarComparator;
/*     */   private boolean methodsFirst;
/*     */   private boolean methodVarsFirst;
/*     */   
/*     */   public static VisitOrder createByInputOrder() {
/*  41 */     return new VisitOrder();
/*     */   }
/*     */   
/*     */   public static VisitOrder createByName() {
/*  45 */     return (new VisitOrder())
/*  46 */       .classesBySrcName()
/*  47 */       .fieldsBySrcNameDesc()
/*  48 */       .methodsBySrcNameDesc()
/*  49 */       .methodArgsByLvIndex()
/*  50 */       .methodVarsByLvIndex();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public VisitOrder classComparator(Comparator<MappingTreeView.ClassMappingView> comparator) {
/*  56 */     this.classComparator = comparator;
/*     */     
/*  58 */     return this;
/*     */   }
/*     */   
/*     */   public VisitOrder classesBySrcName() {
/*  62 */     return classComparator(compareBySrcName());
/*     */   }
/*     */   
/*     */   public VisitOrder fieldComparator(Comparator<MappingTreeView.FieldMappingView> comparator) {
/*  66 */     this.fieldComparator = comparator;
/*     */     
/*  68 */     return this;
/*     */   }
/*     */   
/*     */   public VisitOrder fieldsBySrcNameDesc() {
/*  72 */     return fieldComparator(compareBySrcNameDesc());
/*     */   }
/*     */   
/*     */   public VisitOrder methodComparator(Comparator<MappingTreeView.MethodMappingView> comparator) {
/*  76 */     this.methodComparator = comparator;
/*     */     
/*  78 */     return this;
/*     */   }
/*     */   
/*     */   public VisitOrder methodsBySrcNameDesc() {
/*  82 */     return methodComparator(compareBySrcNameDesc());
/*     */   }
/*     */   
/*     */   public VisitOrder methodArgComparator(Comparator<MappingTreeView.MethodArgMappingView> comparator) {
/*  86 */     this.methodArgComparator = comparator;
/*     */     
/*  88 */     return this;
/*     */   }
/*     */   
/*     */   public VisitOrder methodArgsByPosition() {
/*  92 */     return methodArgComparator(Comparator.comparingInt(MappingTreeView.MethodArgMappingView::getArgPosition));
/*     */   }
/*     */   
/*     */   public VisitOrder methodArgsByLvIndex() {
/*  96 */     return methodArgComparator(Comparator.comparingInt(MappingTreeView.MethodArgMappingView::getLvIndex));
/*     */   }
/*     */   
/*     */   public VisitOrder methodVarComparator(Comparator<MappingTreeView.MethodVarMappingView> comparator) {
/* 100 */     this.methodVarComparator = comparator;
/*     */     
/* 102 */     return this;
/*     */   }
/*     */   
/*     */   public VisitOrder methodVarsByLvtRowIndex() {
/* 106 */     return methodVarComparator(Comparator.<MappingTreeView.MethodVarMappingView>comparingInt(MappingTreeView.MethodVarMappingView::getLvIndex).thenComparingInt(MappingTreeView.MethodVarMappingView::getLvtRowIndex));
/*     */   }
/*     */   
/*     */   public VisitOrder methodVarsByLvIndex() {
/* 110 */     return methodVarComparator(Comparator.<MappingTreeView.MethodVarMappingView>comparingInt(MappingTreeView.MethodVarMappingView::getLvIndex).thenComparingInt(MappingTreeView.MethodVarMappingView::getStartOpIdx));
/*     */   }
/*     */   
/*     */   public VisitOrder methodsFirst(boolean methodsFirst) {
/* 114 */     this.methodsFirst = methodsFirst;
/*     */     
/* 116 */     return this;
/*     */   }
/*     */   
/*     */   public VisitOrder fieldsFirst() {
/* 120 */     return methodsFirst(false);
/*     */   }
/*     */   
/*     */   public VisitOrder methodsFirst() {
/* 124 */     return methodsFirst(true);
/*     */   }
/*     */   
/*     */   public VisitOrder methodVarsFirst(boolean varsFirst) {
/* 128 */     this.methodVarsFirst = varsFirst;
/*     */     
/* 130 */     return this;
/*     */   }
/*     */   
/*     */   public VisitOrder methodArgsFirst() {
/* 134 */     return methodVarsFirst(false);
/*     */   }
/*     */   
/*     */   public VisitOrder methodVarsFirst() {
/* 138 */     return methodVarsFirst(true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends MappingTreeView.ElementMappingView> Comparator<T> compareBySrcName() {
/* 144 */     return (a, b) -> compare(a.getSrcName(), b.getSrcName());
/*     */   }
/*     */   
/*     */   public static <T extends MappingTreeView.MemberMappingView> Comparator<T> compareBySrcNameDesc() {
/* 148 */     return (a, b) -> {
/*     */         int cmp = compare(a.getSrcName(), b.getSrcName());
/*     */         return (cmp != 0) ? cmp : compare(a.getSrcDesc(), b.getSrcDesc());
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public static Comparator<MappingTreeView.ElementMappingView> compareBySrcNameShortFirst() {
/* 156 */     return (a, b) -> compareShortFirst(a.getSrcName(), b.getSrcName());
/*     */   }
/*     */   
/*     */   public static int compare(@Nullable String a, @Nullable String b) {
/* 160 */     if (a == null || b == null) return compareNullLast(a, b);
/*     */     
/* 162 */     return a.compareTo(b);
/*     */   }
/*     */   
/*     */   public static int compareShortFirst(@Nullable String a, @Nullable String b) {
/* 166 */     if (a == null || b == null) return compareNullLast(a, b);
/*     */     
/* 168 */     int cmp = a.length() - b.length();
/*     */     
/* 170 */     return (cmp != 0) ? cmp : a.compareTo(b);
/*     */   }
/*     */   
/*     */   public static int compareShortFirst(String a, int startA, int endA, String b, int startB, int endB) {
/* 174 */     int lenA = endA - startA;
/* 175 */     int ret = Integer.compare(lenA, endB - startB);
/* 176 */     if (ret != 0) return ret;
/*     */     
/* 178 */     for (int i = 0; i < lenA; i++) {
/* 179 */       char ca = a.charAt(startA + i);
/* 180 */       char cb = b.charAt(startB + i);
/*     */       
/* 182 */       if (ca != cb) {
/* 183 */         return ca - cb;
/*     */       }
/*     */     } 
/*     */     
/* 187 */     return 0;
/*     */   }
/*     */   
/*     */   public static int byNameShortFirstNestaware(@Nullable String a, @Nullable String b) {
/* 191 */     if (a == null || b == null) {
/* 192 */       return compareNullLast(a, b);
/*     */     }
/*     */     
/* 195 */     int pos = 0;
/*     */     
/*     */     do {
/* 198 */       int endA = a.indexOf('$', pos);
/* 199 */       int endB = b.indexOf('$', pos);
/*     */       
/* 201 */       int ret = compareShortFirst(a, pos, (endA >= 0) ? endA : a.length(), b, pos, 
/* 202 */           (endB >= 0) ? endB : b.length());
/*     */       
/* 204 */       if (ret != 0)
/* 205 */         return ret; 
/* 206 */       if (((endA < 0) ? true : false) != ((endB < 0) ? true : false)) {
/* 207 */         return (endA < 0) ? -1 : 1;
/*     */       }
/*     */       
/* 210 */       pos = endA + 1;
/* 211 */     } while (pos > 0);
/*     */     
/* 213 */     return 0;
/*     */   }
/*     */   
/*     */   public static int compareNullLast(@Nullable String a, @Nullable String b) {
/* 217 */     if (a == null) {
/* 218 */       if (b == null) {
/* 219 */         return 0;
/*     */       }
/* 221 */       return 1;
/*     */     } 
/* 223 */     if (b == null) {
/* 224 */       return -1;
/*     */     }
/* 226 */     return a.compareTo(b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends MappingTreeView.ClassMappingView> Collection<T> sortClasses(Collection<T> classes) {
/* 233 */     return sort(classes, (Comparator)this.classComparator);
/*     */   }
/*     */   
/*     */   public <T extends MappingTreeView.FieldMappingView> Collection<T> sortFields(Collection<T> fields) {
/* 237 */     return sort(fields, (Comparator)this.fieldComparator);
/*     */   }
/*     */   
/*     */   public <T extends MappingTreeView.MethodMappingView> Collection<T> sortMethods(Collection<T> methods) {
/* 241 */     return sort(methods, (Comparator)this.methodComparator);
/*     */   }
/*     */   
/*     */   public <T extends MappingTreeView.MethodArgMappingView> Collection<T> sortMethodArgs(Collection<T> args) {
/* 245 */     return sort(args, (Comparator)this.methodArgComparator);
/*     */   }
/*     */   
/*     */   public <T extends MappingTreeView.MethodVarMappingView> Collection<T> sortMethodVars(Collection<T> vars) {
/* 249 */     return sort(vars, (Comparator)this.methodVarComparator);
/*     */   }
/*     */   
/*     */   private static <T> Collection<T> sort(Collection<T> inputs, Comparator<? super T> comparator) {
/* 253 */     if (comparator == null || inputs.size() < 2) return inputs;
/*     */     
/* 255 */     List<T> ret = new ArrayList<>(inputs);
/* 256 */     ret.sort(comparator);
/*     */     
/* 258 */     return ret;
/*     */   }
/*     */   
/*     */   public boolean isMethodsFirst() {
/* 262 */     return this.methodsFirst;
/*     */   }
/*     */   
/*     */   public boolean isMethodVarsFirst() {
/* 266 */     return this.methodVarsFirst;
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\fabricmc\mappingio\tree\VisitOrder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */