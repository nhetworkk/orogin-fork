/*     */ package net.fabricmc.mappingio.tree;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import net.fabricmc.mappingio.MappingVisitor;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface MappingTreeView
/*     */ {
/*     */   public static final int SRC_NAMESPACE_ID = -1;
/*     */   public static final int MIN_NAMESPACE_ID = -1;
/*     */   public static final int NULL_NAMESPACE_ID = -2;
/*     */   
/*     */   static {
/*  27 */     if (null.$assertionsDisabled);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default int getMaxNamespaceId() {
/*  44 */     return getDstNamespaces().size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default int getMinNamespaceId() {
/*  51 */     return -1;
/*     */   }
/*     */   
/*     */   default int getNamespaceId(String namespace) {
/*  55 */     if (namespace.equals(getSrcNamespace())) {
/*  56 */       return -1;
/*     */     }
/*     */     
/*  59 */     int ret = getDstNamespaces().indexOf(namespace);
/*     */     
/*  61 */     return (ret >= 0) ? ret : -2;
/*     */   }
/*     */   
/*     */   default String getNamespaceName(int id) {
/*  65 */     if (id < 0) return getSrcNamespace();
/*     */     
/*  67 */     return getDstNamespaces().get(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   default ClassMappingView getClass(String name, int namespace) {
/*  78 */     if (namespace < 0) return getClass(name);
/*     */     
/*  80 */     for (ClassMappingView cls : getClasses()) {
/*  81 */       if (name.equals(cls.getDstName(namespace))) return cls;
/*     */     
/*     */     } 
/*  84 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   default FieldMappingView getField(String srcClsName, String srcName, @Nullable String srcDesc) {
/*  92 */     ClassMappingView owner = getClass(srcClsName);
/*  93 */     return (owner != null) ? owner.getField(srcName, srcDesc) : null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   default FieldMappingView getField(String clsName, String name, @Nullable String desc, int namespace) {
/*  98 */     ClassMappingView owner = getClass(clsName, namespace);
/*  99 */     return (owner != null) ? owner.getField(name, desc, namespace) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   default MethodMappingView getMethod(String srcClsName, String srcName, @Nullable String srcDesc) {
/* 107 */     ClassMappingView owner = getClass(srcClsName);
/* 108 */     return (owner != null) ? owner.getMethod(srcName, srcDesc) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   default MethodMappingView getMethod(String clsName, String name, @Nullable String desc, int namespace) {
/* 116 */     ClassMappingView owner = getClass(clsName, namespace);
/* 117 */     return (owner != null) ? owner.getMethod(name, desc, namespace) : null;
/*     */   }
/*     */   
/*     */   default void accept(MappingVisitor visitor) throws IOException {
/* 121 */     accept(visitor, VisitOrder.createByInputOrder());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   default String mapClassName(String name, int namespace) {
/* 127 */     return mapClassName(name, -1, namespace);
/*     */   }
/*     */   
/*     */   default String mapClassName(String name, int srcNamespace, int dstNamespace) {
/* 131 */     if (!null.$assertionsDisabled && name.indexOf('.') >= 0) throw new AssertionError();
/*     */     
/* 133 */     if (srcNamespace == dstNamespace) return name;
/*     */     
/* 135 */     ClassMappingView cls = getClass(name, srcNamespace);
/* 136 */     if (cls == null) return name;
/*     */     
/* 138 */     String ret = cls.getName(dstNamespace);
/*     */     
/* 140 */     return (ret != null) ? ret : name;
/*     */   }
/*     */   
/*     */   default String mapDesc(CharSequence desc, int namespace) {
/* 144 */     return mapDesc(desc, 0, desc.length(), -1, namespace);
/*     */   }
/*     */   
/*     */   default String mapDesc(CharSequence desc, int srcNamespace, int dstNamespace) {
/* 148 */     return mapDesc(desc, 0, desc.length(), srcNamespace, dstNamespace);
/*     */   }
/*     */   
/*     */   default String mapDesc(CharSequence desc, int start, int end, int namespace) {
/* 152 */     return mapDesc(desc, start, end, -1, namespace);
/*     */   } @Nullable
/*     */   String getSrcNamespace(); List<String> getDstNamespaces(); List<? extends MetadataEntryView> getMetadata(); List<? extends MetadataEntryView> getMetadata(String paramString);
/*     */   default String mapDesc(CharSequence desc, int start, int end, int srcNamespace, int dstNamespace) {
/* 156 */     if (srcNamespace == dstNamespace) return desc.subSequence(start, end).toString();
/*     */     
/* 158 */     StringBuilder ret = null;
/* 159 */     int copyOffset = start;
/* 160 */     int offset = start;
/*     */     
/* 162 */     while (offset < end) {
/* 163 */       char c = desc.charAt(offset++);
/*     */       
/* 165 */       if (c == 'L') {
/* 166 */         int idEnd = offset;
/*     */         
/* 168 */         while (idEnd < end) {
/* 169 */           c = desc.charAt(idEnd);
/* 170 */           if (c == ';')
/* 171 */             break;  idEnd++;
/*     */         } 
/*     */         
/* 174 */         if (idEnd >= end) throw new IllegalArgumentException("invalid descriptor: " + desc.subSequence(start, end));
/*     */         
/* 176 */         String cls = desc.subSequence(offset, idEnd).toString();
/* 177 */         String mappedCls = mapClassName(cls, srcNamespace, dstNamespace);
/*     */         
/* 179 */         if (mappedCls != null && !mappedCls.equals(cls)) {
/* 180 */           if (ret == null) ret = new StringBuilder(end - start);
/*     */           
/* 182 */           ret.append(desc, copyOffset, offset);
/* 183 */           ret.append(mappedCls);
/* 184 */           copyOffset = idEnd;
/*     */         } 
/*     */         
/* 187 */         offset = idEnd + 1;
/*     */       } 
/*     */     } 
/*     */     
/* 191 */     if (ret == null) return desc.subSequence(start, end).toString();
/*     */     
/* 193 */     ret.append(desc, copyOffset, end);
/*     */     
/* 195 */     return ret.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   Collection<? extends ClassMappingView> getClasses();
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   ClassMappingView getClass(String paramString);
/*     */   
/*     */   void accept(MappingVisitor paramMappingVisitor, VisitOrder paramVisitOrder) throws IOException;
/*     */   
/*     */   public static interface ElementMappingView
/*     */   {
/*     */     MappingTreeView getTree();
/*     */     
/*     */     @Nullable
/*     */     default String getName(int namespace) {
/* 213 */       if (namespace < 0) {
/* 214 */         return getSrcName();
/*     */       }
/* 216 */       return getDstName(namespace);
/*     */     } String getSrcName();
/*     */     @Nullable
/*     */     String getDstName(int param1Int);
/*     */     @Nullable
/*     */     default String getName(String namespace) {
/* 222 */       int nsId = getTree().getNamespaceId(namespace);
/*     */       
/* 224 */       if (nsId == -2) {
/* 225 */         return null;
/*     */       }
/* 227 */       return getName(nsId);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     String getComment();
/*     */   }
/*     */ 
/*     */   
/*     */   public static interface ClassMappingView
/*     */     extends ElementMappingView
/*     */   {
/*     */     Collection<? extends MappingTreeView.FieldMappingView> getFields();
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     MappingTreeView.FieldMappingView getField(String param1String1, @Nullable String param1String2);
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     default MappingTreeView.FieldMappingView getField(String name, @Nullable String desc, int namespace) {
/* 249 */       if (namespace < 0) return getField(name, desc);
/*     */       
/* 251 */       for (MappingTreeView.FieldMappingView field : getFields()) {
/* 252 */         if (!name.equals(field.getDstName(namespace)))
/*     */           continue;  String mDesc;
/* 254 */         if (desc != null && (mDesc = field.getDesc(namespace)) != null && !desc.equals(mDesc))
/*     */           continue; 
/* 256 */         return field;
/*     */       } 
/*     */       
/* 259 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     Collection<? extends MappingTreeView.MethodMappingView> getMethods();
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     MappingTreeView.MethodMappingView getMethod(String param1String1, @Nullable String param1String2);
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     default MappingTreeView.MethodMappingView getMethod(String name, @Nullable String desc, int namespace) {
/* 275 */       if (namespace < 0) return getMethod(name, desc);
/*     */       
/* 277 */       for (MappingTreeView.MethodMappingView method : getMethods()) {
/* 278 */         if (!name.equals(method.getDstName(namespace)))
/*     */           continue; 
/*     */         String mDesc;
/* 281 */         if (desc != null && (mDesc = method.getDesc(namespace)) != null && !desc.equals(mDesc) && (!desc.endsWith(")") || !mDesc.startsWith(desc)))
/*     */           continue; 
/* 283 */         return method;
/*     */       } 
/*     */       
/* 286 */       return null;
/*     */     } }
/*     */   
/*     */   public static interface MemberMappingView extends ElementMappingView {
/*     */     MappingTreeView.ClassMappingView getOwner();
/*     */     
/*     */     @Nullable
/*     */     String getSrcDesc();
/*     */     
/*     */     @Nullable
/*     */     default String getDstDesc(int namespace) {
/* 297 */       String srcDesc = getSrcDesc();
/*     */       
/* 299 */       return (srcDesc != null) ? getTree().mapDesc(srcDesc, namespace) : null;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     default String getDesc(int namespace) {
/* 304 */       String srcDesc = getSrcDesc();
/*     */       
/* 306 */       if (namespace < 0 || srcDesc == null) {
/* 307 */         return srcDesc;
/*     */       }
/* 309 */       return getTree().mapDesc(srcDesc, namespace);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     default String getDesc(String namespace) {
/* 315 */       int nsId = getTree().getNamespaceId(namespace);
/*     */       
/* 317 */       if (nsId == -2) {
/* 318 */         return null;
/*     */       }
/* 320 */       return getDesc(nsId);
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface FieldMappingView extends MemberMappingView {}
/*     */   
/*     */   public static interface MethodMappingView extends MemberMappingView {
/*     */     Collection<? extends MappingTreeView.MethodArgMappingView> getArgs();
/*     */     
/*     */     @Nullable
/*     */     MappingTreeView.MethodArgMappingView getArg(int param1Int1, int param1Int2, @Nullable String param1String);
/*     */     
/*     */     Collection<? extends MappingTreeView.MethodVarMappingView> getVars();
/*     */     
/*     */     @Nullable
/*     */     MappingTreeView.MethodVarMappingView getVar(int param1Int1, int param1Int2, int param1Int3, int param1Int4, @Nullable String param1String);
/*     */   }
/*     */   
/*     */   public static interface MethodVarMappingView extends ElementMappingView {
/*     */     MappingTreeView.MethodMappingView getMethod();
/*     */     
/*     */     int getLvtRowIndex();
/*     */     
/*     */     int getLvIndex();
/*     */     
/*     */     int getStartOpIdx();
/*     */     
/*     */     int getEndOpIdx();
/*     */   }
/*     */   
/*     */   public static interface MethodArgMappingView extends ElementMappingView {
/*     */     MappingTreeView.MethodMappingView getMethod();
/*     */     
/*     */     int getArgPosition();
/*     */     
/*     */     int getLvIndex();
/*     */   }
/*     */   
/*     */   public static interface MetadataEntryView {
/*     */     String getKey();
/*     */     
/*     */     @Nullable
/*     */     String getValue();
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\fabricmc\mappingio\tree\MappingTreeView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */