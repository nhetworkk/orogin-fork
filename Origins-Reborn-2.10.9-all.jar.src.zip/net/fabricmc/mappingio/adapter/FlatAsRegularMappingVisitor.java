/*     */ package net.fabricmc.mappingio.adapter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import net.fabricmc.mappingio.FlatMappingVisitor;
/*     */ import net.fabricmc.mappingio.MappedElementKind;
/*     */ import net.fabricmc.mappingio.MappingFlag;
/*     */ import net.fabricmc.mappingio.MappingVisitor;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FlatAsRegularMappingVisitor
/*     */   implements MappingVisitor
/*     */ {
/*     */   private final FlatMappingVisitor next;
/*     */   private String srcClsName;
/*     */   private String srcMemberName;
/*     */   private String srcMemberDesc;
/*     */   private String srcMemberSubName;
/*     */   private int argIdx;
/*     */   private int lvIndex;
/*     */   private int startOpIdx;
/*     */   private int endOpIdx;
/*     */   private String[] dstNames;
/*     */   private String[] dstClassNames;
/*     */   private String[] dstMemberNames;
/*     */   private String[] dstMemberDescs;
/*     */   
/*     */   public FlatAsRegularMappingVisitor(FlatMappingVisitor out) {
/*  33 */     this.next = out;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<MappingFlag> getFlags() {
/*  38 */     return this.next.getFlags();
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/*  43 */     this.next.reset();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitHeader() throws IOException {
/*  48 */     return this.next.visitHeader();
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitNamespaces(String srcNamespace, List<String> dstNamespaces) throws IOException {
/*  53 */     this.next.visitNamespaces(srcNamespace, dstNamespaces);
/*     */     
/*  55 */     int count = dstNamespaces.size();
/*  56 */     this.dstNames = new String[count];
/*  57 */     Set<MappingFlag> flags = this.next.getFlags();
/*     */     
/*  59 */     if (flags.contains(MappingFlag.NEEDS_ELEMENT_UNIQUENESS)) {
/*  60 */       this.dstClassNames = new String[count];
/*  61 */       this.dstMemberNames = new String[count];
/*     */     } else {
/*  63 */       this.dstClassNames = this.dstMemberNames = null;
/*     */     } 
/*     */     
/*  66 */     this.dstMemberDescs = (flags.contains(MappingFlag.NEEDS_DST_FIELD_DESC) || flags.contains(MappingFlag.NEEDS_DST_METHOD_DESC)) ? new String[count] : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitMetadata(String key, @Nullable String value) throws IOException {
/*  71 */     this.next.visitMetadata(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitContent() throws IOException {
/*  76 */     return this.next.visitContent();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitClass(String srcName) {
/*  81 */     this.srcClsName = srcName;
/*     */     
/*  83 */     Arrays.fill((Object[])this.dstNames, (Object)null);
/*  84 */     if (this.dstClassNames != null) Arrays.fill((Object[])this.dstClassNames, (Object)null);
/*     */     
/*  86 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitField(String srcName, @Nullable String srcDesc) {
/*  91 */     this.srcMemberName = srcName;
/*  92 */     this.srcMemberDesc = srcDesc;
/*     */     
/*  94 */     Arrays.fill((Object[])this.dstNames, (Object)null);
/*  95 */     if (this.dstMemberNames != null) Arrays.fill((Object[])this.dstMemberNames, (Object)null); 
/*  96 */     if (this.dstMemberDescs != null) Arrays.fill((Object[])this.dstMemberDescs, (Object)null);
/*     */     
/*  98 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitMethod(String srcName, @Nullable String srcDesc) {
/* 103 */     this.srcMemberName = srcName;
/* 104 */     this.srcMemberDesc = srcDesc;
/*     */     
/* 106 */     Arrays.fill((Object[])this.dstNames, (Object)null);
/* 107 */     if (this.dstMemberNames != null) Arrays.fill((Object[])this.dstMemberNames, (Object)null); 
/* 108 */     if (this.dstMemberDescs != null) Arrays.fill((Object[])this.dstMemberDescs, (Object)null);
/*     */     
/* 110 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitMethodArg(int argPosition, int lvIndex, @Nullable String srcName) {
/* 115 */     this.srcMemberSubName = srcName;
/* 116 */     this.argIdx = argPosition;
/* 117 */     this.lvIndex = lvIndex;
/*     */     
/* 119 */     Arrays.fill((Object[])this.dstNames, (Object)null);
/*     */     
/* 121 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitMethodVar(int lvtRowIndex, int lvIndex, int startOpIdx, int endOpIdx, @Nullable String srcName) {
/* 126 */     this.srcMemberSubName = srcName;
/* 127 */     this.argIdx = lvtRowIndex;
/* 128 */     this.lvIndex = lvIndex;
/* 129 */     this.startOpIdx = startOpIdx;
/* 130 */     this.endOpIdx = endOpIdx;
/*     */     
/* 132 */     Arrays.fill((Object[])this.dstNames, (Object)null);
/*     */     
/* 134 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitEnd() throws IOException {
/* 139 */     return this.next.visitEnd();
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitDstName(MappedElementKind targetKind, int namespace, String name) {
/* 144 */     this.dstNames[namespace] = name;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitDstDesc(MappedElementKind targetKind, int namespace, String desc) {
/* 149 */     if (this.dstMemberDescs != null) this.dstMemberDescs[namespace] = desc;
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitElementContent(MappedElementKind targetKind) throws IOException {
/*     */     boolean relay;
/* 156 */     switch (targetKind) {
/*     */       case CLASS:
/* 158 */         relay = this.next.visitClass(this.srcClsName, this.dstNames);
/* 159 */         if (relay && this.dstClassNames != null) System.arraycopy(this.dstNames, 0, this.dstClassNames, 0, this.dstNames.length);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 183 */         return relay;case FIELD: relay = this.next.visitField(this.srcClsName, this.srcMemberName, this.srcMemberDesc, this.dstClassNames, this.dstNames, this.dstMemberDescs); if (relay && this.dstMemberNames != null) System.arraycopy(this.dstNames, 0, this.dstMemberNames, 0, this.dstNames.length);  return relay;case METHOD: relay = this.next.visitMethod(this.srcClsName, this.srcMemberName, this.srcMemberDesc, this.dstClassNames, this.dstNames, this.dstMemberDescs); if (relay && this.dstMemberNames != null) System.arraycopy(this.dstNames, 0, this.dstMemberNames, 0, this.dstNames.length);  return relay;case METHOD_ARG: relay = this.next.visitMethodArg(this.srcClsName, this.srcMemberName, this.srcMemberDesc, this.argIdx, this.lvIndex, this.srcMemberSubName, this.dstClassNames, this.dstMemberNames, this.dstMemberDescs, this.dstNames); return relay;case METHOD_VAR: relay = this.next.visitMethodVar(this.srcClsName, this.srcMemberName, this.srcMemberDesc, this.argIdx, this.lvIndex, this.startOpIdx, this.endOpIdx, this.srcMemberSubName, this.dstClassNames, this.dstMemberNames, this.dstMemberDescs, this.dstNames); return relay;
/*     */     } 
/*     */     throw new IllegalStateException();
/*     */   }
/*     */   public void visitComment(MappedElementKind targetKind, String comment) throws IOException {
/* 188 */     switch (targetKind) {
/*     */       case CLASS:
/* 190 */         this.next.visitClassComment(this.srcClsName, this.dstClassNames, comment);
/*     */         break;
/*     */       case FIELD:
/* 193 */         this.next.visitFieldComment(this.srcClsName, this.srcMemberName, this.srcMemberDesc, this.dstClassNames, this.dstMemberNames, this.dstMemberDescs, comment);
/*     */         break;
/*     */       
/*     */       case METHOD:
/* 197 */         this.next.visitMethodComment(this.srcClsName, this.srcMemberName, this.srcMemberDesc, this.dstClassNames, this.dstMemberNames, this.dstMemberDescs, comment);
/*     */         break;
/*     */       
/*     */       case METHOD_ARG:
/* 201 */         this.next.visitMethodArgComment(this.srcClsName, this.srcMemberName, this.srcMemberDesc, this.argIdx, this.lvIndex, this.srcMemberSubName, this.dstClassNames, this.dstMemberNames, this.dstMemberDescs, this.dstNames, comment);
/*     */         break;
/*     */       
/*     */       case METHOD_VAR:
/* 205 */         this.next.visitMethodVarComment(this.srcClsName, this.srcMemberName, this.srcMemberDesc, this.argIdx, this.lvIndex, this.startOpIdx, this.endOpIdx, this.srcMemberSubName, this.dstClassNames, this.dstMemberNames, this.dstMemberDescs, this.dstNames, comment);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\fabricmc\mappingio\adapter\FlatAsRegularMappingVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */