/*    */ package net.fabricmc.mappingio.adapter;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Objects;
/*    */ import net.fabricmc.mappingio.MappingVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MappingNsRenamer
/*    */   extends ForwardingMappingVisitor
/*    */ {
/*    */   private final Map<String, String> nameMap;
/*    */   
/*    */   public MappingNsRenamer(MappingVisitor next, Map<String, String> nameMap) {
/* 29 */     super(next);
/*    */     
/* 31 */     Objects.requireNonNull(nameMap, "null name map");
/*    */     
/* 33 */     this.nameMap = nameMap;
/*    */   }
/*    */ 
/*    */   
/*    */   public void visitNamespaces(String srcNamespace, List<String> dstNamespaces) throws IOException {
/* 38 */     String newSrcNamespace = this.nameMap.getOrDefault(srcNamespace, srcNamespace);
/* 39 */     List<String> newDstNamespaces = new ArrayList<>(dstNamespaces.size());
/*    */     
/* 41 */     for (String ns : dstNamespaces) {
/* 42 */       newDstNamespaces.add(this.nameMap.getOrDefault(ns, ns));
/*    */     }
/*    */     
/* 45 */     super.visitNamespaces(newSrcNamespace, newDstNamespaces);
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\fabricmc\mappingio\adapter\MappingNsRenamer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */