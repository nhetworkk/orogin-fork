/*    */ package net.fabricmc.mappingio.adapter;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import net.fabricmc.mappingio.MappingVisitor;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MissingDescFilter
/*    */   extends ForwardingMappingVisitor
/*    */ {
/*    */   public MissingDescFilter(MappingVisitor next) {
/* 27 */     super(next);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean visitField(String srcName, @Nullable String srcDesc) throws IOException {
/* 32 */     if (srcDesc == null) return false;
/*    */     
/* 34 */     return super.visitField(srcName, srcDesc);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean visitMethod(String srcName, @Nullable String srcDesc) throws IOException {
/* 39 */     if (srcDesc == null) return false;
/*    */     
/* 41 */     return super.visitMethod(srcName, srcDesc);
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\fabricmc\mappingio\adapter\MissingDescFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */