/*    */ package net.fabricmc.mappingio.adapter;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import net.fabricmc.mappingio.MappedElementKind;
/*    */ import net.fabricmc.mappingio.MappingVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MappingDstNsReorder
/*    */   extends ForwardingMappingVisitor
/*    */ {
/*    */   private final List<String> newDstNs;
/*    */   private int[] nsMap;
/*    */   
/*    */   public MappingDstNsReorder(MappingVisitor next, List<String> newDstNs) {
/* 29 */     super(next);
/*    */     
/* 31 */     Objects.requireNonNull(newDstNs, "null newDstNs list");
/*    */     
/* 33 */     this.newDstNs = newDstNs;
/*    */   }
/*    */   
/*    */   public MappingDstNsReorder(MappingVisitor next, String... newDstNs) {
/* 37 */     this(next, Arrays.asList(newDstNs));
/*    */   }
/*    */ 
/*    */   
/*    */   public void visitNamespaces(String srcNamespace, List<String> dstNamespaces) throws IOException {
/* 42 */     this.nsMap = new int[dstNamespaces.size()];
/*    */     
/* 44 */     for (int i = 0; i < dstNamespaces.size(); i++) {
/* 45 */       this.nsMap[i] = this.newDstNs.indexOf(dstNamespaces.get(i));
/*    */     }
/*    */     
/* 48 */     super.visitNamespaces(srcNamespace, this.newDstNs);
/*    */   }
/*    */ 
/*    */   
/*    */   public void visitDstName(MappedElementKind targetKind, int namespace, String name) throws IOException {
/* 53 */     namespace = this.nsMap[namespace];
/*    */     
/* 55 */     if (namespace >= 0) {
/* 56 */       super.visitDstName(targetKind, namespace, name);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void visitDstDesc(MappedElementKind targetKind, int namespace, String desc) throws IOException {
/* 62 */     namespace = this.nsMap[namespace];
/*    */     
/* 64 */     if (namespace >= 0)
/* 65 */       super.visitDstDesc(targetKind, namespace, desc); 
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\fabricmc\mappingio\adapter\MappingDstNsReorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */