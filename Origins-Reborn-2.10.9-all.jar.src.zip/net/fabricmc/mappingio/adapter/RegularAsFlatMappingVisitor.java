/*     */ package net.fabricmc.mappingio.adapter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import net.fabricmc.mappingio.FlatMappingVisitor;
/*     */ import net.fabricmc.mappingio.MappedElementKind;
/*     */ import net.fabricmc.mappingio.MappingFlag;
/*     */ import net.fabricmc.mappingio.MappingVisitor;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ public final class RegularAsFlatMappingVisitor
/*     */   implements FlatMappingVisitor
/*     */ {
/*     */   private final MappingVisitor next;
/*     */   private boolean relayDstFieldDescs;
/*     */   private boolean relayDstMethodDescs;
/*     */   private String lastClass;
/*     */   private boolean relayLastClass;
/*     */   private String lastMemberName;
/*     */   private String lastMemberDesc;
/*     */   private boolean lastMemberIsField;
/*     */   private boolean relayLastMember;
/*     */   private int lastArgPosition;
/*     */   private int lastLvIndex;
/*     */   private int lastStartOpIdx;
/*     */   private boolean lastMethodSubIsArg;
/*     */   private boolean relayLastMethodSub;
/*     */   
/*     */   public RegularAsFlatMappingVisitor(MappingVisitor next) {
/*  32 */     this.next = next;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<MappingFlag> getFlags() {
/*  37 */     return this.next.getFlags();
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/*  42 */     this.lastClass = null;
/*  43 */     this.lastMemberName = this.lastMemberDesc = null;
/*  44 */     this.lastArgPosition = this.lastLvIndex = this.lastStartOpIdx = -1;
/*     */     
/*  46 */     this.next.reset();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitHeader() throws IOException {
/*  51 */     return this.next.visitHeader();
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitNamespaces(String srcNamespace, List<String> dstNamespaces) throws IOException {
/*  56 */     this.next.visitNamespaces(srcNamespace, dstNamespaces);
/*     */     
/*  58 */     Set<MappingFlag> flags = this.next.getFlags();
/*  59 */     this.relayDstFieldDescs = flags.contains(MappingFlag.NEEDS_DST_FIELD_DESC);
/*  60 */     this.relayDstMethodDescs = flags.contains(MappingFlag.NEEDS_DST_METHOD_DESC);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitMetadata(String key, @Nullable String value) throws IOException {
/*  65 */     this.next.visitMetadata(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitContent() throws IOException {
/*  70 */     return this.next.visitContent();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitClass(String srcName, String[] dstNames) throws IOException {
/*  75 */     return visitClass(srcName, dstNames, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitClass(String srcName, String dstName) throws IOException {
/*  80 */     return visitClass(srcName, null, dstName);
/*     */   }
/*     */   
/*     */   private boolean visitClass(String srcName, @Nullable String[] dstNames, @Nullable String dstName) throws IOException {
/*  84 */     if (!srcName.equals(this.lastClass)) {
/*  85 */       this.lastClass = srcName;
/*  86 */       this.lastMemberName = this.lastMemberDesc = null;
/*  87 */       this.lastArgPosition = this.lastLvIndex = this.lastStartOpIdx = -1;
/*  88 */       this.relayLastClass = (this.next.visitClass(srcName) && visitDstNames(MappedElementKind.CLASS, dstNames, dstName));
/*     */     } 
/*     */     
/*  91 */     return this.relayLastClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitClassComment(String srcName, @Nullable String[] dstNames, String comment) throws IOException {
/*  96 */     if (!visitClass(srcName, dstNames, null))
/*  97 */       return;  this.next.visitComment(MappedElementKind.CLASS, comment);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitClassComment(String srcName, @Nullable String dstName, String comment) throws IOException {
/* 102 */     if (!visitClass(srcName, null, dstName))
/* 103 */       return;  this.next.visitComment(MappedElementKind.CLASS, comment);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean visitField(String srcClsName, String srcName, @Nullable String srcDesc, @Nullable String[] dstClsNames, String[] dstNames, @Nullable String[] dstDescs) throws IOException {
/* 109 */     return visitField(srcClsName, srcName, srcDesc, dstClsNames, dstNames, dstDescs, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean visitField(String srcClsName, String srcName, @Nullable String srcDesc, @Nullable String dstClsName, String dstName, @Nullable String dstDesc) throws IOException {
/* 115 */     return visitField(srcClsName, srcName, srcDesc, null, null, null, dstClsName, dstName, dstDesc);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean visitField(String srcClsName, String srcName, @Nullable String srcDesc, @Nullable String[] dstClsNames, @Nullable String[] dstNames, @Nullable String[] dstDescs, @Nullable String dstClsName, @Nullable String dstName, @Nullable String dstDesc) throws IOException {
/* 121 */     if (!visitClass(srcClsName, dstClsNames, dstClsName)) return false;
/*     */     
/* 123 */     if (!this.lastMemberIsField || !srcName.equals(this.lastMemberName) || (srcDesc != null && !srcDesc.equals(this.lastMemberDesc))) {
/* 124 */       this.lastMemberName = srcName;
/* 125 */       this.lastMemberDesc = srcDesc;
/* 126 */       this.lastMemberIsField = true;
/* 127 */       this.lastArgPosition = this.lastLvIndex = this.lastStartOpIdx = -1;
/* 128 */       this.relayLastMember = (this.next.visitField(srcName, srcDesc) && visitDstNamesDescs(MappedElementKind.FIELD, dstNames, dstDescs, dstName, dstDesc));
/*     */     } 
/*     */     
/* 131 */     return this.relayLastMember;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitFieldComment(String srcClsName, String srcName, @Nullable String srcDesc, @Nullable String[] dstClsNames, @Nullable String[] dstNames, @Nullable String[] dstDescs, String comment) throws IOException {
/* 138 */     if (!visitField(srcClsName, srcName, srcDesc, dstClsNames, dstNames, dstDescs, null, null, null))
/* 139 */       return;  this.next.visitComment(MappedElementKind.FIELD, comment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitFieldComment(String srcClsName, String srcName, @Nullable String srcDesc, @Nullable String dstClsName, @Nullable String dstName, @Nullable String dstDesc, String comment) throws IOException {
/* 146 */     if (!visitField(srcClsName, srcName, srcDesc, null, null, null, dstClsName, dstName, dstDesc))
/* 147 */       return;  this.next.visitComment(MappedElementKind.FIELD, comment);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean visitMethod(String srcClsName, String srcName, @Nullable String srcDesc, @Nullable String[] dstClsNames, String[] dstNames, @Nullable String[] dstDescs) throws IOException {
/* 153 */     return visitMethod(srcClsName, srcName, srcDesc, dstClsNames, dstNames, dstDescs, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean visitMethod(String srcClsName, String srcName, @Nullable String srcDesc, @Nullable String dstClsName, String dstName, @Nullable String dstDesc) throws IOException {
/* 159 */     return visitMethod(srcClsName, srcName, srcDesc, null, null, null, dstClsName, dstName, dstDesc);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean visitMethod(String srcClsName, String srcName, @Nullable String srcDesc, @Nullable String[] dstClsNames, @Nullable String[] dstNames, @Nullable String[] dstDescs, @Nullable String dstClsName, @Nullable String dstName, @Nullable String dstDesc) throws IOException {
/* 165 */     if (!visitClass(srcClsName, dstClsNames, dstClsName)) return false;
/*     */     
/* 167 */     if (this.lastMemberIsField || !srcName.equals(this.lastMemberName) || (srcDesc != null && !srcDesc.equals(this.lastMemberDesc))) {
/* 168 */       this.lastMemberName = srcName;
/* 169 */       this.lastMemberDesc = srcDesc;
/* 170 */       this.lastMemberIsField = false;
/* 171 */       this.lastArgPosition = this.lastLvIndex = this.lastStartOpIdx = -1;
/* 172 */       this.relayLastMember = (this.next.visitMethod(srcName, srcDesc) && visitDstNamesDescs(MappedElementKind.METHOD, dstNames, dstDescs, dstName, dstDesc));
/*     */     } 
/*     */     
/* 175 */     return this.relayLastMember;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitMethodComment(String srcClsName, String srcName, @Nullable String srcDesc, @Nullable String[] dstClsNames, @Nullable String[] dstNames, @Nullable String[] dstDescs, String comment) throws IOException {
/* 182 */     if (!visitMethod(srcClsName, srcName, srcDesc, dstClsNames, dstNames, dstDescs, null, null, null))
/* 183 */       return;  this.next.visitComment(MappedElementKind.METHOD, comment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitMethodComment(String srcClsName, String srcName, @Nullable String srcDesc, @Nullable String dstClsName, @Nullable String dstName, @Nullable String dstDesc, String comment) throws IOException {
/* 190 */     if (!visitMethod(srcClsName, srcName, srcDesc, null, null, null, dstClsName, dstName, dstDesc))
/* 191 */       return;  this.next.visitComment(MappedElementKind.METHOD, comment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean visitMethodArg(String srcClsName, String srcMethodName, @Nullable String srcMethodDesc, int argPosition, int lvIndex, @Nullable String srcArgName, @Nullable String[] dstClsNames, @Nullable String[] dstMethodNames, @Nullable String[] dstMethodDescs, String[] dstArgNames) throws IOException {
/* 199 */     return visitMethodArg(srcClsName, srcMethodName, srcMethodDesc, argPosition, lvIndex, srcArgName, dstClsNames, dstMethodNames, dstMethodDescs, dstArgNames, null, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean visitMethodArg(String srcClsName, String srcMethodName, @Nullable String srcMethodDesc, int argPosition, int lvIndex, @Nullable String srcArgName, @Nullable String dstClsName, @Nullable String dstMethodName, @Nullable String dstMethodDesc, String dstArgName) throws IOException {
/* 208 */     return visitMethodArg(srcClsName, srcMethodName, srcMethodDesc, argPosition, lvIndex, srcArgName, null, null, null, null, dstClsName, dstMethodName, dstMethodDesc, dstArgName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean visitMethodArg(String srcClsName, String srcMethodName, @Nullable String srcMethodDesc, int argPosition, int lvIndex, @Nullable String srcName, @Nullable String[] dstClsNames, @Nullable String[] dstMethodNames, @Nullable String[] dstMethodDescs, @Nullable String[] dstNames, @Nullable String dstClsName, @Nullable String dstMethodName, @Nullable String dstMethodDesc, @Nullable String dstName) throws IOException {
/* 218 */     if (!visitMethod(srcClsName, srcMethodName, srcMethodDesc, dstClsNames, dstMethodNames, dstMethodDescs, dstClsName, dstMethodName, dstMethodDesc)) return false;
/*     */     
/* 220 */     if (!this.lastMethodSubIsArg || argPosition != this.lastArgPosition || lvIndex != this.lastLvIndex) {
/* 221 */       this.lastArgPosition = argPosition;
/* 222 */       this.lastLvIndex = lvIndex;
/* 223 */       this.lastMethodSubIsArg = true;
/* 224 */       this.relayLastMethodSub = (this.next.visitMethodArg(argPosition, lvIndex, srcName) && visitDstNames(MappedElementKind.METHOD_ARG, dstNames, dstName));
/*     */     } 
/*     */     
/* 227 */     return this.relayLastMethodSub;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitMethodArgComment(String srcClsName, String srcMethodName, @Nullable String srcMethodDesc, int argPosition, int lvIndex, @Nullable String srcArgName, @Nullable String[] dstClsNames, @Nullable String[] dstMethodNames, @Nullable String[] dstMethodDescs, @Nullable String[] dstArgNames, String comment) throws IOException {
/* 235 */     if (!visitMethodArg(srcClsName, srcMethodName, srcMethodDesc, argPosition, lvIndex, srcArgName, dstClsNames, dstMethodNames, dstMethodDescs, dstArgNames, null, null, null, null)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 240 */     this.next.visitComment(MappedElementKind.METHOD_ARG, comment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitMethodArgComment(String srcClsName, String srcMethodName, @Nullable String srcMethodDesc, int argPosition, int lvIndex, @Nullable String srcArgName, @Nullable String dstClsName, @Nullable String dstMethodName, @Nullable String dstMethodDesc, @Nullable String dstArgName, String comment) throws IOException {
/* 248 */     if (!visitMethodArg(srcClsName, srcMethodName, srcMethodDesc, argPosition, lvIndex, srcArgName, null, null, null, null, dstClsName, dstMethodName, dstMethodDesc, dstArgName)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 253 */     this.next.visitComment(MappedElementKind.METHOD_ARG, comment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean visitMethodVar(String srcClsName, String srcMethodName, @Nullable String srcMethodDesc, int lvtRowIndex, int lvIndex, int startOpIdx, int endOpIdx, @Nullable String srcVarName, @Nullable String[] dstClsNames, @Nullable String[] dstMethodNames, @Nullable String[] dstMethodDescs, String[] dstVarNames) throws IOException {
/* 261 */     return visitMethodVar(srcClsName, srcMethodName, srcMethodDesc, lvtRowIndex, lvIndex, startOpIdx, endOpIdx, srcVarName, dstClsNames, dstMethodNames, dstMethodDescs, dstVarNames, null, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean visitMethodVar(String srcClsName, String srcMethodName, @Nullable String srcMethodDesc, int lvtRowIndex, int lvIndex, int startOpIdx, int endOpIdx, @Nullable String srcVarName, @Nullable String dstClsName, @Nullable String dstMethodName, @Nullable String dstMethodDesc, String dstVarName) throws IOException {
/* 270 */     return visitMethodVar(srcClsName, srcMethodName, srcMethodDesc, lvtRowIndex, lvIndex, startOpIdx, endOpIdx, srcVarName, null, null, null, null, dstClsName, dstMethodName, dstMethodDesc, dstVarName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean visitMethodVar(String srcClsName, String srcMethodName, @Nullable String srcMethodDesc, int lvtRowIndex, int lvIndex, int startOpIdx, int endOpIdx, @Nullable String srcName, @Nullable String[] dstClsNames, @Nullable String[] dstMethodNames, @Nullable String[] dstMethodDescs, @Nullable String[] dstNames, @Nullable String dstClsName, @Nullable String dstMethodName, @Nullable String dstMethodDesc, @Nullable String dstName) throws IOException {
/* 278 */     if (!visitMethod(srcClsName, srcMethodName, srcMethodDesc, dstClsNames, dstMethodNames, dstMethodDescs, dstClsName, dstMethodName, dstMethodDesc)) return false;
/*     */     
/* 280 */     if (this.lastMethodSubIsArg || lvtRowIndex != this.lastArgPosition || lvIndex != this.lastLvIndex || startOpIdx != this.lastStartOpIdx) {
/* 281 */       this.lastArgPosition = lvtRowIndex;
/* 282 */       this.lastLvIndex = lvIndex;
/* 283 */       this.lastStartOpIdx = startOpIdx;
/* 284 */       this.lastMethodSubIsArg = false;
/* 285 */       this.relayLastMethodSub = (this.next.visitMethodVar(lvtRowIndex, lvIndex, startOpIdx, endOpIdx, srcName) && visitDstNames(MappedElementKind.METHOD_VAR, dstNames, dstName));
/*     */     } 
/*     */     
/* 288 */     return this.relayLastMethodSub;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitMethodVarComment(String srcClsName, String srcMethodName, @Nullable String srcMethodDesc, int lvtRowIndex, int lvIndex, int startOpIdx, int endOpIdx, @Nullable String srcVarName, @Nullable String[] dstClsNames, @Nullable String[] dstMethodNames, @Nullable String[] dstMethodDescs, @Nullable String[] dstVarNames, String comment) throws IOException {
/* 296 */     if (!visitMethodVar(srcClsName, srcMethodName, srcMethodDesc, lvtRowIndex, lvIndex, startOpIdx, endOpIdx, srcVarName, dstClsNames, dstMethodNames, dstMethodDescs, dstVarNames, null, null, null, null)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 301 */     this.next.visitComment(MappedElementKind.METHOD_VAR, comment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitMethodVarComment(String srcClsName, String srcMethodName, @Nullable String srcMethodDesc, int lvtRowIndex, int lvIndex, int startOpIdx, int endOpIdx, @Nullable String srcVarName, @Nullable String dstClsName, @Nullable String dstMethodName, @Nullable String dstMethodDesc, @Nullable String dstVarName, String comment) throws IOException {
/* 309 */     if (!visitMethodVar(srcClsName, srcMethodName, srcMethodDesc, lvtRowIndex, lvIndex, startOpIdx, endOpIdx, srcVarName, null, null, null, null, dstClsName, dstMethodName, dstMethodDesc, dstVarName)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 314 */     this.next.visitComment(MappedElementKind.METHOD_VAR, comment);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visitEnd() throws IOException {
/* 319 */     return this.next.visitEnd();
/*     */   }
/*     */   
/*     */   private boolean visitDstNames(MappedElementKind targetKind, @Nullable String[] dstNames, @Nullable String dstName) throws IOException {
/* 323 */     if (dstNames != null) {
/* 324 */       for (int i = 0; i < dstNames.length; i++) {
/* 325 */         String name = dstNames[i];
/* 326 */         if (name != null) this.next.visitDstName(targetKind, i, name); 
/*     */       } 
/* 328 */     } else if (dstName != null) {
/* 329 */       this.next.visitDstName(targetKind, 0, dstName);
/*     */     } 
/*     */     
/* 332 */     return this.next.visitElementContent(targetKind);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean visitDstNamesDescs(MappedElementKind targetKind, @Nullable String[] dstNames, @Nullable String[] dstDescs, @Nullable String dstName, @Nullable String dstDesc) throws IOException {
/* 337 */     boolean relayMemberDesc = ((targetKind == MappedElementKind.FIELD && this.relayDstFieldDescs) || (targetKind != MappedElementKind.FIELD && this.relayDstMethodDescs));
/*     */ 
/*     */     
/* 340 */     if (dstNames != null || dstDescs != null) {
/* 341 */       if (dstNames != null) {
/* 342 */         for (int i = 0; i < dstNames.length; i++) {
/* 343 */           String name = dstNames[i];
/* 344 */           if (name != null) this.next.visitDstName(targetKind, i, name);
/*     */         
/*     */         } 
/*     */       }
/* 348 */       if (dstDescs != null && relayMemberDesc)
/* 349 */         for (int i = 0; i < dstDescs.length; i++) {
/* 350 */           String desc = dstDescs[i];
/* 351 */           if (desc != null) this.next.visitDstDesc(targetKind, i, desc);
/*     */         
/*     */         }  
/*     */     } else {
/* 355 */       if (dstName != null) this.next.visitDstName(targetKind, 0, dstName); 
/* 356 */       if (dstDesc != null && relayMemberDesc) this.next.visitDstDesc(targetKind, 0, dstDesc);
/*     */     
/*     */     } 
/* 359 */     return this.next.visitElementContent(targetKind);
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\fabricmc\mappingio\adapter\RegularAsFlatMappingVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */