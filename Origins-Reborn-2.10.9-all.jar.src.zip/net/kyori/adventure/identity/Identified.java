package net.kyori.adventure.identity;

import org.jetbrains.annotations.NotNull;

public interface Identified {
  @NotNull
  Identity identity();
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\kyori\adventure\identity\Identified.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */