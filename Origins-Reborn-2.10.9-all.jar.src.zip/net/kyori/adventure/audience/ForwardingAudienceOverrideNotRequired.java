package net.kyori.adventure.audience;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import org.jetbrains.annotations.ApiStatus.Internal;

@Retention(RetentionPolicy.RUNTIME)
@Internal
@interface ForwardingAudienceOverrideNotRequired {}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\kyori\adventure\audience\ForwardingAudienceOverrideNotRequired.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */