package net.kyori.adventure.key;

import org.jetbrains.annotations.NotNull;

public interface Keyed {
  @NotNull
  Key key();
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\kyori\adventure\key\Keyed.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */