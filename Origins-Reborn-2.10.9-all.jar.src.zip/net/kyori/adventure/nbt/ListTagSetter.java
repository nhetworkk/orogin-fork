package net.kyori.adventure.nbt;

import org.jetbrains.annotations.NotNull;

public interface ListTagSetter<R, T extends BinaryTag> {
  @NotNull
  R add(T paramT);
  
  @NotNull
  R add(Iterable<? extends T> paramIterable);
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\kyori\adventure\nbt\ListTagSetter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */