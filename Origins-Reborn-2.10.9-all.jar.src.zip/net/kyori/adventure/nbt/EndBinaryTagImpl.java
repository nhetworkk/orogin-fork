/*    */ package net.kyori.adventure.nbt;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class EndBinaryTagImpl
/*    */   extends AbstractBinaryTag
/*    */   implements EndBinaryTag
/*    */ {
/* 27 */   static final EndBinaryTagImpl INSTANCE = new EndBinaryTagImpl();
/*    */ 
/*    */   
/*    */   public boolean equals(Object that) {
/* 31 */     return (this == that);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 36 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\kyori\adventure\nbt\EndBinaryTagImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */