/*    */ package net.kyori.adventure.nbt;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class ArrayBinaryTagImpl
/*    */   extends AbstractBinaryTag
/*    */   implements ArrayBinaryTag
/*    */ {
/*    */   static void checkIndex(int index, int length) {
/* 28 */     if (index < 0 || index >= length)
/* 29 */       throw new IndexOutOfBoundsException("Index out of bounds: " + index); 
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\kyori\adventure\nbt\ArrayBinaryTagImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */