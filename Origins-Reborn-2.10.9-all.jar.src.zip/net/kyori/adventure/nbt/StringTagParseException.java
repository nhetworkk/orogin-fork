/*    */ package net.kyori.adventure.nbt;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class StringTagParseException
/*    */   extends IOException
/*    */ {
/*    */   private static final long serialVersionUID = -3001637554903912905L;
/*    */   private final CharSequence buffer;
/*    */   private final int position;
/*    */   
/*    */   StringTagParseException(String message, CharSequence buffer, int position) {
/* 37 */     super(message);
/* 38 */     this.buffer = buffer;
/* 39 */     this.position = position;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getMessage() {
/* 46 */     return super.getMessage() + "(at position " + this.position + ")";
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\kyori\adventure\nbt\StringTagParseException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */