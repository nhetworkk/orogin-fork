/*    */ package net.kyori.adventure.nbt;
/*    */ 
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ByteArrayBinaryTag
/*    */   extends ArrayBinaryTag, Iterable<Byte>
/*    */ {
/*    */   @NotNull
/*    */   static ByteArrayBinaryTag of(byte... value) {
/* 42 */     return new ByteArrayBinaryTagImpl(value);
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   default BinaryTagType<ByteArrayBinaryTag> type() {
/* 47 */     return BinaryTagTypes.BYTE_ARRAY;
/*    */   }
/*    */   
/*    */   byte[] value();
/*    */   
/*    */   int size();
/*    */   
/*    */   byte get(int paramInt);
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\kyori\adventure\nbt\ByteArrayBinaryTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */