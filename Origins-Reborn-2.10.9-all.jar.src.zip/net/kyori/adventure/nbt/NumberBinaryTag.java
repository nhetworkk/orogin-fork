package net.kyori.adventure.nbt;

import org.jetbrains.annotations.NotNull;

public interface NumberBinaryTag extends BinaryTag {
  @NotNull
  BinaryTagType<? extends NumberBinaryTag> type();
  
  byte byteValue();
  
  double doubleValue();
  
  float floatValue();
  
  int intValue();
  
  long longValue();
  
  short shortValue();
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\kyori\adventure\nbt\NumberBinaryTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */