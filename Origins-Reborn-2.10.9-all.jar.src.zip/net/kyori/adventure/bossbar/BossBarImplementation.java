/*    */ package net.kyori.adventure.bossbar;
/*    */ 
/*    */ import org.jetbrains.annotations.ApiStatus.Internal;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Internal
/*    */ public interface BossBarImplementation
/*    */ {
/*    */   @Internal
/*    */   @NotNull
/*    */   static <I extends BossBarImplementation> I get(@NotNull BossBar bar, @NotNull Class<I> type) {
/* 47 */     return BossBarImpl.ImplementationAccessor.get(bar, type);
/*    */   }
/*    */   
/*    */   @Internal
/*    */   public static interface Provider {
/*    */     @Internal
/*    */     @NotNull
/*    */     BossBarImplementation create(@NotNull BossBar param1BossBar);
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\kyori\adventure\bossbar\BossBarImplementation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */