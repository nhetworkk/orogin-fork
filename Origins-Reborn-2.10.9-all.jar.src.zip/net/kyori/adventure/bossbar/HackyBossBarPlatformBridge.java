package net.kyori.adventure.bossbar;

import net.kyori.adventure.util.PlatformAPI;
import org.jetbrains.annotations.ApiStatus.Internal;

@Deprecated
@PlatformAPI
@Internal
abstract class HackyBossBarPlatformBridge {}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\kyori\adventure\bossbar\HackyBossBarPlatformBridge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */