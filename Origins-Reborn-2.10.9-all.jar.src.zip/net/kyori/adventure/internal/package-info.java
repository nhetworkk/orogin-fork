package net.kyori.adventure.internal;

import org.jetbrains.annotations.ApiStatus.Internal;



/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\kyori\adventure\internal\package-info.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */