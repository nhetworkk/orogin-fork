/*     */ package net.kyori.adventure.platform.facet;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import net.kyori.adventure.text.Component;
/*     */ import net.kyori.adventure.text.TranslatableComponent;
/*     */ import net.kyori.adventure.text.flattener.ComponentFlattener;
/*     */ import net.kyori.adventure.translation.GlobalTranslator;
/*     */ import net.kyori.adventure.translation.TranslationRegistry;
/*     */ import org.jetbrains.annotations.ApiStatus.Internal;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Internal
/*     */ public final class FacetComponentFlattener
/*     */ {
/*  47 */   private static final Pattern LOCALIZATION_PATTERN = Pattern.compile("%(?:(\\d+)\\$)?s");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <V> ComponentFlattener get(V instance, Collection<? extends Translator<V>> candidates) {
/*  64 */     Translator<V> translator = Facet.<V, Translator<V>>of((Collection)candidates, instance);
/*  65 */     ComponentFlattener.Builder flattenerBuilder = (ComponentFlattener.Builder)ComponentFlattener.basic().toBuilder();
/*  66 */     flattenerBuilder.complexMapper(TranslatableComponent.class, (translatable, consumer) -> {
/*     */           String key = translatable.key();
/*     */           
/*     */           for (net.kyori.adventure.translation.Translator registry : GlobalTranslator.translator().sources()) {
/*     */             if (registry instanceof TranslationRegistry && ((TranslationRegistry)registry).contains(key)) {
/*     */               consumer.accept(GlobalTranslator.render((Component)translatable, Locale.getDefault()));
/*     */               
/*     */               return;
/*     */             } 
/*     */           } 
/*     */           String translated = (translator == null) ? key : translator.valueOrDefault(instance, key);
/*     */           Matcher matcher = LOCALIZATION_PATTERN.matcher(translated);
/*     */           List<Component> args = translatable.args();
/*     */           int argPosition = 0;
/*     */           int lastIdx = 0;
/*     */           while (matcher.find()) {
/*     */             if (lastIdx < matcher.start()) {
/*     */               consumer.accept(Component.text(translated.substring(lastIdx, matcher.start())));
/*     */             }
/*     */             lastIdx = matcher.end();
/*     */             String argIdx = matcher.group(1);
/*     */             if (argIdx != null) {
/*     */               try {
/*     */                 int i = Integer.parseInt(argIdx) - 1;
/*     */                 if (i < args.size()) {
/*     */                   consumer.accept(args.get(i));
/*     */                 }
/*  93 */               } catch (NumberFormatException numberFormatException) {}
/*     */               
/*     */               continue;
/*     */             } 
/*     */             
/*     */             int idx = argPosition++;
/*     */             
/*     */             if (idx < args.size()) {
/*     */               consumer.accept(args.get(idx));
/*     */             }
/*     */           } 
/*     */           
/*     */           if (lastIdx < translated.length()) {
/*     */             consumer.accept(Component.text(translated.substring(lastIdx)));
/*     */           }
/*     */         });
/*     */     
/* 110 */     return (ComponentFlattener)flattenerBuilder.build();
/*     */   }
/*     */   
/*     */   public static interface Translator<V> extends Facet<V> {
/*     */     @NotNull
/*     */     String valueOrDefault(@NotNull V param1V, @NotNull String param1String);
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\kyori\adventure\platform\facet\FacetComponentFlattener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */