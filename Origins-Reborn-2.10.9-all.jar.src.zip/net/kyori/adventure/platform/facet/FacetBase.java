/*    */ package net.kyori.adventure.platform.facet;
/*    */ 
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class FacetBase<V>
/*    */   implements Facet<V>
/*    */ {
/*    */   protected final Class<? extends V> viewerClass;
/*    */   
/*    */   protected FacetBase(@Nullable Class<? extends V> viewerClass) {
/* 41 */     this.viewerClass = viewerClass;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isSupported() {
/* 46 */     return (this.viewerClass != null);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isApplicable(@NotNull V viewer) {
/* 51 */     return (this.viewerClass != null && this.viewerClass.isInstance(viewer));
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\kyori\adventure\platform\facet\FacetBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */