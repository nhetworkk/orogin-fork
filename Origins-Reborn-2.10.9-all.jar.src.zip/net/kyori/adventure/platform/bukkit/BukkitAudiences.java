/*    */ package net.kyori.adventure.platform.bukkit;
/*    */ 
/*    */ import java.util.function.Predicate;
/*    */ import net.kyori.adventure.audience.Audience;
/*    */ import net.kyori.adventure.platform.AudienceProvider;
/*    */ import net.kyori.adventure.sound.Sound;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface BukkitAudiences
/*    */   extends AudienceProvider
/*    */ {
/*    */   @NotNull
/*    */   static BukkitAudiences create(@NotNull Plugin plugin) {
/* 53 */     return BukkitAudiencesImpl.instanceFor(plugin);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @NotNull
/*    */   static Builder builder(@NotNull Plugin plugin) {
/* 66 */     return BukkitAudiencesImpl.builder(plugin);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static Sound.Emitter asEmitter(@NotNull Entity entity) {
/* 77 */     return new BukkitEmitter(entity);
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   Audience sender(@NotNull CommandSender paramCommandSender);
/*    */   
/*    */   @NotNull
/*    */   Audience player(@NotNull Player paramPlayer);
/*    */   
/*    */   @NotNull
/*    */   Audience filter(@NotNull Predicate<CommandSender> paramPredicate);
/*    */   
/*    */   public static interface Builder extends AudienceProvider.Builder<BukkitAudiences, Builder> {}
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\kyori\adventure\platform\bukkit\BukkitAudiences.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */