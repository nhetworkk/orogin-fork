/*     */ package net.kyori.adventure.platform.bukkit;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.function.Supplier;
/*     */ import net.kyori.adventure.platform.facet.Facet;
/*     */ import net.kyori.adventure.platform.facet.FacetComponentFlattener;
/*     */ import net.kyori.adventure.text.flattener.ComponentFlattener;
/*     */ import net.kyori.adventure.text.serializer.gson.GsonComponentSerializer;
/*     */ import net.kyori.adventure.text.serializer.gson.legacyimpl.NBTLegacyHoverEventSerializer;
/*     */ import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Server;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BukkitComponentSerializer
/*     */ {
/*  49 */   private static final boolean IS_1_16 = (MinecraftReflection.findEnum(Material.class, "NETHERITE_PICKAXE") != null);
/*     */   
/*  51 */   private static final Collection<FacetComponentFlattener.Translator<Server>> TRANSLATORS = Facet.of(new Supplier[] { Translator::new, Translator::new });
/*     */ 
/*     */   
/*     */   private static final LegacyComponentSerializer LEGACY_SERIALIZER;
/*     */ 
/*     */   
/*     */   private static final GsonComponentSerializer GSON_SERIALIZER;
/*     */ 
/*     */   
/*  60 */   static final ComponentFlattener FLATTENER = FacetComponentFlattener.get(Bukkit.getServer(), TRANSLATORS); static {
/*  61 */     if (IS_1_16) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  66 */       LEGACY_SERIALIZER = LegacyComponentSerializer.builder().hexColors().useUnusualXRepeatedCharacterHexFormat().flattener(FLATTENER).build();
/*     */ 
/*     */       
/*  69 */       GSON_SERIALIZER = GsonComponentSerializer.builder().legacyHoverEventSerializer(NBTLegacyHoverEventSerializer.get()).build();
/*     */     
/*     */     }
/*     */     else {
/*     */       
/*  74 */       LEGACY_SERIALIZER = LegacyComponentSerializer.builder().character('§').flattener(FLATTENER).build();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  79 */       GSON_SERIALIZER = GsonComponentSerializer.builder().legacyHoverEventSerializer(NBTLegacyHoverEventSerializer.get()).emitLegacyHoverEvent().downsampleColors().build();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public static LegacyComponentSerializer legacy() {
/*  90 */     return LEGACY_SERIALIZER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public static GsonComponentSerializer gson() {
/* 102 */     return GSON_SERIALIZER;
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\kyori\adventure\platform\bukkit\BukkitComponentSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */