/*     */ package net.kyori.adventure.platform.bukkit;
/*     */ 
/*     */ import com.google.common.collect.ImmutableList;
/*     */ import com.google.common.graph.MutableGraph;
/*     */ import java.lang.invoke.MethodHandle;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.logging.Level;
/*     */ import net.kyori.adventure.audience.Audience;
/*     */ import net.kyori.adventure.identity.Identity;
/*     */ import net.kyori.adventure.platform.AudienceProvider;
/*     */ import net.kyori.adventure.platform.facet.FacetAudience;
/*     */ import net.kyori.adventure.platform.facet.FacetAudienceProvider;
/*     */ import net.kyori.adventure.platform.facet.Knob;
/*     */ import net.kyori.adventure.pointer.Pointered;
/*     */ import net.kyori.adventure.text.flattener.ComponentFlattener;
/*     */ import net.kyori.adventure.text.renderer.ComponentRenderer;
/*     */ import net.kyori.adventure.translation.GlobalTranslator;
/*     */ import net.kyori.adventure.translation.Translator;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.command.ConsoleCommandSender;
/*     */ import org.bukkit.command.ProxiedCommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.event.EventException;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.player.PlayerEvent;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.event.player.PlayerQuitEvent;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.PluginDescriptionFile;
/*     */ import org.bukkit.plugin.PluginManager;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class BukkitAudiencesImpl
/*     */   extends FacetAudienceProvider<CommandSender, BukkitAudience>
/*     */   implements BukkitAudiences, Listener
/*     */ {
/*     */   static {
/*  78 */     Knob.OUT = (message -> Bukkit.getLogger().log(Level.INFO, message));
/*  79 */     Knob.ERR = ((message, error) -> Bukkit.getLogger().log(Level.WARNING, message, error));
/*     */   }
/*     */   
/*  82 */   private static final Map<String, BukkitAudiences> INSTANCES = Collections.synchronizedMap(new HashMap<>(4));
/*     */   
/*     */   static Builder builder(@NotNull Plugin plugin) {
/*  85 */     return new Builder(plugin);
/*     */   }
/*     */   private final Plugin plugin;
/*     */   static BukkitAudiences instanceFor(@NotNull Plugin plugin) {
/*  89 */     return builder(plugin).build();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   BukkitAudiencesImpl(@NotNull Plugin plugin, @NotNull ComponentRenderer<Pointered> componentRenderer) {
/*  95 */     super(componentRenderer);
/*  96 */     this.plugin = Objects.<Plugin>requireNonNull(plugin, "plugin");
/*     */     
/*  98 */     ConsoleCommandSender consoleCommandSender = this.plugin.getServer().getConsoleSender();
/*  99 */     addViewer(consoleCommandSender);
/*     */     
/* 101 */     for (Player player : this.plugin.getServer().getOnlinePlayers()) {
/* 102 */       addViewer(player);
/*     */     }
/*     */     
/* 105 */     registerEvent(PlayerJoinEvent.class, EventPriority.LOWEST, event -> addViewer(event.getPlayer()));
/*     */     
/* 107 */     registerEvent(PlayerQuitEvent.class, EventPriority.MONITOR, event -> removeViewer(event.getPlayer()));
/*     */   }
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public Audience sender(@NotNull CommandSender sender) {
/* 113 */     if (sender instanceof Player)
/* 114 */       return player((Player)sender); 
/* 115 */     if (sender instanceof ConsoleCommandSender)
/* 116 */       return console(); 
/* 117 */     if (sender instanceof ProxiedCommandSender)
/* 118 */       return sender(((ProxiedCommandSender)sender).getCallee()); 
/* 119 */     if (sender instanceof org.bukkit.entity.Entity || sender instanceof org.bukkit.block.Block) {
/* 120 */       return Audience.empty();
/*     */     }
/* 122 */     return (Audience)createAudience(Collections.singletonList(sender));
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Audience player(@NotNull Player player) {
/* 127 */     return player(player.getUniqueId());
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   protected BukkitAudience createAudience(@NotNull Collection<CommandSender> viewers) {
/* 132 */     return new BukkitAudience(this.plugin, this, viewers);
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/* 137 */     INSTANCES.remove(this.plugin.getName());
/* 138 */     super.close();
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public ComponentFlattener flattener() {
/* 143 */     return BukkitComponentSerializer.FLATTENER;
/*     */   }
/*     */   
/*     */   static final class Builder implements BukkitAudiences.Builder { @NotNull
/*     */     private final Plugin plugin;
/*     */     private ComponentRenderer<Pointered> componentRenderer;
/*     */     
/*     */     Builder(@NotNull Plugin plugin) {
/* 151 */       this.plugin = Objects.<Plugin>requireNonNull(plugin, "plugin");
/* 152 */       componentRenderer(ptr -> (Locale)ptr.getOrDefault(Identity.LOCALE, BukkitAudiencesImpl.DEFAULT_LOCALE), (ComponentRenderer)GlobalTranslator.renderer());
/*     */     }
/*     */     
/*     */     @NotNull
/*     */     public Builder componentRenderer(@NotNull ComponentRenderer<Pointered> componentRenderer) {
/* 157 */       this.componentRenderer = Objects.<ComponentRenderer<Pointered>>requireNonNull(componentRenderer, "component renderer");
/* 158 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public BukkitAudiences.Builder partition(@NotNull Function<Pointered, ?> partitionFunction) {
/* 163 */       Objects.requireNonNull(partitionFunction, "partitionFunction");
/* 164 */       return this;
/*     */     }
/*     */     
/*     */     @NotNull
/*     */     public BukkitAudiences build() {
/* 169 */       return BukkitAudiencesImpl.INSTANCES.computeIfAbsent(this.plugin.getName(), name -> {
/*     */             softDepend("ViaVersion");
/*     */             return new BukkitAudiencesImpl(this.plugin, this.componentRenderer);
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void softDepend(@NotNull String pluginName) {
/* 188 */       PluginDescriptionFile file = this.plugin.getDescription();
/* 189 */       if (file.getName().equals(pluginName))
/*     */         return; 
/*     */       try {
/* 192 */         Field softDepend = MinecraftReflection.needField(file.getClass(), "softDepend");
/* 193 */         List<String> dependencies = (List<String>)softDepend.get(file);
/* 194 */         if (!dependencies.contains(pluginName)) {
/* 195 */           ImmutableList immutableList = ImmutableList.builder().addAll(dependencies).add(pluginName).build();
/* 196 */           softDepend.set(file, immutableList);
/*     */         } 
/* 198 */       } catch (Throwable error) {
/* 199 */         Knob.logError(error, "Failed to inject softDepend in plugin.yml: %s %s", new Object[] { this.plugin, pluginName });
/*     */       } 
/*     */       
/*     */       try {
/* 203 */         PluginManager manager = this.plugin.getServer().getPluginManager();
/* 204 */         Field dependencyGraphField = MinecraftReflection.needField(manager.getClass(), "dependencyGraph");
/* 205 */         MutableGraph<String> graph = (MutableGraph<String>)dependencyGraphField.get(manager);
/* 206 */         graph.putEdge(file.getName(), pluginName);
/* 207 */       } catch (Throwable throwable) {}
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T extends Event> void registerEvent(@NotNull Class<T> type, @NotNull EventPriority priority, @NotNull Consumer<T> callback) {
/* 225 */     Objects.requireNonNull(callback, "callback");
/* 226 */     this.plugin.getServer().getPluginManager().registerEvent(type, this, priority, (listener, event) -> callback.accept(event), this.plugin, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void registerLocaleEvent(EventPriority priority, @NotNull BiConsumer<Player, Locale> callback) {
/* 239 */     Class<?> eventClass = MinecraftReflection.findClass(new String[] { "org.bukkit.event.player.PlayerLocaleChangeEvent" });
/* 240 */     if (eventClass == null) {
/* 241 */       eventClass = MinecraftReflection.findClass(new String[] { "com.destroystokyo.paper.event.player.PlayerLocaleChangeEvent" });
/*     */     }
/*     */     
/* 244 */     MethodHandle getMethod = MinecraftReflection.findMethod(eventClass, "getLocale", String.class, new Class[0]);
/* 245 */     if (getMethod == null) {
/* 246 */       getMethod = MinecraftReflection.findMethod(eventClass, "getNewLocale", String.class, new Class[0]);
/*     */     }
/*     */     
/* 249 */     if (getMethod != null && PlayerEvent.class.isAssignableFrom(eventClass)) {
/* 250 */       Class<? extends PlayerEvent> localeEvent = (Class)eventClass;
/* 251 */       MethodHandle getLocale = getMethod;
/*     */       
/* 253 */       registerEvent(localeEvent, priority, event -> {
/*     */             String locale;
/*     */             Player player = event.getPlayer();
/*     */             try {
/*     */               locale = getLocale.invoke(event);
/* 258 */             } catch (Throwable error) {
/*     */               Knob.logError(error, "Failed to accept %s: %s", new Object[] { localeEvent.getName(), player });
/*     */               return;
/*     */             } 
/*     */             callback.accept(player, toLocale(locale));
/*     */           });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   private static Locale toLocale(@Nullable String string) {
/* 274 */     if (string != null) {
/* 275 */       Locale locale = Translator.parseLocale(string);
/* 276 */       if (locale != null) {
/* 277 */         return locale;
/*     */       }
/*     */     } 
/* 280 */     return Locale.US;
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\kyori\adventure\platform\bukkit\BukkitAudiencesImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */