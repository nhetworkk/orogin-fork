/*    */ package net.kyori.adventure.platform.bukkit;
/*    */ 
/*    */ import net.kyori.adventure.sound.Sound;
/*    */ import org.bukkit.entity.Entity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class BukkitEmitter
/*    */   implements Sound.Emitter
/*    */ {
/*    */   final Entity entity;
/*    */   
/*    */   BukkitEmitter(Entity entity) {
/* 33 */     this.entity = entity;
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\net\kyori\adventure\platform\bukkit\BukkitEmitter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */