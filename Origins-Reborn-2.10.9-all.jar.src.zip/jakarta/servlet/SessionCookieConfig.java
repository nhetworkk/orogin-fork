package jakarta.servlet;

public interface SessionCookieConfig {
  void setName(String paramString);
  
  String getName();
  
  void setDomain(String paramString);
  
  String getDomain();
  
  void setPath(String paramString);
  
  String getPath();
  
  void setComment(String paramString);
  
  String getComment();
  
  void setHttpOnly(boolean paramBoolean);
  
  boolean isHttpOnly();
  
  void setSecure(boolean paramBoolean);
  
  boolean isSecure();
  
  void setMaxAge(int paramInt);
  
  int getMaxAge();
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\SessionCookieConfig.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */