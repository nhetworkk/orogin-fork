package jakarta.servlet.annotation;

import jakarta.servlet.DispatcherType;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface WebFilter {
  String description() default "";
  
  String displayName() default "";
  
  WebInitParam[] initParams() default {};
  
  String filterName() default "";
  
  String smallIcon() default "";
  
  String largeIcon() default "";
  
  String[] servletNames() default {};
  
  String[] value() default {};
  
  String[] urlPatterns() default {};
  
  DispatcherType[] dispatcherTypes() default {DispatcherType.REQUEST};
  
  boolean asyncSupported() default false;
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\annotation\WebFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */