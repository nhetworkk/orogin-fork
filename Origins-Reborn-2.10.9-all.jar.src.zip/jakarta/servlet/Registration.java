package jakarta.servlet;

import java.util.Map;
import java.util.Set;

public interface Registration {
  String getName();
  
  String getClassName();
  
  boolean setInitParameter(String paramString1, String paramString2);
  
  String getInitParameter(String paramString);
  
  Set<String> setInitParameters(Map<String, String> paramMap);
  
  Map<String, String> getInitParameters();
  
  public static interface Dynamic extends Registration {
    void setAsyncSupported(boolean param1Boolean);
  }
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\Registration.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */