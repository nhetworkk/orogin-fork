package jakarta.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Locale;

public interface ServletResponse {
  String getCharacterEncoding();
  
  String getContentType();
  
  ServletOutputStream getOutputStream() throws IOException;
  
  PrintWriter getWriter() throws IOException;
  
  void setCharacterEncoding(String paramString);
  
  void setContentLength(int paramInt);
  
  void setContentLengthLong(long paramLong);
  
  void setContentType(String paramString);
  
  void setBufferSize(int paramInt);
  
  int getBufferSize();
  
  void flushBuffer() throws IOException;
  
  void resetBuffer();
  
  boolean isCommitted();
  
  void reset();
  
  void setLocale(Locale paramLocale);
  
  Locale getLocale();
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\ServletResponse.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */