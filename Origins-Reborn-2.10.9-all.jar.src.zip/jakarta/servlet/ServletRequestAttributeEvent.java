/*    */ package jakarta.servlet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServletRequestAttributeEvent
/*    */   extends ServletRequestEvent
/*    */ {
/*    */   private static final long serialVersionUID = -1466635426192317793L;
/*    */   private String name;
/*    */   private Object value;
/*    */   
/*    */   public ServletRequestAttributeEvent(ServletContext sc, ServletRequest request, String name, Object value) {
/* 44 */     super(sc, request);
/* 45 */     this.name = name;
/* 46 */     this.value = value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 55 */     return this.name;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getValue() {
/* 66 */     return this.value;
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\ServletRequestAttributeEvent.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */