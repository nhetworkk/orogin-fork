package jakarta.servlet;

import java.util.EventListener;

public interface ServletContextListener extends EventListener {
  default void contextInitialized(ServletContextEvent sce) {}
  
  default void contextDestroyed(ServletContextEvent sce) {}
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\ServletContextListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */