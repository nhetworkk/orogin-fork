package jakarta.servlet;

import java.io.IOException;

public interface Servlet {
  void init(ServletConfig paramServletConfig) throws ServletException;
  
  ServletConfig getServletConfig();
  
  void service(ServletRequest paramServletRequest, ServletResponse paramServletResponse) throws ServletException, IOException;
  
  String getServletInfo();
  
  void destroy();
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\Servlet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */