package jakarta.servlet;

import java.io.IOException;
import java.util.EventListener;

public interface AsyncListener extends EventListener {
  void onComplete(AsyncEvent paramAsyncEvent) throws IOException;
  
  void onTimeout(AsyncEvent paramAsyncEvent) throws IOException;
  
  void onError(AsyncEvent paramAsyncEvent) throws IOException;
  
  void onStartAsync(AsyncEvent paramAsyncEvent) throws IOException;
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\AsyncListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */