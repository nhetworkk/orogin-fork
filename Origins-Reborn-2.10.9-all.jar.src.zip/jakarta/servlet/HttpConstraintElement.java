/*     */ package jakarta.servlet;
/*     */ 
/*     */ import jakarta.servlet.annotation.ServletSecurity;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpConstraintElement
/*     */ {
/*     */   private ServletSecurity.EmptyRoleSemantic emptyRoleSemantic;
/*     */   private ServletSecurity.TransportGuarantee transportGuarantee;
/*     */   private String[] rolesAllowed;
/*     */   
/*     */   public HttpConstraintElement() {
/*  39 */     this(ServletSecurity.EmptyRoleSemantic.PERMIT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConstraintElement(ServletSecurity.EmptyRoleSemantic semantic) {
/*  48 */     this(semantic, ServletSecurity.TransportGuarantee.NONE, new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConstraintElement(ServletSecurity.TransportGuarantee guarantee, String... roleNames) {
/*  58 */     this(ServletSecurity.EmptyRoleSemantic.PERMIT, guarantee, roleNames);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConstraintElement(ServletSecurity.EmptyRoleSemantic semantic, ServletSecurity.TransportGuarantee guarantee, String... roleNames) {
/*  70 */     if (semantic == ServletSecurity.EmptyRoleSemantic.DENY && roleNames.length > 0) {
/*  71 */       throw new IllegalArgumentException("Deny semantic with rolesAllowed");
/*     */     }
/*  73 */     this.emptyRoleSemantic = semantic;
/*  74 */     this.transportGuarantee = guarantee;
/*  75 */     this.rolesAllowed = copyStrings(roleNames);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletSecurity.EmptyRoleSemantic getEmptyRoleSemantic() {
/*  89 */     return this.emptyRoleSemantic;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletSecurity.TransportGuarantee getTransportGuarantee() {
/*  99 */     return this.transportGuarantee;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getRolesAllowed() {
/* 117 */     return copyStrings(this.rolesAllowed);
/*     */   }
/*     */   
/*     */   private String[] copyStrings(String[] strings) {
/* 121 */     String[] arr = null;
/* 122 */     if (strings != null) {
/* 123 */       int len = strings.length;
/* 124 */       arr = new String[len];
/* 125 */       if (len > 0) {
/* 126 */         System.arraycopy(strings, 0, arr, 0, len);
/*     */       }
/*     */     } 
/*     */     
/* 130 */     return (arr != null) ? arr : new String[0];
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\HttpConstraintElement.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */