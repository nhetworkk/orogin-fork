package jakarta.servlet;

import java.util.Collection;
import java.util.EnumSet;

public interface FilterRegistration extends Registration {
  void addMappingForServletNames(EnumSet<DispatcherType> paramEnumSet, boolean paramBoolean, String... paramVarArgs);
  
  Collection<String> getServletNameMappings();
  
  void addMappingForUrlPatterns(EnumSet<DispatcherType> paramEnumSet, boolean paramBoolean, String... paramVarArgs);
  
  Collection<String> getUrlPatternMappings();
  
  public static interface Dynamic extends FilterRegistration, Registration.Dynamic {}
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\FilterRegistration.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */