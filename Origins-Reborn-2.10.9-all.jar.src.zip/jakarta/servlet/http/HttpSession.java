package jakarta.servlet.http;

import jakarta.servlet.ServletContext;
import java.util.Enumeration;

public interface HttpSession {
  long getCreationTime();
  
  String getId();
  
  long getLastAccessedTime();
  
  ServletContext getServletContext();
  
  void setMaxInactiveInterval(int paramInt);
  
  int getMaxInactiveInterval();
  
  @Deprecated
  HttpSessionContext getSessionContext();
  
  Object getAttribute(String paramString);
  
  @Deprecated
  Object getValue(String paramString);
  
  Enumeration<String> getAttributeNames();
  
  @Deprecated
  String[] getValueNames();
  
  void setAttribute(String paramString, Object paramObject);
  
  @Deprecated
  void putValue(String paramString, Object paramObject);
  
  void removeAttribute(String paramString);
  
  @Deprecated
  void removeValue(String paramString);
  
  void invalidate();
  
  boolean isNew();
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\http\HttpSession.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */