package jakarta.servlet.http;

import jakarta.servlet.ServletInputStream;
import jakarta.servlet.ServletOutputStream;
import java.io.IOException;

public interface WebConnection extends AutoCloseable {
  ServletInputStream getInputStream() throws IOException;
  
  ServletOutputStream getOutputStream() throws IOException;
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\http\WebConnection.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */