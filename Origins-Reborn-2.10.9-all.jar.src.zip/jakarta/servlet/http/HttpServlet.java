/*     */ package jakarta.servlet.http;
/*     */ 
/*     */ import jakarta.servlet.GenericServlet;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletOutputStream;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Enumeration;
/*     */ import java.util.ResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class HttpServlet
/*     */   extends GenericServlet
/*     */ {
/*     */   private static final long serialVersionUID = 8466325577512134784L;
/*     */   private static final String METHOD_DELETE = "DELETE";
/*     */   private static final String METHOD_HEAD = "HEAD";
/*     */   private static final String METHOD_GET = "GET";
/*     */   private static final String METHOD_OPTIONS = "OPTIONS";
/*     */   private static final String METHOD_POST = "POST";
/*     */   private static final String METHOD_PUT = "PUT";
/*     */   private static final String METHOD_TRACE = "TRACE";
/*     */   private static final String HEADER_IFMODSINCE = "If-Modified-Since";
/*     */   private static final String HEADER_LASTMOD = "Last-Modified";
/*     */   private static final String LSTRING_FILE = "jakarta.servlet.http.LocalStrings";
/*  82 */   private static ResourceBundle lStrings = ResourceBundle.getBundle("jakarta.servlet.http.LocalStrings");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/* 144 */     String protocol = req.getProtocol();
/* 145 */     String msg = lStrings.getString("http.method_get_not_supported");
/* 146 */     resp.sendError(getMethodNotSupportedCode(protocol), msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected long getLastModified(HttpServletRequest req) {
/* 164 */     return -1L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doHead(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/* 192 */     NoBodyResponse response = new NoBodyResponse(resp);
/*     */     
/* 194 */     doGet(req, response);
/* 195 */     response.setContentLength();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/* 245 */     String protocol = req.getProtocol();
/* 246 */     String msg = lStrings.getString("http.method_post_not_supported");
/* 247 */     resp.sendError(getMethodNotSupportedCode(protocol), msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/* 279 */     String protocol = req.getProtocol();
/* 280 */     String msg = lStrings.getString("http.method_put_not_supported");
/* 281 */     resp.sendError(getMethodNotSupportedCode(protocol), msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/* 306 */     String protocol = req.getProtocol();
/* 307 */     String msg = lStrings.getString("http.method_delete_not_supported");
/* 308 */     resp.sendError(getMethodNotSupportedCode(protocol), msg);
/*     */   }
/*     */   
/*     */   private int getMethodNotSupportedCode(String protocol) {
/* 312 */     switch (protocol) {
/*     */       case "HTTP/0.9":
/*     */       case "HTTP/1.0":
/* 315 */         return 400;
/*     */     } 
/* 317 */     return 405;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Method[] getAllDeclaredMethods(Class<? extends HttpServlet> c) {
/* 323 */     Class<?> clazz = c;
/* 324 */     Method[] allMethods = null;
/*     */     
/* 326 */     while (!clazz.equals(HttpServlet.class)) {
/* 327 */       Method[] thisMethods = clazz.getDeclaredMethods();
/* 328 */       if (allMethods != null && allMethods.length > 0) {
/* 329 */         Method[] subClassMethods = allMethods;
/* 330 */         allMethods = new Method[thisMethods.length + subClassMethods.length];
/* 331 */         System.arraycopy(thisMethods, 0, allMethods, 0, thisMethods.length);
/* 332 */         System.arraycopy(subClassMethods, 0, allMethods, thisMethods.length, subClassMethods.length);
/*     */       } else {
/* 334 */         allMethods = thisMethods;
/*     */       } 
/*     */       
/* 337 */       clazz = clazz.getSuperclass();
/*     */     } 
/*     */     
/* 340 */     return (allMethods != null) ? allMethods : new Method[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doOptions(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/* 365 */     Method[] methods = getAllDeclaredMethods((Class)getClass());
/*     */     
/* 367 */     boolean ALLOW_GET = false;
/* 368 */     boolean ALLOW_HEAD = false;
/* 369 */     boolean ALLOW_POST = false;
/* 370 */     boolean ALLOW_PUT = false;
/* 371 */     boolean ALLOW_DELETE = false;
/* 372 */     boolean ALLOW_TRACE = true;
/* 373 */     boolean ALLOW_OPTIONS = true;
/*     */     
/* 375 */     for (int i = 0; i < methods.length; i++) {
/* 376 */       String methodName = methods[i].getName();
/*     */       
/* 378 */       if (methodName.equals("doGet")) {
/* 379 */         ALLOW_GET = true;
/* 380 */         ALLOW_HEAD = true;
/* 381 */       } else if (methodName.equals("doPost")) {
/* 382 */         ALLOW_POST = true;
/* 383 */       } else if (methodName.equals("doPut")) {
/* 384 */         ALLOW_PUT = true;
/* 385 */       } else if (methodName.equals("doDelete")) {
/* 386 */         ALLOW_DELETE = true;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 393 */     StringBuilder allow = new StringBuilder();
/* 394 */     if (ALLOW_GET) {
/* 395 */       allow.append("GET");
/*     */     }
/* 397 */     if (ALLOW_HEAD) {
/* 398 */       if (allow.length() > 0) {
/* 399 */         allow.append(", ");
/*     */       }
/* 401 */       allow.append("HEAD");
/*     */     } 
/* 403 */     if (ALLOW_POST) {
/* 404 */       if (allow.length() > 0) {
/* 405 */         allow.append(", ");
/*     */       }
/* 407 */       allow.append("POST");
/*     */     } 
/* 409 */     if (ALLOW_PUT) {
/* 410 */       if (allow.length() > 0) {
/* 411 */         allow.append(", ");
/*     */       }
/* 413 */       allow.append("PUT");
/*     */     } 
/* 415 */     if (ALLOW_DELETE) {
/* 416 */       if (allow.length() > 0) {
/* 417 */         allow.append(", ");
/*     */       }
/* 419 */       allow.append("DELETE");
/*     */     } 
/* 421 */     if (ALLOW_TRACE) {
/* 422 */       if (allow.length() > 0) {
/* 423 */         allow.append(", ");
/*     */       }
/* 425 */       allow.append("TRACE");
/*     */     } 
/* 427 */     if (ALLOW_OPTIONS) {
/* 428 */       if (allow.length() > 0) {
/* 429 */         allow.append(", ");
/*     */       }
/* 431 */       allow.append("OPTIONS");
/*     */     } 
/*     */     
/* 434 */     resp.setHeader("Allow", allow.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doTrace(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/* 456 */     String CRLF = "\r\n";
/*     */     
/* 458 */     StringBuilder buffer = (new StringBuilder("TRACE ")).append(req.getRequestURI()).append(" ").append(req.getProtocol());
/*     */     
/* 460 */     Enumeration<String> reqHeaderEnum = req.getHeaderNames();
/*     */     
/* 462 */     while (reqHeaderEnum.hasMoreElements()) {
/* 463 */       String headerName = reqHeaderEnum.nextElement();
/* 464 */       buffer.append(CRLF).append(headerName).append(": ").append(req.getHeader(headerName));
/*     */     } 
/*     */     
/* 467 */     buffer.append(CRLF);
/*     */     
/* 469 */     int responseLength = buffer.length();
/*     */     
/* 471 */     resp.setContentType("message/http");
/* 472 */     resp.setContentLength(responseLength);
/* 473 */     ServletOutputStream out = resp.getOutputStream();
/* 474 */     out.print(buffer.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/* 493 */     String method = req.getMethod();
/*     */     
/* 495 */     if (method.equals("GET")) {
/* 496 */       long lastModified = getLastModified(req);
/* 497 */       if (lastModified == -1L) {
/*     */ 
/*     */         
/* 500 */         doGet(req, resp);
/*     */       } else {
/* 502 */         long ifModifiedSince = req.getDateHeader("If-Modified-Since");
/* 503 */         if (ifModifiedSince < lastModified) {
/*     */ 
/*     */ 
/*     */           
/* 507 */           maybeSetLastModified(resp, lastModified);
/* 508 */           doGet(req, resp);
/*     */         } else {
/* 510 */           resp.setStatus(304);
/*     */         }
/*     */       
/*     */       } 
/* 514 */     } else if (method.equals("HEAD")) {
/* 515 */       long lastModified = getLastModified(req);
/* 516 */       maybeSetLastModified(resp, lastModified);
/* 517 */       doHead(req, resp);
/*     */     }
/* 519 */     else if (method.equals("POST")) {
/* 520 */       doPost(req, resp);
/*     */     }
/* 522 */     else if (method.equals("PUT")) {
/* 523 */       doPut(req, resp);
/*     */     }
/* 525 */     else if (method.equals("DELETE")) {
/* 526 */       doDelete(req, resp);
/*     */     }
/* 528 */     else if (method.equals("OPTIONS")) {
/* 529 */       doOptions(req, resp);
/*     */     }
/* 531 */     else if (method.equals("TRACE")) {
/* 532 */       doTrace(req, resp);
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */       
/* 540 */       String errMsg = lStrings.getString("http.method_not_implemented");
/* 541 */       Object[] errArgs = new Object[1];
/* 542 */       errArgs[0] = method;
/* 543 */       errMsg = MessageFormat.format(errMsg, errArgs);
/*     */       
/* 545 */       resp.sendError(501, errMsg);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void maybeSetLastModified(HttpServletResponse resp, long lastModified) {
/* 555 */     if (resp.containsHeader("Last-Modified"))
/*     */       return; 
/* 557 */     if (lastModified >= 0L) {
/* 558 */       resp.setDateHeader("Last-Modified", lastModified);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
/* 580 */     if (!(req instanceof HttpServletRequest) || !(res instanceof HttpServletResponse)) {
/* 581 */       throw new ServletException("non-HTTP request or response");
/*     */     }
/*     */     
/* 584 */     HttpServletRequest request = (HttpServletRequest)req;
/* 585 */     HttpServletResponse response = (HttpServletResponse)res;
/*     */     
/* 587 */     service(request, response);
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\http\HttpServlet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */