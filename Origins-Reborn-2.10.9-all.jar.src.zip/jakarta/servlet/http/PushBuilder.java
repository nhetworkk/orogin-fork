package jakarta.servlet.http;

import java.util.Set;

public interface PushBuilder {
  PushBuilder method(String paramString);
  
  PushBuilder queryString(String paramString);
  
  PushBuilder sessionId(String paramString);
  
  PushBuilder setHeader(String paramString1, String paramString2);
  
  PushBuilder addHeader(String paramString1, String paramString2);
  
  PushBuilder removeHeader(String paramString);
  
  PushBuilder path(String paramString);
  
  void push();
  
  String getMethod();
  
  String getQueryString();
  
  String getSessionId();
  
  Set<String> getHeaderNames();
  
  String getHeader(String paramString);
  
  String getPath();
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\http\PushBuilder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */