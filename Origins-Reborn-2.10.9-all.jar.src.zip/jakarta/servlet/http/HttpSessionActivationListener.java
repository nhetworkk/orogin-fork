package jakarta.servlet.http;

import java.util.EventListener;

public interface HttpSessionActivationListener extends EventListener {
  default void sessionWillPassivate(HttpSessionEvent se) {}
  
  default void sessionDidActivate(HttpSessionEvent se) {}
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\http\HttpSessionActivationListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */