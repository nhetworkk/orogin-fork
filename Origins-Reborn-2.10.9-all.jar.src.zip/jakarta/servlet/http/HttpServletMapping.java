package jakarta.servlet.http;

public interface HttpServletMapping {
  String getMatchValue();
  
  String getPattern();
  
  String getServletName();
  
  MappingMatch getMappingMatch();
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\http\HttpServletMapping.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */