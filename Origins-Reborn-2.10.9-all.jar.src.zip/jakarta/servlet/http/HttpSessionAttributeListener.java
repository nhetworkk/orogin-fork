package jakarta.servlet.http;

import java.util.EventListener;

public interface HttpSessionAttributeListener extends EventListener {
  default void attributeAdded(HttpSessionBindingEvent event) {}
  
  default void attributeRemoved(HttpSessionBindingEvent event) {}
  
  default void attributeReplaced(HttpSessionBindingEvent event) {}
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\http\HttpSessionAttributeListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */