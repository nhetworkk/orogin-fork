package jakarta.servlet.http;

import java.util.EventListener;

public interface HttpSessionBindingListener extends EventListener {
  default void valueBound(HttpSessionBindingEvent event) {}
  
  default void valueUnbound(HttpSessionBindingEvent event) {}
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\http\HttpSessionBindingListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */