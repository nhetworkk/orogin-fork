package jakarta.servlet.http;

import java.util.Enumeration;

@Deprecated
public interface HttpSessionContext {
  @Deprecated
  HttpSession getSession(String paramString);
  
  @Deprecated
  Enumeration<String> getIds();
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\http\HttpSessionContext.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */