/*     */ package jakarta.servlet.http;
/*     */ 
/*     */ import jakarta.servlet.ServletInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Hashtable;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class HttpUtils
/*     */ {
/*     */   private static final String LSTRING_FILE = "jakarta.servlet.http.LocalStrings";
/*  36 */   private static ResourceBundle lStrings = ResourceBundle.getBundle("jakarta.servlet.http.LocalStrings");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Hashtable<String, String[]> parseQueryString(String s) {
/*  65 */     String[] valArray = null;
/*     */     
/*  67 */     if (s == null) {
/*  68 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/*  71 */     Hashtable<String, String[]> ht = (Hashtable)new Hashtable<>();
/*  72 */     StringBuilder sb = new StringBuilder();
/*  73 */     StringTokenizer st = new StringTokenizer(s, "&");
/*  74 */     while (st.hasMoreTokens()) {
/*  75 */       String pair = st.nextToken();
/*  76 */       int pos = pair.indexOf('=');
/*  77 */       if (pos == -1)
/*     */       {
/*     */         
/*  80 */         throw new IllegalArgumentException();
/*     */       }
/*  82 */       String key = parseName(pair.substring(0, pos), sb);
/*  83 */       String val = parseName(pair.substring(pos + 1, pair.length()), sb);
/*  84 */       if (ht.containsKey(key)) {
/*  85 */         String[] oldVals = ht.get(key);
/*  86 */         valArray = new String[oldVals.length + 1];
/*  87 */         for (int i = 0; i < oldVals.length; i++) {
/*  88 */           valArray[i] = oldVals[i];
/*     */         }
/*  90 */         valArray[oldVals.length] = val;
/*     */       } else {
/*  92 */         valArray = new String[1];
/*  93 */         valArray[0] = val;
/*     */       } 
/*  95 */       ht.put(key, valArray);
/*     */     } 
/*     */     
/*  98 */     return ht;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Hashtable<String, String[]> parsePostData(int len, ServletInputStream in) {
/* 128 */     if (len <= 0)
/*     */     {
/* 130 */       return (Hashtable)new Hashtable<>();
/*     */     }
/*     */     
/* 133 */     if (in == null) {
/* 134 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 140 */     byte[] postedBytes = new byte[len];
/*     */     try {
/* 142 */       int offset = 0;
/*     */       
/*     */       do {
/* 145 */         int inputLen = in.read(postedBytes, offset, len - offset);
/* 146 */         if (inputLen <= 0) {
/* 147 */           String msg = lStrings.getString("err.io.short_read");
/* 148 */           throw new IllegalArgumentException(msg);
/*     */         } 
/* 150 */         offset += inputLen;
/* 151 */       } while (len - offset > 0);
/*     */     }
/* 153 */     catch (IOException e) {
/* 154 */       throw new IllegalArgumentException(e.getMessage());
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 163 */       String postedBody = new String(postedBytes, 0, len, "8859_1");
/* 164 */       return parseQueryString(postedBody);
/* 165 */     } catch (UnsupportedEncodingException e) {
/*     */ 
/*     */       
/* 168 */       throw new IllegalArgumentException(e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String parseName(String s, StringBuilder sb) {
/* 176 */     sb.setLength(0);
/* 177 */     for (int i = 0; i < s.length(); i++) {
/* 178 */       char c = s.charAt(i);
/* 179 */       switch (c) {
/*     */         case '+':
/* 181 */           sb.append(' ');
/*     */           break;
/*     */         case '%':
/*     */           try {
/* 185 */             sb.append((char)Integer.parseInt(s.substring(i + 1, i + 3), 16));
/* 186 */             i += 2;
/* 187 */           } catch (NumberFormatException e) {
/*     */ 
/*     */             
/* 190 */             throw new IllegalArgumentException();
/* 191 */           } catch (StringIndexOutOfBoundsException e) {
/* 192 */             String rest = s.substring(i);
/* 193 */             sb.append(rest);
/* 194 */             if (rest.length() == 2) {
/* 195 */               i++;
/*     */             }
/*     */           } 
/*     */           break;
/*     */         default:
/* 200 */           sb.append(c);
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/* 205 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StringBuffer getRequestURL(HttpServletRequest req) {
/* 226 */     StringBuffer url = new StringBuffer();
/* 227 */     String scheme = req.getScheme();
/* 228 */     int port = req.getServerPort();
/* 229 */     String urlPath = req.getRequestURI();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 234 */     url.append(scheme);
/* 235 */     url.append("://");
/* 236 */     url.append(req.getServerName());
/* 237 */     if ((scheme.equals("http") && port != 80) || (scheme.equals("https") && port != 443)) {
/* 238 */       url.append(':');
/* 239 */       url.append(req.getServerPort());
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 245 */     url.append(urlPath);
/*     */     
/* 247 */     return url;
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\http\HttpUtils.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */