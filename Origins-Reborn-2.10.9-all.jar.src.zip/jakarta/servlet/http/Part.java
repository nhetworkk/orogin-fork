package jakarta.servlet.http;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;

public interface Part {
  InputStream getInputStream() throws IOException;
  
  String getContentType();
  
  String getName();
  
  String getSubmittedFileName();
  
  long getSize();
  
  void write(String paramString) throws IOException;
  
  void delete() throws IOException;
  
  String getHeader(String paramString);
  
  Collection<String> getHeaders(String paramString);
  
  Collection<String> getHeaderNames();
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\http\Part.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */