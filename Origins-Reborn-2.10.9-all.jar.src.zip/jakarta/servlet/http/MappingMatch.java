/*    */ package jakarta.servlet.http;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum MappingMatch
/*    */ {
/* 33 */   CONTEXT_ROOT,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 40 */   DEFAULT,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 46 */   EXACT,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 52 */   EXTENSION,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 58 */   PATH;
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\http\MappingMatch.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */