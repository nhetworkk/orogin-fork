package jakarta.servlet;

import java.util.Enumeration;

public interface ServletConfig {
  String getServletName();
  
  ServletContext getServletContext();
  
  String getInitParameter(String paramString);
  
  Enumeration<String> getInitParameterNames();
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\ServletConfig.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */