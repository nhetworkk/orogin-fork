/*    */ package jakarta.servlet;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ServletInputStream
/*    */   extends InputStream
/*    */ {
/*    */   public int readLine(byte[] b, int off, int len) throws IOException {
/* 76 */     if (len <= 0) {
/* 77 */       return 0;
/*    */     }
/* 79 */     int count = 0;
/*    */     int c;
/* 81 */     while ((c = read()) != -1) {
/* 82 */       b[off++] = (byte)c;
/* 83 */       count++;
/* 84 */       if (c == 10 || count == len) {
/*    */         break;
/*    */       }
/*    */     } 
/* 88 */     return (count > 0) ? count : -1;
/*    */   }
/*    */   
/*    */   public abstract boolean isFinished();
/*    */   
/*    */   public abstract boolean isReady();
/*    */   
/*    */   public abstract void setReadListener(ReadListener paramReadListener);
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\ServletInputStream.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */