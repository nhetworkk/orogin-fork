package jakarta.servlet;

import java.io.IOException;

public interface Filter {
  default void init(FilterConfig filterConfig) throws ServletException {}
  
  void doFilter(ServletRequest paramServletRequest, ServletResponse paramServletResponse, FilterChain paramFilterChain) throws IOException, ServletException;
  
  default void destroy() {}
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\Filter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */