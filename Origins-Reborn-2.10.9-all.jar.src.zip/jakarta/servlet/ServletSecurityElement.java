/*     */ package jakarta.servlet;
/*     */ 
/*     */ import jakarta.servlet.annotation.HttpMethodConstraint;
/*     */ import jakarta.servlet.annotation.ServletSecurity;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletSecurityElement
/*     */   extends HttpConstraintElement
/*     */ {
/*     */   private Collection<String> methodNames;
/*     */   private Collection<HttpMethodConstraintElement> methodConstraints;
/*     */   
/*     */   public ServletSecurityElement() {
/*  39 */     this.methodConstraints = new HashSet<>();
/*  40 */     this.methodNames = Collections.emptySet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletSecurityElement(HttpConstraintElement constraint) {
/*  50 */     super(constraint.getEmptyRoleSemantic(), constraint.getTransportGuarantee(), constraint.getRolesAllowed());
/*  51 */     this.methodConstraints = new HashSet<>();
/*  52 */     this.methodNames = Collections.emptySet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletSecurityElement(Collection<HttpMethodConstraintElement> methodConstraints) {
/*  64 */     this.methodConstraints = (methodConstraints == null) ? new HashSet<>() : methodConstraints;
/*  65 */     this.methodNames = checkMethodNames(this.methodConstraints);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletSecurityElement(HttpConstraintElement constraint, Collection<HttpMethodConstraintElement> methodConstraints) {
/*  80 */     super(constraint.getEmptyRoleSemantic(), constraint.getTransportGuarantee(), constraint.getRolesAllowed());
/*  81 */     this.methodConstraints = (methodConstraints == null) ? new HashSet<>() : methodConstraints;
/*  82 */     this.methodNames = checkMethodNames(this.methodConstraints);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletSecurityElement(ServletSecurity annotation) {
/*  93 */     super(annotation.value().value(), annotation.value().transportGuarantee(), annotation.value().rolesAllowed());
/*  94 */     this.methodConstraints = new HashSet<>();
/*  95 */     for (HttpMethodConstraint constraint : annotation.httpMethodConstraints()) {
/*  96 */       this.methodConstraints.add(new HttpMethodConstraintElement(constraint.value(), new HttpConstraintElement(constraint
/*  97 */               .emptyRoleSemantic(), constraint.transportGuarantee(), constraint.rolesAllowed())));
/*     */     }
/*  99 */     this.methodNames = checkMethodNames(this.methodConstraints);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<HttpMethodConstraintElement> getHttpMethodConstraints() {
/* 113 */     return Collections.unmodifiableCollection(this.methodConstraints);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<String> getMethodNames() {
/* 128 */     return Collections.unmodifiableCollection(this.methodNames);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Collection<String> checkMethodNames(Collection<HttpMethodConstraintElement> methodConstraints) {
/* 141 */     Collection<String> methodNames = new HashSet<>();
/* 142 */     for (HttpMethodConstraintElement methodConstraint : methodConstraints) {
/* 143 */       String methodName = methodConstraint.getMethodName();
/* 144 */       if (!methodNames.add(methodName)) {
/* 145 */         throw new IllegalArgumentException("Duplicate HTTP method name: " + methodName);
/*     */       }
/*     */     } 
/* 148 */     return methodNames;
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\ServletSecurityElement.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */