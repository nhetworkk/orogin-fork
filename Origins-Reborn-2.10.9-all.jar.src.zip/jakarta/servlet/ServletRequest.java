package jakarta.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Map;

public interface ServletRequest {
  Object getAttribute(String paramString);
  
  Enumeration<String> getAttributeNames();
  
  String getCharacterEncoding();
  
  void setCharacterEncoding(String paramString) throws UnsupportedEncodingException;
  
  int getContentLength();
  
  long getContentLengthLong();
  
  String getContentType();
  
  ServletInputStream getInputStream() throws IOException;
  
  String getParameter(String paramString);
  
  Enumeration<String> getParameterNames();
  
  String[] getParameterValues(String paramString);
  
  Map<String, String[]> getParameterMap();
  
  String getProtocol();
  
  String getScheme();
  
  String getServerName();
  
  int getServerPort();
  
  BufferedReader getReader() throws IOException;
  
  String getRemoteAddr();
  
  String getRemoteHost();
  
  void setAttribute(String paramString, Object paramObject);
  
  void removeAttribute(String paramString);
  
  Locale getLocale();
  
  Enumeration<Locale> getLocales();
  
  boolean isSecure();
  
  RequestDispatcher getRequestDispatcher(String paramString);
  
  @Deprecated
  String getRealPath(String paramString);
  
  int getRemotePort();
  
  String getLocalName();
  
  String getLocalAddr();
  
  int getLocalPort();
  
  ServletContext getServletContext();
  
  AsyncContext startAsync() throws IllegalStateException;
  
  AsyncContext startAsync(ServletRequest paramServletRequest, ServletResponse paramServletResponse) throws IllegalStateException;
  
  boolean isAsyncStarted();
  
  boolean isAsyncSupported();
  
  AsyncContext getAsyncContext();
  
  DispatcherType getDispatcherType();
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\ServletRequest.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */