package jakarta.servlet;

import java.util.Collection;
import java.util.Set;

public interface ServletRegistration extends Registration {
  Set<String> addMapping(String... paramVarArgs);
  
  Collection<String> getMappings();
  
  String getRunAsRole();
  
  public static interface Dynamic extends ServletRegistration, Registration.Dynamic {
    void setLoadOnStartup(int param1Int);
    
    Set<String> setServletSecurity(ServletSecurityElement param1ServletSecurityElement);
    
    void setMultipartConfig(MultipartConfigElement param1MultipartConfigElement);
    
    void setRunAsRole(String param1String);
  }
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\ServletRegistration.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */