/*     */ package jakarta.servlet;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Enumeration;
/*     */ import java.util.ResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class GenericFilter
/*     */   implements Filter, FilterConfig, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 4060116231031076581L;
/*     */   private static final String LSTRING_FILE = "jakarta.servlet.LocalStrings";
/*  50 */   private static final ResourceBundle lStrings = ResourceBundle.getBundle("jakarta.servlet.LocalStrings");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private transient FilterConfig config;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInitParameter(String name) {
/*  84 */     FilterConfig fc = getFilterConfig();
/*  85 */     if (fc == null) {
/*  86 */       throw new IllegalStateException(lStrings.getString("err.filter_config_not_initialized"));
/*     */     }
/*     */     
/*  89 */     return fc.getInitParameter(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<String> getInitParameterNames() {
/* 110 */     FilterConfig fc = getFilterConfig();
/* 111 */     if (fc == null) {
/* 112 */       throw new IllegalStateException(lStrings.getString("err.filter_config_not_initialized"));
/*     */     }
/*     */     
/* 115 */     return fc.getInitParameterNames();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FilterConfig getFilterConfig() {
/* 128 */     return this.config;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletContext getServletContext() {
/* 146 */     FilterConfig sc = getFilterConfig();
/* 147 */     if (sc == null) {
/* 148 */       throw new IllegalStateException(lStrings.getString("err.filter_config_not_initialized"));
/*     */     }
/*     */     
/* 151 */     return sc.getServletContext();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(FilterConfig config) throws ServletException {
/* 174 */     this.config = config;
/* 175 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() throws ServletException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFilterName() {
/* 207 */     FilterConfig sc = getFilterConfig();
/* 208 */     if (sc == null) {
/* 209 */       throw new IllegalStateException(lStrings.getString("err.servlet_config_not_initialized"));
/*     */     }
/*     */     
/* 212 */     return sc.getFilterName();
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\GenericFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */