package jakarta.servlet;

import java.util.EventListener;

public interface ServletContextAttributeListener extends EventListener {
  default void attributeAdded(ServletContextAttributeEvent event) {}
  
  default void attributeRemoved(ServletContextAttributeEvent event) {}
  
  default void attributeReplaced(ServletContextAttributeEvent event) {}
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\ServletContextAttributeListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */