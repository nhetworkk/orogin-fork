/*     */ package jakarta.servlet;
/*     */ 
/*     */ import jakarta.servlet.annotation.MultipartConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultipartConfigElement
/*     */ {
/*     */   private String location;
/*     */   private long maxFileSize;
/*     */   private long maxRequestSize;
/*     */   private int fileSizeThreshold;
/*     */   
/*     */   public MultipartConfigElement(String location) {
/*  40 */     if (location == null) {
/*  41 */       this.location = "";
/*     */     } else {
/*  43 */       this.location = location;
/*     */     } 
/*  45 */     this.maxFileSize = -1L;
/*  46 */     this.maxRequestSize = -1L;
/*  47 */     this.fileSizeThreshold = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultipartConfigElement(String location, long maxFileSize, long maxRequestSize, int fileSizeThreshold) {
/*  59 */     if (location == null) {
/*  60 */       this.location = "";
/*     */     } else {
/*  62 */       this.location = location;
/*     */     } 
/*  64 */     this.maxFileSize = maxFileSize;
/*  65 */     this.maxRequestSize = maxRequestSize;
/*  66 */     this.fileSizeThreshold = fileSizeThreshold;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultipartConfigElement(MultipartConfig annotation) {
/*  75 */     this.location = annotation.location();
/*  76 */     this.fileSizeThreshold = annotation.fileSizeThreshold();
/*  77 */     this.maxFileSize = annotation.maxFileSize();
/*  78 */     this.maxRequestSize = annotation.maxRequestSize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLocation() {
/*  87 */     return this.location;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getMaxFileSize() {
/*  96 */     return this.maxFileSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getMaxRequestSize() {
/* 105 */     return this.maxRequestSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFileSizeThreshold() {
/* 114 */     return this.fileSizeThreshold;
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\MultipartConfigElement.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */