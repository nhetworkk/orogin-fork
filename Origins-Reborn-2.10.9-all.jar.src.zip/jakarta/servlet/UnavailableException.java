/*     */ package jakarta.servlet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnavailableException
/*     */   extends ServletException
/*     */ {
/*     */   private static final long serialVersionUID = 5622686609215003468L;
/*     */   private Servlet servlet;
/*     */   private boolean permanent;
/*     */   private int seconds;
/*     */   
/*     */   @Deprecated
/*     */   public UnavailableException(Servlet servlet, String msg) {
/*  63 */     super(msg);
/*  64 */     this.servlet = servlet;
/*  65 */     this.permanent = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public UnavailableException(int seconds, Servlet servlet, String msg) {
/*  82 */     super(msg);
/*  83 */     this.servlet = servlet;
/*  84 */     if (seconds <= 0) {
/*  85 */       this.seconds = -1;
/*     */     } else {
/*  87 */       this.seconds = seconds;
/*  88 */     }  this.permanent = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnavailableException(String msg) {
/*  99 */     super(msg);
/*     */     
/* 101 */     this.permanent = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnavailableException(String msg, int seconds) {
/* 121 */     super(msg);
/*     */     
/* 123 */     if (seconds <= 0) {
/* 124 */       this.seconds = -1;
/*     */     } else {
/* 126 */       this.seconds = seconds;
/*     */     } 
/* 128 */     this.permanent = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPermanent() {
/* 141 */     return this.permanent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Servlet getServlet() {
/* 154 */     return this.servlet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getUnavailableSeconds() {
/* 170 */     return this.permanent ? -1 : this.seconds;
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\UnavailableException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */