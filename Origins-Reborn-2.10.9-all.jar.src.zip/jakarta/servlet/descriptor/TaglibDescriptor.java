package jakarta.servlet.descriptor;

public interface TaglibDescriptor {
  String getTaglibURI();
  
  String getTaglibLocation();
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\descriptor\TaglibDescriptor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */