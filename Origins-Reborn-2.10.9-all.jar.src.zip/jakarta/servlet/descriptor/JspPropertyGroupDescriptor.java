package jakarta.servlet.descriptor;

import java.util.Collection;

public interface JspPropertyGroupDescriptor {
  Collection<String> getUrlPatterns();
  
  String getElIgnored();
  
  String getPageEncoding();
  
  String getScriptingInvalid();
  
  String getIsXml();
  
  Collection<String> getIncludePreludes();
  
  Collection<String> getIncludeCodas();
  
  String getDeferredSyntaxAllowedAsLiteral();
  
  String getTrimDirectiveWhitespaces();
  
  String getDefaultContentType();
  
  String getBuffer();
  
  String getErrorOnUndeclaredNamespace();
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\descriptor\JspPropertyGroupDescriptor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */