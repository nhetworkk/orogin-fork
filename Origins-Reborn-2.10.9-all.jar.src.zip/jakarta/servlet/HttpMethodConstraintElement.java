/*    */ package jakarta.servlet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpMethodConstraintElement
/*    */   extends HttpConstraintElement
/*    */ {
/*    */   private String methodName;
/*    */   
/*    */   public HttpMethodConstraintElement(String methodName) {
/* 38 */     if (methodName == null || methodName.length() == 0) {
/* 39 */       throw new IllegalArgumentException("invalid HTTP method name");
/*    */     }
/* 41 */     this.methodName = methodName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public HttpMethodConstraintElement(String methodName, HttpConstraintElement constraint) {
/* 53 */     super(constraint.getEmptyRoleSemantic(), constraint.getTransportGuarantee(), constraint.getRolesAllowed());
/* 54 */     if (methodName == null || methodName.length() == 0) {
/* 55 */       throw new IllegalArgumentException("invalid HTTP method name");
/*    */     }
/* 57 */     this.methodName = methodName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getMethodName() {
/* 66 */     return this.methodName;
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\HttpMethodConstraintElement.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */