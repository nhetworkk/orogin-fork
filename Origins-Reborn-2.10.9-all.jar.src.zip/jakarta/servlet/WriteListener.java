package jakarta.servlet;

import java.io.IOException;
import java.util.EventListener;

public interface WriteListener extends EventListener {
  void onWritePossible() throws IOException;
  
  void onError(Throwable paramThrowable);
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\WriteListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */