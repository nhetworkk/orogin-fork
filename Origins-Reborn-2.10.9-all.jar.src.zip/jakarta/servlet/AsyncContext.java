package jakarta.servlet;

public interface AsyncContext {
  public static final String ASYNC_REQUEST_URI = "jakarta.servlet.async.request_uri";
  
  public static final String ASYNC_CONTEXT_PATH = "jakarta.servlet.async.context_path";
  
  public static final String ASYNC_MAPPING = "jakarta.servlet.async.mapping";
  
  public static final String ASYNC_PATH_INFO = "jakarta.servlet.async.path_info";
  
  public static final String ASYNC_SERVLET_PATH = "jakarta.servlet.async.servlet_path";
  
  public static final String ASYNC_QUERY_STRING = "jakarta.servlet.async.query_string";
  
  ServletRequest getRequest();
  
  ServletResponse getResponse();
  
  boolean hasOriginalRequestAndResponse();
  
  void dispatch();
  
  void dispatch(String paramString);
  
  void dispatch(ServletContext paramServletContext, String paramString);
  
  void complete();
  
  void start(Runnable paramRunnable);
  
  void addListener(AsyncListener paramAsyncListener);
  
  void addListener(AsyncListener paramAsyncListener, ServletRequest paramServletRequest, ServletResponse paramServletResponse);
  
  <T extends AsyncListener> T createListener(Class<T> paramClass) throws ServletException;
  
  void setTimeout(long paramLong);
  
  long getTimeout();
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\AsyncContext.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */