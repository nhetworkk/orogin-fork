package jakarta.servlet;

import java.util.EventListener;

public interface ServletRequestAttributeListener extends EventListener {
  default void attributeAdded(ServletRequestAttributeEvent srae) {}
  
  default void attributeRemoved(ServletRequestAttributeEvent srae) {}
  
  default void attributeReplaced(ServletRequestAttributeEvent srae) {}
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\jakarta\servlet\ServletRequestAttributeListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */