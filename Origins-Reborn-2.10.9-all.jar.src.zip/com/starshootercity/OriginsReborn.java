/*     */ package com.starshootercity;
/*     */ import com.starshootercity.abilities.EnderParticles;
/*     */ import com.starshootercity.abilities.ExtraReach;
/*     */ import com.starshootercity.abilities.FreshAir;
/*     */ import com.starshootercity.abilities.Grayscale;
/*     */ import com.starshootercity.abilities.LaunchIntoAir;
/*     */ import com.starshootercity.abilities.LayEggs;
/*     */ import com.starshootercity.abilities.MoreExhaustion;
/*     */ import com.starshootercity.abilities.MoreKineticDamage;
/*     */ import com.starshootercity.abilities.StrongArms;
/*     */ import com.starshootercity.abilities.types.Ability;
/*     */ import com.starshootercity.commands.OriginCommand;
/*     */ import com.starshootercity.cooldowns.Cooldowns;
/*     */ import com.starshootercity.packetsenders.NMSInvoker;
/*     */ import com.starshootercity.util.AbilityRegister;
/*     */ import com.starshootercity.util.Metrics;
/*     */ import com.starshootercity.util.SkinManager;
/*     */ import com.starshootercity.util.WorldGuardHook;
/*     */ import com.starshootercity.util.config.ConfigManager;
/*     */ import com.starshootercity.version.MVAccessor;
/*     */ import com.starshootercity.version.MVAttribute;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.attribute.Attribute;
/*     */ import org.bukkit.command.CommandExecutor;
/*     */ import org.bukkit.command.PluginCommand;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ public class OriginsReborn extends OriginsAddon {
/*     */   private static OriginsReborn instance;
/*     */   
/*     */   public static OriginsReborn getInstance() {
/*  39 */     return instance;
/*     */   }
/*     */   public static FreshAir freshAir; private static Cooldowns cooldowns; private boolean vaultEnabled;
/*     */   private static boolean worldGuardHookInitialized;
/*     */   
/*     */   public static Cooldowns getCooldowns() {
/*  45 */     return cooldowns;
/*     */   }
/*     */   
/*     */   public static MultiVersionExecutor getMVE() {
/*  49 */     return MVAccessor.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   public static NMSInvoker getNMSInvoker() {
/*  59 */     return (NMSInvoker)getMVE();
/*     */   }
/*     */   
/*     */   private static void initializeMVE(OriginsReborn instance) {
/*  63 */     MVAccessor.startInitialize(Bukkit.getBukkitVersion().split("-")[0]);
/*  64 */     Bukkit.getPluginManager().registerEvents((Listener)MVAccessor.get(), (Plugin)instance);
/*  65 */     getMVE().initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isVaultEnabled() {
/*  71 */     return this.vaultEnabled;
/*     */   }
/*     */   
/*     */   public void setComments(String path, List<String> comments) {
/*  75 */     getMVE().setComments(getConfig(), path, comments);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean usesSkriptAbilities = false;
/*     */   
/*     */   public static boolean isWorldGuardHookInitialized() {
/*  82 */     return worldGuardHookInitialized;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onLoad() {
/*     */     try {
/*  88 */       worldGuardHookInitialized = WorldGuardHook.tryInitialize();
/*     */     }
/*  90 */     catch (Throwable t) {
/*  91 */       worldGuardHookInitialized = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  97 */     if (!AbilityRegister.isSkinManagerEnabled())
/*  98 */       return;  SkinManager.unload();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onRegister() {
/* 103 */     instance = this;
/* 104 */     if (Bukkit.getPluginManager().isPluginEnabled("Geyser-Spigot")) {
/* 105 */       OREventRegistrar.initialize(this);
/*     */     }
/*     */     
/* 108 */     if (Bukkit.getPluginManager().isPluginEnabled("GSit")) {
/* 109 */       GSitHook.Setup(this);
/*     */     }
/*     */     
/* 112 */     AbilityRegister.setupAbilityConfig(this);
/*     */     
/* 114 */     int pluginId = 25114;
/* 115 */     Metrics metrics = new Metrics((Plugin)this, pluginId);
/*     */     
/* 117 */     metrics.addCustomChart((Metrics.CustomChart)new Metrics.SimplePie("addon_count", () -> String.valueOf(Math.max(0, AddonLoader.registeredAddons.size() - 1))));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 122 */     metrics.addCustomChart((Metrics.CustomChart)new Metrics.AdvancedPie("addons", () -> {
/*     */             Map<String, Integer> data = new HashMap<>();
/*     */             
/*     */             for (OriginsAddon addon : AddonLoader.registeredAddons) {
/*     */               if (addon == this) {
/*     */                 continue;
/*     */               }
/*     */               
/*     */               data.put(addon.getName(), Integer.valueOf(1));
/*     */             } 
/*     */             return data;
/*     */           }));
/* 134 */     metrics.addCustomChart((Metrics.CustomChart)new Metrics.AdvancedPie("origins", () -> {
/*     */             Map<String, Integer> data = new HashMap<>();
/*     */ 
/*     */             
/*     */             for (String layer : AddonLoader.layers) {
/*     */               for (Origin origin : AddonLoader.getOrigins(layer)) {
/*     */                 String info = "%s - %s".formatted(new Object[] { origin.getNameForDisplay(), layer });
/*     */                 
/*     */                 data.put(info, Integer.valueOf(1));
/*     */               } 
/*     */             } 
/*     */             
/*     */             return data;
/*     */           }));
/*     */     
/* 149 */     freshAir = new FreshAir();
/*     */     
/* 151 */     initializeMVE(this);
/* 152 */     saveDefaultConfig();
/* 153 */     ConfigManager.Option.initialize();
/*     */     
/* 155 */     if (((Boolean)ConfigManager.getConfigValue(ConfigManager.Option.SKINSRESTORER_HOOK_ENABLED)).booleanValue()) {
/* 156 */       if (Bukkit.getPluginManager().isPluginEnabled("SkinsRestorer")) {
/* 157 */         AbilityRegister.setSkinManagerEnabled();
/* 158 */         Bukkit.getPluginManager().registerEvents((Listener)new SkinManager(), (Plugin)this);
/*     */       } else {
/* 160 */         getLogger().warning("The SkinsRestorer hook is enabled in the config, however SkinsRestorer is not installed.");
/*     */       } 
/*     */     }
/*     */     
/* 164 */     metrics.addCustomChart((Metrics.CustomChart)new Metrics.SimplePie("skinsrestorer_hook_enabled", () -> String.valueOf(AbilityRegister.isSkinManagerEnabled())));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 169 */     if (worldGuardHookInitialized) WorldGuardHook.completeInitialize();
/*     */     
/* 171 */     Translator.initialize(this);
/*     */     
/* 173 */     if (((Boolean)ConfigManager.getConfigValue(ConfigManager.Option.SWAP_COMMAND_VAULT_ENABLED)).booleanValue()) {
/* 174 */       this.vaultEnabled = VaultHook.setupEconomy(getServer());
/* 175 */       if (!this.vaultEnabled)
/* 176 */         getLogger().warning("Vault is missing, origin swaps will not cost currency"); 
/*     */     } else {
/* 178 */       this.vaultEnabled = false;
/*     */     } 
/* 180 */     metrics.addCustomChart((Metrics.CustomChart)new Metrics.SimplePie("vault_hook_enabled", () -> String.valueOf(this.vaultEnabled)));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 185 */     metrics.addCustomChart((Metrics.CustomChart)new Metrics.SimplePie("uses_skript_abilities", () -> String.valueOf(usesSkriptAbilities)));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 190 */     metrics.addCustomChart((Metrics.CustomChart)new Metrics.SimplePie("worldguard_hook_enabled", () -> String.valueOf(worldGuardHookInitialized)));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 195 */     cooldowns = new Cooldowns();
/* 196 */     if (!((Boolean)ConfigManager.getConfigValue(ConfigManager.Option.DISABLE_ALL_COOLDOWNS)).booleanValue() && ((Boolean)ConfigManager.getConfigValue(ConfigManager.Option.SHOW_COOLDOWN_ICONS)).booleanValue()) {
/* 197 */       Bukkit.getPluginManager().registerEvents((Listener)cooldowns, (Plugin)this);
/*     */     }
/* 199 */     SkriptInitializer.initialize(this);
/*     */     
/* 201 */     Bukkit.getPluginManager().registerEvents((Listener)TriggerManager.getInstance(), (Plugin)this);
/* 202 */     Bukkit.getPluginManager().registerEvents(new OriginSwapper(), (Plugin)this);
/* 203 */     Bukkit.getPluginManager().registerEvents(new OrbOfOrigin(), (Plugin)this);
/* 204 */     Bukkit.getPluginManager().registerEvents(new PackApplier(), (Plugin)this);
/* 205 */     Bukkit.getPluginManager().registerEvents((Listener)new PlayerLeftClickEvent.PlayerLeftClickEventListener(), (Plugin)this);
/* 206 */     Bukkit.getPluginManager().registerEvents((Listener)new ParticleAbility.ParticleAbilityListener(), (Plugin)this);
/* 207 */     Bukkit.getPluginManager().registerEvents((Listener)new BreakSpeedModifierAbility.BreakSpeedModifierAbilityListener(), (Plugin)this);
/*     */     
/* 209 */     PluginCommand flightCommand = retrieveCommand("fly");
/* 210 */     if (flightCommand != null) flightCommand.setExecutor((CommandExecutor)new FlightToggleCommand());
/*     */     
/* 212 */     File export = new File(getDataFolder(), "export");
/* 213 */     if (!export.exists()) {
/* 214 */       boolean bool = export.mkdir();
/*     */     }
/* 216 */     File imports = new File(getDataFolder(), "import");
/* 217 */     if (!imports.exists()) {
/* 218 */       boolean bool = imports.mkdir();
/*     */     }
/*     */     
/* 221 */     PluginCommand command = retrieveCommand("origin");
/* 222 */     if (command != null) command.setExecutor((CommandExecutor)new OriginCommand()); 
/* 223 */     OriginCommand.initialize();
/*     */     
/* 225 */     PluginCommand discord = retrieveCommand("origindiscord");
/* 226 */     if (discord != null) discord.setExecutor((CommandExecutor)new DiscordCommand());
/*     */     
/* 228 */     AbilityRegister.initialize(this);
/*     */   }
/*     */   @Nullable
/*     */   public PluginCommand retrieveCommand(String command) {
/*     */     try {
/* 233 */       return getCommand(command);
/* 234 */     } catch (UnsupportedOperationException e) {
/* 235 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public String getNamespace() {
/* 241 */     return "origins";
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public List<Ability> getRegisteredAbilities() {
/* 246 */     List<Ability> abilities = new ArrayList<>(List.of((Object[])new Ability[] { (Ability)new PumpkinHate(), (Ability)new FallImmunity(), (Ability)new WeakArms(), (Ability)new Fragile(), (Ability)new SlowFalling(), (Ability)freshAir, (Ability)new Vegetarian(), (Ability)new LayEggs(), (Ability)new NoShield(), (Ability)new MasterOfWebs(), (Ability)new Tailwind(), (Ability)new Arthropod(), (Ability)new Climbing(), (Ability)new Carnivore(), (Ability)new WaterBreathing(), (Ability)new WaterVision(), (Ability)new CatVision(), (Ability)new NineLives(), (Ability)new BurnInDaylight(), (Ability)new WaterVulnerability(), (Ability)new Phantomize(), (Ability)new Invisibility(), (Ability)new ThrowEnderPearl(), (Ability)new PhantomizeOverlay(), (Ability)new FireImmunity(), (Ability)new AirFromPotions(), (Ability)new SwimSpeed(), (Ability)new LikeWater(), (Ability)new LightArmor(), (Ability)new MoreKineticDamage(), (Ability)new DamageFromPotions(), (Ability)new DamageFromSnowballs(), (Ability)new Hotblooded(), (Ability)new BurningWrath(), (Ability)new SprintJump(), (Ability)new AerialCombatant(), (Ability)new Elytra(), (Ability)new LaunchIntoAir(), (Ability)new HungerOverTime(), (Ability)new MoreExhaustion(), (Ability)new Aquatic(), (Ability)new NetherSpawn(), (Ability)new Claustrophobia(), (Ability)new VelvetPaws(), (Ability)new AquaAffinity(), (Ability)new FlameParticles(), (Ability)new EnderParticles(), (Ability)new Phasing(), (Ability)new ScareCreepers(), (Ability)new StrongArms(), (Ability)StrongArms.StrongArmsBreakSpeed.strongArmsBreakSpeed, (Ability)StrongArms.StrongArmsDrops.strongArmsDrops, (Ability)new ShulkerInventory(), (Ability)new NaturalArmor(), (Ability)new ConduitPowerOnLand(), (Ability)new Grayscale() }));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 304 */     Attribute blockInteractionRange = MVAttribute.BLOCK_INTERACTION_RANGE.get();
/* 305 */     Attribute entityInteractionRange = MVAttribute.ENTITY_INTERACTION_RANGE.get();
/* 306 */     if (blockInteractionRange != null && entityInteractionRange != null) {
/* 307 */       abilities.add(new ExtraReach(blockInteractionRange, entityInteractionRange));
/* 308 */       abilities.add(ExtraReach.ExtraReachBlocks.extraReachBlocks);
/* 309 */       abilities.add(ExtraReach.ExtraReachEntities.extraReachEntities);
/*     */     } 
/* 311 */     return abilities;
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\OriginsReborn.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */