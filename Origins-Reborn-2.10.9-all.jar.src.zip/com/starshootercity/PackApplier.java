/*    */ package com.starshootercity;
/*    */ 
/*    */ import com.starshootercity.util.ShortcutUtils;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import com.starshootercity.version.ResourcePackInfo;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerJoinEvent;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class PackApplier implements Listener {
/* 17 */   private static final Map<Class<? extends OriginsAddon>, ResourcePackInfo> addonPacks = new HashMap<>();
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerJoin(PlayerJoinEvent event) {
/* 21 */     if (((Boolean)ConfigManager.getConfigValue(ConfigManager.Option.RESOURCE_PACK_ENABLED)).booleanValue()) {
/* 22 */       if (ShortcutUtils.isBedrockPlayer(event.getPlayer().getUniqueId()))
/* 23 */         return;  Bukkit.getScheduler().runTaskLaterAsynchronously((Plugin)OriginsReborn.getInstance(), () -> sendPacks(event.getPlayer()), 120L);
/*    */     } 
/*    */   }
/*    */   
/*    */   public static void sendPacks(Player player) {
/* 28 */     OriginsReborn.getMVE().sendResourcePacks(player, getPackURL(), addonPacks);
/*    */   }
/*    */   
/*    */   public static String getPackURL() {
/* 32 */     return "https://github.com/cometcake575/Origins-Reborn/raw/refs/heads/main/OriginsPack.zip";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void addResourcePack(OriginsAddon addon, @NotNull ResourcePackInfo info) {
/* 72 */     addonPacks.put(addon.getClass(), info);
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\PackApplier.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */