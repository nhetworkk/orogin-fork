/*     */ package com.starshootercity.util;
/*     */ 
/*     */ import com.starshootercity.OriginsReborn;
/*     */ import jakarta.servlet.ServletOutputStream;
/*     */ import jakarta.servlet.http.HttpServlet;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleServlet
/*     */   extends HttpServlet
/*     */ {
/*     */   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
/* 126 */     response.setContentType("image/png");
/* 127 */     response.setStatus(200);
/*     */     
/* 129 */     String uuid = request.getServletPath().split("\\.")[0];
/* 130 */     File imageFile = new File(OriginsReborn.getInstance().getDataFolder(), "skins/%s.png".formatted(new Object[] { uuid }));
/*     */     
/* 132 */     FileInputStream fis = new FileInputStream(imageFile); try {
/* 133 */       ServletOutputStream servletOutputStream = response.getOutputStream();
/*     */       
/* 135 */       try { byte[] buffer = new byte[4096];
/*     */         int length;
/* 137 */         while ((length = fis.read(buffer)) > 0) {
/* 138 */           servletOutputStream.write(buffer, 0, length);
/*     */         }
/* 140 */         if (servletOutputStream != null) servletOutputStream.close();  } catch (Throwable throwable) { if (servletOutputStream != null) try { servletOutputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  fis.close();
/*     */     } catch (Throwable throwable) {
/*     */       try {
/*     */         fis.close();
/*     */       } catch (Throwable throwable1) {
/*     */         throwable.addSuppressed(throwable1);
/*     */       } 
/*     */       throw throwable;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercit\\util\SkinManager$SimpleServlet.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */