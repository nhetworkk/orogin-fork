/*    */ package com.starshootercity.util.hooks;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.UUID;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ 
/*    */ public class GSitHook {
/* 11 */   public static List<UUID> sitting = new ArrayList<>(); public static boolean enabled = false;
/*    */   
/*    */   public static void Setup(JavaPlugin plugin) {
/* 14 */     Bukkit.getPluginManager().registerEvents(new GSH(), (Plugin)plugin);
/* 15 */     enabled = true;
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercit\\util\hooks\GSitHook.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */