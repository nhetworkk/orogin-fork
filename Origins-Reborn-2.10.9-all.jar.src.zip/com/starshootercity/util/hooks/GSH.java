/*    */ package com.starshootercity.util.hooks;
/*    */ 
/*    */ import dev.geco.gsit.api.event.PlayerPoseEvent;
/*    */ import dev.geco.gsit.api.event.PlayerStopPoseEvent;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ 
/*    */ public class GSH
/*    */   implements Listener {
/*    */   @EventHandler
/*    */   public void onPlayerPose(PlayerPoseEvent event) {
/* 12 */     GSitHook.sitting.add(event.getPlayer().getUniqueId());
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerStopPose(PlayerStopPoseEvent event) {
/* 17 */     GSitHook.sitting.remove(event.getPlayer().getUniqueId());
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercit\\util\hooks\GSH.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */