/*    */ package com.starshootercity.util;
/*    */ 
/*    */ import net.milkbowl.vault.economy.Economy;
/*    */ import org.bukkit.OfflinePlayer;
/*    */ import org.bukkit.Server;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.plugin.RegisteredServiceProvider;
/*    */ 
/*    */ public class VaultHook {
/*    */   public static boolean setupEconomy(Server server) {
/*    */     try {
/* 12 */       RegisteredServiceProvider<Economy> economyProvider = server.getServicesManager().getRegistration(Economy.class);
/* 13 */       if (economyProvider != null) {
/* 14 */         economy = (Economy)economyProvider.getProvider();
/*    */       }
/* 16 */       return (economy != null);
/* 17 */     } catch (NoClassDefFoundError e) {
/* 18 */       return false;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   private static Economy economy;
/*    */   
/*    */   public static boolean has(Player player, int amount) {
/* 26 */     if (economy == null) return true; 
/* 27 */     return economy.has((OfflinePlayer)player, amount);
/*    */   }
/*    */   
/*    */   public static void withdraw(Player player, int amount) {
/* 31 */     economy.withdrawPlayer((OfflinePlayer)player, amount);
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercit\\util\VaultHook.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */