/*     */ package com.starshootercity.util;
/*     */ 
/*     */ import com.starshootercity.OriginsReborn;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import net.kyori.adventure.text.Component;
/*     */ import net.kyori.adventure.text.TextComponent;
/*     */ import net.kyori.adventure.text.format.TextColor;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.HumanEntity;
/*     */ import org.bukkit.entity.LivingEntity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.entity.Projectile;
/*     */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.potion.PotionEffect;
/*     */ import org.bukkit.projectiles.ProjectileSource;
/*     */ import org.geysermc.api.Geyser;
/*     */ import org.geysermc.floodgate.api.FloodgateApi;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public class ShortcutUtils
/*     */ {
/*     */   public static void giveItemWithDrops(Player player, ItemStack... itemStacks) {
/*  32 */     for (ItemStack i : player.getInventory().addItem(itemStacks).values()) {
/*  33 */       player.getWorld().dropItemNaturally(player.getLocation(), i);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static LivingEntity getLivingDamageSource(@NotNull EntityDamageByEntityEvent event) {
/*  43 */     Entity entity = event.getDamager(); if (entity instanceof Projectile) { Projectile projectile = (Projectile)entity; ProjectileSource projectileSource = projectile.getShooter(); if (projectileSource instanceof LivingEntity) return (LivingEntity)projectileSource;  }
/*  44 */      entity = event.getDamager(); if (entity instanceof LivingEntity) return (LivingEntity)entity; 
/*  45 */     return null;
/*     */   }
/*     */   
/*  48 */   private static final Map<UUID, Boolean> isBedrock = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isBedrockPlayer(UUID uuid) {
/*  56 */     return ((Boolean)isBedrock.computeIfAbsent(uuid, ShortcutUtils::checkBedrock)).booleanValue();
/*     */   }
/*     */   
/*     */   private static boolean checkBedrock(UUID uuid) {
/*     */     try {
/*  61 */       return FloodgateApi.getInstance().isFloodgatePlayer(uuid);
/*  62 */     } catch (NoClassDefFoundError e) {
/*     */       try {
/*  64 */         return Geyser.api().isBedrockPlayer(uuid);
/*  65 */       } catch (NoClassDefFoundError ex) {
/*  66 */         return false;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   public static Component getColored(String f) {
/*     */     Component component;
/*  72 */     TextComponent textComponent = Component.empty();
/*  73 */     Iterator<String> iterator = substringsBetween(f, "<", ">").iterator();
/*  74 */     for (String s : f.split("<#\\w{6}>")) {
/*  75 */       if (!s.isEmpty())
/*  76 */         component = textComponent.append(iterator.hasNext() ? Component.text(s).color(TextColor.fromHexString(iterator.next())) : (Component)Component.text(s)); 
/*     */     } 
/*  78 */     return component;
/*     */   }
/*     */   
/*     */   public static List<String> substringsBetween(String s, String start, String end) {
/*  82 */     int starti = s.indexOf(start);
/*  83 */     if (starti == -1) return List.of(); 
/*  84 */     String startPart = s.substring(starti);
/*  85 */     int endi = startPart.indexOf(end);
/*  86 */     if (endi == -1) return List.of(); 
/*  87 */     List<String> data = new ArrayList<>();
/*  88 */     data.add(startPart.substring(0, endi));
/*  89 */     data.addAll(substringsBetween(startPart.substring(endi), start, end));
/*  90 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isInfinite(PotionEffect effect) {
/* 100 */     if (OriginsReborn.getMVE().supportsInfiniteDuration())
/* 101 */       return (effect.getDuration() == -1); 
/* 102 */     return (effect.getDuration() >= 20000);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int infiniteDuration() {
/* 113 */     if (OriginsReborn.getMVE().supportsInfiniteDuration())
/* 114 */       return -1; 
/* 115 */     return 50000;
/*     */   }
/*     */   
/*     */   public static Inventory getTopInventory(HumanEntity player) {
/*     */     try {
/* 120 */       Object view = player.getOpenInventory();
/* 121 */       Method getTopInventory = view.getClass().getMethod("getTopInventory", new Class[0]);
/* 122 */       getTopInventory.setAccessible(true);
/* 123 */       return (Inventory)getTopInventory.invoke(view, new Object[0]);
/* 124 */     } catch (NoSuchMethodException|java.lang.reflect.InvocationTargetException|IllegalAccessException e) {
/* 125 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercit\\util\ShortcutUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */