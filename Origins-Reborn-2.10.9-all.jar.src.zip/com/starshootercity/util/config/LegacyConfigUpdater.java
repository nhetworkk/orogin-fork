/*     */ package com.starshootercity.util.config;
/*     */ 
/*     */ import com.starshootercity.OriginsReborn;
/*     */ import com.starshootercity.abilities.types.Ability;
/*     */ import com.starshootercity.util.AbilityRegister;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import org.bukkit.configuration.ConfigurationSection;
/*     */ import org.bukkit.configuration.file.YamlConfiguration;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LegacyConfigUpdater
/*     */ {
/*     */   public static void updateConfig() {
/*  25 */     String version = getConfig().getString("config-version", "1.0.0");
/*     */     
/*  27 */     if (version.equals("1.0.0")) {
/*  28 */       File configFile = new File(OriginsReborn.getInstance().getDataFolder(), "config.yml");
/*  29 */       boolean ignored = configFile.delete();
/*  30 */       OriginsReborn.getInstance().saveDefaultConfig();
/*     */     } 
/*  32 */     if (version.equals("2.0.0")) {
/*  33 */       getConfig().set("config-version", "2.0.3");
/*  34 */       getConfig().set("display.enable-prefixes", Boolean.valueOf(false));
/*  35 */       setComments("display", List.of("Miscellaneous display options"));
/*  36 */       setComments("display.enable-prefixes", List.of("Enable prefixes in tab and on display names with the names of origins"));
/*  37 */       saveConfig();
/*     */     } 
/*  39 */     if (version.equals("2.0.3")) {
/*  40 */       getConfig().set("config-version", "2.1.7");
/*  41 */       getConfig().set("restrictions.reusing-origins", "NONE");
/*  42 */       getConfig().set("restrictions.prevent-same-origins", Boolean.valueOf(false));
/*  43 */       setComments("restrictions", 
/*  44 */           List.of("Restrictions placed on origin selection", "These are designed for use with addon plugins that add many new origins", "If you run out of origins that fit the restrictions you may experience issues"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  50 */       setComments("restrictions.reusing-origins", 
/*  51 */           List.of("Rule for reusing origins", "\"NONE\" allows origins to be reused", "\"PERPLAYER\" means individual players can only use an origin once", "\"ALL\" means no players can use an origin again after one has selected it"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  58 */       setComments("restrictions.prevent-same-origins", 
/*  59 */           List.of("Prevent players from having the same origins as other players", "This is locked on if reusing-origins is set to ALL"));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  64 */       saveConfig();
/*     */     } 
/*  66 */     if (version.equals("2.1.7") || version.equals("2.1.10")) {
/*  67 */       getConfig().set("config-version", "2.1.11");
/*  68 */       getConfig().set("worlds.disabled-worlds", List.of("example_world"));
/*  69 */       setComments("worlds.disabled-worlds", List.of("Worlds to disable origins in"));
/*  70 */       saveConfig();
/*     */     } 
/*  72 */     if (version.equals("2.1.14")) {
/*  73 */       getConfig().set("config-version", "2.1.11");
/*  74 */       setComments("origin-selection.show-initial-gui", null);
/*  75 */       getConfig().set("origin-selection.show-initial-gui", null);
/*  76 */       saveConfig();
/*     */     } 
/*  78 */     if (version.equals("2.1.11")) {
/*  79 */       getConfig().set("config-version", "2.1.16");
/*  80 */       getConfig().set("origin-selection.auto-spawn-teleport", Boolean.valueOf(true));
/*  81 */       setComments("origin-selection.auto-spawn-teleport", List.of("Automatically teleport players to the world spawn when first selecting an origin"));
/*  82 */       saveConfig();
/*     */     } 
/*  84 */     if (version.equals("2.1.16")) {
/*  85 */       getConfig().set("config-version", "2.1.17");
/*  86 */       getConfig().set("origin-selection.invulnerable-mode", "OFF");
/*  87 */       setComments("origin-selection.invulnerable-mode", List.of("OFF - you can take damage with the origin selection GUI open", "ON - you cannot take damage with the origin selection GUI open", "INITIAL - you cannot take damage if you do not have an origin (and therefore cannot close the screen)"));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  92 */       saveConfig();
/*     */     } 
/*  94 */     if (version.equals("2.1.17")) {
/*  95 */       getConfig().set("config-version", "2.1.18");
/*  96 */       getConfig().set("origin-selection.screen-title.prefix", "");
/*  97 */       getConfig().set("origin-selection.screen-title.suffix", "");
/*  98 */       setComments("origin-selection.screen-title.prefix", List.of("Prefix of GUI title"));
/*  99 */       setComments("origin-selection.screen-title.suffix", List.of("Suffix of GUI title"));
/* 100 */       setComments("origin-selection.screen-title", List.of("Prefixes and suffixes for the selection screen title", "This is an advanced setting - only use it if you know how"));
/* 101 */       saveConfig();
/*     */     } 
/* 103 */     if (version.equals("2.1.18")) {
/* 104 */       getConfig().set("config-version", "2.1.19");
/* 105 */       getConfig().set("origin-selection.screen-title.background", "");
/* 106 */       setComments("origin-selection.screen-title.background", List.of("Background, between Origins-Reborn background and things like text"));
/* 107 */       saveConfig();
/*     */     } 
/* 109 */     if (version.equals("2.1.19") || version.equals("2.1.20")) {
/* 110 */       getConfig().set("config-version", "2.2.3");
/* 111 */       getConfig().set("misc-settings.disable-flight-stuff", Boolean.valueOf(false));
/* 112 */       setComments("misc-settings", List.of("Miscellaneous settings"));
/* 113 */       setComments("misc-settings.disable-flight-stuff", List.of("Disable all flight-related features. This does not hide the abilities themselves, they must be removed from the .yml files in the ~/plugins/Origins-Reborn/origins/ folder"));
/* 114 */       saveConfig();
/*     */     } 
/* 116 */     if (version.equals("2.2.3")) {
/* 117 */       getConfig().set("config-version", "2.2.5");
/* 118 */       getConfig().set("geyser.join-form-delay", Integer.valueOf(20));
/* 119 */       setComments("geyser", List.of("Settings for using GeyserMC"));
/* 120 */       setComments("geyser.join-form-delay", List.of("The delay in ticks to wait before showing a new Bedrock player the selection GUI"));
/* 121 */       saveConfig();
/*     */     } 
/* 123 */     if (version.equals("2.2.5")) {
/* 124 */       getConfig().set("config-version", "2.2.18");
/* 125 */       getConfig().set("swap-command.vault.default-cost", Integer.valueOf(getConfig().getInt("swap-command.vault.cost", 1000)));
/* 126 */       setComments("swap-command.vault.cost", null);
/* 127 */       getConfig().set("swap-command.vault.cost", null);
/* 128 */       setComments("swap-command.vault.default-cost", List.of("Default cost of switching origin, if it hasn't been overriden in the origin file"));
/* 129 */       getConfig().set("origin-selection.default-origin", "NONE");
/* 130 */       setComments("origin-selection.default-origin", List.of("Default origin, automatically gives players this origin rather than opening the GUI when the player has no origin", "Should be the name of the origin file without the ending, e.g. for 'origin_name.json' the value should be 'origin_name'", "Disabled if set to an invalid name such as \"NONE\""));
/* 131 */       saveConfig();
/*     */     } 
/* 133 */     if (version.equals("2.2.18")) {
/* 134 */       getConfig().set("config-version", "2.2.20");
/* 135 */       getConfig().set("swap-command.vault.permanent-purchases", Boolean.valueOf(false));
/* 136 */       setComments("swap-command.vault.permanent-purchases", List.of("Allows the player to switch back to origins for free if they already had the origin before"));
/* 137 */       saveConfig();
/*     */     } 
/* 139 */     if (version.equals("2.2.20")) {
/* 140 */       getConfig().set("config-version", "2.3.0");
/* 141 */       getConfig().set("cooldowns.disable-all-cooldowns", Boolean.valueOf(false));
/* 142 */       getConfig().set("cooldowns.show-cooldown-icons", Boolean.valueOf(true));
/* 143 */       setComments("cooldowns", List.of("Configuration for cooldowns"));
/* 144 */       setComments("cooldowns.disable-all-cooldowns", List.of("Disables every cooldown", " To modify specific cooldowns, edit the cooldown-config.yml file"));
/* 145 */       setComments("cooldowns.show-cooldown-icons", List.of("Use the actionbar to show cooldown icons", "You may want to disable this if using another plugin that requires the actionbar"));
/* 146 */       setComments("resource-pack.enabled", List.of("Whether to enable the resource pack", "If this is set to false you should send the pack to players either in server.properties or in another plugin", "You can find the packs for each version on the GitHub at https://github.com/cometcake575/Origins-Reborn/tree/main/packs/"));
/* 147 */       getConfig().set("resource-pack.link", null);
/* 148 */       saveConfig();
/*     */     } 
/* 150 */     if (version.equals("2.3.0")) {
/* 151 */       getConfig().set("config-version", "2.3.14");
/* 152 */       getConfig().set("commands-on-origin.example", List.of("example %player%", "example %uuid%"));
/* 153 */       setComments("commands-on-origin.example", List.of("Example configuration for a command on origin switch"));
/* 154 */       setComments("commands-on-origin", List.of("Runs commands when the player switches to an origin", "Origins should be formatted as they are in the file names, but without the extension, e.g. \"human\"", "%player% is replaced with the player's username and %uuid% is replaced with their UUID"));
/* 155 */       saveConfig();
/*     */     } 
/* 157 */     if (version.equals("2.3.14")) {
/* 158 */       getConfig().set("config-version", "2.3.17");
/* 159 */       setComments("commands-on-origin", List.of("Runs commands when the player switches to an origin", "Origins should be formatted as they are in the file names, but without the extension, e.g. \"human\"", "%player% is replaced with the player's username and %uuid% is replaced with their UUID", "Use \"default\" for commands that should be run regardless of origin"));
/* 160 */       saveConfig();
/*     */     } 
/* 162 */     if (version.equals("2.3.15") || version.equals("2.3.17")) {
/* 163 */       getConfig().set("config-version", "2.3.18");
/* 164 */       getConfig().set("prevent-abilities-in.no_water_breathing", List.of("origins:water_breathing"));
/* 165 */       getConfig().set("prevent-abilities-in.no_abilities", List.of("all"));
/* 166 */       setComments("prevent-abilities-in.no_water_breathing", List.of("Example region in which the water breathing ability is disabled"));
/* 167 */       setComments("prevent-abilities-in.no_abilities", List.of("Example region where all abilities are disabled"));
/* 168 */       setComments("prevent-abilities-in", List.of("A list of WorldGuard regions in which to prevent the use of certain abilities, use 'all' for all abilities"));
/* 169 */       saveConfig();
/*     */     } 
/* 171 */     if (version.equals("2.3.18")) {
/* 172 */       getConfig().set("config-version", "2.3.20");
/* 173 */       getConfig().set("orb-of-origin.random", Boolean.valueOf(false));
/* 174 */       setComments("orb-of-origin.random", List.of("Randomise origin instead of opening the selector upon using the orb"));
/* 175 */       saveConfig();
/*     */     } 
/* 177 */     if (version.equals("2.3.20")) {
/* 178 */       getConfig().set("config-version", "2.4.0");
/* 179 */       getConfig().set("origin-selection.default-origin.origin", getConfig().get("origin-selection.default-origin"));
/* 180 */       getConfig().set("origin-selection.layer-orders.origin", Integer.valueOf(1));
/* 181 */       setComments("origin-selection.default-origin", List.of("Default origin, automatically gives players this origin rather than opening the GUI when the player has no origin", "Should be the name of the origin file without the ending, e.g. for 'origin_name.json' the value should be 'origin_name'", "Disabled if set to an invalid name such as \"NONE\""));
/* 182 */       setComments("origin-section.layer-orders", List.of("Priorities for different origin 'layers' to be selected in, higher priority layers are selected first."));
/* 183 */       saveConfig();
/*     */     } 
/* 185 */     if (version.equals("2.4.0")) {
/* 186 */       getConfig().set("config-version", "2.4.1");
/* 187 */       getConfig().set("orb-of-origin.random.origin", getConfig().get("orb-of-origin.random"));
/* 188 */       getConfig().set("origin-selection.randomise.origin", getConfig().get("origin-selection.randomise"));
/* 189 */       setComments("orb-of-origin.random", List.of("Randomise origin instead of opening the selector upon using the orb"));
/* 190 */       setComments("origin-selection.randomise", List.of("Randomise origins instead of letting players pick"));
/* 191 */       saveConfig();
/*     */     } 
/* 193 */     if (version.equals("2.4.1")) {
/* 194 */       getConfig().set("config-version", "2.4.2");
/* 195 */       getConfig().set("origin-selection.delay-before-required", Integer.valueOf(0));
/* 196 */       setComments("origin-selection.delay-before-required", List.of("The amount of time (in ticks, a tick is a 20th of a second) to wait between a player joining and when the GUI should open"));
/* 197 */       saveConfig();
/*     */     } 
/* 199 */     if (version.equals("2.4.2")) {
/* 200 */       getConfig().set("config-version", "2.5.0");
/* 201 */       int i = getConfig().getInt("extra-settings.fresh-air-required-sleep-height", 86);
/* 202 */       AbilityRegister.registerConfigOption((JavaPlugin)OriginsReborn.getInstance(), (Ability)OriginsReborn.freshAir, ConfigManager.SettingType.INTEGER, "minimum_altitude", Collections.singletonList("Minimum altitude the player can sleep at"), Integer.valueOf(i));
/* 203 */       getConfig().set("extra-settings", null);
/* 204 */       saveConfig();
/*     */     } 
/* 206 */     if (version.equals("2.5.0")) {
/* 207 */       getConfig().set("config-version", "2.5.5");
/* 208 */       getConfig().set("skinsrestorer-hook.enabled", Boolean.valueOf(false));
/* 209 */       getConfig().set("skinsrestorer-hook.ip", "UNSET");
/* 210 */       getConfig().set("skinsrestorer-hook.port", Integer.valueOf(80));
/*     */       
/* 212 */       setComments("skinsrestorer-hook", Collections.singletonList("Enables abilities that change the player's skin (requires SkinsRestorer to work)"));
/* 213 */       setComments("skinsrestorer-hook.enabled", Collections.singletonList("Whether to enable the SkinsRestorer hook"));
/* 214 */       setComments("skinsrestorer-hook.ip", Collections.singletonList("The IP of your server, set this to your server's public IP (without the port)"));
/* 215 */       setComments("skinsrestorer-hook.port", Collections.singletonList("Set this to any other open port on the server, this is used to host the image of the skin, so it can be used by SkinsRestorer"));
/*     */       
/* 217 */       saveConfig();
/*     */     } 
/* 219 */     if (version.equals("2.5.5")) {
/*     */       
/*     */       try {
/*     */ 
/*     */         
/* 224 */         File internals = new File(OriginsReborn.getInstance().getDataFolder(), "internals");
/* 225 */         boolean ignored2 = internals.mkdirs();
/*     */         
/* 227 */         File inventories = new File(OriginsReborn.getInstance().getDataFolder(), "inventories.yml");
/* 228 */         if (inventories.exists()) {
/* 229 */           Files.move(inventories.toPath(), Path.of(OriginsReborn.getInstance().getDataFolder().getPath(), new String[] { "internals/inventories.yml" }), new java.nio.file.CopyOption[0]);
/*     */         }
/* 231 */         File selectedOrigins = new File(OriginsReborn.getInstance().getDataFolder(), "selected-origins.yml");
/* 232 */         if (selectedOrigins.exists()) {
/* 233 */           Files.move(selectedOrigins.toPath(), Path.of(OriginsReborn.getInstance().getDataFolder().getPath(), new String[] { "internals/selected-origins.yml" }), new java.nio.file.CopyOption[0]);
/*     */         }
/* 235 */         File usedOrigins = new File(OriginsReborn.getInstance().getDataFolder(), "used-origins.yml");
/* 236 */         if (usedOrigins.exists()) {
/* 237 */           Files.move(usedOrigins.toPath(), Path.of(OriginsReborn.getInstance().getDataFolder().getPath(), new String[] { "internals/used-origins.yml" }), new java.nio.file.CopyOption[0]);
/*     */         }
/*     */         
/* 240 */         File cooldownConfig = new File(OriginsReborn.getInstance().getDataFolder(), "cooldown-config.yml");
/* 241 */         File attributeModifierAbilityConfig = new File(OriginsReborn.getInstance().getDataFolder(), "attribute-modifier-ability-config.yml");
/*     */         
/* 243 */         if (cooldownConfig.exists()) {
/* 244 */           YamlConfiguration yamlConfiguration = new YamlConfiguration();
/*     */           
/* 246 */           yamlConfiguration.load(cooldownConfig);
/*     */           
/* 248 */           int i = yamlConfiguration.getInt("origins-reborn:swap-command-cooldown", -1);
/* 249 */           getConfig().set("swap-command.cooldown", Integer.valueOf(i));
/* 250 */           setComments("swap-command.cooldown", Collections.singletonList("Cooldown for the command (in ticks), -1 means no cooldown"));
/* 251 */           yamlConfiguration.set("origins-reborn:swap-command-cooldown", null);
/* 252 */           saveConfig();
/*     */           
/* 254 */           for (String s : yamlConfiguration.getKeys(false)) {
/* 255 */             int amount = yamlConfiguration.getInt(s);
/* 256 */             if (amount == -1)
/*     */               continue; 
/* 258 */             String data = s.split(":")[1];
/* 259 */             String string = data.replaceFirst("-", ":");
/* 260 */             Key key = Key.key(string);
/*     */             
/* 262 */             ((List<AbilityRegister.AbilityRunnable>)AbilityRegister.runOnRegisters.computeIfAbsent(key, k -> new ArrayList()))
/* 263 */               .add(ability -> ability.registerConfigOption("cooldown-duration", Collections.singletonList("The duration of the cooldown (in ticks)"), ConfigManager.SettingType.INTEGER, Integer.valueOf(amount)));
/*     */           } 
/*     */           
/* 266 */           boolean bool = cooldownConfig.delete();
/*     */         } 
/*     */         
/* 269 */         if (attributeModifierAbilityConfig.exists()) {
/* 270 */           YamlConfiguration yamlConfiguration = new YamlConfiguration();
/*     */           
/* 272 */           yamlConfiguration.load(attributeModifierAbilityConfig);
/*     */           
/* 274 */           for (String s : yamlConfiguration.getKeys(false)) {
/* 275 */             String value = yamlConfiguration.getString(s + ".value", "x");
/* 276 */             String operation = yamlConfiguration.getString(s + ".operation", "default");
/*     */             
/* 278 */             Key key = Key.key(s);
/*     */             
/* 280 */             ((List<AbilityRegister.AbilityRunnable>)AbilityRegister.runOnRegisters.computeIfAbsent(key, k -> new ArrayList()))
/* 281 */               .add(ability -> {
/*     */                   if (!operation.equals("default")) {
/*     */                     ability.registerConfigOption("attribute-modifier.operation", Collections.singletonList("The operation to use ('ADD_SCALAR', 'ADD_NUMBER' or 'MULTIPLY_SCALAR_1')"), ConfigManager.SettingType.STRING, operation);
/*     */                   }
/*     */                   
/*     */                   ability.registerConfigOption("attribute-modifier.expression", List.of("A mathematical expression used to modify the attribute, where 'x' is a variable representing the default modifier.", "Example: 'x * 3' will triple the value used in the modifier."), ConfigManager.SettingType.STRING, value);
/*     */                 });
/*     */           } 
/* 289 */           boolean bool = attributeModifierAbilityConfig.delete();
/*     */         } 
/*     */         
/* 292 */         File langFolder = new File(OriginsReborn.getInstance().getDataFolder(), "lang");
/* 293 */         if (langFolder.exists()) {
/* 294 */           boolean bool = langFolder.delete();
/*     */         }
/* 296 */         File characters = new File(OriginsReborn.getInstance().getDataFolder(), "characters.yml");
/* 297 */         if (characters.exists()) {
/* 298 */           boolean bool = characters.delete();
/*     */         }
/* 300 */         File toggleable = new File(OriginsReborn.getInstance().getDataFolder(), "toggleable-abilities.yml");
/* 301 */         if (toggleable.exists()) {
/* 302 */           boolean bool = toggleable.delete();
/*     */         }
/*     */         
/* 305 */         Map<String, Object> configBackup = new HashMap<>();
/* 306 */         for (ConfigManager.Option<?> option : ConfigManager.Option.getOptions().values()) {
/* 307 */           configBackup.put(option.getPath(), option.getValue());
/*     */         }
/*     */         
/* 310 */         for (String s : getConfig().getKeys(false)) {
/* 311 */           getConfig().set(s, null);
/*     */         }
/*     */         
/* 314 */         configBackup.remove("config-version");
/* 315 */         for (String s : ConfigManager.Option.getOptions().keySet()) {
/* 316 */           if (configBackup.containsKey(s)) { ((ConfigManager.Option)ConfigManager.Option.getOptions().get(s)).setValue(configBackup.get(s)); continue; }
/* 317 */            ((ConfigManager.Option)ConfigManager.Option.getOptions().get(s)).resetValue();
/*     */         } 
/* 319 */         saveConfig();
/*     */       }
/* 321 */       catch (IOException|org.bukkit.configuration.InvalidConfigurationException iOException) {}
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static ConfigurationSection getConfig() {
/* 327 */     return (ConfigurationSection)OriginsReborn.getInstance().getConfig();
/*     */   }
/*     */   
/*     */   private static void saveConfig() {
/* 331 */     OriginsReborn.getInstance().saveConfig();
/*     */   }
/*     */   
/*     */   private static void setComments(String path, List<String> comments) {
/* 335 */     OriginsReborn.getInstance().setComments(path, comments);
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercit\\util\config\LegacyConfigUpdater.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */