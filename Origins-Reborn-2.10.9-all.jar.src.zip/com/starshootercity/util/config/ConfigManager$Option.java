/*     */ package com.starshootercity.util.config;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.bukkit.Material;
/*     */ import org.jetbrains.annotations.ApiStatus.Internal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Option<T>
/*     */ {
/*     */   private static boolean hasUpdated = false;
/*  33 */   private static final Map<String, Option<?>> options = new HashMap<>();
/*     */   
/*     */   public static Map<String, Option<?>> getOptions() {
/*  36 */     return options;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Option<String> OVERWORLD_DIMENSION;
/*     */   
/*     */   public static Option<String> NETHER_DIMENSION;
/*     */   
/*     */   public static Option<String> END_DIMENSION;
/*     */   
/*     */   public static Option<List<String>> DISABLED_WORLDS;
/*     */   
/*     */   public static Option<Map<String, List<String>>> COMMANDS_ON_ORIGIN;
/*     */   
/*     */   public static Option<Map<String, List<String>>> ABILITY_BLOCKING_REGIONS;
/*     */   
/*     */   public static Option<Boolean> WORLDGUARD_HOOK;
/*     */   
/*     */   public static Option<Boolean> DISABLE_ALL_COOLDOWNS;
/*     */   
/*     */   public static Option<Boolean> SHOW_COOLDOWN_ICONS;
/*     */   
/*     */   public static Option<Boolean> SLEEPING_RESETS_COOLDOWNS;
/*     */   
/*     */   public static Option<Boolean> DISABLE_FLIGHT_STUFF;
/*     */   
/*     */   public static Option<Boolean> SWAP_COMMAND_ENABLED;
/*     */   
/*     */   public static Option<String> SWAP_COMMAND_PERMISSION;
/*     */   
/*     */   public static Option<Boolean> SWAP_COMMAND_RESETS_PLAYER;
/*     */   
/*     */   public static Option<Integer> SWAP_COMMAND_COOLDOWN;
/*     */   
/*     */   public static Option<Boolean> SWAP_COMMAND_VAULT_ENABLED;
/*     */   
/*     */   public static Option<String> SWAP_COMMAND_VAULT_BYPASS_PERMISSION;
/*     */   
/*     */   public static Option<Integer> SWAP_COMMAND_VAULT_DEFAULT_COST;
/*     */   
/*     */   public static Option<Boolean> SWAP_COMMAND_VAULT_PERMANENT_PURCHASES;
/*     */   
/*     */   public static Option<String> SWAP_COMMAND_VAULT_CURRENCY_SYMBOL;
/*     */   
/*     */   public static Option<Boolean> ORIGIN_SELECTION_CONFIRM_SELECTION;
/*     */   
/*     */   public static Option<Integer> ORIGIN_SELECTION_DELAY_BEFORE_REQUIRED;
/*     */   
/*     */   public static Option<Map<String, Integer>> ORIGIN_SELECTION_LAYER_ORDERS;
/*     */   
/*     */   public static Option<Map<String, String>> ORIGIN_SELECTION_DEFAULT_ORIGINS;
/*     */   
/*     */   public static Option<String> ORIGIN_SELECTION_INVULNERABLE_MODE;
/*     */   
/*     */   public static Option<Boolean> ORIGIN_SELECTION_AUTO_SPAWN_TELEPORT;
/*     */   
/*     */   public static Option<Map<String, Boolean>> ORIGIN_SELECTION_RANDOMISE;
/*     */   
/*     */   public static Option<Boolean> ORIGIN_SELECTION_DEATH_ORIGIN_CHANGE;
/*     */   public static Option<Integer> ORIGIN_SELECTION_SCROLL_AMOUNT;
/*     */   public static Option<Boolean> ORIGIN_SELECTION_RANDOM_OPTION_ENABLED;
/*     */   public static Option<List<String>> ORIGIN_SELECTION_RANDOM_OPTION_EXCLUDE;
/*     */   public static Option<String> ORIGIN_SELECTION_SCREEN_TITLE_PREFIX;
/*     */   public static Option<String> ORIGIN_SELECTION_SCREEN_TITLE_BACKGROUND;
/*     */   public static Option<String> ORIGIN_SELECTION_SCREEN_TITLE_SUFFIX;
/*     */   public static Option<Boolean> ORB_OF_ORIGIN_RESET_PLAYER;
/*     */   public static Option<Boolean> ORB_OF_ORIGIN_CONSUME;
/*     */   public static Option<Map<String, Boolean>> ORB_OF_ORIGIN_RANDOM;
/*     */   public static Option<Boolean> ORB_OF_ORIGIN_ENABLE_RECIPE;
/*     */   public static Option<List<List<Material>>> ORB_OF_ORIGIN_RECIPE;
/*     */   public static Option<Boolean> RESOURCE_PACK_ENABLED;
/*     */   public static Option<Boolean> DISPLAY_ENABLE_PREFIXES;
/*     */   public static Option<Integer> MAX_SAME_ORIGIN;
/*     */   public static Option<String> REUSING_ORIGINS;
/*     */   public static Option<Boolean> PREVENT_SAME_ORIGINS;
/*     */   public static Option<Integer> GEYSER_JOIN_FORM_DELAY;
/*     */   public static Option<Boolean> SKINSRESTORER_HOOK_ENABLED;
/*     */   public static Option<String> SKINSRESTORER_HOOK_IP;
/*     */   public static Option<Integer> SKINSRESTORER_HOOK_PORT;
/*     */   public static Option<Integer> REFRESH_RATE;
/*     */   public static Option<String> CONFIG_VERSION;
/*     */   private final ConfigManager.SettingType<T> type;
/*     */   private final String path;
/*     */   private final T defaultValue;
/*     */   private final List<String> comments;
/*     */   
/*     */   public static void initialize() {
/* 123 */     OVERWORLD_DIMENSION = new Option<>(ConfigManager.SettingType.STRING, "worlds.world", "Overworld dimension", "world");
/* 124 */     NETHER_DIMENSION = new Option<>(ConfigManager.SettingType.STRING, "worlds.world_nether", "Nether dimension", "world_nether");
/* 125 */     END_DIMENSION = new Option<>(ConfigManager.SettingType.STRING, "worlds.world_the_end", "End dimension", "world_the_end");
/* 126 */     DISABLED_WORLDS = new Option<>(ConfigManager.SettingType.STRING_LIST, "worlds.disabled_worlds", "Worlds to disable origins in", List.of("example_world"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 135 */     COMMANDS_ON_ORIGIN = new Option<>(ConfigManager.SettingType.MAP_STRING_TO_STRING_LIST, "commands-on-origin", List.of("Runs commands when the player switches to an origin", "Origins should be formatted as they are in the file names, but without the extension, e.g. \"human\"", "%player% is replaced with the player's username and %uuid% is replaced with their UUID", "Use \"default\" for commands that should be run regardless of origin"), Map.of("example", List.of("example %player%", "example %uuid%")));
/*     */ 
/*     */     
/* 138 */     ABILITY_BLOCKING_REGIONS = new Option<>(ConfigManager.SettingType.MAP_STRING_TO_STRING_LIST, "prevent-abilities-in", Collections.singletonList("A list of WorldGuard regions in which to prevent the use of certain abilities, use 'all' for all abilities"), Map.of("no_water_breathing", 
/* 139 */           Collections.singletonList("origins:water_breathing"), "no_abilities", 
/* 140 */           Collections.singletonList("all")));
/*     */     
/* 142 */     WORLDGUARD_HOOK = new Option<>(ConfigManager.SettingType.BOOLEAN, "enable-worldguard-hook", Collections.singletonList("Whether to enable the WorldGuard hook automatically (can be disabled to improve performance if the hook is not used)"), Boolean.valueOf(true));
/*     */     
/* 144 */     DISABLE_ALL_COOLDOWNS = new Option<>(ConfigManager.SettingType.BOOLEAN, "cooldowns.disable-all-cooldowns", Collections.singletonList("Disables every cooldown"), Boolean.valueOf(false));
/* 145 */     SHOW_COOLDOWN_ICONS = new Option<>(ConfigManager.SettingType.BOOLEAN, "cooldowns.show-cooldown-icons", List.of("Use the actionbar to show cooldown icons", "You may want to disable this if using another plugin that requires the actionbar"), Boolean.valueOf(true));
/* 146 */     SLEEPING_RESETS_COOLDOWNS = new Option<>(ConfigManager.SettingType.BOOLEAN, "cooldowns.sleeping-resets-cooldowns", "Sleeping will reset all the cooldowns", Boolean.valueOf(false));
/*     */     
/* 148 */     DISABLE_FLIGHT_STUFF = new Option<>(ConfigManager.SettingType.BOOLEAN, "misc-settings.disable-flight-stuff", "Disable all flight-related features. This does not hide the abilities themselves, they must be removed from the .yml files in the ~/plugins/Origins-Reborn/origins/ folder", Boolean.valueOf(false));
/*     */     
/* 150 */     SWAP_COMMAND_ENABLED = new Option<>(ConfigManager.SettingType.BOOLEAN, "swap-command.enabled", "Enable the swap command", Boolean.valueOf(true));
/* 151 */     SWAP_COMMAND_PERMISSION = new Option<>(ConfigManager.SettingType.STRING, "swap-command.permission", "Permission required for origin swap command", "originsreborn.admin");
/* 152 */     SWAP_COMMAND_RESETS_PLAYER = new Option<>(ConfigManager.SettingType.BOOLEAN, "swap-command.reset-player", "Reset player data like inventory and spawn point when switching origins using the /origin swap command", Boolean.valueOf(false));
/* 153 */     SWAP_COMMAND_COOLDOWN = new Option<>(ConfigManager.SettingType.INTEGER, "swap-command.cooldown", "Cooldown for the command (in ticks), -1 means no cooldown", Integer.valueOf(-1));
/*     */     
/* 155 */     SWAP_COMMAND_VAULT_ENABLED = new Option<>(ConfigManager.SettingType.BOOLEAN, "swap-command.vault.enabled", "Enable charging players with Vault", Boolean.valueOf(false));
/* 156 */     SWAP_COMMAND_VAULT_BYPASS_PERMISSION = new Option<>(ConfigManager.SettingType.STRING, "swap-command.vault.bypass-permission", "Permission to bypass the cost of the swap command", "originsreborn.costbypass");
/* 157 */     SWAP_COMMAND_VAULT_DEFAULT_COST = new Option<>(ConfigManager.SettingType.INTEGER, "swap-command.vault.default-cost", "Default cost of switching origin, if it hasn't been overriden in the origin file", Integer.valueOf(1000));
/* 158 */     SWAP_COMMAND_VAULT_PERMANENT_PURCHASES = new Option<>(ConfigManager.SettingType.BOOLEAN, "swap-command.vault.permanent-purchases", "Allows the player to switch back to origins for free if they already had the origin before", Boolean.valueOf(false));
/* 159 */     SWAP_COMMAND_VAULT_CURRENCY_SYMBOL = new Option<>(ConfigManager.SettingType.STRING, "swap-command.vault.currency-symbol", "Currency symbol for the economy", "$");
/*     */     
/* 161 */     ORIGIN_SELECTION_CONFIRM_SELECTION = new Option<>(ConfigManager.SettingType.BOOLEAN, "origin-selection.confirm-selection", "Confirm the origin selection by double clicking the button", Boolean.valueOf(false));
/* 162 */     ORIGIN_SELECTION_DELAY_BEFORE_REQUIRED = new Option<>(ConfigManager.SettingType.INTEGER, "origin-selection.delay-before-required", "The amount of time (in ticks, a tick is a 20th of a second) to wait between a player joining and when the GUI should open", Integer.valueOf(0));
/*     */     
/* 164 */     ORIGIN_SELECTION_LAYER_ORDERS = new Option<>(ConfigManager.SettingType.MAP_STRING_TO_INTEGER, "origin-selection.layer-orders", "Priorities for different origin 'layers' to be selected in, higher priority layers are selected first.", Map.of("origin", Integer.valueOf(1)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 170 */     ORIGIN_SELECTION_DEFAULT_ORIGINS = new Option<>(ConfigManager.SettingType.MAP_STRING_TO_STRING, "origin-selection.default-origin", List.of("Default origin, automatically gives players this origin rather than opening the GUI when the player has no origin", "Should be the name of the origin file without the ending, e.g. for 'origin_name.json' the value should be 'origin_name'", "Disabled if set to an invalid name such as \"NONE\""), Map.of("origin", "NONE"));
/*     */     
/* 172 */     ORIGIN_SELECTION_INVULNERABLE_MODE = new Option<>(ConfigManager.SettingType.STRING, "origin-selection.invulnerable-mode", List.of("OFF - you can take damage with the origin selection GUI open", "ON - you cannot take damage with the origin selection GUI open", "INITIAL - you cannot take damage if you do not have an origin (and therefore cannot close the screen)"), "OFF");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 177 */     ORIGIN_SELECTION_AUTO_SPAWN_TELEPORT = new Option<>(ConfigManager.SettingType.BOOLEAN, "origin-selection.auto-spawn-teleport", "Automatically teleport players to the world spawn when first selecting an origin", Boolean.valueOf(true));
/*     */     
/* 179 */     ORIGIN_SELECTION_RANDOMISE = new Option<>(ConfigManager.SettingType.MAP_STRING_TO_BOOLEAN, "origin-selection.randomise", "Randomise origins instead of letting players pick", Map.of("origin", Boolean.valueOf(false)));
/*     */ 
/*     */ 
/*     */     
/* 183 */     ORIGIN_SELECTION_DEATH_ORIGIN_CHANGE = new Option<>(ConfigManager.SettingType.BOOLEAN, "origin-selection.death-origin-change", List.of("Allows players to choose a new origin when they die", "If randomise is enabled this will reroll their origin to something random"), Boolean.valueOf(false));
/* 184 */     ORIGIN_SELECTION_SCROLL_AMOUNT = new Option<>(ConfigManager.SettingType.INTEGER, "origin-selection.scroll-amount", "Amount to scroll per scroll button click", Integer.valueOf(1));
/*     */     
/* 186 */     ORIGIN_SELECTION_RANDOM_OPTION_ENABLED = new Option<>(ConfigManager.SettingType.BOOLEAN, "origin-selection.random-option.enabled", "Enable the random option choice - does nothing if randomise is enabled", Boolean.valueOf(true));
/* 187 */     ORIGIN_SELECTION_RANDOM_OPTION_EXCLUDE = new Option<>(ConfigManager.SettingType.STRING_LIST, "origin-selection.random-option.exclude", "Origins to exclude from random options", List.of("human"));
/*     */     
/* 189 */     ORIGIN_SELECTION_SCREEN_TITLE_PREFIX = new Option<>(ConfigManager.SettingType.STRING, "origin-selection.screen-title.prefix", "Prefix of GUI title", "");
/* 190 */     ORIGIN_SELECTION_SCREEN_TITLE_BACKGROUND = new Option<>(ConfigManager.SettingType.STRING, "origin-selection.screen-title.background", "Background, between Origins-Reborn background and things like text", "");
/* 191 */     ORIGIN_SELECTION_SCREEN_TITLE_SUFFIX = new Option<>(ConfigManager.SettingType.STRING, "origin-selection.screen-title.suffix", "Suffix of GUI title", "");
/*     */     
/* 193 */     ORB_OF_ORIGIN_RESET_PLAYER = new Option<>(ConfigManager.SettingType.BOOLEAN, "orb-of-origin.reset-player", "Reset player data like inventory and spawn point when switching origins using the Orb of Origin", Boolean.valueOf(false));
/* 194 */     ORB_OF_ORIGIN_CONSUME = new Option<>(ConfigManager.SettingType.BOOLEAN, "orb-of-origin.consume", "Consume the Orb of Origin upon use", Boolean.valueOf(true));
/*     */     
/* 196 */     ORB_OF_ORIGIN_RANDOM = new Option<>(ConfigManager.SettingType.MAP_STRING_TO_BOOLEAN, "orb-of-origin.random", "Randomise origin instead of opening the selector upon using the orb", Map.of("origin", Boolean.valueOf(false)));
/* 197 */     ORB_OF_ORIGIN_ENABLE_RECIPE = new Option<>(ConfigManager.SettingType.BOOLEAN, "orb-of-origin.enable-recipe", "Enable recipe for crafting the Orb of Origin", Boolean.valueOf(false));
/*     */     
/* 199 */     ORB_OF_ORIGIN_RECIPE = new Option<>(ConfigManager.SettingType.MATERIAL_LIST_LIST, "orb-of-origin.recipe", "Crafting recipe for the Orb of Origin", List.of(
/* 200 */           List.of(Material.AIR, Material.DIAMOND, Material.AIR), 
/* 201 */           List.of(Material.DIAMOND, Material.NETHER_STAR, Material.DIAMOND), 
/* 202 */           List.of(Material.AIR, Material.DIAMOND, Material.AIR)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 209 */     RESOURCE_PACK_ENABLED = new Option<>(ConfigManager.SettingType.BOOLEAN, "resource-pack.enabled", List.of("Whether to enable the Java resource pack", "If this is set to false you should send the pack to players either in server.properties or in another plugin", "You can find the pack on the GitHub at https://github.com/cometcake575/Origins-Reborn/raw/refs/heads/main/OriginsPack.zip"), Boolean.valueOf(true));
/*     */     
/* 211 */     DISPLAY_ENABLE_PREFIXES = new Option<>(ConfigManager.SettingType.BOOLEAN, "display.enable-prefixes", "Enable prefixes in tab and on display names with the names of origins", Boolean.valueOf(false));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 216 */     MAX_SAME_ORIGIN = new Option<>(ConfigManager.SettingType.INTEGER, "restrictions.max_same_origin", List.of("The maximum number of players who can have the same origin at once (-1 means no limit)", "This can be overridden by the 'max' setting in individual origins"), Integer.valueOf(-1));
/* 217 */     REUSING_ORIGINS = new Option<>(ConfigManager.SettingType.STRING, "restrictions.reusing-origins", List.of("\"NONE\" allows origins to be reused", "\"PERPLAYER\" means individual players can only use an origin once", "\"ALL\" means no players can use an origin again after one has selected it"), "NONE");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 222 */     PREVENT_SAME_ORIGINS = new Option<>(ConfigManager.SettingType.BOOLEAN, "restrictions.prevent-same-origins", "Prevent players from having the same origins as other players, this is locked on if reusing-origins is set to ALL", Boolean.valueOf(false));
/*     */     
/* 224 */     GEYSER_JOIN_FORM_DELAY = new Option<>(ConfigManager.SettingType.INTEGER, "geyser.join-form-delay", "The delay in ticks to wait before showing a new Bedrock player the selection GUI", Integer.valueOf(20));
/*     */     
/* 226 */     SKINSRESTORER_HOOK_ENABLED = new Option<>(ConfigManager.SettingType.BOOLEAN, "skinsrestorer-hook.enabled", "Whether to enable the SkinsRestorer hook", Boolean.valueOf(false));
/* 227 */     SKINSRESTORER_HOOK_IP = new Option<>(ConfigManager.SettingType.STRING, "skinsrestorer-hook.ip", "The IP of your server, set this to your server's public IP (without the port)", "UNSET");
/* 228 */     SKINSRESTORER_HOOK_PORT = new Option<>(ConfigManager.SettingType.INTEGER, "skinsrestorer-hook.port", "Set this to any other open port on the server, this is used to host the image of the skin, so it can be used by SkinsRestorer", Integer.valueOf(80));
/*     */     
/* 230 */     REFRESH_RATE = new Option<>(ConfigManager.SettingType.INTEGER, "refresh-rate", "How many ticks apart should the plugin refresh be, increasing this number will improve performance but will cause issues if too high", Integer.valueOf(4));
/* 231 */     CONFIG_VERSION = new Option<>(ConfigManager.SettingType.STRING, "config-version", "Config version - do not touch this!", ConfigManager.VERSION);
/*     */     
/* 233 */     LegacyConfigUpdater.updateConfig();
/*     */     
/* 235 */     makeOptionHeader("worlds", Collections.singletonList("Worlds used for some abilities"));
/* 236 */     makeOptionHeader("cooldowns", "Configuration for cooldowns");
/* 237 */     makeOptionHeader("misc-settings", "Miscellaneous settings");
/* 238 */     makeOptionHeader("swap-command", "The /origin swap command, allowing players to switch origin at will");
/* 239 */     makeOptionHeader("swap-command.vault", "Charge players using Vault to switch their origins");
/* 240 */     makeOptionHeader("origin-selection", "Settings for origin selection");
/* 241 */     makeOptionHeader("origin-selection.random-option", "Allows the player to pick a 'Random' option");
/* 242 */     makeOptionHeader("origin-selection.screen-title", "Prefixes and suffixes for the selection screen title");
/* 243 */     makeOptionHeader("orb-of-origin", "Settings for the Orb of Origin");
/* 244 */     makeOptionHeader("resource-pack", "Settings for the resource pack");
/* 245 */     makeOptionHeader("display", "Miscellaneous display options");
/* 246 */     makeOptionHeader("restrictions", List.of("Restrictions placed on origin selection", "These are designed for use with addon plugins that add many new origins", "If you run out of origins that fit the restrictions you may experience issues"));
/* 247 */     makeOptionHeader("geyser", "Settings for using GeyserMC");
/* 248 */     makeOptionHeader("skinsrestorer-hook", "Enables abilities that change the player's skin (requires SkinsRestorer to work)");
/*     */     
/* 250 */     if (hasUpdated) ConfigManager.saveConfig();
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Option(ConfigManager.SettingType<T> settingType, String path, List<String> comments, T defaultValue) {
/* 259 */     options.put(path, this);
/* 260 */     this.type = settingType;
/* 261 */     this.path = path;
/* 262 */     this.comments = comments;
/* 263 */     this.defaultValue = defaultValue;
/*     */     
/* 265 */     if (!ConfigManager.getConfig().contains(path)) {
/* 266 */       hasUpdated = true;
/* 267 */       settingType.set(ConfigManager.getConfig(), path, defaultValue);
/* 268 */       ConfigManager.setComments(path, comments);
/*     */     } 
/*     */   }
/*     */   
/*     */   Option(ConfigManager.SettingType<T> settingType, String path, String comment, T defaultValue) {
/* 273 */     this(settingType, path, Collections.singletonList(comment), defaultValue);
/*     */   }
/*     */   
/*     */   public T getValue() {
/* 277 */     return this.type.get(ConfigManager.getConfig(), this.path);
/*     */   }
/*     */   
/*     */   public String getPath() {
/* 281 */     return this.path;
/*     */   }
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public void setValue(Object value) {
/* 287 */     hasUpdated = true;
/* 288 */     this.type.set(ConfigManager.getConfig(), this.path, (T)value);
/* 289 */     ConfigManager.setComments(this.path, this.comments);
/*     */   }
/*     */   
/*     */   public void resetValue() {
/* 293 */     hasUpdated = true;
/* 294 */     this.type.set(ConfigManager.getConfig(), this.path, this.defaultValue);
/* 295 */     ConfigManager.setComments(this.path, this.comments);
/*     */   }
/*     */   
/*     */   private static void makeOptionHeader(String path, List<String> comments) {
/* 299 */     if (!ConfigManager.getConfig().contains(path)) {
/* 300 */       ConfigManager.getConfig().set(path, "[Placeholder]");
/* 301 */       hasUpdated = true;
/*     */     } 
/* 303 */     ConfigManager.setComments(path, comments);
/*     */   }
/*     */   
/*     */   private static void makeOptionHeader(String path, String comment) {
/* 307 */     makeOptionHeader(path, Collections.singletonList(comment));
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercit\\util\config\ConfigManager$Option.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */