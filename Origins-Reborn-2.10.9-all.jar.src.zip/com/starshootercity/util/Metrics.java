/*     */ package com.starshootercity.util;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.logging.Level;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.zip.GZIPOutputStream;
/*     */ import javax.net.ssl.HttpsURLConnection;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.configuration.file.YamlConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Metrics
/*     */ {
/*     */   private final Plugin plugin;
/*     */   private final MetricsBase metricsBase;
/*     */   
/*     */   public Metrics(Plugin plugin, int serviceId) {
/*  63 */     this.plugin = plugin;
/*     */     
/*  65 */     File bStatsFolder = new File(plugin.getDataFolder().getParentFile(), "bStats");
/*  66 */     File configFile = new File(bStatsFolder, "config.yml");
/*  67 */     YamlConfiguration config = YamlConfiguration.loadConfiguration(configFile);
/*  68 */     if (!config.isSet("serverUuid")) {
/*  69 */       config.addDefault("enabled", Boolean.valueOf(true));
/*  70 */       config.addDefault("serverUuid", UUID.randomUUID().toString());
/*  71 */       config.addDefault("logFailedRequests", Boolean.valueOf(false));
/*  72 */       config.addDefault("logSentData", Boolean.valueOf(false));
/*  73 */       config.addDefault("logResponseStatusText", Boolean.valueOf(false));
/*     */       
/*  75 */       config
/*  76 */         .options()
/*  77 */         .header("bStats (https://bStats.org) collects some basic information for plugin authors, like how\nmany people use their plugin and their total player count. It's recommended to keep bStats\nenabled, but if you're not comfortable with this, you can turn this setting off. There is no\nperformance penalty associated with having metrics enabled, and data sent to bStats is fully\nanonymous.")
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  83 */         .copyDefaults(true);
/*     */       try {
/*  85 */         config.save(configFile);
/*  86 */       } catch (IOException iOException) {}
/*     */     } 
/*     */ 
/*     */     
/*  90 */     boolean enabled = config.getBoolean("enabled", true);
/*  91 */     String serverUUID = config.getString("serverUuid");
/*  92 */     boolean logErrors = config.getBoolean("logFailedRequests", false);
/*  93 */     boolean logSentData = config.getBoolean("logSentData", false);
/*  94 */     boolean logResponseStatusText = config.getBoolean("logResponseStatusText", false);
/*  95 */     boolean isFolia = false;
/*     */     try {
/*  97 */       isFolia = (Class.forName("io.papermc.paper.threadedregions.RegionizedServer") != null);
/*  98 */     } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 118 */     Objects.requireNonNull(plugin); this.metricsBase = new MetricsBase("bukkit", serverUUID, serviceId, enabled, this::appendPlatformData, this::appendServiceData, isFolia ? null : (submitDataTask -> Bukkit.getScheduler().runTask(plugin, submitDataTask)), plugin::isEnabled, (message, error) -> this.plugin.getLogger().log(Level.WARNING, message, error), message -> this.plugin.getLogger().log(Level.INFO, message), logErrors, logSentData, logResponseStatusText, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void shutdown() {
/* 129 */     this.metricsBase.shutdown();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addCustomChart(CustomChart chart) {
/* 138 */     this.metricsBase.addCustomChart(chart);
/*     */   }
/*     */   
/*     */   private void appendPlatformData(JsonObjectBuilder builder) {
/* 142 */     builder.appendField("playerAmount", getPlayerAmount());
/* 143 */     builder.appendField("onlineMode", Bukkit.getOnlineMode() ? 1 : 0);
/* 144 */     builder.appendField("bukkitVersion", Bukkit.getVersion());
/* 145 */     builder.appendField("bukkitName", Bukkit.getName());
/* 146 */     builder.appendField("javaVersion", System.getProperty("java.version"));
/* 147 */     builder.appendField("osName", System.getProperty("os.name"));
/* 148 */     builder.appendField("osArch", System.getProperty("os.arch"));
/* 149 */     builder.appendField("osVersion", System.getProperty("os.version"));
/* 150 */     builder.appendField("coreCount", Runtime.getRuntime().availableProcessors());
/*     */   }
/*     */   
/*     */   private void appendServiceData(JsonObjectBuilder builder) {
/* 154 */     builder.appendField("pluginVersion", this.plugin.getDescription().getVersion());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getPlayerAmount() {
/*     */     try {
/* 162 */       Method onlinePlayersMethod = Class.forName("org.bukkit.Server").getMethod("getOnlinePlayers", new Class[0]);
/* 163 */       return onlinePlayersMethod.getReturnType().equals(Collection.class) ? (
/* 164 */         (Collection)onlinePlayersMethod.invoke(Bukkit.getServer(), new Object[0])).size() : (
/* 165 */         (Player[])onlinePlayersMethod.invoke(Bukkit.getServer(), new Object[0])).length;
/* 166 */     } catch (Exception e) {
/*     */       
/* 168 */       return Bukkit.getOnlinePlayers().size();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static class MetricsBase
/*     */   {
/*     */     public static final String METRICS_VERSION = "3.1.0";
/*     */     
/*     */     private static final String REPORT_URL = "https://bStats.org/api/v2/data/%s";
/*     */     
/*     */     private final ScheduledExecutorService scheduler;
/*     */     
/*     */     private final String platform;
/*     */     
/*     */     private final String serverUuid;
/*     */     
/*     */     private final int serviceId;
/*     */     
/*     */     private final Consumer<Metrics.JsonObjectBuilder> appendPlatformDataConsumer;
/*     */     
/*     */     private final Consumer<Metrics.JsonObjectBuilder> appendServiceDataConsumer;
/*     */     
/*     */     private final Consumer<Runnable> submitTaskConsumer;
/*     */     
/*     */     private final Supplier<Boolean> checkServiceEnabledSupplier;
/*     */     
/*     */     private final BiConsumer<String, Throwable> errorLogger;
/*     */     
/*     */     private final Consumer<String> infoLogger;
/*     */     
/*     */     private final boolean logErrors;
/*     */     
/*     */     private final boolean logSentData;
/*     */     
/*     */     private final boolean logResponseStatusText;
/*     */     
/* 205 */     private final Set<Metrics.CustomChart> customCharts = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final boolean enabled;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MetricsBase(String platform, String serverUuid, int serviceId, boolean enabled, Consumer<Metrics.JsonObjectBuilder> appendPlatformDataConsumer, Consumer<Metrics.JsonObjectBuilder> appendServiceDataConsumer, Consumer<Runnable> submitTaskConsumer, Supplier<Boolean> checkServiceEnabledSupplier, BiConsumer<String, Throwable> errorLogger, Consumer<String> infoLogger, boolean logErrors, boolean logSentData, boolean logResponseStatusText, boolean skipRelocateCheck) {
/* 246 */       ScheduledThreadPoolExecutor scheduler = new ScheduledThreadPoolExecutor(1, task -> {
/*     */             Thread thread = new Thread(task, "bStats-Metrics");
/*     */ 
/*     */ 
/*     */             
/*     */             thread.setDaemon(true);
/*     */ 
/*     */             
/*     */             return thread;
/*     */           });
/*     */ 
/*     */       
/* 258 */       scheduler.setExecuteExistingDelayedTasksAfterShutdownPolicy(false);
/* 259 */       this.scheduler = scheduler;
/* 260 */       this.platform = platform;
/* 261 */       this.serverUuid = serverUuid;
/* 262 */       this.serviceId = serviceId;
/* 263 */       this.enabled = enabled;
/* 264 */       this.appendPlatformDataConsumer = appendPlatformDataConsumer;
/* 265 */       this.appendServiceDataConsumer = appendServiceDataConsumer;
/* 266 */       this.submitTaskConsumer = submitTaskConsumer;
/* 267 */       this.checkServiceEnabledSupplier = checkServiceEnabledSupplier;
/* 268 */       this.errorLogger = errorLogger;
/* 269 */       this.infoLogger = infoLogger;
/* 270 */       this.logErrors = logErrors;
/* 271 */       this.logSentData = logSentData;
/* 272 */       this.logResponseStatusText = logResponseStatusText;
/* 273 */       if (!skipRelocateCheck) {
/* 274 */         checkRelocation();
/*     */       }
/* 276 */       if (enabled)
/*     */       {
/*     */         
/* 279 */         startSubmitting();
/*     */       }
/*     */     }
/*     */     
/*     */     public void addCustomChart(Metrics.CustomChart chart) {
/* 284 */       this.customCharts.add(chart);
/*     */     }
/*     */     
/*     */     public void shutdown() {
/* 288 */       this.scheduler.shutdown();
/*     */     }
/*     */     
/*     */     private void startSubmitting() {
/* 292 */       Runnable submitTask = () -> {
/*     */           if (!this.enabled || !((Boolean)this.checkServiceEnabledSupplier.get()).booleanValue()) {
/*     */             this.scheduler.shutdown();
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             return;
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/*     */           if (this.submitTaskConsumer != null) {
/*     */             this.submitTaskConsumer.accept(this::submitData);
/*     */           } else {
/*     */             submitData();
/*     */           } 
/*     */         };
/*     */ 
/*     */ 
/*     */       
/* 313 */       long initialDelay = (long)(60000.0D * (3.0D + Math.random() * 3.0D));
/* 314 */       long secondDelay = (long)(60000.0D * Math.random() * 30.0D);
/* 315 */       this.scheduler.schedule(submitTask, initialDelay, TimeUnit.MILLISECONDS);
/* 316 */       this.scheduler.scheduleAtFixedRate(submitTask, initialDelay + secondDelay, 1800000L, TimeUnit.MILLISECONDS);
/*     */     }
/*     */ 
/*     */     
/*     */     private void submitData() {
/* 321 */       Metrics.JsonObjectBuilder baseJsonBuilder = new Metrics.JsonObjectBuilder();
/* 322 */       this.appendPlatformDataConsumer.accept(baseJsonBuilder);
/* 323 */       Metrics.JsonObjectBuilder serviceJsonBuilder = new Metrics.JsonObjectBuilder();
/* 324 */       this.appendServiceDataConsumer.accept(serviceJsonBuilder);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 329 */       Metrics.JsonObjectBuilder.JsonObject[] chartData = (Metrics.JsonObjectBuilder.JsonObject[])this.customCharts.stream().map(customChart -> customChart.getRequestJsonObject(this.errorLogger, this.logErrors)).filter(Objects::nonNull).toArray(x$0 -> new Metrics.JsonObjectBuilder.JsonObject[x$0]);
/* 330 */       serviceJsonBuilder.appendField("id", this.serviceId);
/* 331 */       serviceJsonBuilder.appendField("customCharts", chartData);
/* 332 */       baseJsonBuilder.appendField("service", serviceJsonBuilder.build());
/* 333 */       baseJsonBuilder.appendField("serverUUID", this.serverUuid);
/* 334 */       baseJsonBuilder.appendField("metricsVersion", "3.1.0");
/* 335 */       Metrics.JsonObjectBuilder.JsonObject data = baseJsonBuilder.build();
/* 336 */       this.scheduler.execute(() -> {
/*     */ 
/*     */             
/*     */             try {
/*     */               sendData(data);
/* 341 */             } catch (Exception e) {
/*     */               if (this.logErrors) {
/*     */                 this.errorLogger.accept("Could not submit bStats metrics data", e);
/*     */               }
/*     */             } 
/*     */           });
/*     */     }
/*     */ 
/*     */     
/*     */     private void sendData(Metrics.JsonObjectBuilder.JsonObject data) throws Exception {
/* 351 */       if (this.logSentData) {
/* 352 */         this.infoLogger.accept("Sent bStats metrics data: " + data.toString());
/*     */       }
/* 354 */       String url = String.format("https://bStats.org/api/v2/data/%s", new Object[] { this.platform });
/* 355 */       HttpsURLConnection connection = (HttpsURLConnection)(new URL(url)).openConnection();
/*     */       
/* 357 */       byte[] compressedData = compress(data.toString());
/* 358 */       connection.setRequestMethod("POST");
/* 359 */       connection.addRequestProperty("Accept", "application/json");
/* 360 */       connection.addRequestProperty("Connection", "close");
/* 361 */       connection.addRequestProperty("Content-Encoding", "gzip");
/* 362 */       connection.addRequestProperty("Content-Length", String.valueOf(compressedData.length));
/* 363 */       connection.setRequestProperty("Content-Type", "application/json");
/* 364 */       connection.setRequestProperty("User-Agent", "Metrics-Service/1");
/* 365 */       connection.setDoOutput(true);
/* 366 */       DataOutputStream outputStream = new DataOutputStream(connection.getOutputStream()); 
/* 367 */       try { outputStream.write(compressedData);
/* 368 */         outputStream.close(); } catch (Throwable throwable) { try { outputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }
/* 369 */        StringBuilder builder = new StringBuilder();
/*     */       
/* 371 */       BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(connection.getInputStream())); 
/*     */       try { String line;
/* 373 */         while ((line = bufferedReader.readLine()) != null) {
/* 374 */           builder.append(line);
/*     */         }
/* 376 */         bufferedReader.close(); } catch (Throwable throwable) { try { bufferedReader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }
/* 377 */        if (this.logResponseStatusText) {
/* 378 */         this.infoLogger.accept("Sent data to bStats and received response: " + String.valueOf(builder));
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private void checkRelocation() {
/* 385 */       if (System.getProperty("bstats.relocatecheck") == null || 
/* 386 */         !System.getProperty("bstats.relocatecheck").equals("false")) {
/*     */ 
/*     */         
/* 389 */         String defaultPackage = new String(new byte[] { 111, 114, 103, 46, 98, 115, 116, 97, 116, 115 });
/*     */         
/* 391 */         String examplePackage = new String(new byte[] { 121, 111, 117, 114, 46, 112, 97, 99, 107, 97, 103, 101 });
/*     */ 
/*     */ 
/*     */         
/* 395 */         if (MetricsBase.class.getPackage().getName().startsWith(defaultPackage) || MetricsBase.class
/* 396 */           .getPackage().getName().startsWith(examplePackage)) {
/* 397 */           throw new IllegalStateException("bStats Metrics class has not been relocated correctly!");
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static byte[] compress(String str) throws IOException {
/* 409 */       if (str == null) {
/* 410 */         return null;
/*     */       }
/* 412 */       ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
/* 413 */       GZIPOutputStream gzip = new GZIPOutputStream(outputStream); 
/* 414 */       try { gzip.write(str.getBytes(StandardCharsets.UTF_8));
/* 415 */         gzip.close(); } catch (Throwable throwable) { try { gzip.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }
/* 416 */        return outputStream.toByteArray();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class AdvancedBarChart
/*     */     extends CustomChart
/*     */   {
/*     */     private final Callable<Map<String, int[]>> callable;
/*     */ 
/*     */ 
/*     */     
/*     */     public AdvancedBarChart(String chartId, Callable<Map<String, int[]>> callable) {
/* 431 */       super(chartId);
/* 432 */       this.callable = callable;
/*     */     }
/*     */ 
/*     */     
/*     */     protected Metrics.JsonObjectBuilder.JsonObject getChartData() throws Exception {
/* 437 */       Metrics.JsonObjectBuilder valuesBuilder = new Metrics.JsonObjectBuilder();
/* 438 */       Map<String, int[]> map = this.callable.call();
/* 439 */       if (map == null || map.isEmpty())
/*     */       {
/* 441 */         return null;
/*     */       }
/* 443 */       boolean allSkipped = true;
/* 444 */       for (Map.Entry<String, int[]> entry : map.entrySet()) {
/* 445 */         if (((int[])entry.getValue()).length == 0) {
/*     */           continue;
/*     */         }
/*     */         
/* 449 */         allSkipped = false;
/* 450 */         valuesBuilder.appendField(entry.getKey(), entry.getValue());
/*     */       } 
/* 452 */       if (allSkipped)
/*     */       {
/* 454 */         return null;
/*     */       }
/* 456 */       return (new Metrics.JsonObjectBuilder()).appendField("values", valuesBuilder.build()).build();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class SimplePie
/*     */     extends CustomChart
/*     */   {
/*     */     private final Callable<String> callable;
/*     */ 
/*     */ 
/*     */     
/*     */     public SimplePie(String chartId, Callable<String> callable) {
/* 471 */       super(chartId);
/* 472 */       this.callable = callable;
/*     */     }
/*     */ 
/*     */     
/*     */     protected Metrics.JsonObjectBuilder.JsonObject getChartData() throws Exception {
/* 477 */       String value = this.callable.call();
/* 478 */       if (value == null || value.isEmpty())
/*     */       {
/* 480 */         return null;
/*     */       }
/* 482 */       return (new Metrics.JsonObjectBuilder()).appendField("value", value).build();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class DrilldownPie
/*     */     extends CustomChart
/*     */   {
/*     */     private final Callable<Map<String, Map<String, Integer>>> callable;
/*     */ 
/*     */ 
/*     */     
/*     */     public DrilldownPie(String chartId, Callable<Map<String, Map<String, Integer>>> callable) {
/* 497 */       super(chartId);
/* 498 */       this.callable = callable;
/*     */     }
/*     */ 
/*     */     
/*     */     public Metrics.JsonObjectBuilder.JsonObject getChartData() throws Exception {
/* 503 */       Metrics.JsonObjectBuilder valuesBuilder = new Metrics.JsonObjectBuilder();
/* 504 */       Map<String, Map<String, Integer>> map = this.callable.call();
/* 505 */       if (map == null || map.isEmpty())
/*     */       {
/* 507 */         return null;
/*     */       }
/* 509 */       boolean reallyAllSkipped = true;
/* 510 */       for (Map.Entry<String, Map<String, Integer>> entryValues : map.entrySet()) {
/* 511 */         Metrics.JsonObjectBuilder valueBuilder = new Metrics.JsonObjectBuilder();
/* 512 */         boolean allSkipped = true;
/* 513 */         for (Map.Entry<String, Integer> valueEntry : (Iterable<Map.Entry<String, Integer>>)((Map)map.get(entryValues.getKey())).entrySet()) {
/* 514 */           valueBuilder.appendField(valueEntry.getKey(), ((Integer)valueEntry.getValue()).intValue());
/* 515 */           allSkipped = false;
/*     */         } 
/* 517 */         if (!allSkipped) {
/* 518 */           reallyAllSkipped = false;
/* 519 */           valuesBuilder.appendField(entryValues.getKey(), valueBuilder.build());
/*     */         } 
/*     */       } 
/* 522 */       if (reallyAllSkipped)
/*     */       {
/* 524 */         return null;
/*     */       }
/* 526 */       return (new Metrics.JsonObjectBuilder()).appendField("values", valuesBuilder.build()).build();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class SingleLineChart
/*     */     extends CustomChart
/*     */   {
/*     */     private final Callable<Integer> callable;
/*     */ 
/*     */ 
/*     */     
/*     */     public SingleLineChart(String chartId, Callable<Integer> callable) {
/* 541 */       super(chartId);
/* 542 */       this.callable = callable;
/*     */     }
/*     */ 
/*     */     
/*     */     protected Metrics.JsonObjectBuilder.JsonObject getChartData() throws Exception {
/* 547 */       int value = ((Integer)this.callable.call()).intValue();
/* 548 */       if (value == 0)
/*     */       {
/* 550 */         return null;
/*     */       }
/* 552 */       return (new Metrics.JsonObjectBuilder()).appendField("value", value).build();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class MultiLineChart
/*     */     extends CustomChart
/*     */   {
/*     */     private final Callable<Map<String, Integer>> callable;
/*     */ 
/*     */ 
/*     */     
/*     */     public MultiLineChart(String chartId, Callable<Map<String, Integer>> callable) {
/* 567 */       super(chartId);
/* 568 */       this.callable = callable;
/*     */     }
/*     */ 
/*     */     
/*     */     protected Metrics.JsonObjectBuilder.JsonObject getChartData() throws Exception {
/* 573 */       Metrics.JsonObjectBuilder valuesBuilder = new Metrics.JsonObjectBuilder();
/* 574 */       Map<String, Integer> map = this.callable.call();
/* 575 */       if (map == null || map.isEmpty())
/*     */       {
/* 577 */         return null;
/*     */       }
/* 579 */       boolean allSkipped = true;
/* 580 */       for (Map.Entry<String, Integer> entry : map.entrySet()) {
/* 581 */         if (((Integer)entry.getValue()).intValue() == 0) {
/*     */           continue;
/*     */         }
/*     */         
/* 585 */         allSkipped = false;
/* 586 */         valuesBuilder.appendField(entry.getKey(), ((Integer)entry.getValue()).intValue());
/*     */       } 
/* 588 */       if (allSkipped)
/*     */       {
/* 590 */         return null;
/*     */       }
/* 592 */       return (new Metrics.JsonObjectBuilder()).appendField("values", valuesBuilder.build()).build();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class AdvancedPie
/*     */     extends CustomChart
/*     */   {
/*     */     private final Callable<Map<String, Integer>> callable;
/*     */ 
/*     */ 
/*     */     
/*     */     public AdvancedPie(String chartId, Callable<Map<String, Integer>> callable) {
/* 607 */       super(chartId);
/* 608 */       this.callable = callable;
/*     */     }
/*     */ 
/*     */     
/*     */     protected Metrics.JsonObjectBuilder.JsonObject getChartData() throws Exception {
/* 613 */       Metrics.JsonObjectBuilder valuesBuilder = new Metrics.JsonObjectBuilder();
/* 614 */       Map<String, Integer> map = this.callable.call();
/* 615 */       if (map == null || map.isEmpty())
/*     */       {
/* 617 */         return null;
/*     */       }
/* 619 */       boolean allSkipped = true;
/* 620 */       for (Map.Entry<String, Integer> entry : map.entrySet()) {
/* 621 */         if (((Integer)entry.getValue()).intValue() == 0) {
/*     */           continue;
/*     */         }
/*     */         
/* 625 */         allSkipped = false;
/* 626 */         valuesBuilder.appendField(entry.getKey(), ((Integer)entry.getValue()).intValue());
/*     */       } 
/* 628 */       if (allSkipped)
/*     */       {
/* 630 */         return null;
/*     */       }
/* 632 */       return (new Metrics.JsonObjectBuilder()).appendField("values", valuesBuilder.build()).build();
/*     */     }
/*     */   }
/*     */   
/*     */   public static abstract class CustomChart
/*     */   {
/*     */     private final String chartId;
/*     */     
/*     */     protected CustomChart(String chartId) {
/* 641 */       if (chartId == null) {
/* 642 */         throw new IllegalArgumentException("chartId must not be null");
/*     */       }
/* 644 */       this.chartId = chartId;
/*     */     }
/*     */ 
/*     */     
/*     */     public Metrics.JsonObjectBuilder.JsonObject getRequestJsonObject(BiConsumer<String, Throwable> errorLogger, boolean logErrors) {
/* 649 */       Metrics.JsonObjectBuilder builder = new Metrics.JsonObjectBuilder();
/* 650 */       builder.appendField("chartId", this.chartId);
/*     */       try {
/* 652 */         Metrics.JsonObjectBuilder.JsonObject data = getChartData();
/* 653 */         if (data == null)
/*     */         {
/* 655 */           return null;
/*     */         }
/* 657 */         builder.appendField("data", data);
/* 658 */       } catch (Throwable t) {
/* 659 */         if (logErrors) {
/* 660 */           errorLogger.accept("Failed to get data for custom chart with id " + this.chartId, t);
/*     */         }
/* 662 */         return null;
/*     */       } 
/* 664 */       return builder.build();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected abstract Metrics.JsonObjectBuilder.JsonObject getChartData() throws Exception;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class SimpleBarChart
/*     */     extends CustomChart
/*     */   {
/*     */     private final Callable<Map<String, Integer>> callable;
/*     */ 
/*     */     
/*     */     public SimpleBarChart(String chartId, Callable<Map<String, Integer>> callable) {
/* 681 */       super(chartId);
/* 682 */       this.callable = callable;
/*     */     }
/*     */ 
/*     */     
/*     */     protected Metrics.JsonObjectBuilder.JsonObject getChartData() throws Exception {
/* 687 */       Metrics.JsonObjectBuilder valuesBuilder = new Metrics.JsonObjectBuilder();
/* 688 */       Map<String, Integer> map = this.callable.call();
/* 689 */       if (map == null || map.isEmpty())
/*     */       {
/* 691 */         return null;
/*     */       }
/* 693 */       for (Map.Entry<String, Integer> entry : map.entrySet()) {
/* 694 */         valuesBuilder.appendField(entry.getKey(), new int[] { ((Integer)entry.getValue()).intValue() });
/*     */       } 
/* 696 */       return (new Metrics.JsonObjectBuilder()).appendField("values", valuesBuilder.build()).build();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class JsonObjectBuilder
/*     */   {
/* 708 */     private StringBuilder builder = new StringBuilder();
/*     */     
/*     */     private boolean hasAtLeastOneField = false;
/*     */     
/*     */     public JsonObjectBuilder() {
/* 713 */       this.builder.append("{");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public JsonObjectBuilder appendNull(String key) {
/* 723 */       appendFieldUnescaped(key, "null");
/* 724 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public JsonObjectBuilder appendField(String key, String value) {
/* 735 */       if (value == null) {
/* 736 */         throw new IllegalArgumentException("JSON value must not be null");
/*     */       }
/* 738 */       appendFieldUnescaped(key, "\"" + escape(value) + "\"");
/* 739 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public JsonObjectBuilder appendField(String key, int value) {
/* 750 */       appendFieldUnescaped(key, String.valueOf(value));
/* 751 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public JsonObjectBuilder appendField(String key, JsonObject object) {
/* 762 */       if (object == null) {
/* 763 */         throw new IllegalArgumentException("JSON object must not be null");
/*     */       }
/* 765 */       appendFieldUnescaped(key, object.toString());
/* 766 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public JsonObjectBuilder appendField(String key, String[] values) {
/* 777 */       if (values == null) {
/* 778 */         throw new IllegalArgumentException("JSON values must not be null");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 783 */       String escapedValues = Arrays.<String>stream(values).map(value -> "\"" + escape(value) + "\"").collect(Collectors.joining(","));
/* 784 */       appendFieldUnescaped(key, "[" + escapedValues + "]");
/* 785 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public JsonObjectBuilder appendField(String key, int[] values) {
/* 796 */       if (values == null) {
/* 797 */         throw new IllegalArgumentException("JSON values must not be null");
/*     */       }
/*     */       
/* 800 */       String escapedValues = Arrays.stream(values).<CharSequence>mapToObj(String::valueOf).collect(Collectors.joining(","));
/* 801 */       appendFieldUnescaped(key, "[" + escapedValues + "]");
/* 802 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public JsonObjectBuilder appendField(String key, JsonObject[] values) {
/* 813 */       if (values == null) {
/* 814 */         throw new IllegalArgumentException("JSON values must not be null");
/*     */       }
/*     */       
/* 817 */       String escapedValues = Arrays.<JsonObject>stream(values).map(JsonObject::toString).collect(Collectors.joining(","));
/* 818 */       appendFieldUnescaped(key, "[" + escapedValues + "]");
/* 819 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void appendFieldUnescaped(String key, String escapedValue) {
/* 829 */       if (this.builder == null) {
/* 830 */         throw new IllegalStateException("JSON has already been built");
/*     */       }
/* 832 */       if (key == null) {
/* 833 */         throw new IllegalArgumentException("JSON key must not be null");
/*     */       }
/* 835 */       if (this.hasAtLeastOneField) {
/* 836 */         this.builder.append(",");
/*     */       }
/* 838 */       this.builder.append("\"").append(escape(key)).append("\":").append(escapedValue);
/* 839 */       this.hasAtLeastOneField = true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public JsonObject build() {
/* 848 */       if (this.builder == null) {
/* 849 */         throw new IllegalStateException("JSON has already been built");
/*     */       }
/* 851 */       JsonObject object = new JsonObject(this.builder.append("}").toString());
/* 852 */       this.builder = null;
/* 853 */       return object;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static String escape(String value) {
/* 866 */       StringBuilder builder = new StringBuilder();
/* 867 */       for (int i = 0; i < value.length(); i++) {
/* 868 */         char c = value.charAt(i);
/* 869 */         if (c == '"') {
/* 870 */           builder.append("\\\"");
/* 871 */         } else if (c == '\\') {
/* 872 */           builder.append("\\\\");
/* 873 */         } else if (c <= '\017') {
/* 874 */           builder.append("\\u000").append(Integer.toHexString(c));
/* 875 */         } else if (c <= '\037') {
/* 876 */           builder.append("\\u00").append(Integer.toHexString(c));
/*     */         } else {
/* 878 */           builder.append(c);
/*     */         } 
/*     */       } 
/* 881 */       return builder.toString();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static class JsonObject
/*     */     {
/*     */       private final String value;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private JsonObject(String value) {
/* 896 */         this.value = value;
/*     */       }
/*     */       
/*     */       public String toString()
/*     */       {
/* 901 */         return this.value; } } } public static class JsonObject { public String toString() { return this.value; }
/*     */ 
/*     */     
/*     */     private final String value;
/*     */     
/*     */     private JsonObject(String value) {
/*     */       this.value = value;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercit\\util\Metrics.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */