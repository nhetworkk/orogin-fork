/*   */ package com.starshootercity.util;public final class Pair<T, U> extends Record { private final T left; private final U right;
/*   */   
/* 3 */   public Pair(T left, U right) { this.left = left; this.right = right; } public final String toString() { // Byte code:
/*   */     //   0: aload_0
/*   */     //   1: <illegal opcode> toString : (Lcom/starshootercity/util/Pair;)Ljava/lang/String;
/*   */     //   6: areturn
/*   */     // Line number table:
/*   */     //   Java source line number -> byte code offset
/*   */     //   #3	-> 0
/*   */     // Local variable table:
/*   */     //   start	length	slot	name	descriptor
/*   */     //   0	7	0	this	Lcom/starshootercity/util/Pair;
/*   */     // Local variable type table:
/*   */     //   start	length	slot	name	signature
/* 3 */     //   0	7	0	this	Lcom/starshootercity/util/Pair<TT;TU;>; } public T left() { return this.left; } public final int hashCode() { // Byte code:
/*   */     //   0: aload_0
/*   */     //   1: <illegal opcode> hashCode : (Lcom/starshootercity/util/Pair;)I
/*   */     //   6: ireturn
/*   */     // Line number table:
/*   */     //   Java source line number -> byte code offset
/*   */     //   #3	-> 0
/*   */     // Local variable table:
/*   */     //   start	length	slot	name	descriptor
/*   */     //   0	7	0	this	Lcom/starshootercity/util/Pair;
/*   */     // Local variable type table:
/*   */     //   start	length	slot	name	signature
/*   */     //   0	7	0	this	Lcom/starshootercity/util/Pair<TT;TU;>; } public final boolean equals(Object o) { // Byte code:
/*   */     //   0: aload_0
/*   */     //   1: aload_1
/*   */     //   2: <illegal opcode> equals : (Lcom/starshootercity/util/Pair;Ljava/lang/Object;)Z
/*   */     //   7: ireturn
/*   */     // Line number table:
/*   */     //   Java source line number -> byte code offset
/*   */     //   #3	-> 0
/*   */     // Local variable table:
/*   */     //   start	length	slot	name	descriptor
/*   */     //   0	8	0	this	Lcom/starshootercity/util/Pair;
/*   */     //   0	8	1	o	Ljava/lang/Object;
/*   */     // Local variable type table:
/*   */     //   start	length	slot	name	signature
/* 3 */     //   0	8	0	this	Lcom/starshootercity/util/Pair<TT;TU;>; } public U right() { return this.right; }
/*   */    }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercit\\util\Pair.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */