/*     */ package com.starshootercity.util;
/*     */ import com.starshootercity.OriginsAddon;
/*     */ import com.starshootercity.abilities.types.Ability;
/*     */ import com.starshootercity.abilities.types.AsyncRepeatingAbility;
/*     */ import com.starshootercity.abilities.types.AttributeModifierAbility;
/*     */ import com.starshootercity.abilities.types.BreakSpeedModifierAbility;
/*     */ import com.starshootercity.abilities.types.DependencyAbility;
/*     */ import com.starshootercity.abilities.types.FlightAllowingAbility;
/*     */ import com.starshootercity.abilities.types.ListenerAbility;
/*     */ import com.starshootercity.abilities.types.MultiAbility;
/*     */ import com.starshootercity.abilities.types.SkinChangingAbility;
/*     */ import com.starshootercity.abilities.types.VisibleAbility;
/*     */ import com.starshootercity.util.config.ConfigManager;
/*     */ import com.starshootercity.version.MVAccessor;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import net.kyori.adventure.util.TriState;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.NamespacedKey;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.LivingEntity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.inventory.EquipmentSlot;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ import org.bukkit.scheduler.BukkitRunnable;
/*     */ 
/*     */ @APITarget
/*     */ public class AbilityRegister {
/*  35 */   public static Map<Key, Ability> abilityMap = new HashMap<>();
/*  36 */   public static Map<Ability, Key> invertedAbilityMap = new HashMap<>();
/*     */   
/*  38 */   public static Map<Key, OriginsAddon> pluginMap = new HashMap<>();
/*  39 */   public static Map<Key, DependencyAbility> dependencyAbilityMap = new HashMap<>();
/*  40 */   public static Map<Key, List<MultiAbility>> multiAbilityMap = new HashMap<>();
/*  41 */   public static List<BreakSpeedModifierAbility> breakSpeedModifierAbilities = new ArrayList<>();
/*     */   
/*  43 */   public static List<Pair<AttributeModifierAbility, NamespacedKey>> attributeModifierAbilities = new ArrayList<>();
/*     */   
/*  45 */   public static List<SkinChangingAbility> skinChangingAbilities = new ArrayList<>();
/*  46 */   public static List<AsyncRepeatingAbility> asyncRepeatingAbilities = new ArrayList<>();
/*  47 */   public static List<FlightAllowingAbility> flightAllowingAbilities = new ArrayList<>();
/*     */   
/*  49 */   public static Map<Key, List<AbilityRunnable>> runOnRegisters = new HashMap<>();
/*     */   
/*     */   private static File abilityFile;
/*     */   private static FileConfiguration abilityFileConfig;
/*     */   
/*     */   public static <T> void registerConfigOption(JavaPlugin plugin, Ability ability, ConfigManager.SettingType<T> settingType, String path, List<String> comments, T defaultValue) {
/*  55 */     String namespace = getNamespace(plugin);
/*  56 */     String pathToUse = namespace + "." + namespace + "." + ability.getRegisteredKey().value();
/*  57 */     if (abilityFileConfig.contains(pathToUse))
/*     */       return; 
/*  59 */     settingType.set((ConfigurationSection)abilityFileConfig, pathToUse, defaultValue);
/*     */     
/*  61 */     MVAccessor.get().setComments(abilityFileConfig, pathToUse, comments);
/*     */     
/*     */     try {
/*  64 */       abilityFileConfig.save(abilityFile);
/*  65 */     } catch (IOException e) {
/*  66 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String getNamespace(JavaPlugin plugin) {
/*  71 */     if (plugin instanceof OriginsAddon) { OriginsAddon addon = (OriginsAddon)plugin;
/*  72 */       return addon.getNamespace(); }
/*  73 */      return plugin.getName().toLowerCase();
/*     */   }
/*     */   
/*  76 */   private static final Map<String, Object> cache = new HashMap<>();
/*     */   public static List<String> disabledWorlds;
/*     */   
/*     */   public static <T> T getConfigOption(JavaPlugin plugin, Ability ability, ConfigManager.SettingType<T> settingType, String path) {
/*  80 */     return (T)cache.computeIfAbsent(
/*  81 */         getNamespace(plugin) + "." + getNamespace(plugin) + "." + ability.getRegisteredKey().value(), s -> settingType.get((ConfigurationSection)abilityFileConfig, s));
/*     */   }
/*     */ 
/*     */   
/*     */   public static void reloadAbilityConfig() {
/*  86 */     cache.clear();
/*     */     try {
/*  88 */       abilityFileConfig.load(abilityFile);
/*  89 */     } catch (IOException|org.bukkit.configuration.InvalidConfigurationException e) {
/*  90 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void setupAbilityConfig(JavaPlugin plugin) {
/*  95 */     abilityFile = new File(plugin.getDataFolder(), "ability-config.yml");
/*     */     
/*  97 */     if (!abilityFile.exists()) {
/*  98 */       boolean ignored = abilityFile.getParentFile().mkdirs();
/*  99 */       plugin.saveResource("ability-config.yml", false);
/*     */     } 
/*     */     
/* 102 */     abilityFileConfig = (FileConfiguration)new YamlConfiguration();
/*     */     
/* 104 */     reloadAbilityConfig();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void initialize(JavaPlugin plugin) {
/* 110 */     disabledWorlds = new ArrayList<>((Collection<? extends String>)ConfigManager.getConfigValue(ConfigManager.Option.DISABLED_WORLDS));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 115 */     MVAccessor.scheduleManager().delayedTask(plugin, () -> {
/*     */           for (AsyncRepeatingAbility ability : asyncRepeatingAbilities) {
/*     */             ability.start();
/*     */           }
/*     */           final int[] tick = { 0 };
/*     */           (new BukkitRunnable()
/*     */             {
/*     */               public void run()
/*     */               {
/* 124 */                 for (AsyncRepeatingAbility ability : AbilityRegister.asyncRepeatingAbilities) {
/*     */                   
/* 126 */                   if (tick[0] % ability.interval() == 0) ability.run();
/*     */                 
/*     */                 } 
/* 129 */                 tick[0] = tick[0] + 1;
/*     */               }
/*     */             }).runTaskTimerAsynchronously((Plugin)plugin, 0L, 1L);
/*     */         });
/*     */   }
/*     */   
/*     */   private static boolean skinManagerEnabled = false;
/*     */   
/*     */   public static void setSkinManagerEnabled() {
/* 138 */     skinManagerEnabled = true;
/*     */   }
/*     */   
/*     */   public static boolean isSkinManagerEnabled() {
/* 142 */     return skinManagerEnabled;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void registerAbility(Ability ability, Key key, JavaPlugin instance) {
/* 147 */     if (ability instanceof SkinChangingAbility) { SkinChangingAbility skinChangingAbility = (SkinChangingAbility)ability;
/* 148 */       if (!isSkinManagerEnabled() && !skinChangingAbility.forceEnabled())
/* 149 */         return;  skinChangingAbilities.add(skinChangingAbility); }
/*     */ 
/*     */     
/* 152 */     invertedAbilityMap.put(ability, key);
/*     */     
/* 154 */     if (instance instanceof OriginsAddon) { OriginsAddon addon = (OriginsAddon)instance;
/* 155 */       pluginMap.put(ability.getRegisteredKey(), addon); }
/*     */ 
/*     */     
/* 158 */     if (runOnRegisters.containsKey(ability.getRegisteredKey())) {
/* 159 */       for (AbilityRunnable r : runOnRegisters.get(ability.getRegisteredKey())) r.run(ability);
/*     */     
/*     */     }
/* 162 */     ability.initialize(instance);
/*     */     
/* 164 */     if (ability instanceof DependencyAbility) { DependencyAbility dependencyAbility = (DependencyAbility)ability;
/* 165 */       dependencyAbilityMap.put(ability.getRegisteredKey(), dependencyAbility); }
/*     */     
/* 167 */     if (ability instanceof AsyncRepeatingAbility) { AsyncRepeatingAbility ara = (AsyncRepeatingAbility)ability;
/* 168 */       asyncRepeatingAbilities.add(ara); }
/*     */     
/* 170 */     if (ability instanceof FlightAllowingAbility) { FlightAllowingAbility flightAllowingAbility = (FlightAllowingAbility)ability;
/* 171 */       flightAllowingAbilities.add(flightAllowingAbility);
/* 172 */       flightAllowingAbilities.sort(Comparator.comparingInt(ab -> -ab.getPriority())); }
/*     */     
/* 174 */     if (ability instanceof TriggerableAbility) { TriggerableAbility triggerableAbility = (TriggerableAbility)ability;
/* 175 */       TriggerManager.getInstance().register(triggerableAbility); }
/*     */     
/* 177 */     if (ability instanceof MultiAbility) { MultiAbility multiAbility = (MultiAbility)ability;
/* 178 */       for (Ability a : multiAbility.getAbilities()) {
/* 179 */         ((List<MultiAbility>)multiAbilityMap.computeIfAbsent(a.getKey(), k -> new ArrayList())).add(multiAbility);
/*     */       } }
/*     */     
/* 182 */     if (ability instanceof CooldownAbility) { CooldownAbility cooldownAbility = (CooldownAbility)ability;
/* 183 */       cooldownAbility.setupCooldownConfig(instance); }
/*     */     
/* 185 */     if (ability instanceof ListenerAbility) { ListenerAbility listenerAbility = (ListenerAbility)ability;
/* 186 */       if (listenerAbility.shouldRegisterEvents()) Bukkit.getPluginManager().registerEvents((Listener)listenerAbility, (Plugin)instance);  }
/* 187 */     else if (ability instanceof Listener) { Listener listener = (Listener)ability;
/* 188 */       Bukkit.getPluginManager().registerEvents(listener, (Plugin)instance); }
/*     */     
/* 190 */     if (ability instanceof VisibleAbility) { VisibleAbility visibleAbility = (VisibleAbility)ability;
/* 191 */       visibleAbility.setupTranslatedText(); }
/*     */     
/* 193 */     if (ability instanceof AttributeModifierAbility) { AttributeModifierAbility ama = (AttributeModifierAbility)ability;
/* 194 */       ama.setupAttributeConfig();
/* 195 */       NamespacedKey amaKey = new NamespacedKey((Plugin)OriginsReborn.getInstance(), ability.getRegisteredKey().asString().replace(":", "-"));
/* 196 */       attributeModifierAbilities.add(new Pair<>(ama, amaKey)); }
/*     */     
/* 198 */     if (ability instanceof BreakSpeedModifierAbility) { BreakSpeedModifierAbility breakSpeedModifierAbility = (BreakSpeedModifierAbility)ability;
/* 199 */       breakSpeedModifierAbilities.add(breakSpeedModifierAbility); }
/*     */     
/* 201 */     abilityMap.put(ability.getRegisteredKey(), ability);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   public static void runForAbility(Entity entity, Key key, Runnable runnable) {
/* 209 */     runForAbility(entity, key, runnable, () -> {
/*     */         
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   public static boolean hasAbility(Player player, Key key) {
/* 217 */     return hasAbility(player, key, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   public static boolean hasAbility(Player player, Key key, boolean ignoreOverrides) {
/* 225 */     if (!abilityMap.containsKey(key)) return false; 
/* 226 */     return ((Ability)abilityMap.get(key)).hasAbility(player);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   public static void runForAbility(Entity entity, Key key, Runnable runnable, Runnable other) {
/* 234 */     if (entity == null)
/* 235 */       return;  String worldId = entity.getWorld().getName();
/* 236 */     if (((List)ConfigManager.getConfigValue(ConfigManager.Option.DISABLED_WORLDS)).contains(worldId))
/* 237 */       return;  if (entity instanceof Player) { Player player = (Player)entity;
/* 238 */       if (hasAbility(player, key)) {
/* 239 */         runnable.run();
/*     */         return;
/*     */       }  }
/*     */     
/* 243 */     other.run();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   public static void runWithoutAbility(Entity entity, Key key, Runnable runnable) {
/* 251 */     runForAbility(entity, key, () -> {  }runnable);
/*     */   }
/*     */   
/*     */   public static FlyData flyData(Player player, boolean disabledWorld) {
/* 255 */     if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR || FlightToggleCommand.canFly(player)) return new FlyData(true, false); 
/* 256 */     if (disabledWorld) return new FlyData(false, false); 
/* 257 */     for (FlightAllowingAbility ability : flightAllowingAbilities) {
/* 258 */       if (ability.hasAbility(player) && ability.canFly(player)) {
/* 259 */         return new FlyData(true, ability.forceFly(player));
/*     */       }
/*     */     } 
/* 262 */     return new FlyData(false, false);
/*     */   } public static final class FlyData extends Record {
/*     */     private final boolean canFly; private final boolean forceFly;
/* 265 */     public FlyData(boolean canFly, boolean forceFly) { this.canFly = canFly; this.forceFly = forceFly; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lcom/starshootercity/util/AbilityRegister$FlyData;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #265	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lcom/starshootercity/util/AbilityRegister$FlyData; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lcom/starshootercity/util/AbilityRegister$FlyData;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #265	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lcom/starshootercity/util/AbilityRegister$FlyData; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lcom/starshootercity/util/AbilityRegister$FlyData;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #265	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lcom/starshootercity/util/AbilityRegister$FlyData;
/* 265 */       //   0	8	1	o	Ljava/lang/Object; } public boolean canFly() { return this.canFly; } public boolean forceFly() { return this.forceFly; }
/*     */   
/*     */   }
/*     */   
/*     */   public static boolean isInvisible(Player player, boolean invisible) {
/* 270 */     if (invisible) return true; 
/* 271 */     if (GSitHook.sitting.contains(player.getUniqueId())) return true; 
/* 272 */     for (Ability ability : abilityMap.values()) {
/* 273 */       if (ability instanceof VisibilityChangingAbility) { VisibilityChangingAbility visibilityChangingAbility = (VisibilityChangingAbility)ability;
/* 274 */         if (ability.hasAbility(player) && visibilityChangingAbility.isInvisible(player)) return true;  }
/*     */     
/*     */     } 
/* 277 */     return false;
/*     */   }
/*     */   
/*     */   public static void updateFlight(Player player, boolean inDisabledWorld) {
/* 281 */     GameMode gm = player.getGameMode();
/* 282 */     if (gm == GameMode.SPECTATOR)
/* 283 */       return;  if (gm == GameMode.CREATIVE || FlightToggleCommand.canFly(player)) {
/* 284 */       player.setFlySpeed(0.1F);
/*     */       return;
/*     */     } 
/* 287 */     if (inDisabledWorld)
/* 288 */       return;  TriState flyingFallDamage = TriState.FALSE;
/* 289 */     float speed = -1.0F;
/* 290 */     for (FlightAllowingAbility ability : flightAllowingAbilities) {
/* 291 */       if (ability.hasAbility(player) && ability.canFly(player)) {
/* 292 */         float abilitySpeed = ability.getFlightSpeed(player);
/* 293 */         speed = (speed == -1.0F) ? abilitySpeed : Math.min(speed, abilitySpeed);
/* 294 */         if (ability.getFlyingFallDamage(player) == TriState.TRUE) {
/* 295 */           flyingFallDamage = TriState.TRUE;
/*     */         }
/*     */       } 
/*     */     } 
/* 299 */     MVAccessor.get().setFlyingFallDamage(player, flyingFallDamage);
/* 300 */     player.setFlySpeed((speed == -1.0F) ? 0.0F : speed);
/*     */   }
/*     */   
/*     */   public static void updateEntity(Player player, Entity target) {
/* 304 */     byte data = 0;
/* 305 */     if (target.getFireTicks() > 0) {
/* 306 */       data = (byte)(data + 1);
/*     */     }
/* 308 */     if (target.isGlowing()) {
/* 309 */       data = (byte)(data + 64);
/*     */     }
/* 311 */     if (target instanceof LivingEntity) { LivingEntity entity = (LivingEntity)target;
/* 312 */       if (entity.isInvisible()) data = (byte)(data + 32);  }
/*     */     
/* 314 */     if (target instanceof Player) { Player targetPlayer = (Player)target;
/* 315 */       if (targetPlayer.isSneaking()) {
/* 316 */         data = (byte)(data + 2);
/*     */       }
/* 318 */       if (targetPlayer.isSprinting()) {
/* 319 */         data = (byte)(data + 8);
/*     */       }
/* 321 */       if (targetPlayer.isSwimming()) {
/* 322 */         data = (byte)(data + 16);
/*     */       }
/* 324 */       if (targetPlayer.isGliding()) {
/* 325 */         data = (byte)(data - 128);
/*     */       }
/* 327 */       for (EquipmentSlot equipmentSlot : EquipmentSlot.values()) {
/*     */         try {
/* 329 */           ItemStack item = targetPlayer.getInventory().getItem(equipmentSlot);
/* 330 */           if (item != null) {
/* 331 */             player.sendEquipmentChange((LivingEntity)targetPlayer, equipmentSlot, item);
/*     */           }
/* 333 */         } catch (IllegalArgumentException illegalArgumentException) {}
/*     */       }  }
/*     */ 
/*     */     
/* 337 */     MVAccessor.get().sendEntityData(player, target, data);
/*     */   }
/*     */   
/*     */   public static interface AbilityRunnable {
/*     */     void run(Ability param1Ability);
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercit\\util\AbilityRegister.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */