/*    */ package com.starshootercity.util;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.util.Collection;
/*    */ import java.util.zip.ZipEntry;
/*    */ import java.util.zip.ZipInputStream;
/*    */ import java.util.zip.ZipOutputStream;
/*    */ 
/*    */ public class CompressionUtils {
/*    */   public static void compressFiles(Collection<File> files, File outputZip) throws IOException {
/* 14 */     FileOutputStream fos = new FileOutputStream(outputZip); 
/* 15 */     try { ZipOutputStream zos = new ZipOutputStream(fos);
/*    */       
/* 17 */       try { for (File file : files) {
/* 18 */           addToZipFile(file, zos);
/*    */         }
/* 20 */         zos.close(); } catch (Throwable throwable) { try { zos.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  fos.close(); }
/*    */     catch (Throwable throwable) { try { fos.close(); }
/*    */       catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*    */        throw throwable; }
/* 24 */      } private static void addToZipFile(File file, ZipOutputStream zos) throws IOException { FileInputStream fis = new FileInputStream(file); 
/* 25 */     try { ZipEntry zipEntry = new ZipEntry(file.getName());
/* 26 */       zos.putNextEntry(zipEntry);
/*    */       
/* 28 */       byte[] buffer = new byte[1024];
/*    */       int length;
/* 30 */       while ((length = fis.read(buffer)) >= 0) {
/* 31 */         zos.write(buffer, 0, length);
/*    */       }
/* 33 */       zos.closeEntry();
/* 34 */       fis.close(); }
/*    */     catch (Throwable throwable) { try { fis.close(); }
/*    */       catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*    */        throw throwable; }
/* 38 */      } public static void decompressFiles(File zipFile, File outputDir) throws IOException { FileInputStream fis = new FileInputStream(zipFile); 
/* 39 */     try { ZipInputStream zis = new ZipInputStream(fis);
/*    */       
/*    */       try { ZipEntry zipEntry;
/* 42 */         while ((zipEntry = zis.getNextEntry()) != null) {
/* 43 */           File newFile = newFile(outputDir, zipEntry);
/* 44 */           if (zipEntry.isDirectory()) {
/* 45 */             if (!newFile.isDirectory() && !newFile.mkdirs()) {
/* 46 */               throw new IOException("Failed to create directory " + String.valueOf(newFile));
/*    */             }
/*    */           } else {
/* 49 */             File parent = newFile.getParentFile();
/* 50 */             if (parent != null && !parent.isDirectory() && 
/* 51 */               !parent.mkdirs()) {
/* 52 */               throw new IOException("Failed to create directory " + String.valueOf(parent));
/*    */             }
/*    */ 
/*    */             
/* 56 */             FileOutputStream fos = new FileOutputStream(newFile); 
/* 57 */             try { byte[] buffer = new byte[1024];
/*    */               int length;
/* 59 */               while ((length = zis.read(buffer)) > 0) {
/* 60 */                 fos.write(buffer, 0, length);
/*    */               }
/* 62 */               fos.close(); } catch (Throwable throwable) { try { fos.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }
/*    */           
/* 64 */           }  zis.closeEntry();
/*    */         } 
/* 66 */         zis.close(); } catch (Throwable throwable) { try { zis.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  fis.close(); }
/*    */     catch (Throwable throwable) { try { fis.close(); }
/*    */       catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*    */        throw throwable; }
/* 70 */      } private static File newFile(File destinationDir, ZipEntry zipEntry) throws IOException { File destFile = new File(destinationDir, zipEntry.getName());
/*    */     
/* 72 */     String destDirPath = destinationDir.getCanonicalPath();
/* 73 */     String destFilePath = destFile.getCanonicalPath();
/*    */     
/* 75 */     if (!destFilePath.startsWith(destDirPath + destDirPath)) {
/* 76 */       throw new IOException("Entry is outside of the target dir: " + zipEntry.getName());
/*    */     }
/*    */     
/* 79 */     return destFile; }
/*    */ 
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercit\\util\CompressionUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */