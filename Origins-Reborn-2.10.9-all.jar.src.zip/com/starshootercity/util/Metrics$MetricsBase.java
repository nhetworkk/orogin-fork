/*     */ package com.starshootercity.util;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.HashSet;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.zip.GZIPOutputStream;
/*     */ import javax.net.ssl.HttpsURLConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MetricsBase
/*     */ {
/*     */   public static final String METRICS_VERSION = "3.1.0";
/*     */   private static final String REPORT_URL = "https://bStats.org/api/v2/data/%s";
/*     */   private final ScheduledExecutorService scheduler;
/*     */   private final String platform;
/*     */   private final String serverUuid;
/*     */   private final int serviceId;
/*     */   private final Consumer<Metrics.JsonObjectBuilder> appendPlatformDataConsumer;
/*     */   private final Consumer<Metrics.JsonObjectBuilder> appendServiceDataConsumer;
/*     */   private final Consumer<Runnable> submitTaskConsumer;
/*     */   private final Supplier<Boolean> checkServiceEnabledSupplier;
/*     */   private final BiConsumer<String, Throwable> errorLogger;
/*     */   private final Consumer<String> infoLogger;
/*     */   private final boolean logErrors;
/*     */   private final boolean logSentData;
/*     */   private final boolean logResponseStatusText;
/* 205 */   private final Set<Metrics.CustomChart> customCharts = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean enabled;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MetricsBase(String platform, String serverUuid, int serviceId, boolean enabled, Consumer<Metrics.JsonObjectBuilder> appendPlatformDataConsumer, Consumer<Metrics.JsonObjectBuilder> appendServiceDataConsumer, Consumer<Runnable> submitTaskConsumer, Supplier<Boolean> checkServiceEnabledSupplier, BiConsumer<String, Throwable> errorLogger, Consumer<String> infoLogger, boolean logErrors, boolean logSentData, boolean logResponseStatusText, boolean skipRelocateCheck) {
/* 246 */     ScheduledThreadPoolExecutor scheduler = new ScheduledThreadPoolExecutor(1, task -> {
/*     */           Thread thread = new Thread(task, "bStats-Metrics");
/*     */ 
/*     */ 
/*     */           
/*     */           thread.setDaemon(true);
/*     */ 
/*     */           
/*     */           return thread;
/*     */         });
/*     */ 
/*     */     
/* 258 */     scheduler.setExecuteExistingDelayedTasksAfterShutdownPolicy(false);
/* 259 */     this.scheduler = scheduler;
/* 260 */     this.platform = platform;
/* 261 */     this.serverUuid = serverUuid;
/* 262 */     this.serviceId = serviceId;
/* 263 */     this.enabled = enabled;
/* 264 */     this.appendPlatformDataConsumer = appendPlatformDataConsumer;
/* 265 */     this.appendServiceDataConsumer = appendServiceDataConsumer;
/* 266 */     this.submitTaskConsumer = submitTaskConsumer;
/* 267 */     this.checkServiceEnabledSupplier = checkServiceEnabledSupplier;
/* 268 */     this.errorLogger = errorLogger;
/* 269 */     this.infoLogger = infoLogger;
/* 270 */     this.logErrors = logErrors;
/* 271 */     this.logSentData = logSentData;
/* 272 */     this.logResponseStatusText = logResponseStatusText;
/* 273 */     if (!skipRelocateCheck) {
/* 274 */       checkRelocation();
/*     */     }
/* 276 */     if (enabled)
/*     */     {
/*     */       
/* 279 */       startSubmitting();
/*     */     }
/*     */   }
/*     */   
/*     */   public void addCustomChart(Metrics.CustomChart chart) {
/* 284 */     this.customCharts.add(chart);
/*     */   }
/*     */   
/*     */   public void shutdown() {
/* 288 */     this.scheduler.shutdown();
/*     */   }
/*     */   
/*     */   private void startSubmitting() {
/* 292 */     Runnable submitTask = () -> {
/*     */         if (!this.enabled || !((Boolean)this.checkServiceEnabledSupplier.get()).booleanValue()) {
/*     */           this.scheduler.shutdown();
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           return;
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/*     */         if (this.submitTaskConsumer != null) {
/*     */           this.submitTaskConsumer.accept(this::submitData);
/*     */         } else {
/*     */           submitData();
/*     */         } 
/*     */       };
/*     */ 
/*     */ 
/*     */     
/* 313 */     long initialDelay = (long)(60000.0D * (3.0D + Math.random() * 3.0D));
/* 314 */     long secondDelay = (long)(60000.0D * Math.random() * 30.0D);
/* 315 */     this.scheduler.schedule(submitTask, initialDelay, TimeUnit.MILLISECONDS);
/* 316 */     this.scheduler.scheduleAtFixedRate(submitTask, initialDelay + secondDelay, 1800000L, TimeUnit.MILLISECONDS);
/*     */   }
/*     */ 
/*     */   
/*     */   private void submitData() {
/* 321 */     Metrics.JsonObjectBuilder baseJsonBuilder = new Metrics.JsonObjectBuilder();
/* 322 */     this.appendPlatformDataConsumer.accept(baseJsonBuilder);
/* 323 */     Metrics.JsonObjectBuilder serviceJsonBuilder = new Metrics.JsonObjectBuilder();
/* 324 */     this.appendServiceDataConsumer.accept(serviceJsonBuilder);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 329 */     Metrics.JsonObjectBuilder.JsonObject[] chartData = (Metrics.JsonObjectBuilder.JsonObject[])this.customCharts.stream().map(customChart -> customChart.getRequestJsonObject(this.errorLogger, this.logErrors)).filter(Objects::nonNull).toArray(x$0 -> new Metrics.JsonObjectBuilder.JsonObject[x$0]);
/* 330 */     serviceJsonBuilder.appendField("id", this.serviceId);
/* 331 */     serviceJsonBuilder.appendField("customCharts", chartData);
/* 332 */     baseJsonBuilder.appendField("service", serviceJsonBuilder.build());
/* 333 */     baseJsonBuilder.appendField("serverUUID", this.serverUuid);
/* 334 */     baseJsonBuilder.appendField("metricsVersion", "3.1.0");
/* 335 */     Metrics.JsonObjectBuilder.JsonObject data = baseJsonBuilder.build();
/* 336 */     this.scheduler.execute(() -> {
/*     */ 
/*     */           
/*     */           try {
/*     */             sendData(data);
/* 341 */           } catch (Exception e) {
/*     */             if (this.logErrors) {
/*     */               this.errorLogger.accept("Could not submit bStats metrics data", e);
/*     */             }
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private void sendData(Metrics.JsonObjectBuilder.JsonObject data) throws Exception {
/* 351 */     if (this.logSentData) {
/* 352 */       this.infoLogger.accept("Sent bStats metrics data: " + data.toString());
/*     */     }
/* 354 */     String url = String.format("https://bStats.org/api/v2/data/%s", new Object[] { this.platform });
/* 355 */     HttpsURLConnection connection = (HttpsURLConnection)(new URL(url)).openConnection();
/*     */     
/* 357 */     byte[] compressedData = compress(data.toString());
/* 358 */     connection.setRequestMethod("POST");
/* 359 */     connection.addRequestProperty("Accept", "application/json");
/* 360 */     connection.addRequestProperty("Connection", "close");
/* 361 */     connection.addRequestProperty("Content-Encoding", "gzip");
/* 362 */     connection.addRequestProperty("Content-Length", String.valueOf(compressedData.length));
/* 363 */     connection.setRequestProperty("Content-Type", "application/json");
/* 364 */     connection.setRequestProperty("User-Agent", "Metrics-Service/1");
/* 365 */     connection.setDoOutput(true);
/* 366 */     DataOutputStream outputStream = new DataOutputStream(connection.getOutputStream()); 
/* 367 */     try { outputStream.write(compressedData);
/* 368 */       outputStream.close(); } catch (Throwable throwable) { try { outputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }
/* 369 */      StringBuilder builder = new StringBuilder();
/*     */     
/* 371 */     BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(connection.getInputStream())); 
/*     */     try { String line;
/* 373 */       while ((line = bufferedReader.readLine()) != null) {
/* 374 */         builder.append(line);
/*     */       }
/* 376 */       bufferedReader.close(); } catch (Throwable throwable) { try { bufferedReader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }
/* 377 */      if (this.logResponseStatusText) {
/* 378 */       this.infoLogger.accept("Sent data to bStats and received response: " + String.valueOf(builder));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkRelocation() {
/* 385 */     if (System.getProperty("bstats.relocatecheck") == null || 
/* 386 */       !System.getProperty("bstats.relocatecheck").equals("false")) {
/*     */ 
/*     */       
/* 389 */       String defaultPackage = new String(new byte[] { 111, 114, 103, 46, 98, 115, 116, 97, 116, 115 });
/*     */       
/* 391 */       String examplePackage = new String(new byte[] { 121, 111, 117, 114, 46, 112, 97, 99, 107, 97, 103, 101 });
/*     */ 
/*     */ 
/*     */       
/* 395 */       if (MetricsBase.class.getPackage().getName().startsWith(defaultPackage) || MetricsBase.class
/* 396 */         .getPackage().getName().startsWith(examplePackage)) {
/* 397 */         throw new IllegalStateException("bStats Metrics class has not been relocated correctly!");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte[] compress(String str) throws IOException {
/* 409 */     if (str == null) {
/* 410 */       return null;
/*     */     }
/* 412 */     ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
/* 413 */     GZIPOutputStream gzip = new GZIPOutputStream(outputStream); 
/* 414 */     try { gzip.write(str.getBytes(StandardCharsets.UTF_8));
/* 415 */       gzip.close(); } catch (Throwable throwable) { try { gzip.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }
/* 416 */      return outputStream.toByteArray();
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercit\\util\Metrics$MetricsBase.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */