package com.starshootercity.util;

import com.starshootercity.abilities.types.Ability;

public interface AbilityRunnable {
  void run(Ability paramAbility);
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercit\\util\AbilityRegister$AbilityRunnable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */