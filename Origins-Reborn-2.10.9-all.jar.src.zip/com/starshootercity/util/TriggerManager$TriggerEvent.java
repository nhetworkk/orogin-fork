/*     */ package com.starshootercity.util;
/*     */ 
/*     */ import java.util.function.Predicate;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TriggerEvent
/*     */ {
/*     */   private final Player player;
/*     */   @Nullable
/*     */   private final ItemStack item;
/*     */   @Nullable
/*     */   private final Block block;
/*     */   private boolean cancelled;
/*     */   
/*     */   public TriggerEvent(Player player, @Nullable ItemStack item, @Nullable Block block) {
/* 124 */     this.player = player;
/* 125 */     this.item = item;
/* 126 */     this.block = block;
/* 127 */     this.cancelled = false;
/*     */   }
/*     */   
/*     */   public void setCancelled(boolean cancelled) {
/* 131 */     this.cancelled = cancelled;
/*     */   }
/*     */   
/*     */   public boolean isCancelled() {
/* 135 */     return this.cancelled;
/*     */   }
/*     */   
/*     */   public boolean hasBlock() {
/* 139 */     return (this.block != null);
/*     */   }
/*     */   
/*     */   public boolean itemType(Predicate<Material> predicate) {
/* 143 */     if (this.item != null) return predicate.test(this.item.getType()); 
/* 144 */     return predicate.test(this.player.getInventory().getItemInMainHand().getType());
/*     */   }
/*     */   
/*     */   public Player player() {
/* 148 */     return this.player;
/*     */   }
/*     */   @Nullable
/*     */   public ItemStack item() {
/* 152 */     return this.item;
/*     */   }
/*     */   @Nullable
/*     */   public Block block() {
/* 156 */     return this.block;
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercit\\util\TriggerManager$TriggerEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */