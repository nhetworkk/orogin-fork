/*    */ package com.starshootercity.util;
/*    */ import com.sk89q.worldedit.bukkit.BukkitAdapter;
/*    */ import com.sk89q.worldedit.math.BlockVector3;
/*    */ import com.sk89q.worldguard.WorldGuard;
/*    */ import com.sk89q.worldguard.protection.ApplicableRegionSet;
/*    */ import com.sk89q.worldguard.protection.flags.BooleanFlag;
/*    */ import com.sk89q.worldguard.protection.flags.Flag;
/*    */ import com.sk89q.worldguard.protection.flags.StringFlag;
/*    */ import com.sk89q.worldguard.protection.flags.registry.FlagRegistry;
/*    */ import com.sk89q.worldguard.protection.managers.RegionManager;
/*    */ import com.sk89q.worldguard.protection.regions.ProtectedRegion;
/*    */ import com.sk89q.worldguard.protection.regions.RegionContainer;
/*    */ import com.starshootercity.abilities.types.Ability;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import org.bukkit.Location;
/*    */ 
/*    */ public class WorldGuardHook {
/*    */   private static RegionContainer rc;
/*    */   
/*    */   public static boolean isAbilityDisabled(Location location, Ability ability) {
/*    */     try {
/* 22 */       RegionManager manager = rc.get(BukkitAdapter.adapt(location.getWorld()));
/* 23 */       if (manager == null) return false; 
/* 24 */       ApplicableRegionSet set = manager.getApplicableRegions(BlockVector3.at(location.getBlockX(), location.getBlockY(), location.getBlockZ()));
/* 25 */       for (ProtectedRegion r : set) {
/* 26 */         String data = (String)r.getFlag((Flag)flag);
/* 27 */         if (data != null)
/* 28 */           for (String s : data.split(",")) {
/* 29 */             if (s.equals(ability.getRegisteredKey().toString())) return true;
/*    */           
/*    */           }  
/*    */       } 
/* 33 */       return false;
/* 34 */     } catch (Throwable t) {
/* 35 */       return false;
/*    */     } 
/*    */   }
/*    */   private static StringFlag flag; private static BooleanFlag flightFlag;
/*    */   public static boolean isFlightDisabled(Location location) {
/*    */     try {
/* 41 */       RegionManager manager = rc.get(BukkitAdapter.adapt(location.getWorld()));
/* 42 */       if (manager == null) return false; 
/* 43 */       ApplicableRegionSet set = manager.getApplicableRegions(BlockVector3.at(location.getBlockX(), location.getBlockY(), location.getBlockZ()));
/* 44 */       for (ProtectedRegion r : set) {
/* 45 */         Boolean b = (Boolean)r.getFlag((Flag)flightFlag);
/* 46 */         if (b != null && 
/* 47 */           b.booleanValue()) {
/* 48 */           return true;
/*    */         }
/*    */       } 
/* 51 */       return false;
/* 52 */     } catch (Throwable t) {
/* 53 */       return false;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean tryInitialize() {
/* 61 */     if (!((Boolean)ConfigManager.getConfigValue(ConfigManager.Option.WORLDGUARD_HOOK)).booleanValue()) return false;
/*    */     
/* 63 */     FlagRegistry registry = WorldGuard.getInstance().getFlagRegistry();
/*    */     
/* 65 */     flag = new StringFlag("origins-reborn:disabled-abilities");
/* 66 */     flightFlag = new BooleanFlag("origins-reborn:disable-flight");
/* 67 */     registry.register((Flag)flag);
/* 68 */     registry.register((Flag)flightFlag);
/*    */     
/* 70 */     return true;
/*    */   }
/*    */   
/*    */   public static void completeInitialize() {
/* 74 */     rc = WorldGuard.getInstance().getPlatform().getRegionContainer();
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercit\\util\WorldGuardHook.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */