/*     */ package com.starshootercity.util;
/*     */ import com.destroystokyo.paper.event.player.PlayerJumpEvent;
/*     */ import com.starshootercity.abilities.types.TriggerableAbility;
/*     */ import com.starshootercity.events.PlayerLeftClickEvent;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Predicate;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.entity.HumanEntity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Cancellable;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.inventory.InventoryType;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.event.player.PlayerSwapHandItemsEvent;
/*     */ import org.bukkit.event.player.PlayerToggleSneakEvent;
/*     */ import org.bukkit.event.player.PlayerToggleSprintEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public class TriggerManager implements Listener {
/*  27 */   private static final TriggerManager instance = new TriggerManager();
/*     */   
/*     */   public static TriggerManager getInstance() {
/*  30 */     return instance;
/*     */   }
/*     */   
/*  33 */   private final Map<TriggerableAbility.TriggerType, Set<TriggerableAbility.Trigger>> triggerableAbilities = new HashMap<>();
/*     */   
/*     */   public void register(TriggerableAbility ability) {
/*  36 */     ((Set<TriggerableAbility.Trigger>)this.triggerableAbilities.computeIfAbsent(ability.getTrigger().getType(), k -> new HashSet()))
/*  37 */       .add(ability.getTrigger());
/*     */   }
/*     */   
/*     */   public void callTriggerEvent(TriggerEvent event, TriggerableAbility.TriggerType type, @Nullable Cancellable cancellable) {
/*  41 */     for (TriggerableAbility.Trigger trigger : this.triggerableAbilities.getOrDefault(type, Collections.emptySet())) {
/*  42 */       trigger.run(event);
/*     */     }
/*  44 */     if (cancellable != null && event.isCancelled()) cancellable.setCancelled(true); 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerLeftClick(PlayerLeftClickEvent event) {
/*  49 */     TriggerEvent triggerEvent = new TriggerEvent(event.getPlayer(), event.getItem(), event.getClickedBlock());
/*  50 */     callTriggerEvent(triggerEvent, TriggerableAbility.TriggerType.LEFT_CLICK, null);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerInteract(PlayerInteractEvent event) {
/*  55 */     if (!event.getAction().isRightClick())
/*  56 */       return;  TriggerEvent triggerEvent = new TriggerEvent(event.getPlayer(), event.getItem(), event.getClickedBlock());
/*  57 */     callTriggerEvent(triggerEvent, TriggerableAbility.TriggerType.RIGHT_CLICK, (Cancellable)event);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerSwapHandItems(PlayerSwapHandItemsEvent event) {
/*  62 */     TriggerEvent triggerEvent = new TriggerEvent(event.getPlayer(), event.getMainHandItem(), null);
/*  63 */     callTriggerEvent(triggerEvent, TriggerableAbility.TriggerType.OFFHAND_SWAP, (Cancellable)event);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onInventoryClick(InventoryClickEvent event) {
/*  68 */     HumanEntity humanEntity = event.getWhoClicked(); if (humanEntity instanceof Player) { Player p = (Player)humanEntity;
/*  69 */       if (event.isRightClick() && 
/*  70 */         event.getSlotType() == InventoryType.SlotType.ARMOR && 
/*  71 */         event.getSlot() == 38) {
/*  72 */         TriggerEvent triggerEvent = new TriggerEvent(p, event.getCurrentItem(), null);
/*  73 */         callTriggerEvent(triggerEvent, TriggerableAbility.TriggerType.RIGHT_CLICK_CHESTPLATE, (Cancellable)event);
/*     */       }  }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerJump(PlayerJumpEvent event) {
/*  82 */     TriggerEvent triggerEvent = new TriggerEvent(event.getPlayer(), null, null);
/*  83 */     callTriggerEvent(triggerEvent, TriggerableAbility.TriggerType.JUMP, (Cancellable)event);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerToggleSprint(PlayerToggleSprintEvent event) {
/*  88 */     TriggerEvent triggerEvent = new TriggerEvent(event.getPlayer(), null, null);
/*  89 */     if (event.isSprinting())
/*  90 */     { callTriggerEvent(triggerEvent, TriggerableAbility.TriggerType.SPRINT_ON, (Cancellable)event); }
/*  91 */     else { callTriggerEvent(triggerEvent, TriggerableAbility.TriggerType.SPRINT_OFF, (Cancellable)event); }
/*  92 */      callTriggerEvent(triggerEvent, TriggerableAbility.TriggerType.SPRINT_TOGGLE, (Cancellable)event);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerToggleSneak(PlayerToggleSneakEvent event) {
/*  97 */     TriggerEvent triggerEvent = new TriggerEvent(event.getPlayer(), null, null);
/*  98 */     callTriggerEvent(triggerEvent, TriggerableAbility.TriggerType.SNEAK_TOGGLE, (Cancellable)event);
/*     */     
/* 100 */     if (!event.isSneaking()) {
/* 101 */       callTriggerEvent(triggerEvent, TriggerableAbility.TriggerType.SNEAK_OFF, (Cancellable)event);
/*     */       
/*     */       return;
/*     */     } 
/* 105 */     callTriggerEvent(triggerEvent, TriggerableAbility.TriggerType.SNEAK_ON, (Cancellable)event);
/*     */     
/* 107 */     if (((Integer)this.lastInteractionTickMap.getOrDefault(event.getPlayer(), Integer.valueOf(0))).intValue() - Bukkit.getCurrentTick() > 0) {
/* 108 */       callTriggerEvent(triggerEvent, TriggerableAbility.TriggerType.DOUBLE_TAP_SNEAK, (Cancellable)event);
/* 109 */       this.lastInteractionTickMap.remove(event.getPlayer());
/*     */       return;
/*     */     } 
/* 112 */     this.lastInteractionTickMap.put(event.getPlayer(), Integer.valueOf(Bukkit.getCurrentTick() + 5));
/*     */   }
/*     */   
/* 115 */   private final Map<Player, Integer> lastInteractionTickMap = new HashMap<>();
/*     */   public static final class TriggerEvent { private final Player player;
/*     */     @Nullable
/*     */     private final ItemStack item;
/*     */     @Nullable
/*     */     private final Block block;
/*     */     private boolean cancelled;
/*     */     
/*     */     public TriggerEvent(Player player, @Nullable ItemStack item, @Nullable Block block) {
/* 124 */       this.player = player;
/* 125 */       this.item = item;
/* 126 */       this.block = block;
/* 127 */       this.cancelled = false;
/*     */     }
/*     */     
/*     */     public void setCancelled(boolean cancelled) {
/* 131 */       this.cancelled = cancelled;
/*     */     }
/*     */     
/*     */     public boolean isCancelled() {
/* 135 */       return this.cancelled;
/*     */     }
/*     */     
/*     */     public boolean hasBlock() {
/* 139 */       return (this.block != null);
/*     */     }
/*     */     
/*     */     public boolean itemType(Predicate<Material> predicate) {
/* 143 */       if (this.item != null) return predicate.test(this.item.getType()); 
/* 144 */       return predicate.test(this.player.getInventory().getItemInMainHand().getType());
/*     */     }
/*     */     
/*     */     public Player player() {
/* 148 */       return this.player;
/*     */     }
/*     */     @Nullable
/*     */     public ItemStack item() {
/* 152 */       return this.item;
/*     */     }
/*     */     @Nullable
/*     */     public Block block() {
/* 156 */       return this.block;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercit\\util\TriggerManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */