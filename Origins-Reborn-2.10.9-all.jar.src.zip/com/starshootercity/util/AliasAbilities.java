/*    */ package com.starshootercity.util;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.configuration.file.FileConfiguration;
/*    */ import org.bukkit.configuration.file.YamlConfiguration;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ 
/*    */ 
/*    */ public class AliasAbilities
/*    */ {
/*    */   public static void initialize(JavaPlugin plugin) {
/* 15 */     File file = new File(plugin.getDataFolder(), "alias-abilities.yml");
/*    */     
/* 17 */     if (!file.exists()) {
/* 18 */       boolean ignored = file.mkdirs();
/* 19 */       plugin.saveResource("alias-abilities.yml", false);
/*    */     } 
/*    */     
/* 22 */     YamlConfiguration yamlConfiguration = new YamlConfiguration();
/*    */     
/*    */     try {
/* 25 */       yamlConfiguration.load(file);
/* 26 */     } catch (IOException|org.bukkit.configuration.InvalidConfigurationException e) {
/* 27 */       throw new RuntimeException(e);
/*    */     } 
/*    */ 
/*    */     
/* 31 */     Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)plugin, () -> {
/*    */           for (String str : config.getKeys(false));
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercit\\util\AliasAbilities.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */