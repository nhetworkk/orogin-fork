/*   */ package com.starshootercity;
/*   */ import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
/*   */ import org.bukkit.Bukkit;
/*   */ import org.bukkit.plugin.Plugin;
/*   */ import org.bukkit.plugin.java.JavaPlugin;
/*   */ 
/*   */ public class FoliaScheduleManager extends AbstractScheduleManager {
/*   */   public void delayedTask(JavaPlugin plugin, Runnable task, long delay) {
/* 9 */     Bukkit.getGlobalRegionScheduler().runDelayed((Plugin)plugin, scheduledTask -> task.run(), delay);
/*   */   }
/*   */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\FoliaScheduleManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */