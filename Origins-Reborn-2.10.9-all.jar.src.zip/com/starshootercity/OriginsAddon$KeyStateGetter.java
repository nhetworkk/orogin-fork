package com.starshootercity;

import net.kyori.adventure.key.Key;
import org.bukkit.entity.Player;

public interface KeyStateGetter {
  OriginsAddon.State get(Player paramPlayer, Key paramKey);
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\OriginsAddon$KeyStateGetter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */