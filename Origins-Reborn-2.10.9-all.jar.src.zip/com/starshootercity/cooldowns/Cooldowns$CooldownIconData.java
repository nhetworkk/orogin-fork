/*     */ package com.starshootercity.cooldowns;
/*     */ 
/*     */ import com.starshootercity.OriginsReborn;
/*     */ import java.util.List;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import net.kyori.adventure.text.Component;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CooldownIconData
/*     */   extends Record
/*     */ {
/*     */   private final List<Component> barPieces;
/*     */   private final Component icon;
/*     */   
/*     */   public final String toString() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> toString : (Lcom/starshootercity/cooldowns/Cooldowns$CooldownIconData;)Ljava/lang/String;
/*     */     //   6: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #140	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Lcom/starshootercity/cooldowns/Cooldowns$CooldownIconData;
/*     */   }
/*     */   
/*     */   public final int hashCode() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> hashCode : (Lcom/starshootercity/cooldowns/Cooldowns$CooldownIconData;)I
/*     */     //   6: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #140	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Lcom/starshootercity/cooldowns/Cooldowns$CooldownIconData;
/*     */   }
/*     */   
/*     */   public final boolean equals(Object o) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: <illegal opcode> equals : (Lcom/starshootercity/cooldowns/Cooldowns$CooldownIconData;Ljava/lang/Object;)Z
/*     */     //   7: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #140	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	8	0	this	Lcom/starshootercity/cooldowns/Cooldowns$CooldownIconData;
/*     */     //   0	8	1	o	Ljava/lang/Object;
/*     */   }
/*     */   
/*     */   public CooldownIconData(List<Component> barPieces, Component icon) {
/* 140 */     this.barPieces = barPieces; this.icon = icon; } public List<Component> barPieces() { return this.barPieces; } public Component icon() { return this.icon; }
/*     */    public Component assemble(float completion, int height) {
/* 142 */     int num = (int)Math.floor((this.barPieces.size() * completion));
/* 143 */     Component result = this.icon.append((Component)Component.text(""));
/*     */     
/* 145 */     for (int i = 0; i < this.barPieces.size(); i++) {
/* 146 */       result = result.append(((i <= num) ? this.barPieces : Cooldowns.emptyBarPieces).get(i));
/* 147 */       result = result.append((Component)Component.text(""));
/*     */     } 
/*     */     
/* 150 */     String formatted = "minecraft:cooldown_bar/height_%s".formatted(new Object[] { Integer.valueOf(height) });
/* 151 */     return OriginsReborn.getMVE().applyFont(result, Key.key(formatted));
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\cooldowns\Cooldowns$CooldownIconData.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */