/*     */ package com.starshootercity.cooldowns;
/*     */ import com.destroystokyo.paper.event.server.ServerTickEndEvent;
/*     */ import com.starshootercity.OriginSwapper;
/*     */ import com.starshootercity.OriginsReborn;
/*     */ import com.starshootercity.events.PlayerSwapOriginEvent;
/*     */ import com.starshootercity.util.config.ConfigManager;
/*     */ import io.papermc.paper.event.player.PlayerDeepSleepEvent;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.time.Instant;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.imageio.ImageIO;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import net.kyori.adventure.text.Component;
/*     */ import net.kyori.adventure.text.TextComponent;
/*     */ import net.kyori.adventure.text.format.TextColor;
/*     */ import org.bukkit.NamespacedKey;
/*     */ import org.bukkit.attribute.AttributeInstance;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.LivingEntity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.persistence.PersistentDataContainer;
/*     */ import org.bukkit.persistence.PersistentDataType;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public class Cooldowns implements Listener {
/*     */   private final Map<NamespacedKey, CooldownInfo> registeredCooldowns;
/*     */   private final NamespacedKey cooldownKey;
/*     */   private final NamespacedKey hasCooldownKey;
/*     */   public static List<Component> emptyBarPieces;
/*     */   public final Map<String, CooldownIconData> iconDataMap;
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerSwapOrigin(PlayerSwapOriginEvent event) {
/*  42 */     event.getPlayer().getPersistentDataContainer().remove(this.cooldownKey);
/*     */   } @Nullable
/*     */   private static String getTime(int cooldownTime) {
/*     */     String time;
/*  46 */     if (cooldownTime <= 0) return null;
/*     */     
/*  48 */     if (Math.floorDiv(cooldownTime, 60) == 0) {
/*  49 */       time = "%ss".formatted(new Object[] { Integer.valueOf(cooldownTime) });
/*     */     } else {
/*  51 */       time = "%sm %ss".formatted(new Object[] { Integer.valueOf(Math.floorDiv(cooldownTime, 60)), Integer.valueOf(cooldownTime % 60) });
/*     */     } 
/*  53 */     return time;
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onServerTickEnd(ServerTickEndEvent event) {
/*  58 */     for (Player player : Bukkit.getOnlinePlayers()) {
/*  59 */       Component component; if (ShortcutUtils.isBedrockPlayer(player.getUniqueId())) {
/*  60 */         StringBuilder s = new StringBuilder();
/*  61 */         for (NamespacedKey key : getCooldowns(player)) {
/*  62 */           CooldownInfo info = this.registeredCooldowns.get(key);
/*  63 */           if (info.getIcon() == null)
/*  64 */             continue;  int amount = (int)(getCooldown(player, key) / 50L);
/*  65 */           s.append(getTime(amount)).append(" ");
/*     */         } 
/*  67 */         player.sendActionBar((Component)Component.text(s.toString()));
/*     */         continue;
/*     */       } 
/*  70 */       TextComponent textComponent = Component.empty();
/*  71 */       int num = 0;
/*  72 */       Entity vehicle = player.getVehicle();
/*  73 */       if (vehicle != null && 
/*  74 */         vehicle instanceof LivingEntity) { LivingEntity entity = (LivingEntity)vehicle;
/*  75 */         AttributeInstance instance = entity.getAttribute(MVAttribute.MAX_HEALTH.get());
/*  76 */         if (instance != null) {
/*  77 */           num += (int)(Math.floor((instance.getValue() - 1.0D) / 10.0D) - 1.0D);
/*     */         } }
/*     */ 
/*     */       
/*  81 */       if (player.getRemainingAir() < player.getMaximumAir() || OriginsReborn.getMVE().isUnderWater((LivingEntity)player)) num++; 
/*  82 */       int i = 0;
/*  83 */       for (NamespacedKey key : getCooldowns(player)) {
/*  84 */         CooldownInfo info = this.registeredCooldowns.get(key);
/*  85 */         if (info.getIcon() == null)
/*  86 */           continue;  i++;
/*  87 */         float amount = (float)getCooldown(player, key) / info.getCooldownTime() * 50.0F;
/*  88 */         if (!info.isReversed()) amount = 1.0F - amount; 
/*  89 */         component = textComponent.append((Component)Component.text("")).append(formCooldownBar(amount, info, num));
/*  90 */         num++;
/*     */       } 
/*  92 */       if (i == 0) {
/*  93 */         if (!player.getPersistentDataContainer().has(this.hasCooldownKey, (PersistentDataType)OriginSwapper.BooleanPDT.BOOLEAN))
/*  94 */           continue;  player.getPersistentDataContainer().remove(this.hasCooldownKey);
/*     */       } 
/*  96 */       player.getPersistentDataContainer().set(this.hasCooldownKey, (PersistentDataType)OriginSwapper.BooleanPDT.BOOLEAN, Boolean.valueOf(true));
/*  97 */       player.sendActionBar(OriginsReborn.getMVE().applyFont((Component)Component.text(""), Key.key("minecraft:cooldown_bar/height_0")).append(component));
/*     */     } 
/*     */   }
/*     */   
/*     */   public Component formCooldownBar(float percentage, CooldownInfo info, int height) {
/* 102 */     return ((CooldownIconData)this.iconDataMap.get(info.getIcon())).assemble(percentage, height);
/*     */   }
/*     */   
/*     */   public long getCooldown(Player player, NamespacedKey key) {
/* 106 */     PersistentDataContainer pdc = (PersistentDataContainer)player.getPersistentDataContainer().getOrDefault(this.cooldownKey, PersistentDataType.TAG_CONTAINER, player.getPersistentDataContainer().getAdapterContext().newPersistentDataContainer());
/* 107 */     CooldownInfo info = this.registeredCooldowns.get(key);
/* 108 */     if (info == null) return 0L; 
/* 109 */     return Math.max(0L, ((Long)pdc.getOrDefault(key, PersistentDataType.LONG, Long.valueOf(0L))).longValue() - (info.isStatic() ? 0L : Instant.now().toEpochMilli()));
/*     */   }
/*     */   
/*     */   public List<NamespacedKey> getCooldowns(Player player) {
/* 113 */     PersistentDataContainer pdc = (PersistentDataContainer)player.getPersistentDataContainer().getOrDefault(this.cooldownKey, PersistentDataType.TAG_CONTAINER, player.getPersistentDataContainer().getAdapterContext().newPersistentDataContainer());
/* 114 */     List<NamespacedKey> keys = new ArrayList<>(pdc.getKeys());
/* 115 */     keys.removeIf(key -> (!this.registeredCooldowns.containsKey(key) || (!hasCooldown(player, key) && !((CooldownInfo)this.registeredCooldowns.get(key)).isStatic())));
/* 116 */     return keys;
/*     */   }
/*     */   
/*     */   public void resetCooldowns(Player player) {
/* 120 */     player.getPersistentDataContainer().remove(this.cooldownKey);
/*     */   }
/*     */   
/*     */   public boolean hasCooldown(Player player, NamespacedKey key) {
/* 124 */     return (getCooldown(player, key) > 0L);
/*     */   }
/*     */   
/*     */   public void setCooldown(Player player, NamespacedKey key, int cooldown) {
/* 128 */     if (cooldown == -1)
/* 129 */       return;  CooldownInfo info = this.registeredCooldowns.get(key);
/* 130 */     PersistentDataContainer pdc = (PersistentDataContainer)player.getPersistentDataContainer().getOrDefault(this.cooldownKey, PersistentDataType.TAG_CONTAINER, player.getPersistentDataContainer().getAdapterContext().newPersistentDataContainer());
/* 131 */     pdc.set(key, PersistentDataType.LONG, Long.valueOf(info.isStatic ? (cooldown * 50L) : (Instant.now().toEpochMilli() + cooldown * 50L)));
/* 132 */     player.getPersistentDataContainer().set(this.cooldownKey, PersistentDataType.TAG_CONTAINER, pdc);
/*     */   }
/*     */   
/*     */   public void setCooldown(Player player, NamespacedKey key) {
/* 136 */     CooldownInfo info = this.registeredCooldowns.get(key);
/* 137 */     setCooldown(player, key, info.getCooldownTime());
/*     */   }
/*     */   public static final class CooldownIconData extends Record { private final List<Component> barPieces; private final Component icon;
/* 140 */     public CooldownIconData(List<Component> barPieces, Component icon) { this.barPieces = barPieces; this.icon = icon; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lcom/starshootercity/cooldowns/Cooldowns$CooldownIconData;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #140	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/* 140 */       //   0	7	0	this	Lcom/starshootercity/cooldowns/Cooldowns$CooldownIconData; } public List<Component> barPieces() { return this.barPieces; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lcom/starshootercity/cooldowns/Cooldowns$CooldownIconData;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #140	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lcom/starshootercity/cooldowns/Cooldowns$CooldownIconData; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lcom/starshootercity/cooldowns/Cooldowns$CooldownIconData;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #140	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lcom/starshootercity/cooldowns/Cooldowns$CooldownIconData;
/* 140 */       //   0	8	1	o	Ljava/lang/Object; } public Component icon() { return this.icon; }
/*     */      public Component assemble(float completion, int height) {
/* 142 */       int num = (int)Math.floor((this.barPieces.size() * completion));
/* 143 */       Component result = this.icon.append((Component)Component.text(""));
/*     */       
/* 145 */       for (int i = 0; i < this.barPieces.size(); i++) {
/* 146 */         result = result.append(((i <= num) ? this.barPieces : Cooldowns.emptyBarPieces).get(i));
/* 147 */         result = result.append((Component)Component.text(""));
/*     */       } 
/*     */       
/* 150 */       String formatted = "minecraft:cooldown_bar/height_%s".formatted(new Object[] { Integer.valueOf(height) });
/* 151 */       return OriginsReborn.getMVE().applyFont(result, Key.key(formatted));
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CooldownIconData makeCID(File file) {
/*     */     BufferedImage image;
/*     */     try {
/* 160 */       image = ImageIO.read(file);
/* 161 */     } catch (IOException e) {
/* 162 */       throw new RuntimeException(e);
/*     */     } 
/* 164 */     return new CooldownIconData(makeBarPieces(image), makeIcon(image));
/*     */   }
/*     */   public Component makeIcon(BufferedImage image) {
/*     */     Component component;
/* 168 */     BufferedImage iconImage = image.getSubimage(73, 0, 8, 8);
/* 169 */     TextComponent textComponent = Component.empty();
/* 170 */     String pixels = "";
/* 171 */     for (int x = 0; x < 8; x++) {
/* 172 */       for (int y = 0; y < 8; y++) {
/* 173 */         int col = iconImage.getRGB(x, y);
/* 174 */         if (col == 0)
/* 175 */         { component = textComponent.append((Component)Component.text("")); }
/* 176 */         else { component = component.append(Component.text(pixels.charAt(y)).color(TextColor.color(col))); }
/* 177 */          component = component.append((Component)Component.text((y == 7) ? "" : ""));
/*     */       } 
/*     */     } 
/* 180 */     return component;
/*     */   }
/*     */   
/*     */   public List<Component> makeBarPieces(BufferedImage image) {
/* 184 */     BufferedImage barImage = image.getSubimage(0, 2, 71, 5);
/* 185 */     String pixels = "";
/* 186 */     List<Component> result = new ArrayList<>();
/* 187 */     for (int x = 0; x < 71; x++) {
/* 188 */       Component component; TextComponent textComponent = Component.empty();
/* 189 */       for (int y = 0; y < 5; y++) {
/* 190 */         int col = barImage.getRGB(x, y);
/* 191 */         if (col == 0)
/* 192 */         { component = textComponent.append((Component)Component.text("")); }
/* 193 */         else { component = component.append(Component.text(pixels.charAt(y)).color(TextColor.color(col))); }
/* 194 */          if (y != 4) component = component.append((Component)Component.text("")); 
/*     */       } 
/* 196 */       result.add(component);
/*     */     } 
/* 198 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public NamespacedKey registerCooldown(JavaPlugin instance, NamespacedKey key, CooldownInfo info)
/*     */   {
/* 204 */     if (((Boolean)ConfigManager.getConfigValue(ConfigManager.Option.DISABLE_ALL_COOLDOWNS)).booleanValue()) return key;
/*     */     
/* 206 */     if (info.getIcon() != null && ((Boolean)ConfigManager.getConfigValue(ConfigManager.Option.SHOW_COOLDOWN_ICONS)).booleanValue()) {
/* 207 */       File icon = new File(instance.getDataFolder(), "icons/%s.png".formatted(new Object[] { info.getIcon() }));
/* 208 */       if (!icon.exists()) {
/* 209 */         boolean ignored = icon.getParentFile().mkdirs();
/* 210 */         instance.saveResource("icons/%s.png".formatted(new Object[] { info.getIcon() }, ), false);
/*     */       } 
/* 212 */       CooldownIconData iconData = makeCID(icon);
/* 213 */       this.iconDataMap.put(info.getIcon(), iconData);
/*     */     } 
/* 215 */     this.registeredCooldowns.put(key, info);
/* 216 */     return key; } public Cooldowns() { BufferedImage image; this.registeredCooldowns = new HashMap<>();
/*     */     this.cooldownKey = new NamespacedKey((Plugin)OriginsReborn.getInstance(), "cooldowns");
/*     */     this.hasCooldownKey = new NamespacedKey((Plugin)OriginsReborn.getInstance(), "has_cooldown");
/*     */     this.iconDataMap = new HashMap<>();
/* 220 */     File icon = new File(OriginsReborn.getInstance().getDataFolder(), "icons/empty_bar.png");
/*     */     
/* 222 */     if (!icon.exists()) {
/* 223 */       boolean ignored = icon.getParentFile().mkdirs();
/* 224 */       OriginsReborn.getInstance().saveResource("icons/empty_bar.png", false);
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 229 */       image = ImageIO.read(icon);
/* 230 */     } catch (IOException e) {
/* 231 */       throw new RuntimeException(e);
/*     */     } 
/*     */     
/* 234 */     emptyBarPieces = makeBarPieces(image); }
/*     */ 
/*     */   
/*     */   public static class CooldownInfo {
/*     */     private int cooldownTime;
/*     */     private final boolean reversed;
/*     */     @Nullable
/*     */     private final String icon;
/*     */     private final boolean isStatic;
/*     */     
/*     */     public CooldownInfo(int cooldownTime, @Nullable String icon, boolean reversed, boolean isStatic) {
/* 245 */       this.cooldownTime = cooldownTime;
/* 246 */       this.icon = icon;
/* 247 */       this.reversed = reversed;
/* 248 */       this.isStatic = isStatic;
/*     */     }
/*     */     
/*     */     public boolean isStatic() {
/* 252 */       return this.isStatic;
/*     */     }
/*     */     
/*     */     public boolean isReversed() {
/* 256 */       return this.reversed;
/*     */     }
/*     */     
/*     */     public CooldownInfo(int cooldownTime, @Nullable String icon, boolean reversed) {
/* 260 */       this(cooldownTime, icon, reversed, false);
/*     */     }
/*     */     
/*     */     public CooldownInfo(int cooldownTime, @Nullable String icon) {
/* 264 */       this(cooldownTime, icon, false, false);
/*     */     }
/*     */     
/*     */     public CooldownInfo(int cooldownTime, boolean reversed) {
/* 268 */       this(cooldownTime, null, reversed, false);
/*     */     }
/*     */     
/*     */     public CooldownInfo(int cooldownTime) {
/* 272 */       this(cooldownTime, null, false, false);
/*     */     }
/*     */     @Nullable
/*     */     public String getIcon() {
/* 276 */       return this.icon;
/*     */     }
/*     */     
/*     */     public void setCooldownTime(int cooldownTime) {
/* 280 */       this.cooldownTime = cooldownTime;
/*     */     }
/*     */     
/*     */     public int getCooldownTime() {
/* 284 */       return this.cooldownTime;
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerDeepSleep(PlayerDeepSleepEvent event) {
/* 290 */     if (((Boolean)ConfigManager.getConfigValue(ConfigManager.Option.SLEEPING_RESETS_COOLDOWNS)).booleanValue())
/* 291 */       for (NamespacedKey key : getCooldowns(event.getPlayer())) {
/* 292 */         if (!((CooldownInfo)this.registeredCooldowns.get(key)).isStatic) setCooldown(event.getPlayer(), key, 0); 
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\cooldowns\Cooldowns.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */