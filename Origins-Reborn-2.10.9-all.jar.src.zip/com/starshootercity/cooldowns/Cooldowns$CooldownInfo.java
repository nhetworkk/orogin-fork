/*     */ package com.starshootercity.cooldowns;
/*     */ 
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CooldownInfo
/*     */ {
/*     */   private int cooldownTime;
/*     */   private final boolean reversed;
/*     */   @Nullable
/*     */   private final String icon;
/*     */   private final boolean isStatic;
/*     */   
/*     */   public CooldownInfo(int cooldownTime, @Nullable String icon, boolean reversed, boolean isStatic) {
/* 245 */     this.cooldownTime = cooldownTime;
/* 246 */     this.icon = icon;
/* 247 */     this.reversed = reversed;
/* 248 */     this.isStatic = isStatic;
/*     */   }
/*     */   
/*     */   public boolean isStatic() {
/* 252 */     return this.isStatic;
/*     */   }
/*     */   
/*     */   public boolean isReversed() {
/* 256 */     return this.reversed;
/*     */   }
/*     */   
/*     */   public CooldownInfo(int cooldownTime, @Nullable String icon, boolean reversed) {
/* 260 */     this(cooldownTime, icon, reversed, false);
/*     */   }
/*     */   
/*     */   public CooldownInfo(int cooldownTime, @Nullable String icon) {
/* 264 */     this(cooldownTime, icon, false, false);
/*     */   }
/*     */   
/*     */   public CooldownInfo(int cooldownTime, boolean reversed) {
/* 268 */     this(cooldownTime, null, reversed, false);
/*     */   }
/*     */   
/*     */   public CooldownInfo(int cooldownTime) {
/* 272 */     this(cooldownTime, null, false, false);
/*     */   }
/*     */   @Nullable
/*     */   public String getIcon() {
/* 276 */     return this.icon;
/*     */   }
/*     */   
/*     */   public void setCooldownTime(int cooldownTime) {
/* 280 */     this.cooldownTime = cooldownTime;
/*     */   }
/*     */   
/*     */   public int getCooldownTime() {
/* 284 */     return this.cooldownTime;
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\cooldowns\Cooldowns$CooldownInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */