/*    */ package com.starshootercity.papi;
/*    */ 
/*    */ import com.starshootercity.OriginsReborn;
/*    */ import me.clip.placeholderapi.expansion.PlaceholderExpansion;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ public class CooldownPlaceholderExpansion
/*    */   extends PlaceholderExpansion {
/*    */   @NotNull
/*    */   public String getIdentifier() {
/* 13 */     return "cooldown";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public String getAuthor() {
/* 18 */     return "cometcake575";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public String getVersion() {
/* 23 */     return OriginsReborn.getInstance().getConfig().getString("config-version", "unknown");
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public String onPlaceholderRequest(Player player, @NotNull String params) {
/* 28 */     return "This placeholder is incomplete!";
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\papi\CooldownPlaceholderExpansion.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */