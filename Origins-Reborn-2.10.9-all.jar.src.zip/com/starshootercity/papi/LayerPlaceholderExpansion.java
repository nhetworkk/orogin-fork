/*    */ package com.starshootercity.papi;
/*    */ 
/*    */ import com.starshootercity.Origin;
/*    */ import com.starshootercity.OriginSwapper;
/*    */ import com.starshootercity.OriginsReborn;
/*    */ import me.clip.placeholderapi.expansion.PlaceholderExpansion;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ public class LayerPlaceholderExpansion
/*    */   extends PlaceholderExpansion {
/*    */   private final String layer;
/*    */   
/*    */   public LayerPlaceholderExpansion(String layer) {
/* 16 */     this.layer = layer;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public String getIdentifier() {
/* 21 */     return this.layer;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public String getAuthor() {
/* 26 */     return "cometcake575";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public String getVersion() {
/* 31 */     return OriginsReborn.getInstance().getConfig().getString("config-version", "unknown");
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean persist() {
/* 36 */     return true;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public String onPlaceholderRequest(Player player, @NotNull String params) {
/* 41 */     Origin origin = OriginSwapper.getOrigin(player, this.layer);
/* 42 */     if (origin == null) return ""; 
/* 43 */     return origin.getNameForDisplay();
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\papi\LayerPlaceholderExpansion.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */