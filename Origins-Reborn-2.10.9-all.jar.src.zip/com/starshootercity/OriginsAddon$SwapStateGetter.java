package com.starshootercity;

import com.starshootercity.events.PlayerSwapOriginEvent;
import org.bukkit.entity.Player;

public interface SwapStateGetter {
  OriginsAddon.State get(Player paramPlayer, PlayerSwapOriginEvent.SwapReason paramSwapReason);
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\OriginsAddon$SwapStateGetter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */