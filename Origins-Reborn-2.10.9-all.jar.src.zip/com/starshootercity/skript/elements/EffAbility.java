/*    */ package com.starshootercity.skript.elements;
/*    */ 
/*    */ import ch.njol.skript.Skript;
/*    */ import ch.njol.skript.lang.Effect;
/*    */ import ch.njol.skript.lang.Expression;
/*    */ import ch.njol.skript.lang.SkriptParser;
/*    */ import ch.njol.util.Kleenean;
/*    */ import com.starshootercity.OriginsReborn;
/*    */ import com.starshootercity.abilities.types.Ability;
/*    */ import com.starshootercity.skript.BasicSkriptAbility;
/*    */ import com.starshootercity.skript.ComplexSkriptAbility;
/*    */ import com.starshootercity.skript.NamedSkriptAbility;
/*    */ import com.starshootercity.util.AbilityRegister;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ public class EffAbility
/*    */   extends Effect {
/*    */   private Expression<String> ability;
/*    */   
/*    */   static {
/* 27 */     Skript.registerEffect(EffAbility.class, new String[] { "(register|create) [(a new|an|a)] (ability|power) with (key|id) %string% [[and] (title|name) %-string% [and] description %-string%]" });
/*    */   }
/*    */   private Expression<String> title; private Expression<String> description;
/*    */   protected void execute(@NotNull Event event) {
/*    */     ComplexSkriptAbility complexSkriptAbility;
/* 32 */     if (this.ability == null)
/* 33 */       return;  String key = (String)this.ability.getSingle(event);
/* 34 */     if (key == null)
/* 35 */       return;  if (((this.title == null) ? true : false) != ((this.description == null) ? true : false))
/*    */       return; 
/* 37 */     List<Ability> abilities = new ArrayList<>();
/*    */     
/* 39 */     if (this.title != null) {
/* 40 */       String titl = (String)this.title.getSingle(event);
/* 41 */       String desc = (String)this.description.getSingle(event);
/* 42 */       Key displayKey = Key.key(key + "_display");
/* 43 */       NamedSkriptAbility nsa = new NamedSkriptAbility(displayKey, titl, desc);
/* 44 */       AbilityRegister.registerAbility((Ability)nsa, displayKey, (JavaPlugin)Skript.getInstance());
/* 45 */       abilities.add(nsa);
/*    */     } 
/*    */     
/* 48 */     Key abilityKey = Key.key(key);
/* 49 */     if (abilities.isEmpty()) {
/* 50 */       BasicSkriptAbility basicSkriptAbility = new BasicSkriptAbility(abilityKey);
/*    */     } else {
/* 52 */       complexSkriptAbility = new ComplexSkriptAbility(abilityKey, abilities);
/*    */     } 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 58 */     OriginsReborn.usesSkriptAbilities = true;
/* 59 */     AbilityRegister.registerAbility((Ability)complexSkriptAbility, abilityKey, 
/*    */ 
/*    */         
/* 62 */         (JavaPlugin)Skript.getInstance());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @NotNull
/*    */   public String toString(@Nullable Event event, boolean debug) {
/* 72 */     if (event == null) return "Ability register effect"; 
/* 73 */     return (this.title != null && this.description != null) ? ("Ability register effect with expression ability\">: " + 
/* 74 */       this.ability.toString(event, debug) + " and title\">: " + this.title.toString(event, debug) + " and description\">: " + this.description.toString(event, debug)) : ("Ability register effect with expression ability\">: " + 
/*    */       
/* 76 */       this.ability.toString(event, debug));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean init(Expression<?>[] expressions, int matchedPattern, @NotNull Kleenean isDelayed, SkriptParser.ParseResult parseResult) {
/* 82 */     this.ability = (Expression)expressions[0];
/* 83 */     this.title = (Expression)expressions[1];
/* 84 */     this.description = (Expression)expressions[2];
/* 85 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\skript\elements\EffAbility.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */