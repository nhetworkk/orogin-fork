/*    */ package com.starshootercity.skript.elements;
/*    */ 
/*    */ import ch.njol.skript.Skript;
/*    */ import ch.njol.skript.lang.Condition;
/*    */ import ch.njol.skript.lang.Expression;
/*    */ import ch.njol.skript.lang.SkriptParser;
/*    */ import ch.njol.util.Kleenean;
/*    */ import com.starshootercity.abilities.types.Ability;
/*    */ import com.starshootercity.util.AbilityRegister;
/*    */ import net.kyori.adventure.key.InvalidKeyException;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Event;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ public class CondAbility extends Condition {
/*    */   Expression<Player> player;
/*    */   
/*    */   static {
/* 21 */     Skript.registerCondition(CondAbility.class, new String[] { "%player% (1¦has|2¦does( not|n't) have) [the] [(ability|power)] [with (id|key)] %string%" });
/*    */   }
/*    */ 
/*    */   
/*    */   Expression<String> ability;
/*    */ 
/*    */   
/*    */   public boolean check(@NotNull Event event) {
/* 29 */     Player p = (Player)this.player.getSingle(event);
/* 30 */     String a = (String)this.ability.getSingle(event);
/* 31 */     if (p == null || a == null) return isNegated(); 
/*    */     try {
/* 33 */       Key key = Key.key(a);
/* 34 */       if (!AbilityRegister.abilityMap.containsKey(key)) return isNegated(); 
/* 35 */       return (((Ability)AbilityRegister.abilityMap.get(key)).hasAbility(p) != isNegated());
/* 36 */     } catch (InvalidKeyException e) {
/* 37 */       return isNegated();
/*    */     } 
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public String toString(@Nullable Event event, boolean debug) {
/* 43 */     if (event == null) return "Player has ability"; 
/* 44 */     return "Player " + this.player.toString(event, debug) + " has ability with id " + this.ability.toString(event, debug);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean init(Expression<?>[] expressions, int matchedPattern, @NotNull Kleenean isDelayed, SkriptParser.ParseResult parseResult) {
/* 50 */     this.player = (Expression)expressions[0];
/* 51 */     this.ability = (Expression)expressions[1];
/* 52 */     setNegated((parseResult.mark == 2));
/* 53 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\skript\elements\CondAbility.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */