/*    */ package com.starshootercity.skript;
/*    */ 
/*    */ import com.starshootercity.abilities.types.Ability;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class BasicSkriptAbility
/*    */   implements Ability {
/*    */   private final Key key;
/*    */   
/*    */   public BasicSkriptAbility(Key key) {
/* 12 */     this.key = key;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 17 */     return this.key;
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\skript\BasicSkriptAbility.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */