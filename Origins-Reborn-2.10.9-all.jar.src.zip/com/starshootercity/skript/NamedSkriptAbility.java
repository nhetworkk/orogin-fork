/*    */ package com.starshootercity.skript;
/*    */ 
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import net.kyori.adventure.key.Key;
/*    */ 
/*    */ public class NamedSkriptAbility
/*    */   extends BasicSkriptAbility implements VisibleAbility {
/*    */   private final String title;
/*    */   private final String description;
/*    */   
/*    */   public NamedSkriptAbility(Key key, String title, String description) {
/* 12 */     super(key);
/* 13 */     this.title = title;
/* 14 */     this.description = description;
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 19 */     return this.description;
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 24 */     return this.title;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean useTranslator() {
/* 29 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\skript\NamedSkriptAbility.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */