/*    */ package com.starshootercity.skript;
/*    */ 
/*    */ import com.starshootercity.abilities.types.Ability;
/*    */ import com.starshootercity.abilities.types.MultiAbility;
/*    */ import java.util.List;
/*    */ import net.kyori.adventure.key.Key;
/*    */ 
/*    */ public class ComplexSkriptAbility
/*    */   extends BasicSkriptAbility
/*    */   implements MultiAbility {
/*    */   private final List<Ability> abilities;
/*    */   
/*    */   public ComplexSkriptAbility(Key key, List<Ability> abilities) {
/* 14 */     super(key);
/* 15 */     this.abilities = abilities;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<Ability> getAbilities() {
/* 20 */     return this.abilities;
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\skript\ComplexSkriptAbility.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */