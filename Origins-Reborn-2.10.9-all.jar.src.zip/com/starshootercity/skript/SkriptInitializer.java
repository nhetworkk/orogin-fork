/*    */ package com.starshootercity.skript;
/*    */ 
/*    */ import ch.njol.skript.Skript;
/*    */ import ch.njol.skript.SkriptAddon;
/*    */ import java.io.IOException;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ 
/*    */ public class SkriptInitializer
/*    */ {
/*    */   public static void initialize(JavaPlugin plugin) {
/*    */     try {
/* 12 */       SkriptAddon addon = Skript.registerAddon(plugin);
/* 13 */       addon.loadClasses("com.starshootercity.skript", new String[] { "elements" });
/* 14 */     } catch (NoClassDefFoundError noClassDefFoundError) {
/*    */     
/* 16 */     } catch (IOException e) {
/* 17 */       throw new RuntimeException(e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\skript\SkriptInitializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */