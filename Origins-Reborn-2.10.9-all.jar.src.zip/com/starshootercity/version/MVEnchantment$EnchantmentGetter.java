package com.starshootercity.version;

import org.bukkit.enchantments.Enchantment;

public interface EnchantmentGetter {
  Enchantment get(MultiVersionExecutor paramMultiVersionExecutor);
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\version\MVEnchantment$EnchantmentGetter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */