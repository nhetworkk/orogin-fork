/*      */ package com.starshootercity.version;
/*      */ import com.destroystokyo.paper.entity.ai.Goal;
/*      */ import java.lang.reflect.Field;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Optional;
/*      */ import java.util.UUID;
/*      */ import java.util.function.BiPredicate;
/*      */ import java.util.function.Predicate;
/*      */ import net.kyori.adventure.key.Key;
/*      */ import net.kyori.adventure.text.Component;
/*      */ import net.minecraft.core.BlockPosition;
/*      */ import net.minecraft.network.PacketDataSerializer;
/*      */ import net.minecraft.network.protocol.Packet;
/*      */ import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket;
/*      */ import net.minecraft.network.protocol.game.PacketPlayOutEntityMetadata;
/*      */ import net.minecraft.network.protocol.game.PacketPlayOutGameStateChange;
/*      */ import net.minecraft.network.syncher.DataWatcher;
/*      */ import net.minecraft.server.level.EntityPlayer;
/*      */ import net.minecraft.world.EnumInteractionResult;
/*      */ import net.minecraft.world.effect.MobEffect;
/*      */ import net.minecraft.world.entity.Entity;
/*      */ import net.minecraft.world.entity.EntityLiving;
/*      */ import net.minecraft.world.entity.ai.goal.PathfinderGoalAvoidTarget;
/*      */ import net.minecraft.world.entity.player.EntityHuman;
/*      */ import net.minecraft.world.entity.projectile.EntityArrow;
/*      */ import net.minecraft.world.entity.projectile.EntityTippedArrow;
/*      */ import net.minecraft.world.item.ItemStack;
/*      */ import net.minecraft.world.level.EnumGamemode;
/*      */ import net.minecraft.world.level.block.entity.TileEntityConduit;
/*      */ import net.minecraft.world.phys.MovingObjectPositionBlock;
/*      */ import net.minecraft.world.phys.Vec3D;
/*      */ import org.bukkit.GameMode;
/*      */ import org.bukkit.Location;
/*      */ import org.bukkit.Material;
/*      */ import org.bukkit.NamespacedKey;
/*      */ import org.bukkit.Particle;
/*      */ import org.bukkit.WorldBorder;
/*      */ import org.bukkit.attribute.Attribute;
/*      */ import org.bukkit.attribute.AttributeInstance;
/*      */ import org.bukkit.attribute.AttributeModifier;
/*      */ import org.bukkit.block.Block;
/*      */ import org.bukkit.block.Conduit;
/*      */ import org.bukkit.configuration.file.FileConfiguration;
/*      */ import org.bukkit.craftbukkit.v1_19_R3.CraftWorld;
/*      */ import org.bukkit.craftbukkit.v1_19_R3.entity.CraftEntity;
/*      */ import org.bukkit.craftbukkit.v1_19_R3.entity.CraftLivingEntity;
/*      */ import org.bukkit.craftbukkit.v1_19_R3.entity.CraftPlayer;
/*      */ import org.bukkit.craftbukkit.v1_19_R3.inventory.CraftItemStack;
/*      */ import org.bukkit.enchantments.Enchantment;
/*      */ import org.bukkit.entity.Allay;
/*      */ import org.bukkit.entity.Arrow;
/*      */ import org.bukkit.entity.Entity;
/*      */ import org.bukkit.entity.LivingEntity;
/*      */ import org.bukkit.entity.Piglin;
/*      */ import org.bukkit.entity.Player;
/*      */ import org.bukkit.event.EventHandler;
/*      */ import org.bukkit.event.block.BlockDamageAbortEvent;
/*      */ import org.bukkit.inventory.EquipmentSlot;
/*      */ import org.bukkit.inventory.ItemStack;
/*      */ import org.bukkit.inventory.meta.ItemMeta;
/*      */ import org.bukkit.inventory.meta.PotionMeta;
/*      */ import org.bukkit.potion.PotionEffect;
/*      */ import org.bukkit.potion.PotionEffectType;
/*      */ import org.bukkit.potion.PotionType;
/*      */ import org.jetbrains.annotations.NotNull;
/*      */ import org.jetbrains.annotations.Nullable;
/*      */ import org.spigotmc.event.entity.EntityDismountEvent;
/*      */ import org.spigotmc.event.entity.EntityMountEvent;
/*      */ 
/*      */ public class MVE_V1_19_4 extends MultiVersionExecutor {
/*      */   public void setTouchingWater(Player player) {
/*   74 */     (((CraftPlayer)player).getHandle()).ah = true;
/*      */   }
/*      */   
/*   77 */   private final ItemStack boneMeal = CraftItemStack.asNMSCopy(new ItemStack(Material.BONE_MEAL));
/*      */   
/*      */   private static Field effectBlocks;
/*      */   
/*      */   private static Field isActive;
/*      */   
/*      */   public boolean boneMeal(Block block, Player player) {
/*   84 */     BlockPosition blockPos = new BlockPosition(block.getX(), block.getY(), block.getZ());
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   89 */     MovingObjectPositionBlock bhr = new MovingObjectPositionBlock(Vec3D.b((BaseBlockPosition)blockPos), ((CraftPlayer)player).getHandle().cA(), blockPos, false);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   94 */     EnumInteractionResult result = ItemBoneMeal.applyBonemeal(new ItemActionContext((World)((CraftWorld)player
/*   95 */           .getWorld()).getHandle(), (EntityHuman)((CraftPlayer)player)
/*   96 */           .getHandle(), EnumHand.a, this.boneMeal, bhr));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  101 */     return (result == EnumInteractionResult.a);
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute miningEfficiencyAttribute() {
/*  106 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute sneakingSpeedAttribute() {
/*  111 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute submergedMiningSpeedAttribute() {
/*  116 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute sweepingDamageRatioAttribute() {
/*  121 */     return null;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public ItemMeta setCustomModelData(ItemMeta meta, int cmd) {
/*  126 */     meta.setCustomModelData(Integer.valueOf(cmd));
/*  127 */     return meta;
/*      */   }
/*      */ 
/*      */   
/*      */   public void initialize() {
/*  132 */     String blocks = ReflectionRemapper.forReobfMappingsInPaperJar().remapFieldName(TileEntityConduit.class, "effectBlocks");
/*  133 */     String active = ReflectionRemapper.forReobfMappingsInPaperJar().remapFieldName(TileEntityConduit.class, "isActive");
/*      */     try {
/*  135 */       effectBlocks = TileEntityConduit.class.getDeclaredField(blocks);
/*  136 */       effectBlocks.setAccessible(true);
/*  137 */       isActive = TileEntityConduit.class.getDeclaredField(active);
/*  138 */       isActive.setAccessible(true);
/*  139 */     } catch (NoSuchFieldException e) {
/*  140 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getConduitRange(Conduit conduit) {
/*      */     try {
/*  151 */       TileEntityConduit tileEntity = (TileEntityConduit)((CraftConduit)conduit).getTileEntity();
/*  152 */       boolean active = ((Boolean)isActive.get(tileEntity)).booleanValue();
/*  153 */       if (!active) return 0; 
/*  154 */       List<BlockPosition> list = (List<BlockPosition>)effectBlocks.get(tileEntity);
/*  155 */       int i = list.size();
/*  156 */       return i / 7 * 16;
/*  157 */     } catch (IllegalAccessException e) {
/*  158 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute flyingSpeedAttribute() {
/*  164 */     return Attribute.GENERIC_FLYING_SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute attackKnockbackAttribute() {
/*  169 */     return Attribute.GENERIC_ATTACK_KNOCKBACK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute attackSpeedAttribute() {
/*  174 */     return Attribute.GENERIC_ATTACK_SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute armorToughnessAttribute() {
/*  179 */     return Attribute.GENERIC_ARMOR_TOUGHNESS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute luckAttribute() {
/*  184 */     return Attribute.GENERIC_LUCK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute horseJumpStrengthAttribute() {
/*  189 */     return Attribute.HORSE_JUMP_STRENGTH;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute spawnReinforcementsAttribute() {
/*  194 */     return Attribute.ZOMBIE_SPAWN_REINFORCEMENTS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute followRangeAttribute() {
/*  199 */     return Attribute.GENERIC_FOLLOW_RANGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute knockbackResistanceAttribute() {
/*  204 */     return Attribute.GENERIC_KNOCKBACK_RESISTANCE;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute fallDamageMultiplierAttribute() {
/*  209 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute maxAbsorptionAttribute() {
/*  214 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute safeFallDistanceAttribute() {
/*  219 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute scaleAttribute() {
/*  224 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute stepHeightAttribute() {
/*  229 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute gravityAttribute() {
/*  234 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute jumpStrengthAttribute() {
/*  239 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute burningTimeAttribute() {
/*  244 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute explosionKnockbackResistanceAttribute() {
/*  249 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute movementEfficiencyAttribute() {
/*  254 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute oxygenBonusAttribute() {
/*  259 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute waterMovementEfficiencyAttribute() {
/*  264 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute temptRangeAttribute() {
/*  269 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealDrowningDamage(LivingEntity entity, int amount) {
/*  274 */     EntityLiving livingEntity = ((CraftLivingEntity)entity).getHandle();
/*  275 */     livingEntity.a(livingEntity.dG().h(), amount);
/*      */   }
/*      */ 
/*      */   
/*      */   public Component applyFont(Component component, Key font) {
/*  280 */     return component.font(font);
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Material getOminousBottle() {
/*  285 */     return null;
/*      */   }
/*      */   
/*      */   @EventHandler
/*      */   public void onBlockDamageAbort(BlockDamageAbortEvent event) {
/*  290 */     (new MVBlockDamageAbortEvent(event.getPlayer(), event.getBlock(), event.getItemInHand())).callEvent();
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute armorAttribute() {
/*  295 */     return Attribute.GENERIC_ARMOR;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute maxHealthAttribute() {
/*  300 */     return Attribute.GENERIC_MAX_HEALTH;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute movementSpeedAttribute() {
/*  305 */     return Attribute.GENERIC_MOVEMENT_SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute attackDamageAttribute() {
/*  310 */     return Attribute.GENERIC_ATTACK_DAMAGE;
/*      */   }
/*      */ 
/*      */   
/*      */   public void sendEntityData(Player player, Entity entity, byte bytes) {
/*  315 */     EntityPlayer serverPlayer = ((CraftPlayer)player).getHandle();
/*  316 */     Entity target = ((CraftEntity)entity).getHandle();
/*      */     
/*  318 */     List<DataWatcher.b<?>> eData = new ArrayList<>();
/*  319 */     eData.add(DataWatcher.b.a(new DataWatcherObject(0, DataWatcherRegistry.a), Byte.valueOf(bytes)));
/*  320 */     PacketPlayOutEntityMetadata metadata = new PacketPlayOutEntityMetadata(target.af(), eData);
/*  321 */     serverPlayer.b.a((Packet)metadata);
/*      */   }
/*      */ 
/*      */   
/*      */   public Attribute blockInteractionRangeAttribute() {
/*  326 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Attribute entityInteractionRangeAttribute() {
/*  331 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Goal<Creeper> getCreeperAfraidGoal(LivingEntity creeper, BiPredicate<LivingEntity, Player> hasAbility) {
/*  336 */     return (new PathfinderGoalAvoidTarget((EntityCreature)((CraftEntity)creeper)
/*  337 */         .getHandle(), EntityHuman.class, 6.0F, 1.0D, 1.2D, livingEntity -> {
/*      */           CraftEntity patt10987$temp = livingEntity.getBukkitEntity();
/*      */ 
/*      */           
/*      */           if (patt10987$temp instanceof Player) {
/*      */             Player player = (Player)patt10987$temp;
/*      */ 
/*      */             
/*      */             return hasAbility.test(creeper, player);
/*      */           } 
/*      */           
/*      */           return false;
/*  349 */         })).asPaperVanillaGoal();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean wasTouchingWater(Player player) {
/*  354 */     return (((CraftPlayer)player).getHandle()).ah;
/*      */   }
/*      */ 
/*      */   
/*      */   public float getDestroySpeed(ItemStack item, Material block) {
/*  359 */     IBlockData b = ((CraftBlockData)block.createBlockData()).getState();
/*  360 */     ItemStack handle = CraftItemStack.asNMSCopy(item);
/*  361 */     return handle.a(b);
/*      */   }
/*      */ 
/*      */   
/*      */   public float getDestroySpeed(Material block) {
/*  366 */     return (((CraftBlockData)block.createBlockData()).getState()).k;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setNoPhysics(Player player, boolean noPhysics) {
/*  371 */     (((CraftPlayer)player).getHandle()).ae = noPhysics;
/*      */   }
/*      */ 
/*      */   
/*      */   public void sendGamemodeUpdate(Player player, GameMode gameMode, boolean bedrock) {
/*  376 */     EntityPlayer serverPlayer = ((CraftPlayer)player).getHandle();
/*      */     
/*  378 */     switch (gameMode) { default: throw new IncompatibleClassChangeError();
/*      */       case NIGHT_VISION: 
/*      */       case INVISIBILITY: 
/*      */       case JUMP: 
/*  382 */       case FIRE_RESISTANCE: break; }  EnumGamemode gameType = EnumGamemode.d;
/*      */ 
/*      */     
/*  385 */     PacketDataSerializer buf = new PacketDataSerializer(Unpooled.buffer());
/*  386 */     buf.a(EnumSet.of(ClientboundPlayerInfoUpdatePacket.a.c), ClientboundPlayerInfoUpdatePacket.a.class);
/*  387 */     buf.a(List.of("null"), (buf2, e) -> {
/*      */           buf2.a(serverPlayer.cs());
/*      */           
/*      */           buf2.d(gameType.a());
/*      */         });
/*  392 */     ClientboundPlayerInfoUpdatePacket packet = new ClientboundPlayerInfoUpdatePacket(buf);
/*  393 */     serverPlayer.b.a((Packet)packet);
/*      */     
/*  395 */     if (bedrock) {
/*  396 */       PacketPlayOutGameStateChange eventPacket = new PacketPlayOutGameStateChange(PacketPlayOutGameStateChange.d, gameType.a());
/*  397 */       serverPlayer.b.a((Packet)eventPacket);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void sendResourcePacks(Player player, String pack, Map<?, ResourcePackInfo> extraPacks) {
/*  404 */     player.setResourcePack(pack);
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Location getRespawnLocation(Player player) {
/*  409 */     return player.getBedSpawnLocation();
/*      */   }
/*      */ 
/*      */   
/*      */   public void resetRespawnLocation(Player player) {
/*  414 */     player.setBedSpawnLocation(null);
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public AttributeModifier getAttributeModifier(AttributeInstance instance, Key key) {
/*  419 */     UUID u = UUID.nameUUIDFromBytes(key.toString().getBytes());
/*  420 */     for (AttributeModifier am : instance.getModifiers()) {
/*  421 */       if (am.getUniqueId().equals(u)) return am; 
/*      */     } 
/*  423 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void addAttributeModifier(AttributeInstance instance, NamespacedKey key, String name, double amount, AttributeModifier.Operation operation) {
/*  428 */     instance.addModifier(new AttributeModifier(UUID.nameUUIDFromBytes(key.toString().getBytes()), name, amount, operation));
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isUnderWater(LivingEntity entity) {
/*  433 */     return entity.isUnderWater();
/*      */   }
/*      */ 
/*      */   
/*      */   public void knockback(LivingEntity entity, double strength, double x, double z) {
/*  438 */     entity.knockback(strength, x, z);
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealDryOutDamage(LivingEntity entity, int amount) {
/*  443 */     EntityLiving livingEntity = ((CraftLivingEntity)entity).getHandle();
/*  444 */     livingEntity.a(livingEntity.dG().r(), amount);
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealFreezeDamage(LivingEntity entity, int amount) {
/*  449 */     EntityLiving livingEntity = ((CraftLivingEntity)entity).getHandle();
/*  450 */     livingEntity.a(livingEntity.dG().t(), amount);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsInfiniteDuration() {
/*  455 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setFlyingFallDamage(Player player, TriState state) {
/*  460 */     player.setFlyingFallDamage(state);
/*      */   }
/*      */ 
/*      */   
/*      */   public void broadcastSlotBreak(Player player, EquipmentSlot slot, Collection<Player> players) {
/*  465 */     player.broadcastSlotBreak(slot, players);
/*      */   }
/*      */ 
/*      */   
/*      */   public void sendBlockDamage(Player player, Location location, float damage, Entity entity) {
/*  470 */     player.sendBlockDamage(location, damage, entity);
/*      */   }
/*      */ 
/*      */   
/*      */   public Attribute blockBreakSpeedAttribute() {
/*  475 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setWorldBorderOverlay(Player player, boolean show) {
/*  480 */     if (show)
/*  481 */     { WorldBorder border = Bukkit.createWorldBorder();
/*  482 */       border.setCenter(player.getWorld().getWorldBorder().getCenter());
/*  483 */       border.setSize(player.getWorld().getWorldBorder().getSize());
/*  484 */       border.setWarningDistance((int)(player.getWorld().getWorldBorder().getSize() * 2.0D));
/*  485 */       player.setWorldBorder(border); }
/*  486 */     else { player.setWorldBorder(null); }
/*      */   
/*      */   }
/*      */   
/*      */   public void setComments(FileConfiguration config, String path, List<String> comments) {
/*  491 */     config.setComments(path, comments);
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealExplosionDamage(Player player, int amount) {
/*  496 */     EntityPlayer serverPlayer = ((CraftPlayer)player).getHandle();
/*  497 */     serverPlayer.a(serverPlayer.dG().a(null), amount);
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealSonicBoomDamage(LivingEntity entity, int amount, Player source) {
/*  502 */     EntityPlayer serverPlayer = ((CraftPlayer)source).getHandle();
/*  503 */     Entity e = ((CraftEntity)entity).getHandle();
/*  504 */     e.a(e.dG().e((Entity)serverPlayer), amount);
/*      */   }
/*      */ 
/*      */   
/*      */   public Goal<Villager> getVillagerAfraidGoal(LivingEntity villager, Predicate<Player> hasAbility) {
/*  509 */     return (new PathfinderGoalAvoidTarget((EntityCreature)((CraftEntity)villager)
/*  510 */         .getHandle(), EntityHuman.class, 6.0F, 0.5D, 0.8D, livingEntity -> {
/*      */           CraftEntity patt17364$temp = livingEntity.getBukkitEntity();
/*      */ 
/*      */           
/*      */           if (patt17364$temp instanceof Player) {
/*      */             Player player = (Player)patt17364$temp;
/*      */             
/*      */             return hasAbility.test(player);
/*      */           } 
/*      */           
/*      */           return false;
/*  521 */         })).asPaperVanillaGoal();
/*      */   }
/*      */ 
/*      */   
/*      */   public void throwItem(Piglin piglin, ItemStack itemStack, Location pos) {
/*  526 */     BehaviorUtil.a(((CraftLivingEntity)piglin).getHandle(), CraftItemStack.asNMSCopy(itemStack), new Vec3D(pos.getX(), pos.getY(), pos.getZ()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void launchArrow(Entity projectile, Entity entity, float roll, float force, float divergence) {
/*  531 */     ((AbstractProjectile)projectile).getHandle().a(((CraftEntity)entity).getHandle(), entity.getLocation().getPitch(), entity.getLocation().getYaw(), roll, force, divergence);
/*      */   }
/*      */ 
/*      */   
/*      */   public void damageItem(ItemStack item, int amount, Player player) {
/*  536 */     item.damage(amount, (LivingEntity)player);
/*      */   }
/*      */ 
/*      */   
/*      */   public void startAutoSpinAttack(Player player, int duration, float riptideAttackDamage, ItemStack item) {
/*  541 */     ((CraftPlayer)player).getHandle().s(duration);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tridentMove(Player player) {
/*  546 */     ((CraftPlayer)player).getHandle().a(EnumMoveType.a, new Vec3D(0.0D, 1.1999999284744263D, 0.0D));
/*      */   }
/*      */ 
/*      */   
/*      */   public void transferDamageEvent(LivingEntity entity, EntityDamageEvent event) {
/*  551 */     entity.damage(event.getDamage());
/*      */   }
/*      */ 
/*      */   
/*      */   public void boostArrow(Arrow arrow) {
/*  556 */     EntityArrow entityArrow = ((CraftArrow)arrow).getHandle(); if (entityArrow instanceof EntityTippedArrow) { EntityTippedArrow a = (EntityTippedArrow)entityArrow;
/*  557 */       for (MobEffect instance : PotionUtil.d(a.o()).a()) {
/*  558 */         a.a(new MobEffect(instance.c(), instance.d(), instance.e() + 1));
/*      */       } }
/*      */   
/*      */   }
/*      */   
/*      */   public boolean duplicateAllay(LivingEntity entity) {
/*      */     Allay allay;
/*  565 */     if (entity instanceof Allay) { allay = (Allay)entity; } else { return false; }
/*  566 */      if (allay.getDuplicationCooldown() > 0L) return false; 
/*  567 */     allay.duplicateAllay();
/*  568 */     ((CraftWorld)allay.getWorld()).getHandle().a((Entity)((CraftAllay)allay).getHandle(), (byte)18);
/*  569 */     return true;
/*      */   }
/*      */   
/*      */   @EventHandler
/*      */   public void onEntityDismount(EntityDismountEvent event) {
/*  574 */     event.setCancelled(!(new MVEntityDismountEvent(event.getEntity(), event.getDismounted(), event.isCancellable())).callEvent());
/*      */   }
/*      */   
/*      */   @EventHandler
/*      */   public void onEntityMount(EntityMountEvent event) {
/*  579 */     event.setCancelled(!(new MVEntityMountEvent(event.getEntity(), event.getMount())).callEvent());
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType speedEffect() {
/*  584 */     return PotionEffectType.SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType slownessEffect() {
/*  589 */     return PotionEffectType.SLOW;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType hasteEffect() {
/*  594 */     return PotionEffectType.FAST_DIGGING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType miningFatigueEffect() {
/*  599 */     return PotionEffectType.SLOW_DIGGING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType strengthEffect() {
/*  604 */     return PotionEffectType.INCREASE_DAMAGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType instantHealthEffect() {
/*  609 */     return PotionEffectType.HEAL;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType instantDamageEffect() {
/*  614 */     return PotionEffectType.HARM;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType jumpBoostEffect() {
/*  619 */     return PotionEffectType.JUMP;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType nauseaEffect() {
/*  624 */     return PotionEffectType.CONFUSION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType regenerationEffect() {
/*  629 */     return PotionEffectType.REGENERATION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType resistanceEffect() {
/*  634 */     return PotionEffectType.DAMAGE_RESISTANCE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType fireResistanceEffect() {
/*  639 */     return PotionEffectType.FIRE_RESISTANCE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType waterBreathingEffect() {
/*  644 */     return PotionEffectType.WATER_BREATHING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType invisibilityEffect() {
/*  649 */     return PotionEffectType.INVISIBILITY;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType blindnessEffect() {
/*  654 */     return PotionEffectType.BLINDNESS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType nightVisionEffect() {
/*  659 */     return PotionEffectType.NIGHT_VISION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType hungerEffect() {
/*  664 */     return PotionEffectType.HUNGER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType weaknessEffect() {
/*  669 */     return PotionEffectType.WEAKNESS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType poisonEffect() {
/*  674 */     return PotionEffectType.POISON;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType witherEffect() {
/*  679 */     return PotionEffectType.WITHER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType healthBoostEffect() {
/*  684 */     return PotionEffectType.HEALTH_BOOST;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType absorptionEffect() {
/*  689 */     return PotionEffectType.ABSORPTION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType saturationEffect() {
/*  694 */     return PotionEffectType.SATURATION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType glowingEffect() {
/*  699 */     return PotionEffectType.GLOWING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType levitationEffect() {
/*  704 */     return PotionEffectType.LEVITATION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType luckEffect() {
/*  709 */     return PotionEffectType.LUCK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType badLuckEffect() {
/*  714 */     return PotionEffectType.UNLUCK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType slowFallingEffect() {
/*  719 */     return PotionEffectType.SLOW_FALLING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType conduitPowerEffect() {
/*  724 */     return PotionEffectType.CONDUIT_POWER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType dolphinsGraceEffect() {
/*  729 */     return PotionEffectType.DOLPHINS_GRACE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType badOmenEffect() {
/*  734 */     return PotionEffectType.BAD_OMEN;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType heroOfTheVillageEffect() {
/*  739 */     return PotionEffectType.HERO_OF_THE_VILLAGE;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType darknessEffect() {
/*  744 */     return PotionEffectType.DARKNESS;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType trialOmenEffect() {
/*  749 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType raidOmenEffect() {
/*  754 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType windChargedEffect() {
/*  759 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType weavingEffect() {
/*  764 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType oozingEffect() {
/*  769 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType infestedEffect() {
/*  774 */     return null;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment protectionEnchantment() {
/*  779 */     return Enchantment.PROTECTION_ENVIRONMENTAL;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment fireProtectionEnchantment() {
/*  784 */     return Enchantment.PROTECTION_FIRE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment featherFallingEnchantment() {
/*  789 */     return Enchantment.PROTECTION_FALL;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment blastProtectionEnchantment() {
/*  794 */     return Enchantment.PROTECTION_EXPLOSIONS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment projectileProtectionEnchantment() {
/*  799 */     return Enchantment.PROTECTION_PROJECTILE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment respirationEnchantment() {
/*  804 */     return Enchantment.OXYGEN;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment aquaAffinityEnchantment() {
/*  809 */     return Enchantment.WATER_WORKER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment thornsEnchantment() {
/*  814 */     return Enchantment.THORNS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment depthStriderEnchantment() {
/*  819 */     return Enchantment.DEPTH_STRIDER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment frostWalkerEnchantment() {
/*  824 */     return Enchantment.FROST_WALKER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment bindingCurseEnchantment() {
/*  829 */     return Enchantment.BINDING_CURSE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment sharpnessEnchantment() {
/*  834 */     return Enchantment.DAMAGE_ALL;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment smiteEnchantment() {
/*  839 */     return Enchantment.DAMAGE_UNDEAD;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment baneOfArthropodsEnchantment() {
/*  844 */     return Enchantment.DAMAGE_ARTHROPODS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment knockbackEnchantment() {
/*  849 */     return Enchantment.KNOCKBACK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment fireAspectEnchantment() {
/*  854 */     return Enchantment.FIRE_ASPECT;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment lootingEnchantment() {
/*  859 */     return Enchantment.LOOT_BONUS_MOBS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment sweepingEdgeEnchantment() {
/*  864 */     return Enchantment.SWEEPING_EDGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment efficiencyEnchantment() {
/*  869 */     return Enchantment.DIG_SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment silkTouchEnchantment() {
/*  874 */     return Enchantment.SILK_TOUCH;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment unbreakingEnchantment() {
/*  879 */     return Enchantment.DURABILITY;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment fortuneEnchantment() {
/*  884 */     return Enchantment.LOOT_BONUS_BLOCKS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment powerEnchantment() {
/*  889 */     return Enchantment.ARROW_DAMAGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment punchEnchantment() {
/*  894 */     return Enchantment.ARROW_KNOCKBACK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment flameEnchantment() {
/*  899 */     return Enchantment.ARROW_FIRE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment infinityEnchantment() {
/*  904 */     return Enchantment.ARROW_INFINITE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment luckOfTheSeaEnchantment() {
/*  909 */     return Enchantment.LUCK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment lureEnchantment() {
/*  914 */     return Enchantment.LURE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment loyaltyEnchantment() {
/*  919 */     return Enchantment.LOYALTY;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment impalingEnchantment() {
/*  924 */     return Enchantment.IMPALING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment riptideEnchantment() {
/*  929 */     return Enchantment.RIPTIDE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment channelingEnchantment() {
/*  934 */     return Enchantment.CHANNELING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment multishotEnchantment() {
/*  939 */     return Enchantment.MULTISHOT;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment quickChargeEnchantment() {
/*  944 */     return Enchantment.QUICK_CHARGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment piercingEnchantment() {
/*  949 */     return Enchantment.PIERCING;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected Enchantment densityEnchantment() {
/*  954 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected Enchantment breachEnchantment() {
/*  959 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected Enchantment windBurstEnchantment() {
/*  964 */     return null;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment mendingEnchantment() {
/*  969 */     return Enchantment.MENDING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment vanishingCurseEnchantment() {
/*  974 */     return Enchantment.VANISHING_CURSE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment soulSpeedEnchantment() {
/*  979 */     return Enchantment.SOUL_SPEED;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected Enchantment swiftSneakEnchantment() {
/*  984 */     return Enchantment.SWIFT_SNEAK;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Player getNearestVisiblePlayer(Piglin piglin) {
/*  989 */     Optional<EntityHuman> optional = ((CraftPiglin)piglin).getHandle().dH().c(MemoryModuleType.k);
/*  990 */     return optional.<Player>map(player -> (Player)player.getBukkitEntity()).orElse(null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealThornsDamage(Entity target, int amount, Entity attacker) {
/*  995 */     Entity entity = ((CraftEntity)target).getHandle();
/*  996 */     entity.a(entity.dG().d(((CraftEntity)attacker).getHandle()), amount);
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Particle getElderGuardianParticle() {
/* 1001 */     return Particle.MOB_APPEARANCE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Particle getWitchParticle() {
/* 1006 */     return Particle.SPELL_WITCH;
/*      */   }
/*      */ 
/*      */   
/*      */   public Goal<Mob> getIronGolemAttackGoal(LivingEntity golem, Predicate<Player> hasAbility) {
/* 1011 */     return (new PathfinderGoalNearestAttackableTarget(((CraftMob)golem)
/* 1012 */         .getHandle(), EntityHuman.class, 10, true, false, livingEntity -> {
/*      */           CraftEntity patt31114$temp = livingEntity.getBukkitEntity();
/*      */           
/*      */           if (patt31114$temp instanceof Player) {
/*      */             Player player = (Player)patt31114$temp;
/*      */             
/*      */             return hasAbility.test(player);
/*      */           } 
/*      */           return false;
/* 1021 */         })).asPaperVanillaGoal();
/*      */   }
/*      */   
/* 1024 */   private final Map<Player, Vec3D> lastVec3Map = new HashMap<>();
/*      */ 
/*      */ 
/*      */   
/*      */   public void bounce(Player player) {
/* 1029 */     EntityPlayer p = ((CraftPlayer)player).getHandle();
/* 1030 */     if (player.isOnGround()) {
/* 1031 */       if (player.getFallDistance() <= 0.0F)
/* 1032 */         return;  Vec3D dm = this.lastVec3Map.get(player);
/* 1033 */       if (dm != null) {
/* 1034 */         player.setVelocity(player.getVelocity().add(new Vector(0.0D, -dm.d, 0.0D)));
/*      */       }
/*      */     } 
/* 1037 */     this.lastVec3Map.put(player, p.dj());
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Particle getHappyVillagerParticle() {
/* 1042 */     return Particle.VILLAGER_HAPPY;
/*      */   }
/*      */ 
/*      */   
/*      */   public void playTotemEffect(Player player) {
/* 1047 */     ((CraftWorld)player.getWorld()).getHandle().a((Entity)((CraftPlayer)player).getHandle(), (byte)35);
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public List<PotionEffect> getDefaultEffects(PotionMeta meta, boolean isLingering) {
/* 1052 */     PotionType type = meta.getBasePotionData().getType();
/* 1053 */     if (type.getEffectType() == null) return Collections.emptyList();
/*      */     
/* 1055 */     if (type.equals(PotionType.TURTLE_MASTER)) {
/* 1056 */       float multiplier = (isLingering ? 1.0F : 0.25F) * (meta.getBasePotionData().isExtended() ? 2 : true);
/* 1057 */       return List.of(new PotionEffect(PotionEffectType.SLOW, (int)(multiplier * 400.0F), 
/* 1058 */             meta.getBasePotionData().isUpgraded() ? 5 : 4), new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, (int)(multiplier * 400.0F), 
/* 1059 */             meta.getBasePotionData().isUpgraded() ? 2 : 3));
/*      */     } 
/*      */     
/* 1062 */     return Collections.singletonList(new PotionEffect(type.getEffectType(), change(getDuration(type), meta.getBasePotionData().isExtended()), meta.getBasePotionData().isUpgraded() ? 1 : 0));
/*      */   }
/*      */   
/*      */   public int change(int duration, boolean extended) {
/* 1066 */     if (!extended) return duration; 
/* 1067 */     if (duration == 3600) return 9600; 
/* 1068 */     return duration * 2;
/*      */   }
/*      */   
/*      */   public int getDuration(PotionType type) {
/* 1072 */     switch (type) { case NIGHT_VISION: case INVISIBILITY: case JUMP: case FIRE_RESISTANCE: case SPEED: case WATER_BREATHING: case STRENGTH: case SLOWNESS: case WEAKNESS: case SLOW_FALLING: case POISON: case REGEN: case LUCK:  }  return 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1077 */       1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void dropItem(Player player, ItemStack it) {
/* 1083 */     ((CraftPlayer)player).getHandle().a(CraftItemStack.asNMSCopy(it), true);
/*      */   }
/*      */   
/*      */   public void setArrow(Arrow arrow, ItemStack itemStack) {}
/*      */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\version\MVE_V1_19_4.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */