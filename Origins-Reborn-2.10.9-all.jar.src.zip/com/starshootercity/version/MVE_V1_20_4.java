/*      */ package com.starshootercity.version;
/*      */ import com.destroystokyo.paper.entity.ai.Goal;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Optional;
/*      */ import java.util.UUID;
/*      */ import java.util.function.BiPredicate;
/*      */ import java.util.function.Predicate;
/*      */ import net.kyori.adventure.key.Key;
/*      */ import net.kyori.adventure.resource.ResourcePackInfo;
/*      */ import net.kyori.adventure.resource.ResourcePackRequest;
/*      */ import net.kyori.adventure.text.Component;
/*      */ import net.minecraft.core.BlockPosition;
/*      */ import net.minecraft.network.protocol.Packet;
/*      */ import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket;
/*      */ import net.minecraft.network.protocol.game.PacketPlayOutEntityMetadata;
/*      */ import net.minecraft.network.protocol.game.PacketPlayOutGameStateChange;
/*      */ import net.minecraft.network.syncher.DataWatcher;
/*      */ import net.minecraft.server.level.EntityPlayer;
/*      */ import net.minecraft.world.EnumInteractionResult;
/*      */ import net.minecraft.world.entity.Entity;
/*      */ import net.minecraft.world.entity.EntityLiving;
/*      */ import net.minecraft.world.entity.ai.goal.PathfinderGoalAvoidTarget;
/*      */ import net.minecraft.world.entity.player.EntityHuman;
/*      */ import net.minecraft.world.item.ItemStack;
/*      */ import net.minecraft.world.level.EnumGamemode;
/*      */ import net.minecraft.world.phys.MovingObjectPositionBlock;
/*      */ import net.minecraft.world.phys.Vec3D;
/*      */ import org.bukkit.GameMode;
/*      */ import org.bukkit.Location;
/*      */ import org.bukkit.Material;
/*      */ import org.bukkit.NamespacedKey;
/*      */ import org.bukkit.Particle;
/*      */ import org.bukkit.WorldBorder;
/*      */ import org.bukkit.attribute.Attribute;
/*      */ import org.bukkit.attribute.AttributeInstance;
/*      */ import org.bukkit.attribute.AttributeModifier;
/*      */ import org.bukkit.block.Block;
/*      */ import org.bukkit.block.Conduit;
/*      */ import org.bukkit.configuration.file.FileConfiguration;
/*      */ import org.bukkit.craftbukkit.v1_20_R3.CraftWorld;
/*      */ import org.bukkit.craftbukkit.v1_20_R3.entity.CraftEntity;
/*      */ import org.bukkit.craftbukkit.v1_20_R3.entity.CraftLivingEntity;
/*      */ import org.bukkit.craftbukkit.v1_20_R3.entity.CraftPlayer;
/*      */ import org.bukkit.craftbukkit.v1_20_R3.inventory.CraftItemStack;
/*      */ import org.bukkit.damage.DamageSource;
/*      */ import org.bukkit.damage.DamageType;
/*      */ import org.bukkit.enchantments.Enchantment;
/*      */ import org.bukkit.entity.Allay;
/*      */ import org.bukkit.entity.Arrow;
/*      */ import org.bukkit.entity.Entity;
/*      */ import org.bukkit.entity.LivingEntity;
/*      */ import org.bukkit.entity.Piglin;
/*      */ import org.bukkit.entity.Player;
/*      */ import org.bukkit.event.EventHandler;
/*      */ import org.bukkit.event.block.BlockDamageAbortEvent;
/*      */ import org.bukkit.event.entity.EntityDamageEvent;
/*      */ import org.bukkit.event.entity.EntityDismountEvent;
/*      */ import org.bukkit.event.entity.EntityMountEvent;
/*      */ import org.bukkit.inventory.EquipmentSlot;
/*      */ import org.bukkit.inventory.ItemStack;
/*      */ import org.bukkit.inventory.meta.ItemMeta;
/*      */ import org.bukkit.inventory.meta.PotionMeta;
/*      */ import org.bukkit.potion.PotionEffect;
/*      */ import org.bukkit.potion.PotionEffectType;
/*      */ import org.jetbrains.annotations.NotNull;
/*      */ import org.jetbrains.annotations.Nullable;
/*      */ 
/*      */ public class MVE_V1_20_4 extends MultiVersionExecutor {
/*      */   public boolean supportsInfiniteDuration() {
/*   72 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTouchingWater(Player player) {
/*   77 */     (((CraftPlayer)player).getHandle()).ai = true;
/*      */   }
/*      */   
/*   80 */   private final ItemStack boneMeal = CraftItemStack.asNMSCopy(new ItemStack(Material.BONE_MEAL));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean boneMeal(Block block, Player player) {
/*   87 */     BlockPosition blockPos = new BlockPosition(block.getX(), block.getY(), block.getZ());
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   92 */     MovingObjectPositionBlock bhr = new MovingObjectPositionBlock(Vec3D.b((BaseBlockPosition)blockPos), ((CraftPlayer)player).getHandle().cE(), blockPos, false);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   97 */     EnumInteractionResult result = ItemBoneMeal.applyBonemeal(new ItemActionContext((World)((CraftWorld)player
/*   98 */           .getWorld()).getHandle(), (EntityHuman)((CraftPlayer)player)
/*   99 */           .getHandle(), EnumHand.a, this.boneMeal, bhr));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  104 */     return (result == EnumInteractionResult.a);
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute miningEfficiencyAttribute() {
/*  109 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute sneakingSpeedAttribute() {
/*  114 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute submergedMiningSpeedAttribute() {
/*  119 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute sweepingDamageRatioAttribute() {
/*  124 */     return null;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public ItemMeta setCustomModelData(ItemMeta meta, int cmd) {
/*  129 */     meta.setCustomModelData(Integer.valueOf(cmd));
/*  130 */     return meta;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getConduitRange(Conduit conduit) {
/*  135 */     if (!conduit.isActive()) return 0; 
/*  136 */     return conduit.getRange();
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute flyingSpeedAttribute() {
/*  141 */     return Attribute.GENERIC_FLYING_SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute attackKnockbackAttribute() {
/*  146 */     return Attribute.GENERIC_ATTACK_KNOCKBACK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute attackSpeedAttribute() {
/*  151 */     return Attribute.GENERIC_ATTACK_SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute armorToughnessAttribute() {
/*  156 */     return Attribute.GENERIC_ARMOR_TOUGHNESS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute luckAttribute() {
/*  161 */     return Attribute.GENERIC_LUCK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute horseJumpStrengthAttribute() {
/*  166 */     return Attribute.HORSE_JUMP_STRENGTH;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute spawnReinforcementsAttribute() {
/*  171 */     return Attribute.ZOMBIE_SPAWN_REINFORCEMENTS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute followRangeAttribute() {
/*  176 */     return Attribute.GENERIC_FOLLOW_RANGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute knockbackResistanceAttribute() {
/*  181 */     return Attribute.GENERIC_KNOCKBACK_RESISTANCE;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute fallDamageMultiplierAttribute() {
/*  186 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute maxAbsorptionAttribute() {
/*  191 */     return Attribute.GENERIC_MAX_ABSORPTION;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute safeFallDistanceAttribute() {
/*  196 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute scaleAttribute() {
/*  201 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute stepHeightAttribute() {
/*  206 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute gravityAttribute() {
/*  211 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute jumpStrengthAttribute() {
/*  216 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute burningTimeAttribute() {
/*  221 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute explosionKnockbackResistanceAttribute() {
/*  226 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute movementEfficiencyAttribute() {
/*  231 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute oxygenBonusAttribute() {
/*  236 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute waterMovementEfficiencyAttribute() {
/*  241 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute temptRangeAttribute() {
/*  246 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void dealDrowningDamage(LivingEntity entity, int amount) {
/*  252 */     entity.damage(amount, DamageSource.builder(DamageType.DROWN).build());
/*      */   }
/*      */ 
/*      */   
/*      */   public Component applyFont(Component component, Key font) {
/*  257 */     return component.font(font);
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Material getOminousBottle() {
/*  262 */     return null;
/*      */   }
/*      */   
/*      */   @EventHandler
/*      */   public void onBlockDamageAbort(BlockDamageAbortEvent event) {
/*  267 */     (new MVBlockDamageAbortEvent(event.getPlayer(), event.getBlock(), event.getItemInHand())).callEvent();
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute armorAttribute() {
/*  272 */     return Attribute.GENERIC_ARMOR;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute maxHealthAttribute() {
/*  277 */     return Attribute.GENERIC_MAX_HEALTH;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute movementSpeedAttribute() {
/*  282 */     return Attribute.GENERIC_MOVEMENT_SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute attackDamageAttribute() {
/*  287 */     return Attribute.GENERIC_ATTACK_DAMAGE;
/*      */   }
/*      */ 
/*      */   
/*      */   public void sendEntityData(Player player, Entity entity, byte bytes) {
/*  292 */     EntityPlayer serverPlayer = ((CraftPlayer)player).getHandle();
/*  293 */     Entity target = ((CraftEntity)entity).getHandle();
/*      */     
/*  295 */     List<DataWatcher.b<?>> eData = new ArrayList<>();
/*  296 */     eData.add(DataWatcher.b.a(new DataWatcherObject(0, DataWatcherRegistry.a), Byte.valueOf(bytes)));
/*  297 */     PacketPlayOutEntityMetadata metadata = new PacketPlayOutEntityMetadata(target.aj(), eData);
/*  298 */     serverPlayer.c.b((Packet)metadata);
/*      */   }
/*      */ 
/*      */   
/*      */   public Goal<Creeper> getCreeperAfraidGoal(LivingEntity creeper, BiPredicate<LivingEntity, Player> hasAbility) {
/*  303 */     return (new PathfinderGoalAvoidTarget((EntityCreature)((CraftEntity)creeper)
/*  304 */         .getHandle(), EntityHuman.class, 6.0F, 1.0D, 1.2D, livingEntity -> {
/*      */           CraftEntity patt9539$temp = livingEntity.getBukkitEntity();
/*      */ 
/*      */           
/*      */           if (patt9539$temp instanceof Player) {
/*      */             Player player = (Player)patt9539$temp;
/*      */ 
/*      */             
/*      */             return hasAbility.test(creeper, player);
/*      */           } 
/*      */           
/*      */           return false;
/*  316 */         })).asPaperVanillaGoal();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean wasTouchingWater(Player player) {
/*  321 */     return (((CraftPlayer)player).getHandle()).ai;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public float getDestroySpeed(Material block) {
/*  327 */     return (((CraftBlockState)block.createBlockData().createBlockState()).getHandle()).n;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public float getDestroySpeed(ItemStack item, Material block) {
/*  333 */     IBlockData b = ((CraftBlockState)block.createBlockData().createBlockState()).getHandle();
/*  334 */     ItemStack handle = CraftItemStack.asNMSCopy(item);
/*  335 */     return handle.a(b);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setNoPhysics(Player player, boolean noPhysics) {
/*  340 */     (((CraftPlayer)player).getHandle()).af = noPhysics;
/*      */   }
/*      */ 
/*      */   
/*      */   public void sendGamemodeUpdate(Player player, GameMode gameMode, boolean bedrock) {
/*  345 */     EntityPlayer serverPlayer = ((CraftPlayer)player).getHandle();
/*  346 */     switch (gameMode) { default: throw new IncompatibleClassChangeError();
/*      */       case CREATIVE: 
/*      */       case SURVIVAL: 
/*      */       case ADVENTURE: 
/*  350 */       case SPECTATOR: break; }  EnumGamemode gameType = EnumGamemode.d;
/*      */     
/*  352 */     ClientboundPlayerInfoUpdatePacket.b entry = new ClientboundPlayerInfoUpdatePacket.b(serverPlayer.cw(), serverPlayer.fR(), true, 1, gameType, serverPlayer.N(), (RemoteChatSession.a)Optionull.a(serverPlayer.ab(), RemoteChatSession::a));
/*  353 */     ClientboundPlayerInfoUpdatePacket packet = new ClientboundPlayerInfoUpdatePacket(EnumSet.of(ClientboundPlayerInfoUpdatePacket.a.c), entry);
/*  354 */     serverPlayer.c.b((Packet)packet);
/*      */     
/*  356 */     if (bedrock) {
/*  357 */       PacketPlayOutGameStateChange eventPacket = new PacketPlayOutGameStateChange(PacketPlayOutGameStateChange.d, gameType.a());
/*  358 */       serverPlayer.c.b((Packet)eventPacket);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void sendResourcePacks(Player player, String pack, Map<?, ResourcePackInfo> extraPacks) {
/*      */     try {
/*  367 */       ResourcePackInfo packInfo = ResourcePackInfo.resourcePackInfo().uri(URI.create(pack)).computeHashAndBuild().get();
/*  368 */       List<ResourcePackInfo> packs = new ArrayList<>();
/*  369 */       packs.add(packInfo);
/*  370 */       for (ResourcePackInfo resourcePackInfo : extraPacks.values()) {
/*  371 */         Object object = resourcePackInfo.packInfo(); if (object instanceof ResourcePackInfo) { ResourcePackInfo info = (ResourcePackInfo)object;
/*  372 */           packs.add(info); }
/*      */       
/*      */       } 
/*  375 */       player.sendResourcePacks((ResourcePackRequest)ResourcePackRequest.resourcePackRequest()
/*  376 */           .packs(packs)
/*  377 */           .required(true)
/*  378 */           .build());
/*      */     }
/*  380 */     catch (InterruptedException|java.util.concurrent.ExecutionException e) {
/*  381 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Location getRespawnLocation(Player player) {
/*  387 */     return player.getRespawnLocation();
/*      */   }
/*      */ 
/*      */   
/*      */   public void resetRespawnLocation(Player player) {
/*  392 */     player.setRespawnLocation(null);
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public AttributeModifier getAttributeModifier(AttributeInstance instance, Key key) {
/*  397 */     UUID u = UUID.nameUUIDFromBytes(key.toString().getBytes());
/*  398 */     return instance.getModifier(u);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addAttributeModifier(AttributeInstance instance, NamespacedKey key, String name, double amount, AttributeModifier.Operation operation) {
/*  403 */     instance.addModifier(new AttributeModifier(UUID.nameUUIDFromBytes(key.toString().getBytes()), name, amount, operation));
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isUnderWater(LivingEntity entity) {
/*  408 */     return entity.isUnderWater();
/*      */   }
/*      */ 
/*      */   
/*      */   public void knockback(LivingEntity entity, double strength, double x, double z) {
/*  413 */     entity.knockback(strength, x, z);
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealDryOutDamage(LivingEntity entity, int amount) {
/*  418 */     EntityLiving livingEntity = ((CraftLivingEntity)entity).getHandle();
/*  419 */     livingEntity.a(livingEntity.dN().r(), amount);
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealFreezeDamage(LivingEntity entity, int amount) {
/*  424 */     EntityLiving livingEntity = ((CraftLivingEntity)entity).getHandle();
/*  425 */     livingEntity.a(livingEntity.dN().t(), amount);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setFlyingFallDamage(Player player, TriState state) {
/*  430 */     player.setFlyingFallDamage(state);
/*      */   }
/*      */ 
/*      */   
/*      */   public void broadcastSlotBreak(Player player, EquipmentSlot slot, Collection<Player> players) {
/*  435 */     player.broadcastSlotBreak(slot, players);
/*      */   }
/*      */ 
/*      */   
/*      */   public void sendBlockDamage(Player player, Location location, float damage, Entity entity) {
/*  440 */     player.sendBlockDamage(location, damage, entity);
/*      */   }
/*      */ 
/*      */   
/*      */   public Attribute blockInteractionRangeAttribute() {
/*  445 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Attribute entityInteractionRangeAttribute() {
/*  450 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Attribute blockBreakSpeedAttribute() {
/*  455 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setWorldBorderOverlay(Player player, boolean show) {
/*  460 */     if (show)
/*  461 */     { WorldBorder border = Bukkit.createWorldBorder();
/*  462 */       border.setCenter(player.getWorld().getWorldBorder().getCenter());
/*  463 */       border.setSize(player.getWorld().getWorldBorder().getSize());
/*  464 */       border.setWarningDistance((int)(player.getWorld().getWorldBorder().getSize() * 2.0D));
/*  465 */       player.setWorldBorder(border); }
/*  466 */     else { player.setWorldBorder(null); }
/*      */   
/*      */   }
/*      */   
/*      */   public void setComments(FileConfiguration config, String path, List<String> comments) {
/*  471 */     config.setComments(path, comments);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void dealExplosionDamage(Player player, int amount) {
/*  477 */     player.damage(amount, DamageSource.builder(DamageType.EXPLOSION).build());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void dealSonicBoomDamage(LivingEntity entity, int amount, Player source) {
/*  483 */     entity.damage(amount, DamageSource.builder(DamageType.SONIC_BOOM).build());
/*      */   }
/*      */ 
/*      */   
/*      */   public Goal<Villager> getVillagerAfraidGoal(LivingEntity villager, Predicate<Player> hasAbility) {
/*  488 */     return (new PathfinderGoalAvoidTarget((EntityCreature)((CraftEntity)villager)
/*  489 */         .getHandle(), EntityHuman.class, 6.0F, 0.5D, 0.8D, livingEntity -> {
/*      */           CraftEntity patt16780$temp = livingEntity.getBukkitEntity();
/*      */ 
/*      */           
/*      */           if (patt16780$temp instanceof Player) {
/*      */             Player player = (Player)patt16780$temp;
/*      */             
/*      */             return hasAbility.test(player);
/*      */           } 
/*      */           
/*      */           return false;
/*  500 */         })).asPaperVanillaGoal();
/*      */   }
/*      */ 
/*      */   
/*      */   public void throwItem(Piglin piglin, ItemStack itemStack, Location pos) {
/*  505 */     BehaviorUtil.a(((CraftLivingEntity)piglin).getHandle(), CraftItemStack.asNMSCopy(itemStack), new Vec3D(pos.getX(), pos.getY(), pos.getZ()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void launchArrow(Entity projectile, Entity entity, float roll, float force, float divergence) {
/*  510 */     ((AbstractProjectile)projectile).getHandle().a(((CraftEntity)entity).getHandle(), entity.getPitch(), entity.getYaw(), roll, force, divergence);
/*      */   }
/*      */ 
/*      */   
/*      */   public void damageItem(ItemStack item, int amount, Player player) {
/*  515 */     item.damage(amount, (LivingEntity)player);
/*      */   }
/*      */ 
/*      */   
/*      */   public void startAutoSpinAttack(Player player, int duration, float riptideAttackDamage, ItemStack item) {
/*  520 */     ((CraftPlayer)player).getHandle().t(duration);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tridentMove(Player player) {
/*  525 */     ((CraftPlayer)player).getHandle().a(EnumMoveType.a, new Vec3D(0.0D, 1.1999999284744263D, 0.0D));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void transferDamageEvent(LivingEntity entity, EntityDamageEvent event) {
/*  531 */     entity.damage(event.getDamage(), event.getDamageSource());
/*      */   }
/*      */ 
/*      */   
/*      */   public void boostArrow(Arrow arrow) {
/*  536 */     for (PotionEffect effect : arrow.getBasePotionType().getPotionEffects()) {
/*  537 */       arrow.addCustomEffect(effect.withDuration(effect.getDuration()).withAmplifier(effect.getAmplifier() + 1), true);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean duplicateAllay(LivingEntity entity) {
/*      */     Allay allay;
/*  543 */     if (entity instanceof Allay) { allay = (Allay)entity; } else { return false; }
/*  544 */      if (allay.getDuplicationCooldown() > 0L) return false; 
/*  545 */     allay.duplicateAllay();
/*  546 */     ((CraftWorld)allay.getWorld()).getHandle().a((Entity)((CraftAllay)allay).getHandle(), (byte)18);
/*  547 */     return true;
/*      */   }
/*      */   
/*      */   @EventHandler
/*      */   public void onEntityDismount(EntityDismountEvent event) {
/*  552 */     event.setCancelled(!(new MVEntityDismountEvent(event.getEntity(), event.getDismounted(), event.isCancellable())).callEvent());
/*      */   }
/*      */   
/*      */   @EventHandler
/*      */   public void onEntityMount(EntityMountEvent event) {
/*  557 */     event.setCancelled(!(new MVEntityMountEvent(event.getEntity(), event.getMount())).callEvent());
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType speedEffect() {
/*  562 */     return PotionEffectType.SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType slownessEffect() {
/*  567 */     return PotionEffectType.SLOW;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType hasteEffect() {
/*  572 */     return PotionEffectType.FAST_DIGGING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType miningFatigueEffect() {
/*  577 */     return PotionEffectType.SLOW_DIGGING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType strengthEffect() {
/*  582 */     return PotionEffectType.INCREASE_DAMAGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType instantHealthEffect() {
/*  587 */     return PotionEffectType.HEAL;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType instantDamageEffect() {
/*  592 */     return PotionEffectType.HARM;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType jumpBoostEffect() {
/*  597 */     return PotionEffectType.JUMP;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType nauseaEffect() {
/*  602 */     return PotionEffectType.CONFUSION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType regenerationEffect() {
/*  607 */     return PotionEffectType.REGENERATION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType resistanceEffect() {
/*  612 */     return PotionEffectType.DAMAGE_RESISTANCE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType fireResistanceEffect() {
/*  617 */     return PotionEffectType.FIRE_RESISTANCE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType waterBreathingEffect() {
/*  622 */     return PotionEffectType.WATER_BREATHING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType invisibilityEffect() {
/*  627 */     return PotionEffectType.INVISIBILITY;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType blindnessEffect() {
/*  632 */     return PotionEffectType.BLINDNESS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType nightVisionEffect() {
/*  637 */     return PotionEffectType.NIGHT_VISION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType hungerEffect() {
/*  642 */     return PotionEffectType.HUNGER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType weaknessEffect() {
/*  647 */     return PotionEffectType.WEAKNESS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType poisonEffect() {
/*  652 */     return PotionEffectType.POISON;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType witherEffect() {
/*  657 */     return PotionEffectType.WITHER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType healthBoostEffect() {
/*  662 */     return PotionEffectType.HEALTH_BOOST;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType absorptionEffect() {
/*  667 */     return PotionEffectType.ABSORPTION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType saturationEffect() {
/*  672 */     return PotionEffectType.SATURATION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType glowingEffect() {
/*  677 */     return PotionEffectType.GLOWING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType levitationEffect() {
/*  682 */     return PotionEffectType.LEVITATION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType luckEffect() {
/*  687 */     return PotionEffectType.LUCK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType badLuckEffect() {
/*  692 */     return PotionEffectType.UNLUCK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType slowFallingEffect() {
/*  697 */     return PotionEffectType.SLOW_FALLING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType conduitPowerEffect() {
/*  702 */     return PotionEffectType.CONDUIT_POWER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType dolphinsGraceEffect() {
/*  707 */     return PotionEffectType.DOLPHINS_GRACE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType badOmenEffect() {
/*  712 */     return PotionEffectType.BAD_OMEN;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType heroOfTheVillageEffect() {
/*  717 */     return PotionEffectType.HERO_OF_THE_VILLAGE;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType darknessEffect() {
/*  722 */     return PotionEffectType.DARKNESS;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType trialOmenEffect() {
/*  727 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType raidOmenEffect() {
/*  732 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType windChargedEffect() {
/*  737 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType weavingEffect() {
/*  742 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType oozingEffect() {
/*  747 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType infestedEffect() {
/*  752 */     return null;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment protectionEnchantment() {
/*  757 */     return Enchantment.PROTECTION_ENVIRONMENTAL;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment fireProtectionEnchantment() {
/*  762 */     return Enchantment.PROTECTION_FIRE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment featherFallingEnchantment() {
/*  767 */     return Enchantment.PROTECTION_FALL;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment blastProtectionEnchantment() {
/*  772 */     return Enchantment.PROTECTION_EXPLOSIONS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment projectileProtectionEnchantment() {
/*  777 */     return Enchantment.PROTECTION_PROJECTILE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment respirationEnchantment() {
/*  782 */     return Enchantment.OXYGEN;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment aquaAffinityEnchantment() {
/*  787 */     return Enchantment.WATER_WORKER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment thornsEnchantment() {
/*  792 */     return Enchantment.THORNS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment depthStriderEnchantment() {
/*  797 */     return Enchantment.DEPTH_STRIDER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment frostWalkerEnchantment() {
/*  802 */     return Enchantment.FROST_WALKER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment bindingCurseEnchantment() {
/*  807 */     return Enchantment.BINDING_CURSE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment sharpnessEnchantment() {
/*  812 */     return Enchantment.DAMAGE_ALL;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment smiteEnchantment() {
/*  817 */     return Enchantment.DAMAGE_UNDEAD;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment baneOfArthropodsEnchantment() {
/*  822 */     return Enchantment.DAMAGE_ARTHROPODS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment knockbackEnchantment() {
/*  827 */     return Enchantment.KNOCKBACK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment fireAspectEnchantment() {
/*  832 */     return Enchantment.FIRE_ASPECT;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment lootingEnchantment() {
/*  837 */     return Enchantment.LOOT_BONUS_MOBS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment sweepingEdgeEnchantment() {
/*  842 */     return Enchantment.SWEEPING_EDGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment efficiencyEnchantment() {
/*  847 */     return Enchantment.DIG_SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment silkTouchEnchantment() {
/*  852 */     return Enchantment.SILK_TOUCH;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment unbreakingEnchantment() {
/*  857 */     return Enchantment.DURABILITY;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment fortuneEnchantment() {
/*  862 */     return Enchantment.LOOT_BONUS_BLOCKS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment powerEnchantment() {
/*  867 */     return Enchantment.ARROW_DAMAGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment punchEnchantment() {
/*  872 */     return Enchantment.ARROW_KNOCKBACK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment flameEnchantment() {
/*  877 */     return Enchantment.ARROW_FIRE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment infinityEnchantment() {
/*  882 */     return Enchantment.ARROW_INFINITE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment luckOfTheSeaEnchantment() {
/*  887 */     return Enchantment.LUCK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment lureEnchantment() {
/*  892 */     return Enchantment.LURE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment loyaltyEnchantment() {
/*  897 */     return Enchantment.LOYALTY;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment impalingEnchantment() {
/*  902 */     return Enchantment.IMPALING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment riptideEnchantment() {
/*  907 */     return Enchantment.RIPTIDE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment channelingEnchantment() {
/*  912 */     return Enchantment.CHANNELING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment multishotEnchantment() {
/*  917 */     return Enchantment.MULTISHOT;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment quickChargeEnchantment() {
/*  922 */     return Enchantment.QUICK_CHARGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment piercingEnchantment() {
/*  927 */     return Enchantment.PIERCING;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected Enchantment densityEnchantment() {
/*  932 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected Enchantment breachEnchantment() {
/*  937 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected Enchantment windBurstEnchantment() {
/*  942 */     return null;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment mendingEnchantment() {
/*  947 */     return Enchantment.MENDING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment vanishingCurseEnchantment() {
/*  952 */     return Enchantment.VANISHING_CURSE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment soulSpeedEnchantment() {
/*  957 */     return Enchantment.SOUL_SPEED;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected Enchantment swiftSneakEnchantment() {
/*  962 */     return Enchantment.SWIFT_SNEAK;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Player getNearestVisiblePlayer(Piglin piglin) {
/*  967 */     Optional<EntityHuman> optional = ((CraftPiglin)piglin).getHandle().dO().c(MemoryModuleType.k);
/*  968 */     return optional.<Player>map(player -> (Player)player.getBukkitEntity()).orElse(null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealThornsDamage(Entity target, int amount, Entity attacker) {
/*  973 */     Entity entity = ((CraftEntity)target).getHandle();
/*  974 */     entity.a(entity.dN().d(((CraftEntity)attacker).getHandle()), amount);
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Particle getElderGuardianParticle() {
/*  979 */     return Particle.MOB_APPEARANCE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Particle getWitchParticle() {
/*  984 */     return Particle.SPELL_WITCH;
/*      */   }
/*      */ 
/*      */   
/*      */   public Goal<Mob> getIronGolemAttackGoal(LivingEntity golem, Predicate<Player> hasAbility) {
/*  989 */     return (new PathfinderGoalNearestAttackableTarget(((CraftMob)golem)
/*  990 */         .getHandle(), EntityHuman.class, 10, true, false, livingEntity -> {
/*      */           CraftEntity patt30426$temp = livingEntity.getBukkitEntity();
/*      */           
/*      */           if (patt30426$temp instanceof Player) {
/*      */             Player player = (Player)patt30426$temp;
/*      */             
/*      */             return hasAbility.test(player);
/*      */           } 
/*      */           return false;
/*  999 */         })).asPaperVanillaGoal();
/*      */   }
/*      */   
/* 1002 */   private final Map<Player, Vec3D> lastVec3Map = new HashMap<>();
/*      */ 
/*      */ 
/*      */   
/*      */   public void bounce(Player player) {
/* 1007 */     EntityPlayer p = ((CraftPlayer)player).getHandle();
/* 1008 */     if (player.isOnGround()) {
/* 1009 */       if (player.getFallDistance() <= 0.0F)
/* 1010 */         return;  Vec3D dm = this.lastVec3Map.get(player);
/* 1011 */       if (dm != null) {
/* 1012 */         player.setVelocity(player.getVelocity().add(new Vector(0.0D, -dm.d, 0.0D)));
/*      */       }
/*      */     } 
/* 1015 */     this.lastVec3Map.put(player, p.dp());
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Particle getHappyVillagerParticle() {
/* 1020 */     return Particle.VILLAGER_HAPPY;
/*      */   }
/*      */ 
/*      */   
/*      */   public void playTotemEffect(Player player) {
/* 1025 */     ((CraftWorld)player.getWorld()).getHandle().a((Entity)((CraftPlayer)player).getHandle(), (byte)35);
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public List<PotionEffect> getDefaultEffects(PotionMeta meta, boolean isLingering) {
/* 1030 */     PotionType type = meta.getBasePotionType();
/* 1031 */     return type.getPotionEffects();
/*      */   }
/*      */ 
/*      */   
/*      */   public void dropItem(Player player, ItemStack it) {
/* 1036 */     ((CraftPlayer)player).getHandle().a(CraftItemStack.asNMSCopy(it), true);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setArrow(Arrow arrow, ItemStack itemStack) {
/* 1041 */     (((CraftArrow)arrow).getHandle()).s = CraftItemStack.asNMSCopy(itemStack);
/*      */   }
/*      */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\version\MVE_V1_20_4.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */