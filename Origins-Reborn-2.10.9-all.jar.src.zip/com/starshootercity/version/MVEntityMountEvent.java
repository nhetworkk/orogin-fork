/*    */ package com.starshootercity.version;
/*    */ 
/*    */ import com.starshootercity.APITarget;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.event.Cancellable;
/*    */ import org.bukkit.event.HandlerList;
/*    */ import org.bukkit.event.entity.EntityEvent;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ @APITarget
/*    */ public class MVEntityMountEvent
/*    */   extends EntityEvent
/*    */   implements Cancellable
/*    */ {
/* 16 */   private static final HandlerList handlers = new HandlerList();
/*    */   private boolean cancelled;
/*    */   private final Entity mount;
/*    */   
/*    */   public MVEntityMountEvent(@NotNull Entity what, @NotNull Entity mount) {
/* 21 */     super(what);
/* 22 */     this.mount = mount;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Entity getMount() {
/* 27 */     return this.mount;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isCancelled() {
/* 32 */     return this.cancelled;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setCancelled(boolean cancel) {
/* 37 */     this.cancelled = cancel;
/*    */   }
/*    */ 
/*    */   
/*    */   @NotNull
/*    */   public HandlerList getHandlers() {
/* 43 */     return handlers;
/*    */   }
/*    */ 
/*    */   
/*    */   @NotNull
/*    */   public static HandlerList getHandlerList() {
/* 49 */     return handlers;
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\version\MVEntityMountEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */