/*     */ package com.starshootercity.version;
/*     */ 
/*     */ import org.bukkit.GameMode;
/*     */ 


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\version\MVE_V1_21$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */