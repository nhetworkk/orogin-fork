/*      */ package com.starshootercity.version;
/*      */ import com.destroystokyo.paper.entity.ai.Goal;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Optional;
/*      */ import java.util.function.BiPredicate;
/*      */ import java.util.function.Predicate;
/*      */ import net.kyori.adventure.key.Key;
/*      */ import net.kyori.adventure.resource.ResourcePackInfo;
/*      */ import net.kyori.adventure.resource.ResourcePackRequest;
/*      */ import net.kyori.adventure.text.Component;
/*      */ import net.minecraft.core.BlockPosition;
/*      */ import net.minecraft.network.protocol.Packet;
/*      */ import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket;
/*      */ import net.minecraft.network.protocol.game.PacketPlayOutEntityMetadata;
/*      */ import net.minecraft.network.protocol.game.PacketPlayOutGameStateChange;
/*      */ import net.minecraft.network.syncher.DataWatcher;
/*      */ import net.minecraft.server.level.EntityPlayer;
/*      */ import net.minecraft.server.level.WorldServer;
/*      */ import net.minecraft.world.EnumInteractionResult;
/*      */ import net.minecraft.world.entity.Entity;
/*      */ import net.minecraft.world.entity.EntityLiving;
/*      */ import net.minecraft.world.entity.ai.goal.PathfinderGoalAvoidTarget;
/*      */ import net.minecraft.world.entity.player.EntityHuman;
/*      */ import net.minecraft.world.item.ItemStack;
/*      */ import net.minecraft.world.level.EnumGamemode;
/*      */ import net.minecraft.world.phys.MovingObjectPositionBlock;
/*      */ import net.minecraft.world.phys.Vec3D;
/*      */ import org.bukkit.GameMode;
/*      */ import org.bukkit.Location;
/*      */ import org.bukkit.Material;
/*      */ import org.bukkit.NamespacedKey;
/*      */ import org.bukkit.Particle;
/*      */ import org.bukkit.WorldBorder;
/*      */ import org.bukkit.attribute.Attribute;
/*      */ import org.bukkit.attribute.AttributeInstance;
/*      */ import org.bukkit.attribute.AttributeModifier;
/*      */ import org.bukkit.block.Block;
/*      */ import org.bukkit.block.Conduit;
/*      */ import org.bukkit.configuration.file.FileConfiguration;
/*      */ import org.bukkit.craftbukkit.v1_21_R2.CraftWorld;
/*      */ import org.bukkit.craftbukkit.v1_21_R2.block.CraftBlockState;
/*      */ import org.bukkit.craftbukkit.v1_21_R2.entity.CraftEntity;
/*      */ import org.bukkit.craftbukkit.v1_21_R2.entity.CraftPlayer;
/*      */ import org.bukkit.craftbukkit.v1_21_R2.inventory.CraftItemStack;
/*      */ import org.bukkit.damage.DamageSource;
/*      */ import org.bukkit.damage.DamageType;
/*      */ import org.bukkit.enchantments.Enchantment;
/*      */ import org.bukkit.entity.Allay;
/*      */ import org.bukkit.entity.Arrow;
/*      */ import org.bukkit.entity.Entity;
/*      */ import org.bukkit.entity.LivingEntity;
/*      */ import org.bukkit.entity.Piglin;
/*      */ import org.bukkit.entity.Player;
/*      */ import org.bukkit.event.EventHandler;
/*      */ import org.bukkit.event.block.BlockDamageAbortEvent;
/*      */ import org.bukkit.event.entity.EntityDamageEvent;
/*      */ import org.bukkit.event.entity.EntityDismountEvent;
/*      */ import org.bukkit.event.entity.EntityMountEvent;
/*      */ import org.bukkit.inventory.EquipmentSlot;
/*      */ import org.bukkit.inventory.ItemStack;
/*      */ import org.bukkit.inventory.meta.ItemMeta;
/*      */ import org.bukkit.inventory.meta.PotionMeta;
/*      */ import org.bukkit.potion.PotionEffect;
/*      */ import org.bukkit.potion.PotionEffectType;
/*      */ import org.bukkit.potion.PotionType;
/*      */ import org.jetbrains.annotations.NotNull;
/*      */ import org.jetbrains.annotations.Nullable;
/*      */ 
/*      */ public class MVE_V1_21_3 extends MultiVersionExecutor {
/*      */   public void setTouchingWater(Player player) {
/*   74 */     (((CraftPlayer)player).getHandle()).ag = true;
/*      */   }
/*      */   
/*   77 */   private final ItemStack boneMeal = CraftItemStack.asNMSCopy(ItemStack.of(Material.BONE_MEAL));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean boneMeal(Block block, Player player) {
/*   84 */     BlockPosition blockPos = new BlockPosition(block.getX(), block.getY(), block.getZ());
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   89 */     MovingObjectPositionBlock bhr = new MovingObjectPositionBlock(Vec3D.b((BaseBlockPosition)blockPos), ((CraftPlayer)player).getHandle().cO(), blockPos, false);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   94 */     EnumInteractionResult result = ItemBoneMeal.applyBonemeal(new ItemActionContext((World)((CraftWorld)player
/*   95 */           .getWorld()).getHandle(), (EntityHuman)((CraftPlayer)player)
/*   96 */           .getHandle(), EnumHand.a, this.boneMeal, bhr));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  101 */     return (result == EnumInteractionResult.a);
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType speedEffect() {
/*  106 */     return PotionEffectType.SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType slownessEffect() {
/*  111 */     return PotionEffectType.SLOWNESS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType hasteEffect() {
/*  116 */     return PotionEffectType.HASTE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType miningFatigueEffect() {
/*  121 */     return PotionEffectType.MINING_FATIGUE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType strengthEffect() {
/*  126 */     return PotionEffectType.STRENGTH;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType instantHealthEffect() {
/*  131 */     return PotionEffectType.INSTANT_HEALTH;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType instantDamageEffect() {
/*  136 */     return PotionEffectType.INSTANT_DAMAGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType jumpBoostEffect() {
/*  141 */     return PotionEffectType.JUMP_BOOST;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType nauseaEffect() {
/*  146 */     return PotionEffectType.NAUSEA;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType regenerationEffect() {
/*  151 */     return PotionEffectType.REGENERATION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType resistanceEffect() {
/*  156 */     return PotionEffectType.RESISTANCE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType fireResistanceEffect() {
/*  161 */     return PotionEffectType.FIRE_RESISTANCE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType waterBreathingEffect() {
/*  166 */     return PotionEffectType.WATER_BREATHING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType invisibilityEffect() {
/*  171 */     return PotionEffectType.INVISIBILITY;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType blindnessEffect() {
/*  176 */     return PotionEffectType.BLINDNESS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType nightVisionEffect() {
/*  181 */     return PotionEffectType.NIGHT_VISION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType hungerEffect() {
/*  186 */     return PotionEffectType.HUNGER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType weaknessEffect() {
/*  191 */     return PotionEffectType.WEAKNESS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType poisonEffect() {
/*  196 */     return PotionEffectType.POISON;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType witherEffect() {
/*  201 */     return PotionEffectType.WITHER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType healthBoostEffect() {
/*  206 */     return PotionEffectType.HEALTH_BOOST;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType absorptionEffect() {
/*  211 */     return PotionEffectType.ABSORPTION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType saturationEffect() {
/*  216 */     return PotionEffectType.SATURATION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType glowingEffect() {
/*  221 */     return PotionEffectType.GLOWING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType levitationEffect() {
/*  226 */     return PotionEffectType.LEVITATION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType luckEffect() {
/*  231 */     return PotionEffectType.LUCK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType badLuckEffect() {
/*  236 */     return PotionEffectType.UNLUCK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType slowFallingEffect() {
/*  241 */     return PotionEffectType.SLOW_FALLING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType conduitPowerEffect() {
/*  246 */     return PotionEffectType.CONDUIT_POWER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType dolphinsGraceEffect() {
/*  251 */     return PotionEffectType.DOLPHINS_GRACE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType badOmenEffect() {
/*  256 */     return PotionEffectType.BAD_OMEN;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType heroOfTheVillageEffect() {
/*  261 */     return PotionEffectType.HERO_OF_THE_VILLAGE;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType darknessEffect() {
/*  266 */     return PotionEffectType.DARKNESS;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType trialOmenEffect() {
/*  271 */     return PotionEffectType.TRIAL_OMEN;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType raidOmenEffect() {
/*  276 */     return PotionEffectType.RAID_OMEN;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType windChargedEffect() {
/*  281 */     return PotionEffectType.WIND_CHARGED;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType weavingEffect() {
/*  286 */     return PotionEffectType.WEAVING;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType oozingEffect() {
/*  291 */     return PotionEffectType.OOZING;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType infestedEffect() {
/*  296 */     return PotionEffectType.INFESTED;
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealThornsDamage(Entity target, int amount, Entity attacker) {
/*  301 */     Entity entity = ((CraftEntity)target).getHandle();
/*  302 */     entity.a((WorldServer)entity.dW(), entity.dX().d(((CraftEntity)attacker).getHandle()), amount);
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Particle getElderGuardianParticle() {
/*  307 */     return Particle.ELDER_GUARDIAN;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Particle getWitchParticle() {
/*  312 */     return Particle.WITCH;
/*      */   }
/*      */ 
/*      */   
/*      */   public Goal<Mob> getIronGolemAttackGoal(LivingEntity golem, Predicate<Player> hasAbility) {
/*  317 */     return (new PathfinderGoalNearestAttackableTarget(((CraftMob)golem)
/*  318 */         .getHandle(), EntityHuman.class, 10, true, false, (livingEntity, serverLevel) -> {
/*      */           CraftEntity patt0$temp = livingEntity.getBukkitEntity();
/*      */           
/*      */           if (patt0$temp instanceof Player) {
/*      */             Player player = (Player)patt0$temp;
/*      */             
/*      */             return hasAbility.test(player);
/*      */           } 
/*      */           return false;
/*  327 */         })).asPaperVanillaGoal();
/*      */   }
/*      */   
/*  330 */   private final Map<Player, Vec3D> lastVec3Map = new HashMap<>();
/*      */ 
/*      */ 
/*      */   
/*      */   public void bounce(Player player) {
/*  335 */     EntityPlayer p = ((CraftPlayer)player).getHandle();
/*  336 */     if (player.isOnGround()) {
/*  337 */       if (player.getFallDistance() <= 0.0F)
/*  338 */         return;  Vec3D dm = this.lastVec3Map.get(player);
/*  339 */       if (dm != null) {
/*  340 */         player.setVelocity(player.getVelocity().add(new Vector(0.0D, -dm.e, 0.0D)));
/*      */       }
/*      */     } 
/*  343 */     this.lastVec3Map.put(player, p.dz());
/*      */   }
/*      */ 
/*      */   
/*      */   public void sendEntityData(Player player, Entity entity, byte bytes) {
/*  348 */     EntityPlayer serverPlayer = ((CraftPlayer)player).getHandle();
/*  349 */     Entity target = ((CraftEntity)entity).getHandle();
/*      */     
/*  351 */     List<DataWatcher.c<?>> eData = new ArrayList<>();
/*  352 */     eData.add(DataWatcher.c.a(new DataWatcherObject(0, DataWatcherRegistry.a), Byte.valueOf(bytes)));
/*  353 */     PacketPlayOutEntityMetadata metadata = new PacketPlayOutEntityMetadata(target.ar(), eData);
/*  354 */     serverPlayer.f.b((Packet)metadata);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getConduitRange(Conduit conduit) {
/*  359 */     if (!conduit.isActive()) return 0; 
/*  360 */     return conduit.getRange();
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public ItemMeta setCustomModelData(ItemMeta meta, int cmd) {
/*  365 */     meta.setCustomModelData(Integer.valueOf(cmd));
/*  366 */     return meta;
/*      */   }
/*      */ 
/*      */   
/*      */   public Goal<Creeper> getCreeperAfraidGoal(LivingEntity creeper, BiPredicate<LivingEntity, Player> hasAbility) {
/*  371 */     return (new PathfinderGoalAvoidTarget((EntityCreature)((CraftEntity)creeper)
/*  372 */         .getHandle(), EntityHuman.class, 6.0F, 1.0D, 1.2D, livingEntity -> {
/*      */           CraftEntity patt0$temp = livingEntity.getBukkitEntity();
/*      */ 
/*      */           
/*      */           if (patt0$temp instanceof Player) {
/*      */             Player player = (Player)patt0$temp;
/*      */ 
/*      */             
/*      */             return hasAbility.test(creeper, player);
/*      */           } 
/*      */           
/*      */           return false;
/*  384 */         })).asPaperVanillaGoal();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean wasTouchingWater(Player player) {
/*  389 */     return (((CraftPlayer)player).getHandle()).ag;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public float getDestroySpeed(Material block) {
/*  395 */     return (((CraftBlockState)block.createBlockData().createBlockState()).getHandle()).p;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isCustomAttribute(AttributeModifier modifier) {
/*  400 */     return !modifier.getKey().getNamespace().equals("minecraft");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public float getDestroySpeed(ItemStack item, Material block) {
/*  406 */     IBlockData b = ((CraftBlockState)block.createBlockData().createBlockState()).getHandle();
/*  407 */     ItemStack handle = CraftItemStack.asNMSCopy(item);
/*  408 */     return handle.a(b);
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute armorAttribute() {
/*  413 */     return Attribute.ARMOR;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute maxHealthAttribute() {
/*  418 */     return Attribute.MAX_HEALTH;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute movementSpeedAttribute() {
/*  423 */     return Attribute.MOVEMENT_SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute attackDamageAttribute() {
/*  428 */     return Attribute.ATTACK_DAMAGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute flyingSpeedAttribute() {
/*  433 */     return Attribute.FLYING_SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute attackKnockbackAttribute() {
/*  438 */     return Attribute.ATTACK_KNOCKBACK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute attackSpeedAttribute() {
/*  443 */     return Attribute.ATTACK_SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute armorToughnessAttribute() {
/*  448 */     return Attribute.ARMOR_TOUGHNESS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute luckAttribute() {
/*  453 */     return Attribute.LUCK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute horseJumpStrengthAttribute() {
/*  458 */     return Attribute.JUMP_STRENGTH;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute spawnReinforcementsAttribute() {
/*  463 */     return Attribute.SPAWN_REINFORCEMENTS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute followRangeAttribute() {
/*  468 */     return Attribute.FOLLOW_RANGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute knockbackResistanceAttribute() {
/*  473 */     return Attribute.KNOCKBACK_RESISTANCE;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute fallDamageMultiplierAttribute() {
/*  478 */     return Attribute.FALL_DAMAGE_MULTIPLIER;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute maxAbsorptionAttribute() {
/*  483 */     return Attribute.MAX_ABSORPTION;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute safeFallDistanceAttribute() {
/*  488 */     return Attribute.SAFE_FALL_DISTANCE;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute scaleAttribute() {
/*  493 */     return Attribute.SCALE;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute stepHeightAttribute() {
/*  498 */     return Attribute.STEP_HEIGHT;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute gravityAttribute() {
/*  503 */     return Attribute.GRAVITY;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute jumpStrengthAttribute() {
/*  508 */     return Attribute.JUMP_STRENGTH;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute burningTimeAttribute() {
/*  513 */     return Attribute.BURNING_TIME;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute explosionKnockbackResistanceAttribute() {
/*  518 */     return Attribute.EXPLOSION_KNOCKBACK_RESISTANCE;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute movementEfficiencyAttribute() {
/*  523 */     return Attribute.MOVEMENT_EFFICIENCY;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute oxygenBonusAttribute() {
/*  528 */     return Attribute.OXYGEN_BONUS;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute waterMovementEfficiencyAttribute() {
/*  533 */     return Attribute.WATER_MOVEMENT_EFFICIENCY;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute temptRangeAttribute() {
/*  538 */     return Attribute.TEMPT_RANGE;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setNoPhysics(Player player, boolean noPhysics) {
/*  543 */     (((CraftPlayer)player).getHandle()).ad = noPhysics;
/*      */   }
/*      */ 
/*      */   
/*      */   public void sendGamemodeUpdate(Player player, GameMode gameMode, boolean bedrock) {
/*  548 */     EntityPlayer serverPlayer = ((CraftPlayer)player).getHandle();
/*  549 */     switch (gameMode) { default: throw new IncompatibleClassChangeError();
/*      */       case CREATIVE: 
/*      */       case SURVIVAL: 
/*      */       case ADVENTURE: 
/*  553 */       case SPECTATOR: break; }  EnumGamemode gameType = EnumGamemode.d;
/*      */     
/*  555 */     ClientboundPlayerInfoUpdatePacket.b entry = new ClientboundPlayerInfoUpdatePacket.b(serverPlayer.cG(), serverPlayer.gh(), true, 1, gameType, serverPlayer.O(), 0, (RemoteChatSession.a)Optionull.a(serverPlayer.ad(), RemoteChatSession::a));
/*  556 */     ClientboundPlayerInfoUpdatePacket packet = new ClientboundPlayerInfoUpdatePacket(EnumSet.of(ClientboundPlayerInfoUpdatePacket.a.c), entry);
/*  557 */     serverPlayer.f.b((Packet)packet);
/*      */     
/*  559 */     if (bedrock) {
/*  560 */       PacketPlayOutGameStateChange eventPacket = new PacketPlayOutGameStateChange(PacketPlayOutGameStateChange.e, gameType.a());
/*  561 */       serverPlayer.f.b((Packet)eventPacket);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void sendResourcePacks(Player player, String pack, Map<?, ResourcePackInfo> extraPacks) {
/*      */     try {
/*  570 */       ResourcePackInfo packInfo = ResourcePackInfo.resourcePackInfo().uri(URI.create(pack)).computeHashAndBuild().get();
/*  571 */       List<ResourcePackInfo> packs = new ArrayList<>();
/*  572 */       packs.add(packInfo);
/*  573 */       for (ResourcePackInfo resourcePackInfo : extraPacks.values()) {
/*  574 */         Object object = resourcePackInfo.packInfo(); if (object instanceof ResourcePackInfo) { ResourcePackInfo info = (ResourcePackInfo)object;
/*  575 */           packs.add(info); }
/*      */       
/*      */       } 
/*  578 */       player.sendResourcePacks((ResourcePackRequest)ResourcePackRequest.resourcePackRequest()
/*  579 */           .packs(packs)
/*  580 */           .required(true)
/*  581 */           .build());
/*      */     }
/*  583 */     catch (InterruptedException|java.util.concurrent.ExecutionException e) {
/*  584 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Location getRespawnLocation(Player player) {
/*  590 */     return player.getRespawnLocation();
/*      */   }
/*      */ 
/*      */   
/*      */   public void resetRespawnLocation(Player player) {
/*  595 */     player.setRespawnLocation(null);
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public AttributeModifier getAttributeModifier(AttributeInstance instance, Key key) {
/*  600 */     return instance.getModifier(key);
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Particle getHappyVillagerParticle() {
/*  605 */     return Particle.HAPPY_VILLAGER;
/*      */   }
/*      */ 
/*      */   
/*      */   public void playTotemEffect(Player player) {
/*  610 */     ((CraftWorld)player.getWorld()).getHandle().a((Entity)((CraftPlayer)player).getHandle(), (byte)35);
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public List<PotionEffect> getDefaultEffects(PotionMeta meta, boolean isLingering) {
/*  615 */     PotionType type = meta.getBasePotionType();
/*  616 */     if (type == null) return List.of(); 
/*  617 */     return type.getPotionEffects();
/*      */   }
/*      */ 
/*      */   
/*      */   public void dropItem(Player player, ItemStack it) {
/*  622 */     ((CraftPlayer)player).getHandle().a(CraftItemStack.asNMSCopy(it), true);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void addAttributeModifier(AttributeInstance instance, NamespacedKey key, String name, double amount, AttributeModifier.Operation operation) {
/*  628 */     instance.addModifier(new AttributeModifier(key, amount, operation, EquipmentSlotGroup.ANY));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void dealDryOutDamage(LivingEntity entity, int amount) {
/*  634 */     entity.damage(amount, DamageSource.builder(DamageType.DRY_OUT).build());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void dealFreezeDamage(LivingEntity entity, int amount) {
/*  640 */     entity.damage(amount, DamageSource.builder(DamageType.FREEZE).build());
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsInfiniteDuration() {
/*  645 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isUnderWater(LivingEntity entity) {
/*  650 */     return entity.isUnderWater();
/*      */   }
/*      */ 
/*      */   
/*      */   public void knockback(LivingEntity entity, double strength, double x, double z) {
/*  655 */     entity.knockback(strength, x, z);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setFlyingFallDamage(Player player, TriState state) {
/*  660 */     player.setFlyingFallDamage(state);
/*      */   }
/*      */ 
/*      */   
/*      */   public void broadcastSlotBreak(Player player, EquipmentSlot slot, Collection<Player> players) {
/*  665 */     player.broadcastSlotBreak(slot, players);
/*      */   }
/*      */ 
/*      */   
/*      */   public void sendBlockDamage(Player player, Location location, float damage, Entity entity) {
/*  670 */     player.sendBlockDamage(location, damage, entity);
/*      */   }
/*      */ 
/*      */   
/*      */   public Attribute blockInteractionRangeAttribute() {
/*  675 */     return Attribute.BLOCK_INTERACTION_RANGE;
/*      */   }
/*      */ 
/*      */   
/*      */   public Attribute entityInteractionRangeAttribute() {
/*  680 */     return Attribute.ENTITY_INTERACTION_RANGE;
/*      */   }
/*      */ 
/*      */   
/*      */   public Attribute blockBreakSpeedAttribute() {
/*  685 */     return Attribute.BLOCK_BREAK_SPEED;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute miningEfficiencyAttribute() {
/*  690 */     return Attribute.MINING_EFFICIENCY;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute sneakingSpeedAttribute() {
/*  695 */     return Attribute.SNEAKING_SPEED;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute submergedMiningSpeedAttribute() {
/*  700 */     return Attribute.SUBMERGED_MINING_SPEED;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute sweepingDamageRatioAttribute() {
/*  705 */     return Attribute.SWEEPING_DAMAGE_RATIO;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment protectionEnchantment() {
/*  710 */     return Enchantment.PROTECTION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment fireProtectionEnchantment() {
/*  715 */     return Enchantment.FIRE_PROTECTION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment featherFallingEnchantment() {
/*  720 */     return Enchantment.FEATHER_FALLING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment blastProtectionEnchantment() {
/*  725 */     return Enchantment.BLAST_PROTECTION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment projectileProtectionEnchantment() {
/*  730 */     return Enchantment.PROJECTILE_PROTECTION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment respirationEnchantment() {
/*  735 */     return Enchantment.RESPIRATION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment aquaAffinityEnchantment() {
/*  740 */     return Enchantment.AQUA_AFFINITY;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment thornsEnchantment() {
/*  745 */     return Enchantment.THORNS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment depthStriderEnchantment() {
/*  750 */     return Enchantment.DEPTH_STRIDER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment frostWalkerEnchantment() {
/*  755 */     return Enchantment.FROST_WALKER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment bindingCurseEnchantment() {
/*  760 */     return Enchantment.BINDING_CURSE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment sharpnessEnchantment() {
/*  765 */     return Enchantment.SHARPNESS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment smiteEnchantment() {
/*  770 */     return Enchantment.SMITE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment baneOfArthropodsEnchantment() {
/*  775 */     return Enchantment.BANE_OF_ARTHROPODS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment knockbackEnchantment() {
/*  780 */     return Enchantment.KNOCKBACK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment fireAspectEnchantment() {
/*  785 */     return Enchantment.FIRE_ASPECT;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment lootingEnchantment() {
/*  790 */     return Enchantment.LOOTING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment sweepingEdgeEnchantment() {
/*  795 */     return Enchantment.SWEEPING_EDGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment efficiencyEnchantment() {
/*  800 */     return Enchantment.EFFICIENCY;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment silkTouchEnchantment() {
/*  805 */     return Enchantment.SILK_TOUCH;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment unbreakingEnchantment() {
/*  810 */     return Enchantment.UNBREAKING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment fortuneEnchantment() {
/*  815 */     return Enchantment.FORTUNE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment powerEnchantment() {
/*  820 */     return Enchantment.POWER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment punchEnchantment() {
/*  825 */     return Enchantment.PUNCH;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment flameEnchantment() {
/*  830 */     return Enchantment.FLAME;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment infinityEnchantment() {
/*  835 */     return Enchantment.INFINITY;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment luckOfTheSeaEnchantment() {
/*  840 */     return Enchantment.LUCK_OF_THE_SEA;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment lureEnchantment() {
/*  845 */     return Enchantment.LURE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment loyaltyEnchantment() {
/*  850 */     return Enchantment.LOYALTY;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment impalingEnchantment() {
/*  855 */     return Enchantment.IMPALING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment riptideEnchantment() {
/*  860 */     return Enchantment.RIPTIDE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment channelingEnchantment() {
/*  865 */     return Enchantment.CHANNELING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment multishotEnchantment() {
/*  870 */     return Enchantment.MULTISHOT;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment quickChargeEnchantment() {
/*  875 */     return Enchantment.QUICK_CHARGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment piercingEnchantment() {
/*  880 */     return Enchantment.PIERCING;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected Enchantment densityEnchantment() {
/*  885 */     return Enchantment.DENSITY;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected Enchantment breachEnchantment() {
/*  890 */     return Enchantment.BREACH;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected Enchantment windBurstEnchantment() {
/*  895 */     return Enchantment.WIND_BURST;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment mendingEnchantment() {
/*  900 */     return Enchantment.MENDING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment vanishingCurseEnchantment() {
/*  905 */     return Enchantment.VANISHING_CURSE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment soulSpeedEnchantment() {
/*  910 */     return Enchantment.SOUL_SPEED;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected Enchantment swiftSneakEnchantment() {
/*  915 */     return Enchantment.SWIFT_SNEAK;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setWorldBorderOverlay(Player player, boolean show) {
/*  920 */     if (show)
/*  921 */     { WorldBorder border = Bukkit.createWorldBorder();
/*  922 */       border.setCenter(player.getWorld().getWorldBorder().getCenter());
/*  923 */       border.setSize(player.getWorld().getWorldBorder().getSize());
/*  924 */       border.setWarningDistance((int)(player.getWorld().getWorldBorder().getSize() * 2.0D));
/*  925 */       player.setWorldBorder(border); }
/*  926 */     else { player.setWorldBorder(null); }
/*      */   
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealDrowningDamage(LivingEntity entity, int amount) {
/*  932 */     entity.damage(amount, DamageSource.builder(DamageType.DROWN).build());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setComments(FileConfiguration config, String path, List<String> comments) {
/*  937 */     config.setComments(path, comments);
/*      */   }
/*      */   
/*      */   @EventHandler
/*      */   public void onBlockDamageAbort(BlockDamageAbortEvent event) {
/*  942 */     (new MVBlockDamageAbortEvent(event.getPlayer(), event.getBlock(), event.getItemInHand())).callEvent();
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Material getOminousBottle() {
/*  947 */     return Material.OMINOUS_BOTTLE;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void dealExplosionDamage(Player player, int amount) {
/*  953 */     player.damage(amount, DamageSource.builder(DamageType.EXPLOSION).build());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void dealSonicBoomDamage(LivingEntity entity, int amount, Player source) {
/*  959 */     entity.damage(amount, DamageSource.builder(DamageType.SONIC_BOOM).build());
/*      */   }
/*      */ 
/*      */   
/*      */   public Goal<Villager> getVillagerAfraidGoal(LivingEntity villager, Predicate<Player> hasAbility) {
/*  964 */     return (new PathfinderGoalAvoidTarget((EntityCreature)((CraftEntity)villager)
/*  965 */         .getHandle(), EntityHuman.class, 6.0F, 0.5D, 0.8D, livingEntity -> {
/*      */           CraftEntity patt0$temp = livingEntity.getBukkitEntity();
/*      */ 
/*      */           
/*      */           if (patt0$temp instanceof Player) {
/*      */             Player player = (Player)patt0$temp;
/*      */             
/*      */             return hasAbility.test(player);
/*      */           } 
/*      */           
/*      */           return false;
/*  976 */         })).asPaperVanillaGoal();
/*      */   }
/*      */ 
/*      */   
/*      */   public void throwItem(Piglin piglin, ItemStack itemStack, Location pos) {
/*  981 */     BehaviorUtil.a(((CraftLivingEntity)piglin).getHandle(), CraftItemStack.asNMSCopy(itemStack), new Vec3D(pos.getX(), pos.getY(), pos.getZ()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void launchArrow(Entity projectile, Entity entity, float roll, float force, float divergence) {
/*  986 */     ((AbstractProjectile)projectile).getHandle().a(((CraftEntity)entity).getHandle(), entity.getPitch(), entity.getYaw(), roll, force, divergence);
/*      */   }
/*      */ 
/*      */   
/*      */   public void damageItem(ItemStack item, int amount, Player player) {
/*  991 */     item.damage(amount, (LivingEntity)player);
/*      */   }
/*      */ 
/*      */   
/*      */   public void startAutoSpinAttack(Player player, int duration, float riptideAttackDamage, ItemStack item) {
/*  996 */     ((CraftPlayer)player).getHandle().a(duration, riptideAttackDamage, CraftItemStack.asNMSCopy(item));
/*      */   }
/*      */ 
/*      */   
/*      */   public void tridentMove(Player player) {
/* 1001 */     ((CraftPlayer)player).getHandle().a(EnumMoveType.a, new Vec3D(0.0D, 1.1999999284744263D, 0.0D));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void transferDamageEvent(LivingEntity entity, EntityDamageEvent event) {
/* 1007 */     entity.damage(event.getDamage(), event.getDamageSource());
/*      */   }
/*      */ 
/*      */   
/*      */   public void boostArrow(Arrow arrow) {
/* 1012 */     if (arrow.getBasePotionType() == null)
/* 1013 */       return;  for (PotionEffect effect : arrow.getBasePotionType().getPotionEffects()) {
/* 1014 */       arrow.addCustomEffect(effect.withDuration(effect.getDuration()).withAmplifier(effect.getAmplifier() + 1), true);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean duplicateAllay(LivingEntity entity) {
/*      */     Allay allay;
/* 1020 */     if (entity instanceof Allay) { allay = (Allay)entity; } else { return false; }
/* 1021 */      if (allay.getDuplicationCooldown() > 0L) return false; 
/* 1022 */     allay.duplicateAllay();
/* 1023 */     ((CraftWorld)allay.getWorld()).getHandle().a((Entity)((CraftAllay)allay).getHandle(), (byte)18);
/* 1024 */     return true;
/*      */   }
/*      */   
/*      */   @EventHandler
/*      */   public void onEntityDismount(EntityDismountEvent event) {
/* 1029 */     event.setCancelled(!(new MVEntityDismountEvent(event.getEntity(), event.getDismounted(), event.isCancellable())).callEvent());
/*      */   }
/*      */   
/*      */   @EventHandler
/*      */   public void onEntityMount(EntityMountEvent event) {
/* 1034 */     event.setCancelled(!(new MVEntityMountEvent(event.getEntity(), event.getMount())).callEvent());
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Player getNearestVisiblePlayer(Piglin piglin) {
/* 1039 */     Optional<EntityHuman> optional = ((CraftPiglin)piglin).getHandle().ec().c(MemoryModuleType.k);
/* 1040 */     return optional.<Player>map(player -> (Player)player.getBukkitEntity()).orElse(null);
/*      */   }
/*      */ 
/*      */   
/*      */   public Component applyFont(Component component, Key font) {
/* 1045 */     return component.font(font);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setArrow(Arrow arrow, ItemStack itemStack) {
/* 1050 */     arrow.setItemStack(itemStack);
/*      */   }
/*      */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\version\MVE_V1_21_3.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */