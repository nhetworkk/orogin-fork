/*      */ package com.starshootercity.version;
/*      */ import com.destroystokyo.paper.entity.ai.Goal;
/*      */ import java.lang.reflect.Field;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Optional;
/*      */ import java.util.UUID;
/*      */ import java.util.function.BiPredicate;
/*      */ import java.util.function.Predicate;
/*      */ import net.kyori.adventure.key.Key;
/*      */ import net.kyori.adventure.text.Component;
/*      */ import net.minecraft.core.BlockPosition;
/*      */ import net.minecraft.network.protocol.Packet;
/*      */ import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket;
/*      */ import net.minecraft.network.protocol.game.PacketPlayOutEntityMetadata;
/*      */ import net.minecraft.network.protocol.game.PacketPlayOutGameStateChange;
/*      */ import net.minecraft.network.syncher.DataWatcher;
/*      */ import net.minecraft.server.level.EntityPlayer;
/*      */ import net.minecraft.world.EnumInteractionResult;
/*      */ import net.minecraft.world.entity.Entity;
/*      */ import net.minecraft.world.entity.EntityLiving;
/*      */ import net.minecraft.world.entity.ai.goal.PathfinderGoalAvoidTarget;
/*      */ import net.minecraft.world.entity.player.EntityHuman;
/*      */ import net.minecraft.world.item.ItemStack;
/*      */ import net.minecraft.world.level.EnumGamemode;
/*      */ import net.minecraft.world.level.block.entity.TileEntityConduit;
/*      */ import net.minecraft.world.phys.MovingObjectPositionBlock;
/*      */ import net.minecraft.world.phys.Vec3D;
/*      */ import org.bukkit.GameMode;
/*      */ import org.bukkit.Location;
/*      */ import org.bukkit.Material;
/*      */ import org.bukkit.NamespacedKey;
/*      */ import org.bukkit.Particle;
/*      */ import org.bukkit.WorldBorder;
/*      */ import org.bukkit.attribute.Attribute;
/*      */ import org.bukkit.attribute.AttributeInstance;
/*      */ import org.bukkit.attribute.AttributeModifier;
/*      */ import org.bukkit.block.Block;
/*      */ import org.bukkit.block.Conduit;
/*      */ import org.bukkit.configuration.file.FileConfiguration;
/*      */ import org.bukkit.craftbukkit.v1_20_R3.CraftWorld;
/*      */ import org.bukkit.craftbukkit.v1_20_R3.entity.CraftEntity;
/*      */ import org.bukkit.craftbukkit.v1_20_R3.entity.CraftLivingEntity;
/*      */ import org.bukkit.craftbukkit.v1_20_R3.entity.CraftPlayer;
/*      */ import org.bukkit.craftbukkit.v1_20_R3.inventory.CraftItemStack;
/*      */ import org.bukkit.enchantments.Enchantment;
/*      */ import org.bukkit.entity.Allay;
/*      */ import org.bukkit.entity.Arrow;
/*      */ import org.bukkit.entity.Entity;
/*      */ import org.bukkit.entity.LivingEntity;
/*      */ import org.bukkit.entity.Piglin;
/*      */ import org.bukkit.entity.Player;
/*      */ import org.bukkit.event.EventHandler;
/*      */ import org.bukkit.event.block.BlockDamageAbortEvent;
/*      */ import org.bukkit.inventory.EquipmentSlot;
/*      */ import org.bukkit.inventory.ItemStack;
/*      */ import org.bukkit.inventory.meta.ItemMeta;
/*      */ import org.bukkit.inventory.meta.PotionMeta;
/*      */ import org.bukkit.potion.PotionEffect;
/*      */ import org.bukkit.potion.PotionEffectType;
/*      */ import org.bukkit.potion.PotionType;
/*      */ import org.jetbrains.annotations.NotNull;
/*      */ import org.jetbrains.annotations.Nullable;
/*      */ import org.spigotmc.event.entity.EntityDismountEvent;
/*      */ import org.spigotmc.event.entity.EntityMountEvent;
/*      */ import xyz.jpenilla.reflectionremapper.ReflectionRemapper;
/*      */ 
/*      */ public class MVE_V1_20_3 extends MultiVersionExecutor {
/*      */   public void setTouchingWater(Player player) {
/*   71 */     (((CraftPlayer)player).getHandle()).ai = true;
/*      */   }
/*      */   
/*   74 */   private final ItemStack boneMeal = CraftItemStack.asNMSCopy(new ItemStack(Material.BONE_MEAL));
/*      */   
/*      */   private static Field effectBlocks;
/*      */   
/*      */   private static Field isActive;
/*      */   
/*      */   public boolean boneMeal(Block block, Player player) {
/*   81 */     BlockPosition blockPos = new BlockPosition(block.getX(), block.getY(), block.getZ());
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   86 */     MovingObjectPositionBlock bhr = new MovingObjectPositionBlock(Vec3D.b((BaseBlockPosition)blockPos), ((CraftPlayer)player).getHandle().cE(), blockPos, false);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   91 */     EnumInteractionResult result = ItemBoneMeal.applyBonemeal(new ItemActionContext((World)((CraftWorld)player
/*   92 */           .getWorld()).getHandle(), (EntityHuman)((CraftPlayer)player)
/*   93 */           .getHandle(), EnumHand.a, this.boneMeal, bhr));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   98 */     return (result == EnumInteractionResult.a);
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute miningEfficiencyAttribute() {
/*  103 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute sneakingSpeedAttribute() {
/*  108 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute submergedMiningSpeedAttribute() {
/*  113 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute sweepingDamageRatioAttribute() {
/*  118 */     return null;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public ItemMeta setCustomModelData(ItemMeta meta, int cmd) {
/*  123 */     meta.setCustomModelData(Integer.valueOf(cmd));
/*  124 */     return meta;
/*      */   }
/*      */ 
/*      */   
/*      */   public void initialize() {
/*  129 */     String blocks = ReflectionRemapper.forReobfMappingsInPaperJar().remapFieldName(TileEntityConduit.class, "effectBlocks");
/*  130 */     String active = ReflectionRemapper.forReobfMappingsInPaperJar().remapFieldName(TileEntityConduit.class, "isActive");
/*      */     try {
/*  132 */       effectBlocks = TileEntityConduit.class.getDeclaredField(blocks);
/*  133 */       effectBlocks.setAccessible(true);
/*  134 */       isActive = TileEntityConduit.class.getDeclaredField(active);
/*  135 */       isActive.setAccessible(true);
/*  136 */     } catch (NoSuchFieldException e) {
/*  137 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getConduitRange(Conduit conduit) {
/*      */     try {
/*  148 */       TileEntityConduit tileEntity = (TileEntityConduit)((CraftConduit)conduit).getTileEntity();
/*  149 */       boolean active = ((Boolean)isActive.get(tileEntity)).booleanValue();
/*  150 */       if (!active) return 0; 
/*  151 */       List<BlockPosition> list = (List<BlockPosition>)effectBlocks.get(tileEntity);
/*  152 */       int i = list.size();
/*  153 */       return i / 7 * 16;
/*  154 */     } catch (IllegalAccessException e) {
/*  155 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute flyingSpeedAttribute() {
/*  161 */     return Attribute.GENERIC_FLYING_SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute attackKnockbackAttribute() {
/*  166 */     return Attribute.GENERIC_ATTACK_KNOCKBACK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute attackSpeedAttribute() {
/*  171 */     return Attribute.GENERIC_ATTACK_SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute armorToughnessAttribute() {
/*  176 */     return Attribute.GENERIC_ARMOR_TOUGHNESS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute luckAttribute() {
/*  181 */     return Attribute.GENERIC_LUCK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute horseJumpStrengthAttribute() {
/*  186 */     return Attribute.HORSE_JUMP_STRENGTH;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute spawnReinforcementsAttribute() {
/*  191 */     return Attribute.ZOMBIE_SPAWN_REINFORCEMENTS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute followRangeAttribute() {
/*  196 */     return Attribute.GENERIC_FOLLOW_RANGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute knockbackResistanceAttribute() {
/*  201 */     return Attribute.GENERIC_KNOCKBACK_RESISTANCE;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute fallDamageMultiplierAttribute() {
/*  206 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute maxAbsorptionAttribute() {
/*  211 */     return Attribute.GENERIC_MAX_ABSORPTION;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute safeFallDistanceAttribute() {
/*  216 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute scaleAttribute() {
/*  221 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute stepHeightAttribute() {
/*  226 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute gravityAttribute() {
/*  231 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute jumpStrengthAttribute() {
/*  236 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute burningTimeAttribute() {
/*  241 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute explosionKnockbackResistanceAttribute() {
/*  246 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute movementEfficiencyAttribute() {
/*  251 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute oxygenBonusAttribute() {
/*  256 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute waterMovementEfficiencyAttribute() {
/*  261 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute temptRangeAttribute() {
/*  266 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Component applyFont(Component component, Key font) {
/*  271 */     return component.font(font);
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Material getOminousBottle() {
/*  276 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealDrowningDamage(LivingEntity entity, int amount) {
/*  281 */     EntityLiving livingEntity = ((CraftLivingEntity)entity).getHandle();
/*  282 */     livingEntity.a(livingEntity.dN().h(), amount);
/*      */   }
/*      */   
/*      */   @EventHandler
/*      */   public void onBlockDamageAbort(BlockDamageAbortEvent event) {
/*  287 */     (new MVBlockDamageAbortEvent(event.getPlayer(), event.getBlock(), event.getItemInHand())).callEvent();
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute armorAttribute() {
/*  292 */     return Attribute.GENERIC_ARMOR;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute maxHealthAttribute() {
/*  297 */     return Attribute.GENERIC_MAX_HEALTH;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute movementSpeedAttribute() {
/*  302 */     return Attribute.GENERIC_MOVEMENT_SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute attackDamageAttribute() {
/*  307 */     return Attribute.GENERIC_ATTACK_DAMAGE;
/*      */   }
/*      */ 
/*      */   
/*      */   public void sendEntityData(Player player, Entity entity, byte bytes) {
/*  312 */     EntityPlayer serverPlayer = ((CraftPlayer)player).getHandle();
/*  313 */     Entity target = ((CraftEntity)entity).getHandle();
/*      */     
/*  315 */     List<DataWatcher.b<?>> eData = new ArrayList<>();
/*  316 */     eData.add(DataWatcher.b.a(new DataWatcherObject(0, DataWatcherRegistry.a), Byte.valueOf(bytes)));
/*  317 */     PacketPlayOutEntityMetadata metadata = new PacketPlayOutEntityMetadata(target.aj(), eData);
/*  318 */     serverPlayer.c.b((Packet)metadata);
/*      */   }
/*      */ 
/*      */   
/*      */   public Goal<Creeper> getCreeperAfraidGoal(LivingEntity creeper, BiPredicate<LivingEntity, Player> hasAbility) {
/*  323 */     return (new PathfinderGoalAvoidTarget((EntityCreature)((CraftEntity)creeper)
/*  324 */         .getHandle(), EntityHuman.class, 6.0F, 1.0D, 1.2D, livingEntity -> {
/*      */           CraftEntity patt10657$temp = livingEntity.getBukkitEntity();
/*      */ 
/*      */           
/*      */           if (patt10657$temp instanceof Player) {
/*      */             Player player = (Player)patt10657$temp;
/*      */ 
/*      */             
/*      */             return hasAbility.test(creeper, player);
/*      */           } 
/*      */           
/*      */           return false;
/*  336 */         })).asPaperVanillaGoal();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean wasTouchingWater(Player player) {
/*  341 */     return (((CraftPlayer)player).getHandle()).ai;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public float getDestroySpeed(Material block) {
/*  347 */     return (((CraftBlockState)block.createBlockData().createBlockState()).getHandle()).n;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public float getDestroySpeed(ItemStack item, Material block) {
/*  353 */     IBlockData b = ((CraftBlockState)block.createBlockData().createBlockState()).getHandle();
/*  354 */     ItemStack handle = CraftItemStack.asNMSCopy(item);
/*  355 */     return handle.a(b);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setNoPhysics(Player player, boolean noPhysics) {
/*  360 */     (((CraftPlayer)player).getHandle()).af = noPhysics;
/*      */   }
/*      */ 
/*      */   
/*      */   public void sendGamemodeUpdate(Player player, GameMode gameMode, boolean bedrock) {
/*  365 */     EntityPlayer serverPlayer = ((CraftPlayer)player).getHandle();
/*  366 */     switch (gameMode) { default: throw new IncompatibleClassChangeError();
/*      */       case CREATIVE: 
/*      */       case SURVIVAL: 
/*      */       case ADVENTURE: 
/*  370 */       case SPECTATOR: break; }  EnumGamemode gameType = EnumGamemode.d;
/*      */     
/*  372 */     ClientboundPlayerInfoUpdatePacket.b entry = new ClientboundPlayerInfoUpdatePacket.b(serverPlayer.cw(), serverPlayer.fR(), true, 1, gameType, serverPlayer.N(), (RemoteChatSession.a)Optionull.a(serverPlayer.ab(), RemoteChatSession::a));
/*  373 */     ClientboundPlayerInfoUpdatePacket packet = new ClientboundPlayerInfoUpdatePacket(EnumSet.of(ClientboundPlayerInfoUpdatePacket.a.c), entry);
/*  374 */     serverPlayer.c.b((Packet)packet);
/*      */     
/*  376 */     if (bedrock) {
/*  377 */       PacketPlayOutGameStateChange eventPacket = new PacketPlayOutGameStateChange(PacketPlayOutGameStateChange.d, gameType.a());
/*  378 */       serverPlayer.c.b((Packet)eventPacket);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void sendResourcePacks(Player player, String pack, Map<?, ResourcePackInfo> extraPacks) {
/*  385 */     player.setResourcePack(pack);
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Location getRespawnLocation(Player player) {
/*  390 */     return player.getBedSpawnLocation();
/*      */   }
/*      */ 
/*      */   
/*      */   public void resetRespawnLocation(Player player) {
/*  395 */     player.setBedSpawnLocation(null);
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public AttributeModifier getAttributeModifier(AttributeInstance instance, Key key) {
/*  400 */     UUID u = UUID.nameUUIDFromBytes(key.toString().getBytes());
/*  401 */     return instance.getModifier(u);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addAttributeModifier(AttributeInstance instance, NamespacedKey key, String name, double amount, AttributeModifier.Operation operation) {
/*  406 */     instance.addModifier(new AttributeModifier(UUID.nameUUIDFromBytes(key.toString().getBytes()), name, amount, operation));
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isUnderWater(LivingEntity entity) {
/*  411 */     return entity.isUnderWater();
/*      */   }
/*      */ 
/*      */   
/*      */   public void knockback(LivingEntity entity, double strength, double x, double z) {
/*  416 */     entity.knockback(strength, x, z);
/*      */   }
/*      */ 
/*      */   
/*      */   public Attribute blockInteractionRangeAttribute() {
/*  421 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Attribute entityInteractionRangeAttribute() {
/*  426 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealDryOutDamage(LivingEntity entity, int amount) {
/*  431 */     EntityLiving livingEntity = ((CraftLivingEntity)entity).getHandle();
/*  432 */     livingEntity.a(livingEntity.dN().r(), amount);
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealFreezeDamage(LivingEntity entity, int amount) {
/*  437 */     EntityLiving livingEntity = ((CraftLivingEntity)entity).getHandle();
/*  438 */     livingEntity.a(livingEntity.dN().t(), amount);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsInfiniteDuration() {
/*  443 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setFlyingFallDamage(Player player, TriState state) {
/*  448 */     player.setFlyingFallDamage(state);
/*      */   }
/*      */ 
/*      */   
/*      */   public void broadcastSlotBreak(Player player, EquipmentSlot slot, Collection<Player> players) {
/*  453 */     player.broadcastSlotBreak(slot, players);
/*      */   }
/*      */ 
/*      */   
/*      */   public void sendBlockDamage(Player player, Location location, float damage, Entity entity) {
/*  458 */     player.sendBlockDamage(location, damage, entity);
/*      */   }
/*      */ 
/*      */   
/*      */   public Attribute blockBreakSpeedAttribute() {
/*  463 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setWorldBorderOverlay(Player player, boolean show) {
/*  468 */     if (show)
/*  469 */     { WorldBorder border = Bukkit.createWorldBorder();
/*  470 */       border.setCenter(player.getWorld().getWorldBorder().getCenter());
/*  471 */       border.setSize(player.getWorld().getWorldBorder().getSize());
/*  472 */       border.setWarningDistance((int)(player.getWorld().getWorldBorder().getSize() * 2.0D));
/*  473 */       player.setWorldBorder(border); }
/*  474 */     else { player.setWorldBorder(null); }
/*      */   
/*      */   }
/*      */   
/*      */   public void setComments(FileConfiguration config, String path, List<String> comments) {
/*  479 */     config.setComments(path, comments);
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealExplosionDamage(Player player, int amount) {
/*  484 */     EntityPlayer serverPlayer = ((CraftPlayer)player).getHandle();
/*  485 */     serverPlayer.a(serverPlayer.dN().a(null), amount);
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealSonicBoomDamage(LivingEntity entity, int amount, Player source) {
/*  490 */     EntityPlayer serverPlayer = ((CraftPlayer)source).getHandle();
/*  491 */     Entity e = ((CraftEntity)entity).getHandle();
/*  492 */     e.a(e.dN().e((Entity)serverPlayer), amount);
/*      */   }
/*      */ 
/*      */   
/*      */   public Goal<Villager> getVillagerAfraidGoal(LivingEntity villager, Predicate<Player> hasAbility) {
/*  497 */     return (new PathfinderGoalAvoidTarget((EntityCreature)((CraftEntity)villager)
/*  498 */         .getHandle(), EntityHuman.class, 6.0F, 0.5D, 0.8D, livingEntity -> {
/*      */           CraftEntity patt17255$temp = livingEntity.getBukkitEntity();
/*      */ 
/*      */           
/*      */           if (patt17255$temp instanceof Player) {
/*      */             Player player = (Player)patt17255$temp;
/*      */             
/*      */             return hasAbility.test(player);
/*      */           } 
/*      */           
/*      */           return false;
/*  509 */         })).asPaperVanillaGoal();
/*      */   }
/*      */ 
/*      */   
/*      */   public void throwItem(Piglin piglin, ItemStack itemStack, Location pos) {
/*  514 */     BehaviorUtil.a(((CraftLivingEntity)piglin).getHandle(), CraftItemStack.asNMSCopy(itemStack), new Vec3D(pos.getX(), pos.getY(), pos.getZ()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void launchArrow(Entity projectile, Entity entity, float roll, float force, float divergence) {
/*  519 */     ((AbstractProjectile)projectile).getHandle().a(((CraftEntity)entity).getHandle(), entity.getPitch(), entity.getYaw(), roll, force, divergence);
/*      */   }
/*      */ 
/*      */   
/*      */   public void damageItem(ItemStack item, int amount, Player player) {
/*  524 */     item.damage(amount, (LivingEntity)player);
/*      */   }
/*      */ 
/*      */   
/*      */   public void startAutoSpinAttack(Player player, int duration, float riptideAttackDamage, ItemStack item) {
/*  529 */     ((CraftPlayer)player).getHandle().t(duration);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tridentMove(Player player) {
/*  534 */     ((CraftPlayer)player).getHandle().a(EnumMoveType.a, new Vec3D(0.0D, 1.1999999284744263D, 0.0D));
/*      */   }
/*      */ 
/*      */   
/*      */   public void transferDamageEvent(LivingEntity entity, EntityDamageEvent event) {
/*  539 */     entity.damage(event.getDamage());
/*      */   }
/*      */ 
/*      */   
/*      */   public void boostArrow(Arrow arrow) {
/*  544 */     for (PotionEffect effect : arrow.getBasePotionType().getPotionEffects()) {
/*  545 */       arrow.addCustomEffect(effect.withDuration(effect.getDuration()).withAmplifier(effect.getAmplifier() + 1), true);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean duplicateAllay(LivingEntity entity) {
/*      */     Allay allay;
/*  551 */     if (entity instanceof Allay) { allay = (Allay)entity; } else { return false; }
/*  552 */      if (allay.getDuplicationCooldown() > 0L) return false; 
/*  553 */     allay.duplicateAllay();
/*  554 */     ((CraftWorld)allay.getWorld()).getHandle().a((Entity)((CraftAllay)allay).getHandle(), (byte)18);
/*  555 */     return true;
/*      */   }
/*      */   
/*      */   @EventHandler
/*      */   public void onEntityDismount(EntityDismountEvent event) {
/*  560 */     event.setCancelled(!(new MVEntityDismountEvent(event.getEntity(), event.getDismounted(), event.isCancellable())).callEvent());
/*      */   }
/*      */   
/*      */   @EventHandler
/*      */   public void onEntityMount(EntityMountEvent event) {
/*  565 */     event.setCancelled(!(new MVEntityMountEvent(event.getEntity(), event.getMount())).callEvent());
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType speedEffect() {
/*  570 */     return PotionEffectType.SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType slownessEffect() {
/*  575 */     return PotionEffectType.SLOW;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType hasteEffect() {
/*  580 */     return PotionEffectType.FAST_DIGGING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType miningFatigueEffect() {
/*  585 */     return PotionEffectType.SLOW_DIGGING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType strengthEffect() {
/*  590 */     return PotionEffectType.INCREASE_DAMAGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType instantHealthEffect() {
/*  595 */     return PotionEffectType.HEAL;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType instantDamageEffect() {
/*  600 */     return PotionEffectType.HARM;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType jumpBoostEffect() {
/*  605 */     return PotionEffectType.JUMP;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType nauseaEffect() {
/*  610 */     return PotionEffectType.CONFUSION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType regenerationEffect() {
/*  615 */     return PotionEffectType.REGENERATION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType resistanceEffect() {
/*  620 */     return PotionEffectType.DAMAGE_RESISTANCE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType fireResistanceEffect() {
/*  625 */     return PotionEffectType.FIRE_RESISTANCE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType waterBreathingEffect() {
/*  630 */     return PotionEffectType.WATER_BREATHING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType invisibilityEffect() {
/*  635 */     return PotionEffectType.INVISIBILITY;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType blindnessEffect() {
/*  640 */     return PotionEffectType.BLINDNESS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType nightVisionEffect() {
/*  645 */     return PotionEffectType.NIGHT_VISION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType hungerEffect() {
/*  650 */     return PotionEffectType.HUNGER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType weaknessEffect() {
/*  655 */     return PotionEffectType.WEAKNESS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType poisonEffect() {
/*  660 */     return PotionEffectType.POISON;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType witherEffect() {
/*  665 */     return PotionEffectType.WITHER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType healthBoostEffect() {
/*  670 */     return PotionEffectType.HEALTH_BOOST;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType absorptionEffect() {
/*  675 */     return PotionEffectType.ABSORPTION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType saturationEffect() {
/*  680 */     return PotionEffectType.SATURATION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType glowingEffect() {
/*  685 */     return PotionEffectType.GLOWING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType levitationEffect() {
/*  690 */     return PotionEffectType.LEVITATION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType luckEffect() {
/*  695 */     return PotionEffectType.LUCK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType badLuckEffect() {
/*  700 */     return PotionEffectType.UNLUCK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType slowFallingEffect() {
/*  705 */     return PotionEffectType.SLOW_FALLING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType conduitPowerEffect() {
/*  710 */     return PotionEffectType.CONDUIT_POWER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType dolphinsGraceEffect() {
/*  715 */     return PotionEffectType.DOLPHINS_GRACE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType badOmenEffect() {
/*  720 */     return PotionEffectType.BAD_OMEN;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType heroOfTheVillageEffect() {
/*  725 */     return PotionEffectType.HERO_OF_THE_VILLAGE;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType darknessEffect() {
/*  730 */     return PotionEffectType.DARKNESS;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType trialOmenEffect() {
/*  735 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType raidOmenEffect() {
/*  740 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType windChargedEffect() {
/*  745 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType weavingEffect() {
/*  750 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType oozingEffect() {
/*  755 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType infestedEffect() {
/*  760 */     return null;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment protectionEnchantment() {
/*  765 */     return Enchantment.PROTECTION_ENVIRONMENTAL;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment fireProtectionEnchantment() {
/*  770 */     return Enchantment.PROTECTION_FIRE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment featherFallingEnchantment() {
/*  775 */     return Enchantment.PROTECTION_FALL;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment blastProtectionEnchantment() {
/*  780 */     return Enchantment.PROTECTION_EXPLOSIONS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment projectileProtectionEnchantment() {
/*  785 */     return Enchantment.PROTECTION_PROJECTILE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment respirationEnchantment() {
/*  790 */     return Enchantment.OXYGEN;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment aquaAffinityEnchantment() {
/*  795 */     return Enchantment.WATER_WORKER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment thornsEnchantment() {
/*  800 */     return Enchantment.THORNS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment depthStriderEnchantment() {
/*  805 */     return Enchantment.DEPTH_STRIDER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment frostWalkerEnchantment() {
/*  810 */     return Enchantment.FROST_WALKER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment bindingCurseEnchantment() {
/*  815 */     return Enchantment.BINDING_CURSE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment sharpnessEnchantment() {
/*  820 */     return Enchantment.DAMAGE_ALL;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment smiteEnchantment() {
/*  825 */     return Enchantment.DAMAGE_UNDEAD;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment baneOfArthropodsEnchantment() {
/*  830 */     return Enchantment.DAMAGE_ARTHROPODS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment knockbackEnchantment() {
/*  835 */     return Enchantment.KNOCKBACK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment fireAspectEnchantment() {
/*  840 */     return Enchantment.FIRE_ASPECT;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment lootingEnchantment() {
/*  845 */     return Enchantment.LOOT_BONUS_MOBS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment sweepingEdgeEnchantment() {
/*  850 */     return Enchantment.SWEEPING_EDGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment efficiencyEnchantment() {
/*  855 */     return Enchantment.DIG_SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment silkTouchEnchantment() {
/*  860 */     return Enchantment.SILK_TOUCH;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment unbreakingEnchantment() {
/*  865 */     return Enchantment.DURABILITY;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment fortuneEnchantment() {
/*  870 */     return Enchantment.LOOT_BONUS_BLOCKS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment powerEnchantment() {
/*  875 */     return Enchantment.ARROW_DAMAGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment punchEnchantment() {
/*  880 */     return Enchantment.ARROW_KNOCKBACK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment flameEnchantment() {
/*  885 */     return Enchantment.ARROW_FIRE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment infinityEnchantment() {
/*  890 */     return Enchantment.ARROW_INFINITE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment luckOfTheSeaEnchantment() {
/*  895 */     return Enchantment.LUCK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment lureEnchantment() {
/*  900 */     return Enchantment.LURE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment loyaltyEnchantment() {
/*  905 */     return Enchantment.LOYALTY;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment impalingEnchantment() {
/*  910 */     return Enchantment.IMPALING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment riptideEnchantment() {
/*  915 */     return Enchantment.RIPTIDE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment channelingEnchantment() {
/*  920 */     return Enchantment.CHANNELING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment multishotEnchantment() {
/*  925 */     return Enchantment.MULTISHOT;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment quickChargeEnchantment() {
/*  930 */     return Enchantment.QUICK_CHARGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment piercingEnchantment() {
/*  935 */     return Enchantment.PIERCING;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected Enchantment densityEnchantment() {
/*  940 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected Enchantment breachEnchantment() {
/*  945 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected Enchantment windBurstEnchantment() {
/*  950 */     return null;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment mendingEnchantment() {
/*  955 */     return Enchantment.MENDING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment vanishingCurseEnchantment() {
/*  960 */     return Enchantment.VANISHING_CURSE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment soulSpeedEnchantment() {
/*  965 */     return Enchantment.SOUL_SPEED;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected Enchantment swiftSneakEnchantment() {
/*  970 */     return Enchantment.SWIFT_SNEAK;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Player getNearestVisiblePlayer(Piglin piglin) {
/*  975 */     Optional<EntityHuman> optional = ((CraftPiglin)piglin).getHandle().dO().c(MemoryModuleType.k);
/*  976 */     return optional.<Player>map(player -> (Player)player.getBukkitEntity()).orElse(null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealThornsDamage(Entity target, int amount, Entity attacker) {
/*  981 */     Entity entity = ((CraftEntity)target).getHandle();
/*  982 */     entity.a(entity.dN().d(((CraftEntity)attacker).getHandle()), amount);
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Particle getElderGuardianParticle() {
/*  987 */     return Particle.MOB_APPEARANCE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Particle getWitchParticle() {
/*  992 */     return Particle.SPELL_WITCH;
/*      */   }
/*      */ 
/*      */   
/*      */   public Goal<Mob> getIronGolemAttackGoal(LivingEntity golem, Predicate<Player> hasAbility) {
/*  997 */     return (new PathfinderGoalNearestAttackableTarget(((CraftMob)golem)
/*  998 */         .getHandle(), EntityHuman.class, 10, true, false, livingEntity -> {
/*      */           CraftEntity patt30834$temp = livingEntity.getBukkitEntity();
/*      */           
/*      */           if (patt30834$temp instanceof Player) {
/*      */             Player player = (Player)patt30834$temp;
/*      */             
/*      */             return hasAbility.test(player);
/*      */           } 
/*      */           return false;
/* 1007 */         })).asPaperVanillaGoal();
/*      */   }
/*      */   
/* 1010 */   private final Map<Player, Vec3D> lastVec3Map = new HashMap<>();
/*      */ 
/*      */ 
/*      */   
/*      */   public void bounce(Player player) {
/* 1015 */     EntityPlayer p = ((CraftPlayer)player).getHandle();
/* 1016 */     if (player.isOnGround()) {
/* 1017 */       if (player.getFallDistance() <= 0.0F)
/* 1018 */         return;  Vec3D dm = this.lastVec3Map.get(player);
/* 1019 */       if (dm != null) {
/* 1020 */         player.setVelocity(player.getVelocity().add(new Vector(0.0D, -dm.d, 0.0D)));
/*      */       }
/*      */     } 
/* 1023 */     this.lastVec3Map.put(player, p.dp());
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Particle getHappyVillagerParticle() {
/* 1028 */     return Particle.VILLAGER_HAPPY;
/*      */   }
/*      */ 
/*      */   
/*      */   public void playTotemEffect(Player player) {
/* 1033 */     ((CraftWorld)player.getWorld()).getHandle().a((Entity)((CraftPlayer)player).getHandle(), (byte)35);
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public List<PotionEffect> getDefaultEffects(PotionMeta meta, boolean isLingering) {
/* 1038 */     PotionType type = meta.getBasePotionType();
/* 1039 */     return type.getPotionEffects();
/*      */   }
/*      */ 
/*      */   
/*      */   public void dropItem(Player player, ItemStack it) {
/* 1044 */     ((CraftPlayer)player).getHandle().a(CraftItemStack.asNMSCopy(it), true);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setArrow(Arrow arrow, ItemStack itemStack) {
/* 1049 */     (((CraftArrow)arrow).getHandle()).s = CraftItemStack.asNMSCopy(itemStack);
/*      */   }
/*      */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\version\MVE_V1_20_3.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */