/*     */ package com.starshootercity.version;
/*     */ import com.destroystokyo.paper.entity.ai.Goal;
/*     */ import com.starshootercity.APITarget;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.function.Predicate;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import net.kyori.adventure.text.Component;
/*     */ import net.kyori.adventure.util.TriState;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.NamespacedKey;
/*     */ import org.bukkit.Particle;
/*     */ import org.bukkit.attribute.Attribute;
/*     */ import org.bukkit.attribute.AttributeInstance;
/*     */ import org.bukkit.attribute.AttributeModifier;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.block.Conduit;
/*     */ import org.bukkit.enchantments.Enchantment;
/*     */ import org.bukkit.entity.Arrow;
/*     */ import org.bukkit.entity.Creeper;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.LivingEntity;
/*     */ import org.bukkit.entity.Mob;
/*     */ import org.bukkit.entity.Piglin;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.entity.EntityDamageEvent;
/*     */ import org.bukkit.inventory.EquipmentSlot;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.potion.PotionEffect;
/*     */ import org.bukkit.potion.PotionEffectType;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ @APITarget
/*     */ public abstract class MultiVersionExecutor extends NMSInvoker {
/*     */   public boolean isCustomAttribute(AttributeModifier modifier) {
/*  40 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void launchArrow(Entity paramEntity1, Entity paramEntity2, float paramFloat1, float paramFloat2, float paramFloat3);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void transferDamageEvent(LivingEntity paramLivingEntity, EntityDamageEvent paramEntityDamageEvent);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void boostArrow(Arrow paramArrow);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean duplicateAllay(LivingEntity paramLivingEntity);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void dealExplosionDamage(Player paramPlayer, int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void dealSonicBoomDamage(LivingEntity paramLivingEntity, int paramInt, Player paramPlayer);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Goal<Villager> getVillagerAfraidGoal(LivingEntity paramLivingEntity, Predicate<Player> paramPredicate);
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public abstract Player getNearestVisiblePlayer(Piglin paramPiglin);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void throwItem(Piglin paramPiglin, ItemStack paramItemStack, Location paramLocation);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void damageItem(ItemStack paramItemStack, int paramInt, Player paramPlayer);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void startAutoSpinAttack(Player paramPlayer, int paramInt, float paramFloat, ItemStack paramItemStack);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void tridentMove(Player paramPlayer);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void dealThornsDamage(Entity paramEntity1, int paramInt, Entity paramEntity2);
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public abstract Particle getElderGuardianParticle();
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public abstract Particle getWitchParticle();
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Goal<Mob> getIronGolemAttackGoal(LivingEntity paramLivingEntity, Predicate<Player> paramPredicate);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void bounce(Player paramPlayer);
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public abstract Particle getHappyVillagerParticle();
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void playTotemEffect(Player paramPlayer);
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public abstract List<PotionEffect> getDefaultEffects(PotionMeta paramPotionMeta, boolean paramBoolean);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void dropItem(Player paramPlayer, ItemStack paramItemStack);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void sendEntityData(Player paramPlayer, Entity paramEntity, byte paramByte);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void sendResourcePacks(Player paramPlayer, String paramString, Map<?, ResourcePackInfo> paramMap);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Goal<Creeper> getCreeperAfraidGoal(LivingEntity paramLivingEntity, BiPredicate<LivingEntity, Player> paramBiPredicate);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean wasTouchingWater(Player paramPlayer);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract float getDestroySpeed(ItemStack paramItemStack, Material paramMaterial);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract float getDestroySpeed(Material paramMaterial);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void setNoPhysics(Player paramPlayer, boolean paramBoolean);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void sendGamemodeUpdate(Player paramPlayer, GameMode paramGameMode, boolean paramBoolean);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void setArrow(Arrow paramArrow, ItemStack paramItemStack);
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void sendPhasingGamemodeUpdate(Player player, GameMode gameMode) {}
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public abstract Location getRespawnLocation(Player paramPlayer);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void resetRespawnLocation(Player paramPlayer);
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public abstract AttributeModifier getAttributeModifier(AttributeInstance paramAttributeInstance, Key paramKey);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void dealDryOutDamage(LivingEntity paramLivingEntity, int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void dealDrowningDamage(LivingEntity paramLivingEntity, int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void dealFreezeDamage(LivingEntity paramLivingEntity, int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean supportsInfiniteDuration();
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isUnderWater(LivingEntity paramLivingEntity);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void knockback(LivingEntity paramLivingEntity, double paramDouble1, double paramDouble2, double paramDouble3);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void setFlyingFallDamage(Player paramPlayer, TriState paramTriState);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void broadcastSlotBreak(Player paramPlayer, EquipmentSlot paramEquipmentSlot, Collection<Player> paramCollection);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void sendBlockDamage(Player paramPlayer, Location paramLocation, float paramFloat, Entity paramEntity);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void addAttributeModifier(AttributeInstance paramAttributeInstance, NamespacedKey paramNamespacedKey, String paramString, double paramDouble, AttributeModifier.Operation paramOperation);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void setWorldBorderOverlay(Player paramPlayer, boolean paramBoolean);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void setComments(FileConfiguration paramFileConfiguration, String paramString, List<String> paramList);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Component applyFont(Component paramComponent, Key paramKey);
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public abstract Material getOminousBottle();
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   protected abstract Attribute armorAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   protected abstract Attribute maxHealthAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   protected abstract Attribute movementSpeedAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   protected abstract Attribute flyingSpeedAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   protected abstract Attribute attackDamageAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   protected abstract Attribute attackKnockbackAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   protected abstract Attribute attackSpeedAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   protected abstract Attribute armorToughnessAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   protected abstract Attribute luckAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   protected abstract Attribute horseJumpStrengthAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   protected abstract Attribute spawnReinforcementsAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   protected abstract Attribute followRangeAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   protected abstract Attribute knockbackResistanceAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract Attribute fallDamageMultiplierAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract Attribute maxAbsorptionAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract Attribute safeFallDistanceAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract Attribute scaleAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract Attribute stepHeightAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract Attribute gravityAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract Attribute jumpStrengthAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract Attribute burningTimeAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract Attribute explosionKnockbackResistanceAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract Attribute movementEfficiencyAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract Attribute oxygenBonusAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract Attribute waterMovementEfficiencyAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract Attribute temptRangeAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract Attribute blockInteractionRangeAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract Attribute entityInteractionRangeAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract Attribute blockBreakSpeedAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract Attribute miningEfficiencyAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract Attribute sneakingSpeedAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract Attribute submergedMiningSpeedAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected abstract Attribute sweepingDamageRatioAttribute();
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   protected abstract Enchantment protectionEnchantment();
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   protected abstract Enchantment fireProtectionEnchantment();
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @Nullable
/*     */   public Attribute getSweepingDamageRatioAttribute() {
/* 428 */     return sweepingDamageRatioAttribute(); } @NotNull protected abstract Enchantment featherFallingEnchantment(); @NotNull protected abstract Enchantment blastProtectionEnchantment(); @NotNull protected abstract Enchantment projectileProtectionEnchantment(); @NotNull protected abstract Enchantment respirationEnchantment(); @NotNull protected abstract Enchantment aquaAffinityEnchantment(); @NotNull protected abstract Enchantment thornsEnchantment(); @NotNull protected abstract Enchantment depthStriderEnchantment(); @NotNull protected abstract Enchantment frostWalkerEnchantment(); @NotNull protected abstract Enchantment bindingCurseEnchantment(); @NotNull protected abstract Enchantment sharpnessEnchantment(); @NotNull protected abstract Enchantment smiteEnchantment(); @NotNull protected abstract Enchantment baneOfArthropodsEnchantment(); @NotNull protected abstract Enchantment knockbackEnchantment(); @NotNull protected abstract Enchantment fireAspectEnchantment(); @NotNull protected abstract Enchantment lootingEnchantment(); @NotNull protected abstract Enchantment sweepingEdgeEnchantment(); @NotNull protected abstract Enchantment efficiencyEnchantment(); @NotNull protected abstract Enchantment silkTouchEnchantment(); @NotNull protected abstract Enchantment unbreakingEnchantment(); @NotNull protected abstract Enchantment fortuneEnchantment(); @NotNull protected abstract Enchantment powerEnchantment(); @NotNull protected abstract Enchantment punchEnchantment(); @NotNull protected abstract Enchantment flameEnchantment(); @NotNull protected abstract Enchantment infinityEnchantment(); @NotNull protected abstract Enchantment luckOfTheSeaEnchantment(); @NotNull protected abstract Enchantment lureEnchantment(); @NotNull protected abstract Enchantment loyaltyEnchantment(); @NotNull protected abstract Enchantment impalingEnchantment(); @NotNull protected abstract Enchantment riptideEnchantment(); @NotNull protected abstract Enchantment channelingEnchantment(); @NotNull protected abstract Enchantment multishotEnchantment(); @NotNull protected abstract Enchantment quickChargeEnchantment(); @NotNull protected abstract Enchantment piercingEnchantment(); @Nullable protected abstract Enchantment densityEnchantment(); @Nullable protected abstract Enchantment breachEnchantment(); @Nullable protected abstract Enchantment windBurstEnchantment(); @NotNull protected abstract Enchantment mendingEnchantment(); @NotNull protected abstract Enchantment vanishingCurseEnchantment(); @NotNull protected abstract Enchantment soulSpeedEnchantment(); @Nullable protected abstract Enchantment swiftSneakEnchantment(); @NotNull public abstract ItemMeta setCustomModelData(ItemMeta paramItemMeta, int paramInt); public abstract int getConduitRange(Conduit paramConduit); public abstract void setTouchingWater(Player paramPlayer); public abstract boolean boneMeal(Block paramBlock, Player paramPlayer); @NotNull protected abstract PotionEffectType speedEffect(); @NotNull protected abstract PotionEffectType slownessEffect(); @NotNull protected abstract PotionEffectType hasteEffect(); @NotNull protected abstract PotionEffectType miningFatigueEffect(); @NotNull protected abstract PotionEffectType strengthEffect(); @NotNull protected abstract PotionEffectType instantHealthEffect(); @NotNull protected abstract PotionEffectType instantDamageEffect(); @NotNull protected abstract PotionEffectType jumpBoostEffect(); @NotNull protected abstract PotionEffectType nauseaEffect(); @NotNull protected abstract PotionEffectType regenerationEffect(); @NotNull protected abstract PotionEffectType resistanceEffect(); @NotNull protected abstract PotionEffectType fireResistanceEffect(); @NotNull protected abstract PotionEffectType waterBreathingEffect(); @NotNull protected abstract PotionEffectType invisibilityEffect(); @NotNull protected abstract PotionEffectType blindnessEffect(); @NotNull protected abstract PotionEffectType nightVisionEffect(); @NotNull protected abstract PotionEffectType hungerEffect(); @NotNull protected abstract PotionEffectType weaknessEffect(); @NotNull protected abstract PotionEffectType poisonEffect(); @NotNull protected abstract PotionEffectType witherEffect(); @NotNull protected abstract PotionEffectType healthBoostEffect(); @NotNull protected abstract PotionEffectType absorptionEffect(); @NotNull protected abstract PotionEffectType saturationEffect(); @NotNull protected abstract PotionEffectType glowingEffect(); @NotNull protected abstract PotionEffectType levitationEffect(); @NotNull protected abstract PotionEffectType luckEffect(); @NotNull protected abstract PotionEffectType badLuckEffect(); @NotNull protected abstract PotionEffectType slowFallingEffect(); @NotNull protected abstract PotionEffectType conduitPowerEffect(); @NotNull protected abstract PotionEffectType dolphinsGraceEffect(); @NotNull protected abstract PotionEffectType badOmenEffect(); @NotNull protected abstract PotionEffectType heroOfTheVillageEffect(); @Nullable protected abstract PotionEffectType darknessEffect(); @Nullable protected abstract PotionEffectType trialOmenEffect(); @Nullable protected abstract PotionEffectType raidOmenEffect(); @Nullable
/*     */   protected abstract PotionEffectType windChargedEffect(); @Nullable
/*     */   protected abstract PotionEffectType weavingEffect(); @Nullable
/*     */   protected abstract PotionEffectType oozingEffect(); @Nullable
/*     */   protected abstract PotionEffectType infestedEffect(); public void initialize() {} @Deprecated(forRemoval = true)
/*     */   @NotNull
/* 434 */   public Attribute getArmorAttribute() { return armorAttribute(); }
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @NotNull
/*     */   public Attribute getArmorToughnessAttribute() {
/* 440 */     return armorToughnessAttribute();
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @NotNull
/*     */   public Attribute getAttackDamageAttribute() {
/* 446 */     return attackDamageAttribute();
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @NotNull
/*     */   public Attribute getAttackKnockbackAttribute() {
/* 452 */     return attackKnockbackAttribute();
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @NotNull
/*     */   public Attribute getAttackSpeedAttribute() {
/* 458 */     return attackSpeedAttribute();
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @Nullable
/*     */   public Attribute getBlockBreakSpeedAttribute() {
/* 464 */     return blockBreakSpeedAttribute();
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @Nullable
/*     */   public Attribute getBlockInteractionRangeAttribute() {
/* 470 */     return blockInteractionRangeAttribute();
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @Nullable
/*     */   public Attribute getBurningTimeAttribute() {
/* 476 */     return burningTimeAttribute();
/*     */   }
/*     */   @Deprecated(forRemoval = true)
/*     */   @Nullable
/*     */   public Attribute getGenericScaleAttribute() {
/* 481 */     return scaleAttribute();
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @Nullable
/*     */   public Attribute getEntityInteractionRangeAttribute() {
/* 487 */     return entityInteractionRangeAttribute();
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @Nullable
/*     */   public Attribute getExplosionKnockbackResistanceAttribute() {
/* 493 */     return explosionKnockbackResistanceAttribute();
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @Nullable
/*     */   public Attribute getFallDamageMultiplierAttribute() {
/* 499 */     return fallDamageMultiplierAttribute();
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @NotNull
/*     */   public Attribute getFlyingSpeedAttribute() {
/* 505 */     return flyingSpeedAttribute();
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @NotNull
/*     */   public Attribute getFollowRangeAttribute() {
/* 511 */     return followRangeAttribute();
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @Nullable
/*     */   public Attribute getGravityAttribute() {
/* 517 */     return gravityAttribute();
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @NotNull
/*     */   public Attribute getHorseJumpStrengthAttribute() {
/* 523 */     return horseJumpStrengthAttribute();
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @Nullable
/*     */   public Attribute getJumpStrengthAttribute() {
/* 529 */     return jumpStrengthAttribute();
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @NotNull
/*     */   public Attribute getKnockbackResistanceAttribute() {
/* 535 */     return knockbackResistanceAttribute();
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @NotNull
/*     */   public Attribute getLuckAttribute() {
/* 541 */     return luckAttribute();
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @Nullable
/*     */   public Attribute getMaxAbsorptionAttribute() {
/* 547 */     return maxAbsorptionAttribute();
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @NotNull
/*     */   public Attribute getMaxHealthAttribute() {
/* 553 */     return maxHealthAttribute();
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @Nullable
/*     */   public Attribute getMiningEfficiencyAttribute() {
/* 559 */     return miningEfficiencyAttribute();
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @Nullable
/*     */   public Attribute getMovementEfficiencyAttribute() {
/* 565 */     return movementEfficiencyAttribute();
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @NotNull
/*     */   public Attribute getMovementSpeedAttribute() {
/* 571 */     return movementSpeedAttribute();
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @Nullable
/*     */   public Attribute getOxygenBonusAttribute() {
/* 577 */     return oxygenBonusAttribute();
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @Nullable
/*     */   public Attribute getSafeFallDistanceAttribute() {
/* 583 */     return safeFallDistanceAttribute();
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @Nullable
/*     */   public Attribute getScaleAttribute() {
/* 589 */     return scaleAttribute();
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @Nullable
/*     */   public Attribute getSneakingSpeedAttribute() {
/* 595 */     return sneakingSpeedAttribute();
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @NotNull
/*     */   public Attribute getSpawnReinforcementsAttribute() {
/* 601 */     return spawnReinforcementsAttribute();
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @Nullable
/*     */   public Attribute getStepHeightAttribute() {
/* 607 */     return stepHeightAttribute();
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @Nullable
/*     */   public Attribute getSubmergedMiningSpeedAttribute() {
/* 613 */     return submergedMiningSpeedAttribute();
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @Nullable
/*     */   public Attribute getTemptRangeAttribute() {
/* 619 */     return temptRangeAttribute();
/*     */   }
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   @Nullable
/*     */   public Attribute getWaterMovementEfficiencyAttribute() {
/* 625 */     return waterMovementEfficiencyAttribute();
/*     */   }
/*     */   @Deprecated(forRemoval = true)
/*     */   @NotNull
/*     */   public PotionEffectType getNauseaEffect() {
/* 630 */     return nauseaEffect();
/*     */   }
/*     */   @Deprecated(forRemoval = true)
/*     */   @NotNull
/*     */   public PotionEffectType getMiningFatigueEffect() {
/* 635 */     return miningFatigueEffect();
/*     */   }
/*     */   @Deprecated(forRemoval = true)
/*     */   @NotNull
/*     */   public PotionEffectType getHasteEffect() {
/* 640 */     return hasteEffect();
/*     */   }
/*     */   @Deprecated(forRemoval = true)
/*     */   @NotNull
/*     */   public PotionEffectType getJumpBoostEffect() {
/* 645 */     return jumpBoostEffect();
/*     */   }
/*     */   @Deprecated(forRemoval = true)
/*     */   @NotNull
/*     */   public PotionEffectType getSlownessEffect() {
/* 650 */     return slownessEffect();
/*     */   }
/*     */   @Deprecated(forRemoval = true)
/*     */   @NotNull
/*     */   public PotionEffectType getStrengthEffect() {
/* 655 */     return strengthEffect();
/*     */   }
/*     */   @Deprecated(forRemoval = true)
/*     */   @NotNull
/*     */   public Enchantment getUnbreakingEnchantment() {
/* 660 */     return unbreakingEnchantment();
/*     */   }
/*     */   @Deprecated(forRemoval = true)
/*     */   @NotNull
/*     */   public Enchantment getEfficiencyEnchantment() {
/* 665 */     return efficiencyEnchantment();
/*     */   }
/*     */   @Deprecated(forRemoval = true)
/*     */   @NotNull
/*     */   public Enchantment getRespirationEnchantment() {
/* 670 */     return respirationEnchantment();
/*     */   }
/*     */   @Deprecated(forRemoval = true)
/*     */   @NotNull
/*     */   public Enchantment getAquaAffinityEnchantment() {
/* 675 */     return aquaAffinityEnchantment();
/*     */   }
/*     */   @Deprecated(forRemoval = true)
/*     */   @NotNull
/*     */   public Enchantment getBaneOfArthropodsEnchantment() {
/* 680 */     return baneOfArthropodsEnchantment();
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\version\MultiVersionExecutor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */