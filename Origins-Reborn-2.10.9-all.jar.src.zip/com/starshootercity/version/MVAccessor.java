/*    */ package com.starshootercity.version;
/*    */ 
/*    */ import com.starshootercity.APITarget;
/*    */ import com.starshootercity.AbstractScheduleManager;
/*    */ import com.starshootercity.FoliaScheduleManager;
/*    */ import com.starshootercity.ScheduleManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @APITarget
/*    */ public class MVAccessor
/*    */ {
/* 15 */   private static MultiVersionExecutor mve = null;
/* 16 */   private static AbstractScheduleManager sm = null;
/*    */   
/*    */   public static void startInitialize(String version) {
/* 19 */     if (mve != null)
/* 20 */       return;  switch (version) { case "1.18.1": 
/*    */       case "1.18.2": 
/*    */       case "1.19": 
/*    */       case "1.19.1": 
/*    */       case "1.19.2": 
/*    */       case "1.19.3": 
/*    */       case "1.19.4": 
/*    */       case "1.20": 
/*    */       case "1.20.1": 
/*    */       case "1.20.2": 
/*    */       case "1.20.3": 
/*    */       case "1.20.4": 
/*    */       case "1.20.5": case "1.20.6": 
/*    */       case "1.21": 
/*    */       case "1.21.1": 
/*    */       case "1.21.2": case "1.21.3": 
/*    */       case "1.21.4": 
/*    */       case "1.21.5": 
/*    */       case "1.21.6": 
/*    */       case "1.21.7": 
/*    */       case "1.21.8": 
/*    */       case "1.21.9": 
/*    */       default:
/* 43 */         break; }  mve = getLatestMVE();
/*    */     
/* 45 */     if (isFolia()) { sm = (AbstractScheduleManager)new FoliaScheduleManager(); }
/* 46 */     else { sm = (AbstractScheduleManager)new ScheduleManager(); }
/*    */   
/*    */   }
/*    */   private static boolean isFolia() {
/*    */     try {
/* 51 */       Class.forName("io.papermc.paper.threadedregions.RegionizedServer");
/* 52 */       return true;
/* 53 */     } catch (ClassNotFoundException e) {
/* 54 */       return false;
/*    */     } 
/*    */   }
/*    */   
/*    */   private static MultiVersionExecutor getLatestMVE() {
/* 59 */     return new MVE_V1_21_9();
/*    */   }
/*    */   
/*    */   public static MultiVersionExecutor get() {
/* 63 */     return mve;
/*    */   }
/*    */   
/*    */   public static AbstractScheduleManager scheduleManager() {
/* 67 */     return sm;
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\version\MVAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */