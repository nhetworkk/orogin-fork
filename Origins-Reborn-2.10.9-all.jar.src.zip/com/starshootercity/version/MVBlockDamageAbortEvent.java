/*    */ package com.starshootercity.version;
/*    */ 
/*    */ import com.starshootercity.APITarget;
/*    */ import org.bukkit.block.Block;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.HandlerList;
/*    */ import org.bukkit.event.block.BlockEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ @APITarget
/*    */ public class MVBlockDamageAbortEvent
/*    */   extends BlockEvent {
/* 14 */   private static final HandlerList handlers = new HandlerList();
/*    */   private final Player player;
/*    */   private final ItemStack itemstack;
/*    */   
/*    */   public MVBlockDamageAbortEvent(@NotNull Player player, @NotNull Block block, @NotNull ItemStack itemInHand) {
/* 19 */     super(block);
/* 20 */     this.player = player;
/* 21 */     this.itemstack = itemInHand;
/*    */   }
/*    */   @NotNull
/*    */   public Player getPlayer() {
/* 25 */     return this.player;
/*    */   }
/*    */   @NotNull
/*    */   public ItemStack getItemInHand() {
/* 29 */     return this.itemstack;
/*    */   }
/*    */   @NotNull
/*    */   public HandlerList getHandlers() {
/* 33 */     return handlers;
/*    */   }
/*    */   @NotNull
/*    */   public static HandlerList getHandlerList() {
/* 37 */     return handlers;
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\version\MVBlockDamageAbortEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */