/*      */ package com.starshootercity.version;
/*      */ import com.destroystokyo.paper.entity.ai.Goal;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Optional;
/*      */ import java.util.function.BiPredicate;
/*      */ import java.util.function.Predicate;
/*      */ import net.kyori.adventure.key.Key;
/*      */ import net.kyori.adventure.resource.ResourcePackInfo;
/*      */ import net.kyori.adventure.resource.ResourcePackRequest;
/*      */ import net.kyori.adventure.text.Component;
/*      */ import net.minecraft.core.BlockPos;
/*      */ import net.minecraft.network.protocol.Packet;
/*      */ import net.minecraft.network.protocol.game.ClientboundGameEventPacket;
/*      */ import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket;
/*      */ import net.minecraft.network.protocol.game.ClientboundSetEntityDataPacket;
/*      */ import net.minecraft.network.syncher.SynchedEntityData;
/*      */ import net.minecraft.server.level.ServerPlayer;
/*      */ import net.minecraft.world.InteractionResult;
/*      */ import net.minecraft.world.entity.Entity;
/*      */ import net.minecraft.world.entity.LivingEntity;
/*      */ import net.minecraft.world.entity.PathfinderMob;
/*      */ import net.minecraft.world.entity.ai.goal.AvoidEntityGoal;
/*      */ import net.minecraft.world.entity.player.Player;
/*      */ import net.minecraft.world.item.ItemStack;
/*      */ import net.minecraft.world.level.GameType;
/*      */ import net.minecraft.world.phys.BlockHitResult;
/*      */ import net.minecraft.world.phys.Vec3;
/*      */ import org.bukkit.GameMode;
/*      */ import org.bukkit.Location;
/*      */ import org.bukkit.Material;
/*      */ import org.bukkit.NamespacedKey;
/*      */ import org.bukkit.Particle;
/*      */ import org.bukkit.WorldBorder;
/*      */ import org.bukkit.attribute.Attribute;
/*      */ import org.bukkit.attribute.AttributeInstance;
/*      */ import org.bukkit.attribute.AttributeModifier;
/*      */ import org.bukkit.block.Block;
/*      */ import org.bukkit.block.Conduit;
/*      */ import org.bukkit.configuration.file.FileConfiguration;
/*      */ import org.bukkit.craftbukkit.CraftWorld;
/*      */ import org.bukkit.craftbukkit.block.CraftBlockState;
/*      */ import org.bukkit.craftbukkit.entity.CraftEntity;
/*      */ import org.bukkit.craftbukkit.entity.CraftPlayer;
/*      */ import org.bukkit.craftbukkit.inventory.CraftItemStack;
/*      */ import org.bukkit.damage.DamageSource;
/*      */ import org.bukkit.damage.DamageType;
/*      */ import org.bukkit.enchantments.Enchantment;
/*      */ import org.bukkit.entity.Allay;
/*      */ import org.bukkit.entity.Arrow;
/*      */ import org.bukkit.entity.Entity;
/*      */ import org.bukkit.entity.LivingEntity;
/*      */ import org.bukkit.entity.Piglin;
/*      */ import org.bukkit.entity.Player;
/*      */ import org.bukkit.event.EventHandler;
/*      */ import org.bukkit.event.block.BlockDamageAbortEvent;
/*      */ import org.bukkit.event.entity.EntityDamageEvent;
/*      */ import org.bukkit.event.entity.EntityDismountEvent;
/*      */ import org.bukkit.event.entity.EntityMountEvent;
/*      */ import org.bukkit.inventory.EquipmentSlot;
/*      */ import org.bukkit.inventory.ItemStack;
/*      */ import org.bukkit.inventory.meta.ItemMeta;
/*      */ import org.bukkit.inventory.meta.PotionMeta;
/*      */ import org.bukkit.inventory.meta.components.CustomModelDataComponent;
/*      */ import org.bukkit.potion.PotionEffect;
/*      */ import org.bukkit.potion.PotionEffectType;
/*      */ import org.bukkit.potion.PotionType;
/*      */ import org.jetbrains.annotations.NotNull;
/*      */ import org.jetbrains.annotations.Nullable;
/*      */ 
/*      */ public class MVE_V1_21_7 extends MultiVersionExecutor {
/*      */   public boolean isCustomAttribute(AttributeModifier modifier) {
/*   73 */     return !modifier.getKey().getNamespace().equals("minecraft");
/*      */   }
/*      */ 
/*      */   
/*      */   public Component applyFont(Component component, Key font) {
/*   78 */     return component.font(font);
/*      */   }
/*      */ 
/*      */   
/*      */   public void sendEntityData(Player player, Entity entity, byte bytes) {
/*   83 */     ServerPlayer serverPlayer = ((CraftPlayer)player).getHandle();
/*   84 */     Entity target = ((CraftEntity)entity).getHandle();
/*      */     
/*   86 */     List<SynchedEntityData.DataValue<?>> eData = new ArrayList<>();
/*   87 */     eData.add(SynchedEntityData.DataValue.create(new EntityDataAccessor(0, EntityDataSerializers.BYTE), Byte.valueOf(bytes)));
/*   88 */     ClientboundSetEntityDataPacket metadata = new ClientboundSetEntityDataPacket(target.getId(), eData);
/*   89 */     serverPlayer.connection.send((Packet)metadata);
/*      */   }
/*      */ 
/*      */   
/*      */   public Goal<Creeper> getCreeperAfraidGoal(LivingEntity creeper, BiPredicate<LivingEntity, Player> hasAbility) {
/*   94 */     return (new AvoidEntityGoal((PathfinderMob)((CraftEntity)creeper)
/*   95 */         .getHandle(), Player.class, 6.0F, 1.0D, 1.2D, livingEntity -> {
/*      */           CraftEntity patt0$temp = livingEntity.getBukkitEntity();
/*      */ 
/*      */           
/*      */           if (patt0$temp instanceof Player) {
/*      */             Player player = (Player)patt0$temp;
/*      */ 
/*      */             
/*      */             return hasAbility.test(creeper, player);
/*      */           } 
/*      */           
/*      */           return false;
/*  107 */         })).asPaperGoal();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean wasTouchingWater(Player player) {
/*  112 */     return (((CraftPlayer)player).getHandle()).wasTouchingWater;
/*      */   }
/*      */ 
/*      */   
/*      */   public float getDestroySpeed(Material block) {
/*  117 */     return (((CraftBlockState)block.createBlockData().createBlockState()).getHandle()).destroySpeed;
/*      */   }
/*      */ 
/*      */   
/*      */   public float getDestroySpeed(ItemStack item, Material block) {
/*  122 */     BlockState b = ((CraftBlockState)block.createBlockData().createBlockState()).getHandle();
/*  123 */     ItemStack handle = CraftItemStack.asNMSCopy(item);
/*  124 */     return handle.getDestroySpeed(b);
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute armorAttribute() {
/*  129 */     return Attribute.ARMOR;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute maxHealthAttribute() {
/*  134 */     return Attribute.MAX_HEALTH;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute movementSpeedAttribute() {
/*  139 */     return Attribute.MOVEMENT_SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute attackDamageAttribute() {
/*  144 */     return Attribute.ATTACK_DAMAGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute flyingSpeedAttribute() {
/*  149 */     return Attribute.FLYING_SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute attackKnockbackAttribute() {
/*  154 */     return Attribute.ATTACK_KNOCKBACK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute attackSpeedAttribute() {
/*  159 */     return Attribute.ATTACK_SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute armorToughnessAttribute() {
/*  164 */     return Attribute.ARMOR_TOUGHNESS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute luckAttribute() {
/*  169 */     return Attribute.LUCK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute horseJumpStrengthAttribute() {
/*  174 */     return Attribute.JUMP_STRENGTH;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute spawnReinforcementsAttribute() {
/*  179 */     return Attribute.SPAWN_REINFORCEMENTS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute followRangeAttribute() {
/*  184 */     return Attribute.FOLLOW_RANGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute knockbackResistanceAttribute() {
/*  189 */     return Attribute.KNOCKBACK_RESISTANCE;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute fallDamageMultiplierAttribute() {
/*  194 */     return Attribute.FALL_DAMAGE_MULTIPLIER;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute maxAbsorptionAttribute() {
/*  199 */     return Attribute.MAX_ABSORPTION;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute safeFallDistanceAttribute() {
/*  204 */     return Attribute.SAFE_FALL_DISTANCE;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute scaleAttribute() {
/*  209 */     return Attribute.SCALE;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute stepHeightAttribute() {
/*  214 */     return Attribute.STEP_HEIGHT;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute gravityAttribute() {
/*  219 */     return Attribute.GRAVITY;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute jumpStrengthAttribute() {
/*  224 */     return Attribute.JUMP_STRENGTH;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute burningTimeAttribute() {
/*  229 */     return Attribute.BURNING_TIME;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute explosionKnockbackResistanceAttribute() {
/*  234 */     return Attribute.EXPLOSION_KNOCKBACK_RESISTANCE;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute movementEfficiencyAttribute() {
/*  239 */     return Attribute.MOVEMENT_EFFICIENCY;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute oxygenBonusAttribute() {
/*  244 */     return Attribute.OXYGEN_BONUS;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute waterMovementEfficiencyAttribute() {
/*  249 */     return Attribute.WATER_MOVEMENT_EFFICIENCY;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute temptRangeAttribute() {
/*  254 */     return Attribute.TEMPT_RANGE;
/*      */   }
/*      */ 
/*      */   
/*      */   @NotNull
/*      */   public ItemMeta setCustomModelData(ItemMeta meta, int cmd) {
/*  260 */     CustomModelDataComponent component = meta.getCustomModelDataComponent();
/*  261 */     component.setStrings(List.of(String.valueOf(cmd)));
/*  262 */     component.setFloats(List.of(Float.valueOf(cmd)));
/*  263 */     meta.setCustomModelDataComponent(component);
/*  264 */     return meta;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getConduitRange(Conduit conduit) {
/*  269 */     if (!conduit.isActive()) return 0; 
/*  270 */     return conduit.getRange();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setNoPhysics(Player player, boolean noPhysics) {
/*  275 */     (((CraftPlayer)player).getHandle()).noPhysics = noPhysics;
/*      */   }
/*      */ 
/*      */   
/*      */   public void sendGamemodeUpdate(Player player, GameMode gameMode, boolean bedrock) {
/*  280 */     ServerPlayer serverPlayer = ((CraftPlayer)player).getHandle();
/*  281 */     switch (gameMode) { default: throw new IncompatibleClassChangeError();
/*      */       case CREATIVE: 
/*      */       case SURVIVAL: 
/*      */       case ADVENTURE: 
/*  285 */       case SPECTATOR: break; }  GameType gameType = GameType.SPECTATOR;
/*      */     
/*  287 */     ClientboundPlayerInfoUpdatePacket.Entry entry = new ClientboundPlayerInfoUpdatePacket.Entry(serverPlayer.getUUID(), serverPlayer.getGameProfile(), true, 1, gameType, serverPlayer.getTabListDisplayName(), true, 0, (RemoteChatSession.Data)Optionull.map(serverPlayer.getChatSession(), RemoteChatSession::asData));
/*  288 */     ClientboundPlayerInfoUpdatePacket packet = new ClientboundPlayerInfoUpdatePacket(EnumSet.of(ClientboundPlayerInfoUpdatePacket.Action.UPDATE_GAME_MODE), entry);
/*  289 */     serverPlayer.connection.send((Packet)packet);
/*      */     
/*  291 */     if (bedrock) {
/*  292 */       ClientboundGameEventPacket eventPacket = new ClientboundGameEventPacket(ClientboundGameEventPacket.CHANGE_GAME_MODE, gameType.getId());
/*  293 */       serverPlayer.connection.send((Packet)eventPacket);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void sendResourcePacks(Player player, String pack, Map<?, ResourcePackInfo> extraPacks) {
/*      */     try {
/*  302 */       ResourcePackInfo packInfo = ResourcePackInfo.resourcePackInfo().uri(URI.create(pack)).computeHashAndBuild().get();
/*  303 */       List<ResourcePackInfo> packs = new ArrayList<>();
/*  304 */       packs.add(packInfo);
/*  305 */       for (ResourcePackInfo resourcePackInfo : extraPacks.values()) {
/*  306 */         Object object = resourcePackInfo.packInfo(); if (object instanceof ResourcePackInfo) { ResourcePackInfo info = (ResourcePackInfo)object;
/*  307 */           packs.add(info); }
/*      */       
/*      */       } 
/*  310 */       player.sendResourcePacks((ResourcePackRequest)ResourcePackRequest.resourcePackRequest()
/*  311 */           .packs(packs)
/*  312 */           .required(true)
/*  313 */           .build());
/*      */     }
/*  315 */     catch (InterruptedException|java.util.concurrent.ExecutionException e) {
/*  316 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Location getRespawnLocation(Player player) {
/*  322 */     return player.getRespawnLocation();
/*      */   }
/*      */ 
/*      */   
/*      */   public void resetRespawnLocation(Player player) {
/*  327 */     player.setRespawnLocation(null);
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public AttributeModifier getAttributeModifier(AttributeInstance instance, Key key) {
/*  332 */     return instance.getModifier(key);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addAttributeModifier(AttributeInstance instance, NamespacedKey key, String name, double amount, AttributeModifier.Operation operation) {
/*  337 */     instance.addModifier(new AttributeModifier(key, amount, operation, EquipmentSlotGroup.ANY));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void dealDryOutDamage(LivingEntity entity, int amount) {
/*  343 */     entity.damage(amount, DamageSource.builder(DamageType.DRY_OUT).build());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void dealFreezeDamage(LivingEntity entity, int amount) {
/*  349 */     entity.damage(amount, DamageSource.builder(DamageType.FREEZE).build());
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsInfiniteDuration() {
/*  354 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isUnderWater(LivingEntity entity) {
/*  359 */     return entity.isUnderWater();
/*      */   }
/*      */ 
/*      */   
/*      */   public void knockback(LivingEntity entity, double strength, double x, double z) {
/*  364 */     entity.knockback(strength, x, z);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setFlyingFallDamage(Player player, TriState state) {
/*  369 */     player.setFlyingFallDamage(state);
/*      */   }
/*      */ 
/*      */   
/*      */   public void broadcastSlotBreak(Player player, EquipmentSlot slot, Collection<Player> players) {
/*  374 */     player.broadcastSlotBreak(slot, players);
/*      */   }
/*      */ 
/*      */   
/*      */   public void sendBlockDamage(Player player, Location location, float damage, Entity entity) {
/*  379 */     player.sendBlockDamage(location, damage, entity);
/*      */   }
/*      */ 
/*      */   
/*      */   public Attribute blockInteractionRangeAttribute() {
/*  384 */     return Attribute.BLOCK_INTERACTION_RANGE;
/*      */   }
/*      */ 
/*      */   
/*      */   public Attribute entityInteractionRangeAttribute() {
/*  389 */     return Attribute.ENTITY_INTERACTION_RANGE;
/*      */   }
/*      */ 
/*      */   
/*      */   public Attribute blockBreakSpeedAttribute() {
/*  394 */     return Attribute.BLOCK_BREAK_SPEED;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute miningEfficiencyAttribute() {
/*  399 */     return Attribute.MINING_EFFICIENCY;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute sneakingSpeedAttribute() {
/*  404 */     return Attribute.SNEAKING_SPEED;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute submergedMiningSpeedAttribute() {
/*  409 */     return Attribute.SUBMERGED_MINING_SPEED;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute sweepingDamageRatioAttribute() {
/*  414 */     return Attribute.SWEEPING_DAMAGE_RATIO;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setWorldBorderOverlay(Player player, boolean show) {
/*  419 */     if (show)
/*  420 */     { WorldBorder border = Bukkit.createWorldBorder();
/*  421 */       border.setCenter(player.getWorld().getWorldBorder().getCenter());
/*  422 */       border.setSize(player.getWorld().getWorldBorder().getSize());
/*  423 */       border.setWarningDistance((int)(player.getWorld().getWorldBorder().getSize() * 2.0D));
/*  424 */       player.setWorldBorder(border); }
/*  425 */     else { player.setWorldBorder(null); }
/*      */   
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealDrowningDamage(LivingEntity entity, int amount) {
/*  431 */     entity.damage(amount, DamageSource.builder(DamageType.DROWN).build());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setComments(FileConfiguration config, String path, List<String> comments) {
/*  436 */     config.setComments(path, comments);
/*      */   }
/*      */   
/*      */   @EventHandler
/*      */   public void onBlockDamageAbort(BlockDamageAbortEvent event) {
/*  441 */     (new MVBlockDamageAbortEvent(event.getPlayer(), event.getBlock(), event.getItemInHand())).callEvent();
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Material getOminousBottle() {
/*  446 */     return Material.OMINOUS_BOTTLE;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTouchingWater(Player player) {
/*  451 */     (((CraftPlayer)player).getHandle()).wasTouchingWater = true;
/*      */   }
/*      */   
/*  454 */   private final ItemStack boneMeal = CraftItemStack.asNMSCopy(ItemStack.of(Material.BONE_MEAL));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean boneMeal(Block block, Player player) {
/*  461 */     BlockPos blockPos = new BlockPos(block.getX(), block.getY(), block.getZ());
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  466 */     BlockHitResult bhr = new BlockHitResult(Vec3.atCenterOf((Vec3i)blockPos), ((CraftPlayer)player).getHandle().getDirection(), blockPos, false);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  471 */     InteractionResult result = BoneMealItem.applyBonemeal(new UseOnContext((Level)((CraftWorld)player
/*  472 */           .getWorld()).getHandle(), (Player)((CraftPlayer)player)
/*  473 */           .getHandle(), InteractionHand.MAIN_HAND, this.boneMeal, bhr));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  478 */     return (result == InteractionResult.SUCCESS);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void dealExplosionDamage(Player player, int amount) {
/*  484 */     player.damage(amount, DamageSource.builder(DamageType.EXPLOSION).build());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void dealSonicBoomDamage(LivingEntity entity, int amount, Player source) {
/*  490 */     entity.damage(amount, DamageSource.builder(DamageType.SONIC_BOOM).build());
/*      */   }
/*      */ 
/*      */   
/*      */   public Goal<Villager> getVillagerAfraidGoal(LivingEntity villager, Predicate<Player> hasAbility) {
/*  495 */     return (new AvoidEntityGoal((PathfinderMob)((CraftEntity)villager)
/*  496 */         .getHandle(), Player.class, 6.0F, 0.5D, 0.8D, livingEntity -> {
/*      */           CraftEntity patt0$temp = livingEntity.getBukkitEntity();
/*      */ 
/*      */           
/*      */           if (patt0$temp instanceof Player) {
/*      */             Player player = (Player)patt0$temp;
/*      */             
/*      */             return hasAbility.test(player);
/*      */           } 
/*      */           
/*      */           return false;
/*  507 */         })).asPaperGoal();
/*      */   }
/*      */ 
/*      */   
/*      */   public void throwItem(Piglin piglin, ItemStack itemStack, Location pos) {
/*  512 */     BehaviorUtils.throwItem(((CraftLivingEntity)piglin).getHandle(), CraftItemStack.asNMSCopy(itemStack), new Vec3(pos.getX(), pos.getY(), pos.getZ()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void launchArrow(Entity projectile, Entity entity, float roll, float force, float divergence) {
/*  517 */     ((AbstractProjectile)projectile).getHandle().shootFromRotation(((CraftEntity)entity).getHandle(), entity.getPitch(), entity.getYaw(), roll, force, divergence);
/*      */   }
/*      */ 
/*      */   
/*      */   public void damageItem(ItemStack item, int amount, Player player) {
/*  522 */     item.damage(amount, (LivingEntity)player);
/*      */   }
/*      */ 
/*      */   
/*      */   public void startAutoSpinAttack(Player player, int duration, float riptideAttackDamage, ItemStack item) {
/*  527 */     ((CraftPlayer)player).getHandle().startAutoSpinAttack(duration, riptideAttackDamage, CraftItemStack.asNMSCopy(item));
/*      */   }
/*      */ 
/*      */   
/*      */   public void tridentMove(Player player) {
/*  532 */     ((CraftPlayer)player).getHandle().move(MoverType.SELF, new Vec3(0.0D, 1.1999999284744263D, 0.0D));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void transferDamageEvent(LivingEntity entity, EntityDamageEvent event) {
/*  538 */     entity.damage(event.getDamage(), event.getDamageSource());
/*      */   }
/*      */ 
/*      */   
/*      */   public void boostArrow(Arrow arrow) {
/*  543 */     if (arrow.getBasePotionType() == null)
/*  544 */       return;  for (PotionEffect effect : arrow.getBasePotionType().getPotionEffects()) {
/*  545 */       arrow.addCustomEffect(effect.withDuration(effect.getDuration()).withAmplifier(effect.getAmplifier() + 1), true);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean duplicateAllay(LivingEntity entity) {
/*      */     Allay allay;
/*  551 */     if (entity instanceof Allay) { allay = (Allay)entity; } else { return false; }
/*  552 */      if (allay.getDuplicationCooldown() > 0L) return false; 
/*  553 */     allay.duplicateAllay();
/*  554 */     ((CraftWorld)allay.getWorld()).getHandle().broadcastEntityEvent((Entity)((CraftAllay)allay).getHandle(), (byte)18);
/*  555 */     return true;
/*      */   }
/*      */   
/*      */   @EventHandler
/*      */   public void onEntityDismount(EntityDismountEvent event) {
/*  560 */     event.setCancelled(!(new MVEntityDismountEvent(event.getEntity(), event.getDismounted(), event.isCancellable())).callEvent());
/*      */   }
/*      */   
/*      */   @EventHandler
/*      */   public void onEntityMount(EntityMountEvent event) {
/*  565 */     event.setCancelled(!(new MVEntityMountEvent(event.getEntity(), event.getMount())).callEvent());
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType speedEffect() {
/*  570 */     return PotionEffectType.SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType slownessEffect() {
/*  575 */     return PotionEffectType.SLOWNESS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType hasteEffect() {
/*  580 */     return PotionEffectType.HASTE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType miningFatigueEffect() {
/*  585 */     return PotionEffectType.MINING_FATIGUE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType strengthEffect() {
/*  590 */     return PotionEffectType.STRENGTH;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType instantHealthEffect() {
/*  595 */     return PotionEffectType.INSTANT_HEALTH;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType instantDamageEffect() {
/*  600 */     return PotionEffectType.INSTANT_DAMAGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType jumpBoostEffect() {
/*  605 */     return PotionEffectType.JUMP_BOOST;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType nauseaEffect() {
/*  610 */     return PotionEffectType.NAUSEA;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType regenerationEffect() {
/*  615 */     return PotionEffectType.REGENERATION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType resistanceEffect() {
/*  620 */     return PotionEffectType.RESISTANCE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType fireResistanceEffect() {
/*  625 */     return PotionEffectType.FIRE_RESISTANCE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType waterBreathingEffect() {
/*  630 */     return PotionEffectType.WATER_BREATHING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType invisibilityEffect() {
/*  635 */     return PotionEffectType.INVISIBILITY;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType blindnessEffect() {
/*  640 */     return PotionEffectType.BLINDNESS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType nightVisionEffect() {
/*  645 */     return PotionEffectType.NIGHT_VISION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType hungerEffect() {
/*  650 */     return PotionEffectType.HUNGER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType weaknessEffect() {
/*  655 */     return PotionEffectType.WEAKNESS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType poisonEffect() {
/*  660 */     return PotionEffectType.POISON;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType witherEffect() {
/*  665 */     return PotionEffectType.WITHER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType healthBoostEffect() {
/*  670 */     return PotionEffectType.HEALTH_BOOST;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType absorptionEffect() {
/*  675 */     return PotionEffectType.ABSORPTION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType saturationEffect() {
/*  680 */     return PotionEffectType.SATURATION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType glowingEffect() {
/*  685 */     return PotionEffectType.GLOWING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType levitationEffect() {
/*  690 */     return PotionEffectType.LEVITATION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType luckEffect() {
/*  695 */     return PotionEffectType.LUCK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType badLuckEffect() {
/*  700 */     return PotionEffectType.UNLUCK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType slowFallingEffect() {
/*  705 */     return PotionEffectType.SLOW_FALLING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType conduitPowerEffect() {
/*  710 */     return PotionEffectType.CONDUIT_POWER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType dolphinsGraceEffect() {
/*  715 */     return PotionEffectType.DOLPHINS_GRACE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType badOmenEffect() {
/*  720 */     return PotionEffectType.BAD_OMEN;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType heroOfTheVillageEffect() {
/*  725 */     return PotionEffectType.HERO_OF_THE_VILLAGE;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType darknessEffect() {
/*  730 */     return PotionEffectType.DARKNESS;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType trialOmenEffect() {
/*  735 */     return PotionEffectType.TRIAL_OMEN;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType raidOmenEffect() {
/*  740 */     return PotionEffectType.RAID_OMEN;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType windChargedEffect() {
/*  745 */     return PotionEffectType.WIND_CHARGED;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType weavingEffect() {
/*  750 */     return PotionEffectType.WEAVING;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType oozingEffect() {
/*  755 */     return PotionEffectType.OOZING;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType infestedEffect() {
/*  760 */     return PotionEffectType.INFESTED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment protectionEnchantment() {
/*  765 */     return Enchantment.PROTECTION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment fireProtectionEnchantment() {
/*  770 */     return Enchantment.FIRE_PROTECTION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment featherFallingEnchantment() {
/*  775 */     return Enchantment.FEATHER_FALLING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment blastProtectionEnchantment() {
/*  780 */     return Enchantment.BLAST_PROTECTION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment projectileProtectionEnchantment() {
/*  785 */     return Enchantment.PROJECTILE_PROTECTION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment respirationEnchantment() {
/*  790 */     return Enchantment.RESPIRATION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment aquaAffinityEnchantment() {
/*  795 */     return Enchantment.AQUA_AFFINITY;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment thornsEnchantment() {
/*  800 */     return Enchantment.THORNS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment depthStriderEnchantment() {
/*  805 */     return Enchantment.DEPTH_STRIDER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment frostWalkerEnchantment() {
/*  810 */     return Enchantment.FROST_WALKER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment bindingCurseEnchantment() {
/*  815 */     return Enchantment.BINDING_CURSE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment sharpnessEnchantment() {
/*  820 */     return Enchantment.SHARPNESS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment smiteEnchantment() {
/*  825 */     return Enchantment.SMITE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment baneOfArthropodsEnchantment() {
/*  830 */     return Enchantment.BANE_OF_ARTHROPODS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment knockbackEnchantment() {
/*  835 */     return Enchantment.KNOCKBACK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment fireAspectEnchantment() {
/*  840 */     return Enchantment.FIRE_ASPECT;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment lootingEnchantment() {
/*  845 */     return Enchantment.LOOTING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment sweepingEdgeEnchantment() {
/*  850 */     return Enchantment.SWEEPING_EDGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment efficiencyEnchantment() {
/*  855 */     return Enchantment.EFFICIENCY;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment silkTouchEnchantment() {
/*  860 */     return Enchantment.SILK_TOUCH;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment unbreakingEnchantment() {
/*  865 */     return Enchantment.UNBREAKING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment fortuneEnchantment() {
/*  870 */     return Enchantment.FORTUNE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment powerEnchantment() {
/*  875 */     return Enchantment.POWER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment punchEnchantment() {
/*  880 */     return Enchantment.PUNCH;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment flameEnchantment() {
/*  885 */     return Enchantment.FLAME;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment infinityEnchantment() {
/*  890 */     return Enchantment.INFINITY;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment luckOfTheSeaEnchantment() {
/*  895 */     return Enchantment.LUCK_OF_THE_SEA;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment lureEnchantment() {
/*  900 */     return Enchantment.LURE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment loyaltyEnchantment() {
/*  905 */     return Enchantment.LOYALTY;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment impalingEnchantment() {
/*  910 */     return Enchantment.IMPALING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment riptideEnchantment() {
/*  915 */     return Enchantment.RIPTIDE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment channelingEnchantment() {
/*  920 */     return Enchantment.CHANNELING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment multishotEnchantment() {
/*  925 */     return Enchantment.MULTISHOT;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment quickChargeEnchantment() {
/*  930 */     return Enchantment.QUICK_CHARGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment piercingEnchantment() {
/*  935 */     return Enchantment.PIERCING;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected Enchantment densityEnchantment() {
/*  940 */     return Enchantment.DENSITY;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected Enchantment breachEnchantment() {
/*  945 */     return Enchantment.BREACH;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected Enchantment windBurstEnchantment() {
/*  950 */     return Enchantment.WIND_BURST;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment mendingEnchantment() {
/*  955 */     return Enchantment.MENDING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment vanishingCurseEnchantment() {
/*  960 */     return Enchantment.VANISHING_CURSE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment soulSpeedEnchantment() {
/*  965 */     return Enchantment.SOUL_SPEED;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected Enchantment swiftSneakEnchantment() {
/*  970 */     return Enchantment.SWIFT_SNEAK;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Player getNearestVisiblePlayer(Piglin piglin) {
/*  975 */     Optional<Player> optional = ((CraftPiglin)piglin).getHandle().getBrain().getMemory(MemoryModuleType.NEAREST_VISIBLE_PLAYER);
/*  976 */     return optional.<Player>map(player -> (Player)player.getBukkitEntity()).orElse(null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealThornsDamage(Entity target, int amount, Entity attacker) {
/*  981 */     Entity entity = ((CraftEntity)target).getHandle();
/*  982 */     entity.hurtServer(entity.level().getMinecraftWorld(), entity.damageSources().thorns(((CraftEntity)attacker).getHandle()), amount);
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Particle getElderGuardianParticle() {
/*  987 */     return Particle.ELDER_GUARDIAN;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Particle getWitchParticle() {
/*  992 */     return Particle.WITCH;
/*      */   }
/*      */ 
/*      */   
/*      */   public Goal<Mob> getIronGolemAttackGoal(LivingEntity golem, Predicate<Player> hasAbility) {
/*  997 */     return (new NearestAttackableTargetGoal(((CraftMob)golem)
/*  998 */         .getHandle(), Player.class, 10, true, false, (livingEntity, server) -> {
/*      */           CraftEntity patt0$temp = livingEntity.getBukkitEntity();
/*      */           
/*      */           if (patt0$temp instanceof Player) {
/*      */             Player player = (Player)patt0$temp;
/*      */             
/*      */             return hasAbility.test(player);
/*      */           } 
/*      */           return false;
/* 1007 */         })).asPaperGoal();
/*      */   }
/*      */   
/* 1010 */   private final Map<Player, Vec3> lastVec3Map = new HashMap<>();
/*      */ 
/*      */ 
/*      */   
/*      */   public void bounce(Player player) {
/* 1015 */     ServerPlayer p = ((CraftPlayer)player).getHandle();
/* 1016 */     if (player.isOnGround()) {
/* 1017 */       if (player.getFallDistance() <= 0.0F)
/* 1018 */         return;  Vec3 dm = this.lastVec3Map.get(player);
/* 1019 */       if (dm != null) {
/* 1020 */         player.setVelocity(player.getVelocity().add(new Vector(0.0D, -dm.y, 0.0D)));
/*      */       }
/*      */     } 
/* 1023 */     this.lastVec3Map.put(player, p.getDeltaMovement());
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Particle getHappyVillagerParticle() {
/* 1028 */     return Particle.HAPPY_VILLAGER;
/*      */   }
/*      */ 
/*      */   
/*      */   public void playTotemEffect(Player player) {
/* 1033 */     ((CraftWorld)player.getWorld()).getHandle().broadcastEntityEvent((Entity)((CraftPlayer)player).getHandle(), (byte)35);
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public List<PotionEffect> getDefaultEffects(PotionMeta meta, boolean isLingering) {
/* 1038 */     PotionType type = meta.getBasePotionType();
/* 1039 */     if (type == null) return List.of(); 
/* 1040 */     return type.getPotionEffects();
/*      */   }
/*      */ 
/*      */   
/*      */   public void dropItem(Player player, ItemStack it) {
/* 1045 */     ((CraftPlayer)player).getHandle().drop(CraftItemStack.asNMSCopy(it), true);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setArrow(Arrow arrow, ItemStack itemStack) {
/* 1050 */     arrow.setItemStack(itemStack);
/*      */   }
/*      */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\version\MVE_V1_21_7.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */