/*    */ package com.starshootercity.version;
/*    */ 
/*    */ import com.starshootercity.APITarget;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @APITarget
/*    */ public class ResourcePackInfo
/*    */ {
/*    */   private final Object packInfo;
/*    */   
/*    */   public ResourcePackInfo(Object packInfo) {
/* 16 */     this.packInfo = packInfo;
/*    */   }
/*    */   
/*    */   public Object packInfo() {
/* 20 */     return this.packInfo;
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\version\ResourcePackInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */