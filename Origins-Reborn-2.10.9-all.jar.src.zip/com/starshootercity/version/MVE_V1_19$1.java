/*      */ package com.starshootercity.version;
/*      */ 
/*      */ import org.bukkit.GameMode;
/*      */ import org.bukkit.inventory.EquipmentSlot;
/*      */ import org.bukkit.potion.PotionType;
/*      */ 


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\version\MVE_V1_19$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */