/*    */ package com.starshootercity.version;
/*    */ 
/*    */ import com.starshootercity.APITarget;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.event.Cancellable;
/*    */ import org.bukkit.event.HandlerList;
/*    */ import org.bukkit.event.entity.EntityEvent;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ @APITarget
/*    */ public class MVEntityDismountEvent
/*    */   extends EntityEvent
/*    */   implements Cancellable
/*    */ {
/* 16 */   private static final HandlerList handlers = new HandlerList();
/*    */   private boolean cancelled;
/*    */   private final Entity dismounted;
/*    */   private final boolean isCancellable;
/*    */   
/*    */   public MVEntityDismountEvent(@NotNull Entity what, @NotNull Entity dismounted) {
/* 22 */     this(what, dismounted, true);
/*    */   }
/*    */   
/*    */   public MVEntityDismountEvent(@NotNull Entity what, @NotNull Entity dismounted, boolean isCancellable) {
/* 26 */     super(what);
/* 27 */     this.dismounted = dismounted;
/* 28 */     this.isCancellable = isCancellable;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Entity getDismounted() {
/* 33 */     return this.dismounted;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isCancelled() {
/* 38 */     return this.cancelled;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setCancelled(boolean cancel) {
/* 43 */     if (cancel && !this.isCancellable) {
/*    */       return;
/*    */     }
/* 46 */     this.cancelled = cancel;
/*    */   }
/*    */   
/*    */   public boolean isCancellable() {
/* 50 */     return this.isCancellable;
/*    */   }
/*    */ 
/*    */   
/*    */   @NotNull
/*    */   public HandlerList getHandlers() {
/* 56 */     return handlers;
/*    */   }
/*    */ 
/*    */   
/*    */   @NotNull
/*    */   public static HandlerList getHandlerList() {
/* 62 */     return handlers;
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\version\MVEntityDismountEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */