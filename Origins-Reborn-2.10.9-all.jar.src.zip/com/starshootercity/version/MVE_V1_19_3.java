/*      */ package com.starshootercity.version;
/*      */ import com.destroystokyo.paper.entity.ai.Goal;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Optional;
/*      */ import java.util.UUID;
/*      */ import java.util.function.BiPredicate;
/*      */ import java.util.function.Predicate;
/*      */ import net.kyori.adventure.key.Key;
/*      */ import net.kyori.adventure.text.Component;
/*      */ import net.minecraft.core.BlockPosition;
/*      */ import net.minecraft.network.PacketDataSerializer;
/*      */ import net.minecraft.network.protocol.Packet;
/*      */ import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket;
/*      */ import net.minecraft.network.protocol.game.PacketPlayOutBlockBreakAnimation;
/*      */ import net.minecraft.network.protocol.game.PacketPlayOutEntityMetadata;
/*      */ import net.minecraft.network.protocol.game.PacketPlayOutGameStateChange;
/*      */ import net.minecraft.network.syncher.DataWatcher;
/*      */ import net.minecraft.server.level.EntityPlayer;
/*      */ import net.minecraft.world.EnumInteractionResult;
/*      */ import net.minecraft.world.damagesource.DamageSource;
/*      */ import net.minecraft.world.effect.MobEffect;
/*      */ import net.minecraft.world.entity.Entity;
/*      */ import net.minecraft.world.entity.EntityLiving;
/*      */ import net.minecraft.world.entity.ai.goal.PathfinderGoalAvoidTarget;
/*      */ import net.minecraft.world.entity.player.EntityHuman;
/*      */ import net.minecraft.world.entity.projectile.EntityArrow;
/*      */ import net.minecraft.world.entity.projectile.EntityTippedArrow;
/*      */ import net.minecraft.world.item.ItemStack;
/*      */ import net.minecraft.world.level.EnumGamemode;
/*      */ import net.minecraft.world.level.block.entity.TileEntityConduit;
/*      */ import net.minecraft.world.phys.MovingObjectPositionBlock;
/*      */ import net.minecraft.world.phys.Vec3D;
/*      */ import org.bukkit.GameMode;
/*      */ import org.bukkit.Location;
/*      */ import org.bukkit.Material;
/*      */ import org.bukkit.NamespacedKey;
/*      */ import org.bukkit.Particle;
/*      */ import org.bukkit.WorldBorder;
/*      */ import org.bukkit.attribute.Attribute;
/*      */ import org.bukkit.attribute.AttributeInstance;
/*      */ import org.bukkit.attribute.AttributeModifier;
/*      */ import org.bukkit.block.Block;
/*      */ import org.bukkit.block.Conduit;
/*      */ import org.bukkit.configuration.file.FileConfiguration;
/*      */ import org.bukkit.craftbukkit.v1_19_R2.CraftWorld;
/*      */ import org.bukkit.craftbukkit.v1_19_R2.block.data.CraftBlockData;
/*      */ import org.bukkit.craftbukkit.v1_19_R2.entity.CraftEntity;
/*      */ import org.bukkit.craftbukkit.v1_19_R2.entity.CraftLivingEntity;
/*      */ import org.bukkit.craftbukkit.v1_19_R2.entity.CraftPlayer;
/*      */ import org.bukkit.craftbukkit.v1_19_R2.inventory.CraftItemStack;
/*      */ import org.bukkit.enchantments.Enchantment;
/*      */ import org.bukkit.entity.Allay;
/*      */ import org.bukkit.entity.Arrow;
/*      */ import org.bukkit.entity.Entity;
/*      */ import org.bukkit.entity.LivingEntity;
/*      */ import org.bukkit.entity.Piglin;
/*      */ import org.bukkit.entity.Player;
/*      */ import org.bukkit.event.EventHandler;
/*      */ import org.bukkit.event.block.BlockDamageAbortEvent;
/*      */ import org.bukkit.inventory.EquipmentSlot;
/*      */ import org.bukkit.inventory.ItemStack;
/*      */ import org.bukkit.inventory.meta.ItemMeta;
/*      */ import org.bukkit.inventory.meta.PotionMeta;
/*      */ import org.bukkit.potion.PotionEffect;
/*      */ import org.bukkit.potion.PotionEffectType;
/*      */ import org.bukkit.potion.PotionType;
/*      */ import org.jetbrains.annotations.NotNull;
/*      */ import org.jetbrains.annotations.Nullable;
/*      */ import org.spigotmc.event.entity.EntityDismountEvent;
/*      */ import org.spigotmc.event.entity.EntityMountEvent;
/*      */ 
/*      */ public class MVE_V1_19_3 extends MultiVersionExecutor {
/*      */   public void setTouchingWater(Player player) {
/*   76 */     (((CraftPlayer)player).getHandle()).T = true;
/*      */   }
/*      */   
/*   79 */   private final ItemStack boneMeal = CraftItemStack.asNMSCopy(new ItemStack(Material.BONE_MEAL));
/*      */   
/*      */   private static Field effectBlocks;
/*      */   
/*      */   private static Field isActive;
/*      */   
/*      */   public boolean boneMeal(Block block, Player player) {
/*   86 */     BlockPosition blockPos = new BlockPosition(block.getX(), block.getY(), block.getZ());
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   91 */     MovingObjectPositionBlock bhr = new MovingObjectPositionBlock(Vec3D.a((BaseBlockPosition)blockPos), ((CraftPlayer)player).getHandle().cA(), blockPos, false);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   96 */     EnumInteractionResult result = ItemBoneMeal.applyBonemeal(new ItemActionContext((World)((CraftWorld)player
/*   97 */           .getWorld()).getHandle(), (EntityHuman)((CraftPlayer)player)
/*   98 */           .getHandle(), EnumHand.a, this.boneMeal, bhr));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  103 */     return (result == EnumInteractionResult.a);
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute miningEfficiencyAttribute() {
/*  108 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute sneakingSpeedAttribute() {
/*  113 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute submergedMiningSpeedAttribute() {
/*  118 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute sweepingDamageRatioAttribute() {
/*  123 */     return null;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public ItemMeta setCustomModelData(ItemMeta meta, int cmd) {
/*  128 */     meta.setCustomModelData(Integer.valueOf(cmd));
/*  129 */     return meta;
/*      */   }
/*      */ 
/*      */   
/*      */   public void initialize() {
/*  134 */     String blocks = ReflectionRemapper.forReobfMappingsInPaperJar().remapFieldName(TileEntityConduit.class, "effectBlocks");
/*  135 */     String active = ReflectionRemapper.forReobfMappingsInPaperJar().remapFieldName(TileEntityConduit.class, "isActive");
/*      */     try {
/*  137 */       effectBlocks = TileEntityConduit.class.getDeclaredField(blocks);
/*  138 */       effectBlocks.setAccessible(true);
/*  139 */       isActive = TileEntityConduit.class.getDeclaredField(active);
/*  140 */       isActive.setAccessible(true);
/*  141 */     } catch (NoSuchFieldException e) {
/*  142 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getConduitRange(Conduit conduit) {
/*      */     try {
/*  153 */       TileEntityConduit tileEntity = (TileEntityConduit)((CraftConduit)conduit).getTileEntity();
/*  154 */       boolean active = ((Boolean)isActive.get(tileEntity)).booleanValue();
/*  155 */       if (!active) return 0; 
/*  156 */       List<BlockPosition> list = (List<BlockPosition>)effectBlocks.get(tileEntity);
/*  157 */       int i = list.size();
/*  158 */       return i / 7 * 16;
/*  159 */     } catch (IllegalAccessException e) {
/*  160 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute flyingSpeedAttribute() {
/*  166 */     return Attribute.GENERIC_FLYING_SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute attackKnockbackAttribute() {
/*  171 */     return Attribute.GENERIC_ATTACK_KNOCKBACK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute attackSpeedAttribute() {
/*  176 */     return Attribute.GENERIC_ATTACK_SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute armorToughnessAttribute() {
/*  181 */     return Attribute.GENERIC_ARMOR_TOUGHNESS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute luckAttribute() {
/*  186 */     return Attribute.GENERIC_LUCK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute horseJumpStrengthAttribute() {
/*  191 */     return Attribute.HORSE_JUMP_STRENGTH;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute spawnReinforcementsAttribute() {
/*  196 */     return Attribute.ZOMBIE_SPAWN_REINFORCEMENTS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute followRangeAttribute() {
/*  201 */     return Attribute.GENERIC_FOLLOW_RANGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute knockbackResistanceAttribute() {
/*  206 */     return Attribute.GENERIC_KNOCKBACK_RESISTANCE;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute fallDamageMultiplierAttribute() {
/*  211 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute maxAbsorptionAttribute() {
/*  216 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute safeFallDistanceAttribute() {
/*  221 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute scaleAttribute() {
/*  226 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute stepHeightAttribute() {
/*  231 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute gravityAttribute() {
/*  236 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute jumpStrengthAttribute() {
/*  241 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute burningTimeAttribute() {
/*  246 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute explosionKnockbackResistanceAttribute() {
/*  251 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute movementEfficiencyAttribute() {
/*  256 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute oxygenBonusAttribute() {
/*  261 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute waterMovementEfficiencyAttribute() {
/*  266 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute temptRangeAttribute() {
/*  271 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealDrowningDamage(LivingEntity entity, int amount) {
/*  276 */     EntityLiving livingEntity = ((CraftLivingEntity)entity).getHandle();
/*  277 */     livingEntity.a(DamageSource.h, amount);
/*      */   }
/*      */ 
/*      */   
/*      */   public Component applyFont(Component component, Key font) {
/*  282 */     return component.font(font);
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Material getOminousBottle() {
/*  287 */     return null;
/*      */   }
/*      */   
/*      */   @EventHandler
/*      */   public void onBlockDamageAbort(BlockDamageAbortEvent event) {
/*  292 */     (new MVBlockDamageAbortEvent(event.getPlayer(), event.getBlock(), event.getItemInHand())).callEvent();
/*      */   }
/*      */ 
/*      */   
/*      */   public void sendEntityData(Player player, Entity entity, byte bytes) {
/*  297 */     EntityPlayer serverPlayer = ((CraftPlayer)player).getHandle();
/*  298 */     Entity target = ((CraftEntity)entity).getHandle();
/*      */     
/*  300 */     List<DataWatcher.b<?>> eData = new ArrayList<>();
/*  301 */     eData.add(DataWatcher.b.a(new DataWatcherObject(0, DataWatcherRegistry.a), Byte.valueOf(bytes)));
/*  302 */     PacketPlayOutEntityMetadata metadata = new PacketPlayOutEntityMetadata(target.ah(), eData);
/*  303 */     serverPlayer.b.a((Packet)metadata);
/*      */   }
/*      */ 
/*      */   
/*      */   public Goal<Creeper> getCreeperAfraidGoal(LivingEntity creeper, BiPredicate<LivingEntity, Player> hasAbility) {
/*  308 */     return (new PathfinderGoalAvoidTarget((EntityCreature)((CraftEntity)creeper)
/*  309 */         .getHandle(), EntityHuman.class, 6.0F, 1.0D, 1.2D, livingEntity -> {
/*      */           CraftEntity patt10423$temp = livingEntity.getBukkitEntity();
/*      */ 
/*      */           
/*      */           if (patt10423$temp instanceof Player) {
/*      */             Player player = (Player)patt10423$temp;
/*      */ 
/*      */             
/*      */             return hasAbility.test(creeper, player);
/*      */           } 
/*      */           
/*      */           return false;
/*  321 */         })).asPaperVanillaGoal();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean wasTouchingWater(Player player) {
/*  326 */     return (((CraftPlayer)player).getHandle()).T;
/*      */   }
/*      */ 
/*      */   
/*      */   public float getDestroySpeed(ItemStack item, Material block) {
/*  331 */     IBlockData b = ((CraftBlockData)block.createBlockData()).getState();
/*  332 */     ItemStack handle = CraftItemStack.asNMSCopy(item);
/*  333 */     return handle.a(b);
/*      */   }
/*      */ 
/*      */   
/*      */   public float getDestroySpeed(Material block) {
/*  338 */     return (((CraftBlockData)block.createBlockData()).getState()).k;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setNoPhysics(Player player, boolean noPhysics) {
/*  343 */     (((CraftPlayer)player).getHandle()).Q = noPhysics;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute armorAttribute() {
/*  348 */     return Attribute.GENERIC_ARMOR;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute maxHealthAttribute() {
/*  353 */     return Attribute.GENERIC_MAX_HEALTH;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute movementSpeedAttribute() {
/*  358 */     return Attribute.GENERIC_MOVEMENT_SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute attackDamageAttribute() {
/*  363 */     return Attribute.GENERIC_ATTACK_DAMAGE;
/*      */   }
/*      */ 
/*      */   
/*      */   public void sendGamemodeUpdate(Player player, GameMode gameMode, boolean bedrock) {
/*  368 */     EntityPlayer serverPlayer = ((CraftPlayer)player).getHandle();
/*      */     
/*  370 */     switch (gameMode) { default: throw new IncompatibleClassChangeError();
/*      */       case NIGHT_VISION: 
/*      */       case INVISIBILITY: 
/*      */       case JUMP: 
/*  374 */       case FIRE_RESISTANCE: break; }  EnumGamemode gameType = EnumGamemode.d;
/*      */ 
/*      */     
/*  377 */     PacketDataSerializer buf = new PacketDataSerializer(Unpooled.buffer());
/*  378 */     buf.a(EnumSet.of(ClientboundPlayerInfoUpdatePacket.a.c), ClientboundPlayerInfoUpdatePacket.a.class);
/*  379 */     buf.a(List.of("null"), (buf2, e) -> {
/*      */           buf2.a(serverPlayer.cs());
/*      */           
/*      */           buf2.d(gameType.a());
/*      */         });
/*  384 */     ClientboundPlayerInfoUpdatePacket packet = new ClientboundPlayerInfoUpdatePacket(buf);
/*  385 */     serverPlayer.b.a((Packet)packet);
/*      */     
/*  387 */     if (bedrock) {
/*  388 */       PacketPlayOutGameStateChange eventPacket = new PacketPlayOutGameStateChange(PacketPlayOutGameStateChange.d, gameType.a());
/*  389 */       serverPlayer.b.a((Packet)eventPacket);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void sendResourcePacks(Player player, String pack, Map<?, ResourcePackInfo> extraPacks) {
/*  396 */     player.setResourcePack(pack);
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Location getRespawnLocation(Player player) {
/*  401 */     return player.getBedSpawnLocation();
/*      */   }
/*      */ 
/*      */   
/*      */   public void resetRespawnLocation(Player player) {
/*  406 */     player.setBedSpawnLocation(null);
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public AttributeModifier getAttributeModifier(AttributeInstance instance, Key key) {
/*  411 */     UUID u = UUID.nameUUIDFromBytes(key.toString().getBytes());
/*  412 */     for (AttributeModifier am : instance.getModifiers()) {
/*  413 */       if (am.getUniqueId().equals(u)) return am; 
/*      */     } 
/*  415 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void addAttributeModifier(AttributeInstance instance, NamespacedKey key, String name, double amount, AttributeModifier.Operation operation) {
/*  420 */     instance.addModifier(new AttributeModifier(UUID.nameUUIDFromBytes(key.toString().getBytes()), name, amount, operation));
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsInfiniteDuration() {
/*  425 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isUnderWater(LivingEntity entity) {
/*  430 */     return entity.isUnderWater();
/*      */   }
/*      */ 
/*      */   
/*      */   public void knockback(LivingEntity entity, double strength, double x, double z) {
/*  435 */     entity.knockback(strength, x, z);
/*      */   }
/*      */ 
/*      */   
/*      */   public Attribute blockInteractionRangeAttribute() {
/*  440 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Attribute entityInteractionRangeAttribute() {
/*  445 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealDryOutDamage(LivingEntity entity, int amount) {
/*  450 */     EntityLiving livingEntity = ((CraftLivingEntity)entity).getHandle();
/*  451 */     livingEntity.a(DamageSource.r, amount);
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealFreezeDamage(LivingEntity entity, int amount) {
/*  456 */     EntityLiving livingEntity = ((CraftLivingEntity)entity).getHandle();
/*  457 */     livingEntity.a(DamageSource.t, amount);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setFlyingFallDamage(Player player, TriState state) {
/*  462 */     player.setFlyingFallDamage(state);
/*      */   }
/*      */ 
/*      */   
/*      */   public void broadcastSlotBreak(Player player, EquipmentSlot slot, Collection<Player> players) {
/*  467 */     player.broadcastSlotBreak(slot, players);
/*      */   }
/*      */ 
/*      */   
/*      */   public void sendBlockDamage(Player player, Location location, float damage, Entity entity) {
/*  472 */     PacketPlayOutBlockBreakAnimation packet = new PacketPlayOutBlockBreakAnimation(entity.getEntityId(), new BlockPosition(location.getX(), location.getY(), location.getZ()), (int)(damage * 10.0F));
/*  473 */     (((CraftPlayer)player).getHandle()).b.a((Packet)packet);
/*      */   }
/*      */ 
/*      */   
/*      */   public Attribute blockBreakSpeedAttribute() {
/*  478 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setWorldBorderOverlay(Player player, boolean show) {
/*  483 */     if (show)
/*  484 */     { WorldBorder border = Bukkit.createWorldBorder();
/*  485 */       border.setCenter(player.getWorld().getWorldBorder().getCenter());
/*  486 */       border.setSize(player.getWorld().getWorldBorder().getSize());
/*  487 */       border.setWarningDistance((int)(player.getWorld().getWorldBorder().getSize() * 2.0D));
/*  488 */       player.setWorldBorder(border); }
/*  489 */     else { player.setWorldBorder(null); }
/*      */   
/*      */   }
/*      */   
/*      */   public void setComments(FileConfiguration config, String path, List<String> comments) {
/*  494 */     config.setComments(path, comments);
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealExplosionDamage(Player player, int amount) {
/*  499 */     EntityPlayer serverPlayer = ((CraftPlayer)player).getHandle();
/*  500 */     serverPlayer.a(DamageSource.a(null), amount);
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealSonicBoomDamage(LivingEntity entity, int amount, Player source) {
/*  505 */     EntityPlayer serverPlayer = ((CraftPlayer)source).getHandle();
/*  506 */     Entity e = ((CraftEntity)entity).getHandle();
/*  507 */     e.a(DamageSource.e((Entity)serverPlayer), amount);
/*      */   }
/*      */ 
/*      */   
/*      */   public Goal<Villager> getVillagerAfraidGoal(LivingEntity villager, Predicate<Player> hasAbility) {
/*  512 */     return (new PathfinderGoalAvoidTarget((EntityCreature)((CraftEntity)villager)
/*  513 */         .getHandle(), EntityHuman.class, 6.0F, 0.5D, 0.8D, livingEntity -> {
/*      */           CraftEntity patt17629$temp = livingEntity.getBukkitEntity();
/*      */ 
/*      */           
/*      */           if (patt17629$temp instanceof Player) {
/*      */             Player player = (Player)patt17629$temp;
/*      */             
/*      */             return hasAbility.test(player);
/*      */           } 
/*      */           
/*      */           return false;
/*  524 */         })).asPaperVanillaGoal();
/*      */   }
/*      */ 
/*      */   
/*      */   public void throwItem(Piglin piglin, ItemStack itemStack, Location pos) {
/*  529 */     BehaviorUtil.a(((CraftLivingEntity)piglin).getHandle(), CraftItemStack.asNMSCopy(itemStack), new Vec3D(pos.getX(), pos.getY(), pos.getZ()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void launchArrow(Entity projectile, Entity entity, float roll, float force, float divergence) {
/*  534 */     ((AbstractProjectile)projectile).getHandle().a(((CraftEntity)entity).getHandle(), entity.getLocation().getPitch(), entity.getLocation().getYaw(), roll, force, divergence);
/*      */   }
/*      */ 
/*      */   
/*      */   public void damageItem(ItemStack item, int amount, Player player) {
/*  539 */     item.damage(amount, (LivingEntity)player);
/*      */   }
/*      */ 
/*      */   
/*      */   public void startAutoSpinAttack(Player player, int duration, float riptideAttackDamage, ItemStack item) {
/*  544 */     ((CraftPlayer)player).getHandle().t(duration);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tridentMove(Player player) {
/*  549 */     ((CraftPlayer)player).getHandle().a(EnumMoveType.a, new Vec3D(0.0D, 1.1999999284744263D, 0.0D));
/*      */   }
/*      */ 
/*      */   
/*      */   public void transferDamageEvent(LivingEntity entity, EntityDamageEvent event) {
/*  554 */     entity.damage(event.getDamage());
/*      */   }
/*      */ 
/*      */   
/*      */   public void boostArrow(Arrow arrow) {
/*  559 */     EntityArrow entityArrow = ((CraftArrow)arrow).getHandle(); if (entityArrow instanceof EntityTippedArrow) { EntityTippedArrow a = (EntityTippedArrow)entityArrow;
/*  560 */       for (MobEffect instance : PotionUtil.d(a.k()).a()) {
/*  561 */         a.a(new MobEffect(instance.b(), instance.c(), instance.d() + 1));
/*      */       } }
/*      */   
/*      */   }
/*      */   
/*      */   public boolean duplicateAllay(LivingEntity entity) {
/*      */     Allay allay;
/*  568 */     if (entity instanceof Allay) { allay = (Allay)entity; } else { return false; }
/*  569 */      if (allay.getDuplicationCooldown() > 0L) return false; 
/*  570 */     allay.duplicateAllay();
/*  571 */     ((CraftWorld)allay.getWorld()).getHandle().a((Entity)((CraftAllay)allay).getHandle(), (byte)18);
/*  572 */     return true;
/*      */   }
/*      */   
/*      */   @EventHandler
/*      */   public void onEntityDismount(EntityDismountEvent event) {
/*  577 */     event.setCancelled(!(new MVEntityDismountEvent(event.getEntity(), event.getDismounted(), event.isCancellable())).callEvent());
/*      */   }
/*      */   
/*      */   @EventHandler
/*      */   public void onEntityMount(EntityMountEvent event) {
/*  582 */     event.setCancelled(!(new MVEntityMountEvent(event.getEntity(), event.getMount())).callEvent());
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType speedEffect() {
/*  587 */     return PotionEffectType.SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType slownessEffect() {
/*  592 */     return PotionEffectType.SLOW;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType hasteEffect() {
/*  597 */     return PotionEffectType.FAST_DIGGING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType miningFatigueEffect() {
/*  602 */     return PotionEffectType.SLOW_DIGGING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType strengthEffect() {
/*  607 */     return PotionEffectType.INCREASE_DAMAGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType instantHealthEffect() {
/*  612 */     return PotionEffectType.HEAL;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType instantDamageEffect() {
/*  617 */     return PotionEffectType.HARM;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType jumpBoostEffect() {
/*  622 */     return PotionEffectType.JUMP;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType nauseaEffect() {
/*  627 */     return PotionEffectType.CONFUSION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType regenerationEffect() {
/*  632 */     return PotionEffectType.REGENERATION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType resistanceEffect() {
/*  637 */     return PotionEffectType.DAMAGE_RESISTANCE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType fireResistanceEffect() {
/*  642 */     return PotionEffectType.FIRE_RESISTANCE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType waterBreathingEffect() {
/*  647 */     return PotionEffectType.WATER_BREATHING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType invisibilityEffect() {
/*  652 */     return PotionEffectType.INVISIBILITY;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType blindnessEffect() {
/*  657 */     return PotionEffectType.BLINDNESS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType nightVisionEffect() {
/*  662 */     return PotionEffectType.NIGHT_VISION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType hungerEffect() {
/*  667 */     return PotionEffectType.HUNGER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType weaknessEffect() {
/*  672 */     return PotionEffectType.WEAKNESS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType poisonEffect() {
/*  677 */     return PotionEffectType.POISON;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType witherEffect() {
/*  682 */     return PotionEffectType.WITHER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType healthBoostEffect() {
/*  687 */     return PotionEffectType.HEALTH_BOOST;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType absorptionEffect() {
/*  692 */     return PotionEffectType.ABSORPTION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType saturationEffect() {
/*  697 */     return PotionEffectType.SATURATION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType glowingEffect() {
/*  702 */     return PotionEffectType.GLOWING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType levitationEffect() {
/*  707 */     return PotionEffectType.LEVITATION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType luckEffect() {
/*  712 */     return PotionEffectType.LUCK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType badLuckEffect() {
/*  717 */     return PotionEffectType.UNLUCK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType slowFallingEffect() {
/*  722 */     return PotionEffectType.SLOW_FALLING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType conduitPowerEffect() {
/*  727 */     return PotionEffectType.CONDUIT_POWER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType dolphinsGraceEffect() {
/*  732 */     return PotionEffectType.DOLPHINS_GRACE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType badOmenEffect() {
/*  737 */     return PotionEffectType.BAD_OMEN;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType heroOfTheVillageEffect() {
/*  742 */     return PotionEffectType.HERO_OF_THE_VILLAGE;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType darknessEffect() {
/*  747 */     return PotionEffectType.DARKNESS;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType trialOmenEffect() {
/*  752 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType raidOmenEffect() {
/*  757 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType windChargedEffect() {
/*  762 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType weavingEffect() {
/*  767 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType oozingEffect() {
/*  772 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType infestedEffect() {
/*  777 */     return null;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment protectionEnchantment() {
/*  782 */     return Enchantment.PROTECTION_ENVIRONMENTAL;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment fireProtectionEnchantment() {
/*  787 */     return Enchantment.PROTECTION_FIRE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment featherFallingEnchantment() {
/*  792 */     return Enchantment.PROTECTION_FALL;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment blastProtectionEnchantment() {
/*  797 */     return Enchantment.PROTECTION_EXPLOSIONS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment projectileProtectionEnchantment() {
/*  802 */     return Enchantment.PROTECTION_PROJECTILE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment respirationEnchantment() {
/*  807 */     return Enchantment.OXYGEN;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment aquaAffinityEnchantment() {
/*  812 */     return Enchantment.WATER_WORKER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment thornsEnchantment() {
/*  817 */     return Enchantment.THORNS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment depthStriderEnchantment() {
/*  822 */     return Enchantment.DEPTH_STRIDER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment frostWalkerEnchantment() {
/*  827 */     return Enchantment.FROST_WALKER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment bindingCurseEnchantment() {
/*  832 */     return Enchantment.BINDING_CURSE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment sharpnessEnchantment() {
/*  837 */     return Enchantment.DAMAGE_ALL;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment smiteEnchantment() {
/*  842 */     return Enchantment.DAMAGE_UNDEAD;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment baneOfArthropodsEnchantment() {
/*  847 */     return Enchantment.DAMAGE_ARTHROPODS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment knockbackEnchantment() {
/*  852 */     return Enchantment.KNOCKBACK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment fireAspectEnchantment() {
/*  857 */     return Enchantment.FIRE_ASPECT;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment lootingEnchantment() {
/*  862 */     return Enchantment.LOOT_BONUS_MOBS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment sweepingEdgeEnchantment() {
/*  867 */     return Enchantment.SWEEPING_EDGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment efficiencyEnchantment() {
/*  872 */     return Enchantment.DIG_SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment silkTouchEnchantment() {
/*  877 */     return Enchantment.SILK_TOUCH;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment unbreakingEnchantment() {
/*  882 */     return Enchantment.DURABILITY;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment fortuneEnchantment() {
/*  887 */     return Enchantment.LOOT_BONUS_BLOCKS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment powerEnchantment() {
/*  892 */     return Enchantment.ARROW_DAMAGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment punchEnchantment() {
/*  897 */     return Enchantment.ARROW_KNOCKBACK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment flameEnchantment() {
/*  902 */     return Enchantment.ARROW_FIRE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment infinityEnchantment() {
/*  907 */     return Enchantment.ARROW_INFINITE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment luckOfTheSeaEnchantment() {
/*  912 */     return Enchantment.LUCK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment lureEnchantment() {
/*  917 */     return Enchantment.LURE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment loyaltyEnchantment() {
/*  922 */     return Enchantment.LOYALTY;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment impalingEnchantment() {
/*  927 */     return Enchantment.IMPALING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment riptideEnchantment() {
/*  932 */     return Enchantment.RIPTIDE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment channelingEnchantment() {
/*  937 */     return Enchantment.CHANNELING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment multishotEnchantment() {
/*  942 */     return Enchantment.MULTISHOT;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment quickChargeEnchantment() {
/*  947 */     return Enchantment.QUICK_CHARGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment piercingEnchantment() {
/*  952 */     return Enchantment.PIERCING;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected Enchantment densityEnchantment() {
/*  957 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected Enchantment breachEnchantment() {
/*  962 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected Enchantment windBurstEnchantment() {
/*  967 */     return null;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment mendingEnchantment() {
/*  972 */     return Enchantment.MENDING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment vanishingCurseEnchantment() {
/*  977 */     return Enchantment.VANISHING_CURSE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment soulSpeedEnchantment() {
/*  982 */     return Enchantment.SOUL_SPEED;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected Enchantment swiftSneakEnchantment() {
/*  987 */     return Enchantment.SWIFT_SNEAK;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Player getNearestVisiblePlayer(Piglin piglin) {
/*  992 */     Optional<EntityHuman> optional = ((CraftPiglin)piglin).getHandle().dD().c(MemoryModuleType.k);
/*  993 */     return optional.<Player>map(player -> (Player)player.getBukkitEntity()).orElse(null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealThornsDamage(Entity target, int amount, Entity attacker) {
/*  998 */     Entity entity = ((CraftEntity)target).getHandle();
/*  999 */     entity.a(DamageSource.d(((CraftEntity)attacker).getHandle()), amount);
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Particle getElderGuardianParticle() {
/* 1004 */     return Particle.MOB_APPEARANCE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Particle getWitchParticle() {
/* 1009 */     return Particle.SPELL_WITCH;
/*      */   }
/*      */ 
/*      */   
/*      */   public Goal<Mob> getIronGolemAttackGoal(LivingEntity golem, Predicate<Player> hasAbility) {
/* 1014 */     return (new PathfinderGoalNearestAttackableTarget(((CraftMob)golem)
/* 1015 */         .getHandle(), EntityHuman.class, 10, true, false, livingEntity -> {
/*      */           CraftEntity patt31369$temp = livingEntity.getBukkitEntity();
/*      */           
/*      */           if (patt31369$temp instanceof Player) {
/*      */             Player player = (Player)patt31369$temp;
/*      */             
/*      */             return hasAbility.test(player);
/*      */           } 
/*      */           return false;
/* 1024 */         })).asPaperVanillaGoal();
/*      */   }
/*      */   
/* 1027 */   private final Map<Player, Vec3D> lastVec3Map = new HashMap<>();
/*      */ 
/*      */ 
/*      */   
/*      */   public void bounce(Player player) {
/* 1032 */     EntityPlayer p = ((CraftPlayer)player).getHandle();
/* 1033 */     if (player.isOnGround()) {
/* 1034 */       if (player.getFallDistance() <= 0.0F)
/* 1035 */         return;  Vec3D dm = this.lastVec3Map.get(player);
/* 1036 */       if (dm != null) {
/* 1037 */         player.setVelocity(player.getVelocity().add(new Vector(0.0D, -dm.d, 0.0D)));
/*      */       }
/*      */     } 
/* 1040 */     this.lastVec3Map.put(player, p.di());
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Particle getHappyVillagerParticle() {
/* 1045 */     return Particle.VILLAGER_HAPPY;
/*      */   }
/*      */ 
/*      */   
/*      */   public void playTotemEffect(Player player) {
/* 1050 */     ((CraftWorld)player.getWorld()).getHandle().a((Entity)((CraftPlayer)player).getHandle(), (byte)35);
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public List<PotionEffect> getDefaultEffects(PotionMeta meta, boolean isLingering) {
/* 1055 */     PotionType type = meta.getBasePotionData().getType();
/* 1056 */     if (type.getEffectType() == null) return Collections.emptyList();
/*      */     
/* 1058 */     if (type.equals(PotionType.TURTLE_MASTER)) {
/* 1059 */       float multiplier = (isLingering ? 1.0F : 0.25F) * (meta.getBasePotionData().isExtended() ? 2 : true);
/* 1060 */       return List.of(new PotionEffect(PotionEffectType.SLOW, (int)(multiplier * 400.0F), 
/* 1061 */             meta.getBasePotionData().isUpgraded() ? 5 : 4), new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, (int)(multiplier * 400.0F), 
/* 1062 */             meta.getBasePotionData().isUpgraded() ? 2 : 3));
/*      */     } 
/*      */     
/* 1065 */     return Collections.singletonList(new PotionEffect(type.getEffectType(), change(getDuration(type), meta.getBasePotionData().isExtended()), meta.getBasePotionData().isUpgraded() ? 1 : 0));
/*      */   }
/*      */   
/*      */   public int change(int duration, boolean extended) {
/* 1069 */     if (!extended) return duration; 
/* 1070 */     if (duration == 3600) return 9600; 
/* 1071 */     return duration * 2;
/*      */   }
/*      */   
/*      */   public int getDuration(PotionType type) {
/* 1075 */     switch (type) { case NIGHT_VISION: case INVISIBILITY: case JUMP: case FIRE_RESISTANCE: case SPEED: case WATER_BREATHING: case STRENGTH: case SLOWNESS: case WEAKNESS: case SLOW_FALLING: case POISON: case REGEN: case LUCK:  }  return 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1080 */       1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void dropItem(Player player, ItemStack it) {
/* 1086 */     ((CraftPlayer)player).getHandle().a(CraftItemStack.asNMSCopy(it), true);
/*      */   }
/*      */   
/*      */   public void setArrow(Arrow arrow, ItemStack itemStack) {}
/*      */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\version\MVE_V1_19_3.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */