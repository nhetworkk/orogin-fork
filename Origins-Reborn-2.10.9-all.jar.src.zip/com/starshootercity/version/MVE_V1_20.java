/*      */ package com.starshootercity.version;
/*      */ import com.destroystokyo.paper.entity.ai.Goal;
/*      */ import java.util.Collection;
/*      */ import java.util.EnumSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Optional;
/*      */ import java.util.UUID;
/*      */ import java.util.function.BiPredicate;
/*      */ import java.util.function.Predicate;
/*      */ import net.kyori.adventure.key.Key;
/*      */ import net.kyori.adventure.text.Component;
/*      */ import net.minecraft.core.BlockPosition;
/*      */ import net.minecraft.network.protocol.Packet;
/*      */ import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket;
/*      */ import net.minecraft.network.protocol.game.PacketPlayOutEntityMetadata;
/*      */ import net.minecraft.network.protocol.game.PacketPlayOutGameStateChange;
/*      */ import net.minecraft.network.syncher.DataWatcher;
/*      */ import net.minecraft.server.level.EntityPlayer;
/*      */ import net.minecraft.world.EnumInteractionResult;
/*      */ import net.minecraft.world.effect.MobEffect;
/*      */ import net.minecraft.world.entity.Entity;
/*      */ import net.minecraft.world.entity.EntityLiving;
/*      */ import net.minecraft.world.entity.ai.goal.PathfinderGoalAvoidTarget;
/*      */ import net.minecraft.world.entity.player.EntityHuman;
/*      */ import net.minecraft.world.entity.projectile.EntityArrow;
/*      */ import net.minecraft.world.entity.projectile.EntityTippedArrow;
/*      */ import net.minecraft.world.item.ItemStack;
/*      */ import net.minecraft.world.level.EnumGamemode;
/*      */ import net.minecraft.world.level.block.entity.TileEntityConduit;
/*      */ import net.minecraft.world.phys.MovingObjectPositionBlock;
/*      */ import net.minecraft.world.phys.Vec3D;
/*      */ import org.bukkit.GameMode;
/*      */ import org.bukkit.Location;
/*      */ import org.bukkit.Material;
/*      */ import org.bukkit.NamespacedKey;
/*      */ import org.bukkit.Particle;
/*      */ import org.bukkit.WorldBorder;
/*      */ import org.bukkit.attribute.Attribute;
/*      */ import org.bukkit.attribute.AttributeInstance;
/*      */ import org.bukkit.attribute.AttributeModifier;
/*      */ import org.bukkit.block.Block;
/*      */ import org.bukkit.block.Conduit;
/*      */ import org.bukkit.configuration.file.FileConfiguration;
/*      */ import org.bukkit.craftbukkit.v1_20_R1.CraftWorld;
/*      */ import org.bukkit.craftbukkit.v1_20_R1.block.data.CraftBlockData;
/*      */ import org.bukkit.craftbukkit.v1_20_R1.entity.CraftEntity;
/*      */ import org.bukkit.craftbukkit.v1_20_R1.entity.CraftLivingEntity;
/*      */ import org.bukkit.craftbukkit.v1_20_R1.entity.CraftPlayer;
/*      */ import org.bukkit.craftbukkit.v1_20_R1.inventory.CraftItemStack;
/*      */ import org.bukkit.enchantments.Enchantment;
/*      */ import org.bukkit.entity.Allay;
/*      */ import org.bukkit.entity.Arrow;
/*      */ import org.bukkit.entity.Entity;
/*      */ import org.bukkit.entity.LivingEntity;
/*      */ import org.bukkit.entity.Piglin;
/*      */ import org.bukkit.entity.Player;
/*      */ import org.bukkit.event.EventHandler;
/*      */ import org.bukkit.event.block.BlockDamageAbortEvent;
/*      */ import org.bukkit.inventory.EquipmentSlot;
/*      */ import org.bukkit.inventory.ItemStack;
/*      */ import org.bukkit.inventory.meta.ItemMeta;
/*      */ import org.bukkit.inventory.meta.PotionMeta;
/*      */ import org.bukkit.potion.PotionEffect;
/*      */ import org.bukkit.potion.PotionEffectType;
/*      */ import org.bukkit.potion.PotionType;
/*      */ import org.jetbrains.annotations.NotNull;
/*      */ import org.jetbrains.annotations.Nullable;
/*      */ import org.spigotmc.event.entity.EntityDismountEvent;
/*      */ import org.spigotmc.event.entity.EntityMountEvent;
/*      */ 
/*      */ public class MVE_V1_20 extends MultiVersionExecutor {
/*      */   public void setTouchingWater(Player player) {
/*   74 */     (((CraftPlayer)player).getHandle()).ah = true;
/*      */   }
/*      */   
/*   77 */   private final ItemStack boneMeal = CraftItemStack.asNMSCopy(new ItemStack(Material.BONE_MEAL));
/*      */   
/*      */   private static Field effectBlocks;
/*      */   
/*      */   private static Field isActive;
/*      */   
/*      */   public boolean boneMeal(Block block, Player player) {
/*   84 */     BlockPosition blockPos = new BlockPosition(block.getX(), block.getY(), block.getZ());
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   89 */     MovingObjectPositionBlock bhr = new MovingObjectPositionBlock(Vec3D.b((BaseBlockPosition)blockPos), ((CraftPlayer)player).getHandle().cB(), blockPos, false);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   94 */     EnumInteractionResult result = ItemBoneMeal.applyBonemeal(new ItemActionContext((World)((CraftWorld)player
/*   95 */           .getWorld()).getHandle(), (EntityHuman)((CraftPlayer)player)
/*   96 */           .getHandle(), EnumHand.a, this.boneMeal, bhr));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  101 */     return (result == EnumInteractionResult.a);
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute miningEfficiencyAttribute() {
/*  106 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute sneakingSpeedAttribute() {
/*  111 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute submergedMiningSpeedAttribute() {
/*  116 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute sweepingDamageRatioAttribute() {
/*  121 */     return null;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public ItemMeta setCustomModelData(ItemMeta meta, int cmd) {
/*  126 */     meta.setCustomModelData(Integer.valueOf(cmd));
/*  127 */     return meta;
/*      */   }
/*      */ 
/*      */   
/*      */   public void initialize() {
/*  132 */     String blocks = ReflectionRemapper.forReobfMappingsInPaperJar().remapFieldName(TileEntityConduit.class, "effectBlocks");
/*  133 */     String active = ReflectionRemapper.forReobfMappingsInPaperJar().remapFieldName(TileEntityConduit.class, "isActive");
/*      */     try {
/*  135 */       effectBlocks = TileEntityConduit.class.getDeclaredField(blocks);
/*  136 */       effectBlocks.setAccessible(true);
/*  137 */       isActive = TileEntityConduit.class.getDeclaredField(active);
/*  138 */       isActive.setAccessible(true);
/*  139 */     } catch (NoSuchFieldException e) {
/*  140 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getConduitRange(Conduit conduit) {
/*      */     try {
/*  151 */       TileEntityConduit tileEntity = (TileEntityConduit)((CraftConduit)conduit).getTileEntity();
/*  152 */       boolean active = ((Boolean)isActive.get(tileEntity)).booleanValue();
/*  153 */       if (!active) return 0; 
/*  154 */       List<BlockPosition> list = (List<BlockPosition>)effectBlocks.get(tileEntity);
/*  155 */       int i = list.size();
/*  156 */       return i / 7 * 16;
/*  157 */     } catch (IllegalAccessException e) {
/*  158 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute flyingSpeedAttribute() {
/*  164 */     return Attribute.GENERIC_FLYING_SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute attackKnockbackAttribute() {
/*  169 */     return Attribute.GENERIC_ATTACK_KNOCKBACK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute attackSpeedAttribute() {
/*  174 */     return Attribute.GENERIC_ATTACK_SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute armorToughnessAttribute() {
/*  179 */     return Attribute.GENERIC_ARMOR_TOUGHNESS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute luckAttribute() {
/*  184 */     return Attribute.GENERIC_LUCK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute horseJumpStrengthAttribute() {
/*  189 */     return Attribute.HORSE_JUMP_STRENGTH;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute spawnReinforcementsAttribute() {
/*  194 */     return Attribute.ZOMBIE_SPAWN_REINFORCEMENTS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute followRangeAttribute() {
/*  199 */     return Attribute.GENERIC_FOLLOW_RANGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute knockbackResistanceAttribute() {
/*  204 */     return Attribute.GENERIC_KNOCKBACK_RESISTANCE;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute fallDamageMultiplierAttribute() {
/*  209 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute maxAbsorptionAttribute() {
/*  214 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute safeFallDistanceAttribute() {
/*  219 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute scaleAttribute() {
/*  224 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute stepHeightAttribute() {
/*  229 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute gravityAttribute() {
/*  234 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute jumpStrengthAttribute() {
/*  239 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute burningTimeAttribute() {
/*  244 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute explosionKnockbackResistanceAttribute() {
/*  249 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute movementEfficiencyAttribute() {
/*  254 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute oxygenBonusAttribute() {
/*  259 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute waterMovementEfficiencyAttribute() {
/*  264 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Attribute temptRangeAttribute() {
/*  269 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealDrowningDamage(LivingEntity entity, int amount) {
/*  274 */     EntityLiving livingEntity = ((CraftLivingEntity)entity).getHandle();
/*  275 */     livingEntity.a(livingEntity.dJ().h(), amount);
/*      */   }
/*      */ 
/*      */   
/*      */   public Component applyFont(Component component, Key font) {
/*  280 */     return component.font(font);
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Material getOminousBottle() {
/*  285 */     return null;
/*      */   }
/*      */   
/*      */   @EventHandler
/*      */   public void onBlockDamageAbort(BlockDamageAbortEvent event) {
/*  290 */     (new MVBlockDamageAbortEvent(event.getPlayer(), event.getBlock(), event.getItemInHand())).callEvent();
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute armorAttribute() {
/*  295 */     return Attribute.GENERIC_ARMOR;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute maxHealthAttribute() {
/*  300 */     return Attribute.GENERIC_MAX_HEALTH;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute movementSpeedAttribute() {
/*  305 */     return Attribute.GENERIC_MOVEMENT_SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Attribute attackDamageAttribute() {
/*  310 */     return Attribute.GENERIC_ATTACK_DAMAGE;
/*      */   }
/*      */ 
/*      */   
/*      */   public void sendEntityData(Player player, Entity entity, byte bytes) {
/*  315 */     EntityPlayer serverPlayer = ((CraftPlayer)player).getHandle();
/*  316 */     Entity target = ((CraftEntity)entity).getHandle();
/*      */     
/*  318 */     List<DataWatcher.b<?>> eData = new ArrayList<>();
/*  319 */     eData.add(DataWatcher.b.a(new DataWatcherObject(0, DataWatcherRegistry.a), Byte.valueOf(bytes)));
/*  320 */     PacketPlayOutEntityMetadata metadata = new PacketPlayOutEntityMetadata(target.af(), eData);
/*  321 */     serverPlayer.c.a((Packet)metadata);
/*      */   }
/*      */ 
/*      */   
/*      */   public Goal<Creeper> getCreeperAfraidGoal(LivingEntity creeper, BiPredicate<LivingEntity, Player> hasAbility) {
/*  326 */     return (new PathfinderGoalAvoidTarget((EntityCreature)((CraftEntity)creeper)
/*  327 */         .getHandle(), EntityHuman.class, 6.0F, 1.0D, 1.2D, livingEntity -> {
/*      */           CraftEntity patt10794$temp = livingEntity.getBukkitEntity();
/*      */ 
/*      */           
/*      */           if (patt10794$temp instanceof Player) {
/*      */             Player player = (Player)patt10794$temp;
/*      */ 
/*      */             
/*      */             return hasAbility.test(creeper, player);
/*      */           } 
/*      */           
/*      */           return false;
/*  339 */         })).asPaperVanillaGoal();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean wasTouchingWater(Player player) {
/*  344 */     return (((CraftPlayer)player).getHandle()).ah;
/*      */   }
/*      */ 
/*      */   
/*      */   public float getDestroySpeed(ItemStack item, Material block) {
/*  349 */     IBlockData b = ((CraftBlockData)block.createBlockData()).getState();
/*  350 */     ItemStack handle = CraftItemStack.asNMSCopy(item);
/*  351 */     return handle.a(b);
/*      */   }
/*      */ 
/*      */   
/*      */   public float getDestroySpeed(Material block) {
/*  356 */     return (((CraftBlockData)block.createBlockData()).getState()).n;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setNoPhysics(Player player, boolean noPhysics) {
/*  361 */     (((CraftPlayer)player).getHandle()).ae = noPhysics;
/*      */   }
/*      */ 
/*      */   
/*      */   public void sendGamemodeUpdate(Player player, GameMode gameMode, boolean bedrock) {
/*  366 */     EntityPlayer serverPlayer = ((CraftPlayer)player).getHandle();
/*  367 */     switch (gameMode) { default: throw new IncompatibleClassChangeError();
/*      */       case NIGHT_VISION: 
/*      */       case INVISIBILITY: 
/*      */       case JUMP: 
/*  371 */       case FIRE_RESISTANCE: break; }  EnumGamemode gameType = EnumGamemode.d;
/*      */     
/*  373 */     ClientboundPlayerInfoUpdatePacket.b entry = new ClientboundPlayerInfoUpdatePacket.b(serverPlayer.ct(), serverPlayer.fM(), true, 1, gameType, serverPlayer.J(), (RemoteChatSession.a)Optionull.a(serverPlayer.X(), RemoteChatSession::b));
/*  374 */     ClientboundPlayerInfoUpdatePacket packet = new OriginsRebornClientboundPlayerInfoUpdatePacket(EnumSet.of(ClientboundPlayerInfoUpdatePacket.a.c), entry);
/*  375 */     serverPlayer.c.a((Packet)packet);
/*      */     
/*  377 */     if (bedrock) {
/*  378 */       PacketPlayOutGameStateChange eventPacket = new PacketPlayOutGameStateChange(PacketPlayOutGameStateChange.d, gameType.a());
/*  379 */       serverPlayer.c.a((Packet)eventPacket);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void sendResourcePacks(Player player, String pack, Map<?, ResourcePackInfo> extraPacks) {
/*  386 */     player.setResourcePack(pack);
/*      */   }
/*      */   
/*      */   public void setArrow(Arrow arrow, ItemStack itemStack) {}
/*      */   
/*      */   public static class OriginsRebornClientboundPlayerInfoUpdatePacket
/*      */     extends ClientboundPlayerInfoUpdatePacket {
/*      */     public OriginsRebornClientboundPlayerInfoUpdatePacket(EnumSet<ClientboundPlayerInfoUpdatePacket.a> actions, ClientboundPlayerInfoUpdatePacket.b entry) {
/*  394 */       super(actions, List.of());
/*  395 */       c().add(entry);
/*      */     }
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Location getRespawnLocation(Player player) {
/*  401 */     return player.getBedSpawnLocation();
/*      */   }
/*      */ 
/*      */   
/*      */   public void resetRespawnLocation(Player player) {
/*  406 */     player.setBedSpawnLocation(null);
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public AttributeModifier getAttributeModifier(AttributeInstance instance, Key key) {
/*  411 */     UUID u = UUID.nameUUIDFromBytes(key.toString().getBytes());
/*  412 */     for (AttributeModifier am : instance.getModifiers()) {
/*  413 */       if (am.getUniqueId().equals(u)) return am; 
/*      */     } 
/*  415 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void addAttributeModifier(AttributeInstance instance, NamespacedKey key, String name, double amount, AttributeModifier.Operation operation) {
/*  420 */     instance.addModifier(new AttributeModifier(UUID.nameUUIDFromBytes(key.toString().getBytes()), name, amount, operation));
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isUnderWater(LivingEntity entity) {
/*  425 */     return entity.isUnderWater();
/*      */   }
/*      */ 
/*      */   
/*      */   public void knockback(LivingEntity entity, double strength, double x, double z) {
/*  430 */     entity.knockback(strength, x, z);
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealDryOutDamage(LivingEntity entity, int amount) {
/*  435 */     EntityLiving livingEntity = ((CraftLivingEntity)entity).getHandle();
/*  436 */     livingEntity.a(livingEntity.dJ().r(), amount);
/*      */   }
/*      */ 
/*      */   
/*      */   public Attribute blockInteractionRangeAttribute() {
/*  441 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Attribute entityInteractionRangeAttribute() {
/*  446 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealFreezeDamage(LivingEntity entity, int amount) {
/*  451 */     EntityLiving livingEntity = ((CraftLivingEntity)entity).getHandle();
/*  452 */     livingEntity.a(livingEntity.dJ().t(), amount);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsInfiniteDuration() {
/*  457 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setFlyingFallDamage(Player player, TriState state) {
/*  462 */     player.setFlyingFallDamage(state);
/*      */   }
/*      */ 
/*      */   
/*      */   public void broadcastSlotBreak(Player player, EquipmentSlot slot, Collection<Player> players) {
/*  467 */     player.broadcastSlotBreak(slot, players);
/*      */   }
/*      */ 
/*      */   
/*      */   public void sendBlockDamage(Player player, Location location, float damage, Entity entity) {
/*  472 */     player.sendBlockDamage(location, damage, entity);
/*      */   }
/*      */ 
/*      */   
/*      */   public Attribute blockBreakSpeedAttribute() {
/*  477 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setWorldBorderOverlay(Player player, boolean show) {
/*  482 */     if (show)
/*  483 */     { WorldBorder border = Bukkit.createWorldBorder();
/*  484 */       border.setCenter(player.getWorld().getWorldBorder().getCenter());
/*  485 */       border.setSize(player.getWorld().getWorldBorder().getSize());
/*  486 */       border.setWarningDistance((int)(player.getWorld().getWorldBorder().getSize() * 2.0D));
/*  487 */       player.setWorldBorder(border); }
/*  488 */     else { player.setWorldBorder(null); }
/*      */   
/*      */   }
/*      */   
/*      */   public void setComments(FileConfiguration config, String path, List<String> comments) {
/*  493 */     config.setComments(path, comments);
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealExplosionDamage(Player player, int amount) {
/*  498 */     EntityPlayer serverPlayer = ((CraftPlayer)player).getHandle();
/*  499 */     serverPlayer.a(serverPlayer.dJ().a(null), amount);
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealSonicBoomDamage(LivingEntity entity, int amount, Player source) {
/*  504 */     EntityPlayer serverPlayer = ((CraftPlayer)source).getHandle();
/*  505 */     Entity e = ((CraftEntity)entity).getHandle();
/*  506 */     e.a(e.dJ().e((Entity)serverPlayer), amount);
/*      */   }
/*      */ 
/*      */   
/*      */   public Goal<Villager> getVillagerAfraidGoal(LivingEntity villager, Predicate<Player> hasAbility) {
/*  511 */     return (new PathfinderGoalAvoidTarget((EntityCreature)((CraftEntity)villager)
/*  512 */         .getHandle(), EntityHuman.class, 6.0F, 0.5D, 0.8D, livingEntity -> {
/*      */           CraftEntity patt17802$temp = livingEntity.getBukkitEntity();
/*      */ 
/*      */           
/*      */           if (patt17802$temp instanceof Player) {
/*      */             Player player = (Player)patt17802$temp;
/*      */             
/*      */             return hasAbility.test(player);
/*      */           } 
/*      */           
/*      */           return false;
/*  523 */         })).asPaperVanillaGoal();
/*      */   }
/*      */ 
/*      */   
/*      */   public void throwItem(Piglin piglin, ItemStack itemStack, Location pos) {
/*  528 */     BehaviorUtil.a(((CraftLivingEntity)piglin).getHandle(), CraftItemStack.asNMSCopy(itemStack), new Vec3D(pos.getX(), pos.getY(), pos.getZ()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void launchArrow(Entity projectile, Entity entity, float roll, float force, float divergence) {
/*  533 */     ((AbstractProjectile)projectile).getHandle().a(((CraftEntity)entity).getHandle(), entity.getLocation().getPitch(), entity.getLocation().getYaw(), roll, force, divergence);
/*      */   }
/*      */ 
/*      */   
/*      */   public void damageItem(ItemStack item, int amount, Player player) {
/*  538 */     item.damage(amount, (LivingEntity)player);
/*      */   }
/*      */ 
/*      */   
/*      */   public void startAutoSpinAttack(Player player, int duration, float riptideAttackDamage, ItemStack item) {
/*  543 */     ((CraftPlayer)player).getHandle().t(duration);
/*      */   }
/*      */ 
/*      */   
/*      */   public void tridentMove(Player player) {
/*  548 */     ((CraftPlayer)player).getHandle().a(EnumMoveType.a, new Vec3D(0.0D, 1.1999999284744263D, 0.0D));
/*      */   }
/*      */ 
/*      */   
/*      */   public void transferDamageEvent(LivingEntity entity, EntityDamageEvent event) {
/*  553 */     entity.damage(event.getDamage());
/*      */   }
/*      */ 
/*      */   
/*      */   public void boostArrow(Arrow arrow) {
/*  558 */     EntityArrow entityArrow = ((CraftArrow)arrow).getHandle(); if (entityArrow instanceof EntityTippedArrow) { EntityTippedArrow a = (EntityTippedArrow)entityArrow;
/*  559 */       for (MobEffect instance : PotionUtil.d(a.p()).a()) {
/*  560 */         a.a(new MobEffect(instance.c(), instance.d(), instance.e() + 1));
/*      */       } }
/*      */   
/*      */   }
/*      */   
/*      */   public boolean duplicateAllay(LivingEntity entity) {
/*      */     Allay allay;
/*  567 */     if (entity instanceof Allay) { allay = (Allay)entity; } else { return false; }
/*  568 */      if (allay.getDuplicationCooldown() > 0L) return false; 
/*  569 */     allay.duplicateAllay();
/*  570 */     ((CraftWorld)allay.getWorld()).getHandle().a((Entity)((CraftAllay)allay).getHandle(), (byte)18);
/*  571 */     return true;
/*      */   }
/*      */   
/*      */   @EventHandler
/*      */   public void onEntityDismount(EntityDismountEvent event) {
/*  576 */     event.setCancelled(!(new MVEntityDismountEvent(event.getEntity(), event.getDismounted(), event.isCancellable())).callEvent());
/*      */   }
/*      */   
/*      */   @EventHandler
/*      */   public void onEntityMount(EntityMountEvent event) {
/*  581 */     event.setCancelled(!(new MVEntityMountEvent(event.getEntity(), event.getMount())).callEvent());
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType speedEffect() {
/*  586 */     return PotionEffectType.SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType slownessEffect() {
/*  591 */     return PotionEffectType.SLOW;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType hasteEffect() {
/*  596 */     return PotionEffectType.FAST_DIGGING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType miningFatigueEffect() {
/*  601 */     return PotionEffectType.SLOW_DIGGING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType strengthEffect() {
/*  606 */     return PotionEffectType.INCREASE_DAMAGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType instantHealthEffect() {
/*  611 */     return PotionEffectType.HEAL;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType instantDamageEffect() {
/*  616 */     return PotionEffectType.HARM;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType jumpBoostEffect() {
/*  621 */     return PotionEffectType.JUMP;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType nauseaEffect() {
/*  626 */     return PotionEffectType.CONFUSION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType regenerationEffect() {
/*  631 */     return PotionEffectType.REGENERATION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType resistanceEffect() {
/*  636 */     return PotionEffectType.DAMAGE_RESISTANCE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType fireResistanceEffect() {
/*  641 */     return PotionEffectType.FIRE_RESISTANCE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType waterBreathingEffect() {
/*  646 */     return PotionEffectType.WATER_BREATHING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType invisibilityEffect() {
/*  651 */     return PotionEffectType.INVISIBILITY;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType blindnessEffect() {
/*  656 */     return PotionEffectType.BLINDNESS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType nightVisionEffect() {
/*  661 */     return PotionEffectType.NIGHT_VISION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType hungerEffect() {
/*  666 */     return PotionEffectType.HUNGER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType weaknessEffect() {
/*  671 */     return PotionEffectType.WEAKNESS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType poisonEffect() {
/*  676 */     return PotionEffectType.POISON;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType witherEffect() {
/*  681 */     return PotionEffectType.WITHER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType healthBoostEffect() {
/*  686 */     return PotionEffectType.HEALTH_BOOST;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType absorptionEffect() {
/*  691 */     return PotionEffectType.ABSORPTION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType saturationEffect() {
/*  696 */     return PotionEffectType.SATURATION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType glowingEffect() {
/*  701 */     return PotionEffectType.GLOWING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType levitationEffect() {
/*  706 */     return PotionEffectType.LEVITATION;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType luckEffect() {
/*  711 */     return PotionEffectType.LUCK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType badLuckEffect() {
/*  716 */     return PotionEffectType.UNLUCK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType slowFallingEffect() {
/*  721 */     return PotionEffectType.SLOW_FALLING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType conduitPowerEffect() {
/*  726 */     return PotionEffectType.CONDUIT_POWER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType dolphinsGraceEffect() {
/*  731 */     return PotionEffectType.DOLPHINS_GRACE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType badOmenEffect() {
/*  736 */     return PotionEffectType.BAD_OMEN;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected PotionEffectType heroOfTheVillageEffect() {
/*  741 */     return PotionEffectType.HERO_OF_THE_VILLAGE;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType darknessEffect() {
/*  746 */     return PotionEffectType.DARKNESS;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType trialOmenEffect() {
/*  751 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType raidOmenEffect() {
/*  756 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType windChargedEffect() {
/*  761 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType weavingEffect() {
/*  766 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType oozingEffect() {
/*  771 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected PotionEffectType infestedEffect() {
/*  776 */     return null;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment protectionEnchantment() {
/*  781 */     return Enchantment.PROTECTION_ENVIRONMENTAL;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment fireProtectionEnchantment() {
/*  786 */     return Enchantment.PROTECTION_FIRE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment featherFallingEnchantment() {
/*  791 */     return Enchantment.PROTECTION_FALL;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment blastProtectionEnchantment() {
/*  796 */     return Enchantment.PROTECTION_EXPLOSIONS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment projectileProtectionEnchantment() {
/*  801 */     return Enchantment.PROTECTION_PROJECTILE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment respirationEnchantment() {
/*  806 */     return Enchantment.OXYGEN;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment aquaAffinityEnchantment() {
/*  811 */     return Enchantment.WATER_WORKER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment thornsEnchantment() {
/*  816 */     return Enchantment.THORNS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment depthStriderEnchantment() {
/*  821 */     return Enchantment.DEPTH_STRIDER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment frostWalkerEnchantment() {
/*  826 */     return Enchantment.FROST_WALKER;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment bindingCurseEnchantment() {
/*  831 */     return Enchantment.BINDING_CURSE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment sharpnessEnchantment() {
/*  836 */     return Enchantment.DAMAGE_ALL;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment smiteEnchantment() {
/*  841 */     return Enchantment.DAMAGE_UNDEAD;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment baneOfArthropodsEnchantment() {
/*  846 */     return Enchantment.DAMAGE_ARTHROPODS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment knockbackEnchantment() {
/*  851 */     return Enchantment.KNOCKBACK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment fireAspectEnchantment() {
/*  856 */     return Enchantment.FIRE_ASPECT;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment lootingEnchantment() {
/*  861 */     return Enchantment.LOOT_BONUS_MOBS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment sweepingEdgeEnchantment() {
/*  866 */     return Enchantment.SWEEPING_EDGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment efficiencyEnchantment() {
/*  871 */     return Enchantment.DIG_SPEED;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment silkTouchEnchantment() {
/*  876 */     return Enchantment.SILK_TOUCH;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment unbreakingEnchantment() {
/*  881 */     return Enchantment.DURABILITY;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment fortuneEnchantment() {
/*  886 */     return Enchantment.LOOT_BONUS_BLOCKS;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment powerEnchantment() {
/*  891 */     return Enchantment.ARROW_DAMAGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment punchEnchantment() {
/*  896 */     return Enchantment.ARROW_KNOCKBACK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment flameEnchantment() {
/*  901 */     return Enchantment.ARROW_FIRE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment infinityEnchantment() {
/*  906 */     return Enchantment.ARROW_INFINITE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment luckOfTheSeaEnchantment() {
/*  911 */     return Enchantment.LUCK;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment lureEnchantment() {
/*  916 */     return Enchantment.LURE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment loyaltyEnchantment() {
/*  921 */     return Enchantment.LOYALTY;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment impalingEnchantment() {
/*  926 */     return Enchantment.IMPALING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment riptideEnchantment() {
/*  931 */     return Enchantment.RIPTIDE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment channelingEnchantment() {
/*  936 */     return Enchantment.CHANNELING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment multishotEnchantment() {
/*  941 */     return Enchantment.MULTISHOT;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment quickChargeEnchantment() {
/*  946 */     return Enchantment.QUICK_CHARGE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment piercingEnchantment() {
/*  951 */     return Enchantment.PIERCING;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected Enchantment densityEnchantment() {
/*  956 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected Enchantment breachEnchantment() {
/*  961 */     return null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected Enchantment windBurstEnchantment() {
/*  966 */     return null;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment mendingEnchantment() {
/*  971 */     return Enchantment.MENDING;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment vanishingCurseEnchantment() {
/*  976 */     return Enchantment.VANISHING_CURSE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   protected Enchantment soulSpeedEnchantment() {
/*  981 */     return Enchantment.SOUL_SPEED;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   protected Enchantment swiftSneakEnchantment() {
/*  986 */     return Enchantment.SWIFT_SNEAK;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Player getNearestVisiblePlayer(Piglin piglin) {
/*  991 */     Optional<EntityHuman> optional = ((CraftPiglin)piglin).getHandle().dK().c(MemoryModuleType.k);
/*  992 */     return optional.<Player>map(player -> (Player)player.getBukkitEntity()).orElse(null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void dealThornsDamage(Entity target, int amount, Entity attacker) {
/*  997 */     Entity entity = ((CraftEntity)target).getHandle();
/*  998 */     entity.a(entity.dJ().d(((CraftEntity)attacker).getHandle()), amount);
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Particle getElderGuardianParticle() {
/* 1003 */     return Particle.MOB_APPEARANCE;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Particle getWitchParticle() {
/* 1008 */     return Particle.SPELL_WITCH;
/*      */   }
/*      */ 
/*      */   
/*      */   public Goal<Mob> getIronGolemAttackGoal(LivingEntity golem, Predicate<Player> hasAbility) {
/* 1013 */     return (new PathfinderGoalNearestAttackableTarget(((CraftMob)golem)
/* 1014 */         .getHandle(), EntityHuman.class, 10, true, false, livingEntity -> {
/*      */           CraftEntity patt31552$temp = livingEntity.getBukkitEntity();
/*      */           
/*      */           if (patt31552$temp instanceof Player) {
/*      */             Player player = (Player)patt31552$temp;
/*      */             
/*      */             return hasAbility.test(player);
/*      */           } 
/*      */           return false;
/* 1023 */         })).asPaperVanillaGoal();
/*      */   }
/*      */   
/* 1026 */   private final Map<Player, Vec3D> lastVec3Map = new HashMap<>();
/*      */ 
/*      */ 
/*      */   
/*      */   public void bounce(Player player) {
/* 1031 */     EntityPlayer p = ((CraftPlayer)player).getHandle();
/* 1032 */     if (player.isOnGround()) {
/* 1033 */       if (player.getFallDistance() <= 0.0F)
/* 1034 */         return;  Vec3D dm = this.lastVec3Map.get(player);
/* 1035 */       if (dm != null) {
/* 1036 */         player.setVelocity(player.getVelocity().add(new Vector(0.0D, -dm.d, 0.0D)));
/*      */       }
/*      */     } 
/* 1039 */     this.lastVec3Map.put(player, p.dl());
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public Particle getHappyVillagerParticle() {
/* 1044 */     return Particle.VILLAGER_HAPPY;
/*      */   }
/*      */ 
/*      */   
/*      */   public void playTotemEffect(Player player) {
/* 1049 */     ((CraftWorld)player.getWorld()).getHandle().a((Entity)((CraftPlayer)player).getHandle(), (byte)35);
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public List<PotionEffect> getDefaultEffects(PotionMeta meta, boolean isLingering) {
/* 1054 */     PotionType type = meta.getBasePotionData().getType();
/* 1055 */     if (type.getEffectType() == null) return Collections.emptyList();
/*      */     
/* 1057 */     if (type.equals(PotionType.TURTLE_MASTER)) {
/* 1058 */       float multiplier = (isLingering ? 1.0F : 0.25F) * (meta.getBasePotionData().isExtended() ? 2 : true);
/* 1059 */       return List.of(new PotionEffect(PotionEffectType.SLOW, (int)(multiplier * 400.0F), 
/* 1060 */             meta.getBasePotionData().isUpgraded() ? 5 : 4), new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, (int)(multiplier * 400.0F), 
/* 1061 */             meta.getBasePotionData().isUpgraded() ? 2 : 3));
/*      */     } 
/*      */     
/* 1064 */     return Collections.singletonList(new PotionEffect(type.getEffectType(), change(getDuration(type), meta.getBasePotionData().isExtended()), meta.getBasePotionData().isUpgraded() ? 1 : 0));
/*      */   }
/*      */   
/*      */   public int change(int duration, boolean extended) {
/* 1068 */     if (!extended) return duration; 
/* 1069 */     if (duration == 3600) return 9600; 
/* 1070 */     return duration * 2;
/*      */   }
/*      */   
/*      */   public int getDuration(PotionType type) {
/* 1074 */     switch (type) { case NIGHT_VISION: case INVISIBILITY: case JUMP: case FIRE_RESISTANCE: case SPEED: case WATER_BREATHING: case STRENGTH: case SLOWNESS: case WEAKNESS: case SLOW_FALLING: case POISON: case REGEN: case LUCK:  }  return 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1079 */       1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void dropItem(Player player, ItemStack it) {
/* 1085 */     ((CraftPlayer)player).getHandle().a(CraftItemStack.asNMSCopy(it), true);
/*      */   }
/*      */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\version\MVE_V1_20.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */