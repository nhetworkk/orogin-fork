/*     */ package com.starshootercity.geysermc;
/*     */ import com.starshootercity.AddonLoader;
/*     */ import com.starshootercity.Origin;
/*     */ import com.starshootercity.OriginSwapper;
/*     */ import com.starshootercity.OriginsReborn;
/*     */ import com.starshootercity.commands.OriginCommand;
/*     */ import com.starshootercity.events.PlayerSwapOriginEvent;
/*     */ import com.starshootercity.util.VaultHook;
/*     */ import com.starshootercity.util.config.ConfigManager;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import java.util.UUID;
/*     */ import net.kyori.adventure.text.Component;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.geysermc.cumulus.form.Form;
/*     */ import org.geysermc.cumulus.form.ModalForm;
/*     */ import org.geysermc.cumulus.form.SimpleForm;
/*     */ import org.geysermc.cumulus.response.ModalFormResponse;
/*     */ import org.geysermc.cumulus.response.SimpleFormResponse;
/*     */ import org.geysermc.cumulus.util.FormImage;
/*     */ import org.geysermc.floodgate.api.FloodgateApi;
/*     */ 
/*     */ public class GeyserSwapper {
/*     */   public static boolean checkBedrockSwap(Player player, PlayerSwapOriginEvent.SwapReason reason, boolean cost, boolean displayOnly, String layer) {
/*     */     try {
/*  30 */       if (!ShortcutUtils.isBedrockPlayer(player.getUniqueId())) {
/*  31 */         return true;
/*     */       }
/*  33 */       openOriginSwapper(player, reason, displayOnly, cost, layer);
/*  34 */       return false;
/*     */     }
/*  36 */     catch (NoClassDefFoundError e) {
/*  37 */       return true;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void openOriginSwapper(Player player, PlayerSwapOriginEvent.SwapReason reason, boolean displayOnly, boolean cost, String layer) {
/*  42 */     List<Origin> origins = new ArrayList<>(AddonLoader.getOrigins(layer));
/*  43 */     if (!displayOnly) { origins.removeIf(origin -> (origin.isUnchoosable(player) || (origin.hasPermission() && !player.hasPermission(origin.getPermission())))); }
/*     */     else
/*  45 */     { Origin origin = OriginSwapper.getOrigin(player, layer);
/*  46 */       if (origin != null) openOriginInfo(player, origin, PlayerSwapOriginEvent.SwapReason.COMMAND, true, false, layer); 
/*     */       return; }
/*     */     
/*  49 */     origins.sort((o1, o2) -> (o1.getImpact() == o2.getImpact()) ? ((o1.getPosition() == o2.getPosition()) ? 0 : ((o1.getPosition() > o2.getPosition()) ? 1 : -1)) : ((o1.getImpact() > o2.getImpact()) ? 1 : -1));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  57 */     SimpleForm.Builder form = (SimpleForm.Builder)SimpleForm.builder().title("Choose your Origin");
/*     */     
/*  59 */     for (Origin origin : origins) {
/*  60 */       if (origin.getIcon().getType() == Material.PLAYER_HEAD) {
/*  61 */         form.button(origin.getName(), FormImage.Type.URL, "https://mc-heads.net/avatar/MHF_Steve"); continue;
/*     */       } 
/*  63 */       form.button(origin.getName(), FormImage.Type.URL, origin.getResourceURL());
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  68 */     boolean enableRandom = ((Boolean)ConfigManager.getConfigValue(ConfigManager.Option.ORIGIN_SELECTION_RANDOM_OPTION_ENABLED)).booleanValue();
/*  69 */     if (enableRandom) form.button("Random", FormImage.Type.URL, "https://static.wikia.nocookie.net/origins-smp/images/1/13/Origin_Orb.png/revision/latest?cb=20210411202749");
/*     */     
/*  71 */     sendForm(player.getUniqueId(), ((SimpleForm.Builder)((SimpleForm.Builder)form
/*  72 */         .closedOrInvalidResultHandler(() -> {
/*     */             
/*     */             if (OriginSwapper.getOrigin(player, layer) == null) {
/*     */               openOriginSwapper(player, reason, false, cost, layer);
/*     */             }
/*  77 */           })).validResultHandler(response -> openOriginInfo(player, AddonLoader.getOrigin(response.clickedButton().text().toLowerCase()), reason, false, cost, layer))).build());
/*     */   }
/*     */ 
/*     */   
/*     */   private static void sendForm(UUID uuid, Form form) {
/*     */     try {
/*  83 */       FloodgateApi.getInstance().sendForm(uuid, form);
/*  84 */     } catch (NoClassDefFoundError e) {
/*  85 */       GeyserApi.api().sendForm(uuid, form);
/*     */     } 
/*     */   }
/*     */   
/*  89 */   private static final Random random = new Random();
/*     */   
/*     */   public static void setOrigin(Player player, Origin origin, PlayerSwapOriginEvent.SwapReason reason, boolean cost, String layer) {
/*  92 */     if (OriginsReborn.getInstance().isVaultEnabled() && cost) {
/*  93 */       int amount = ((Integer)ConfigManager.getConfigValue(ConfigManager.Option.SWAP_COMMAND_VAULT_DEFAULT_COST)).intValue();
/*  94 */       if (origin.getCost() != null) amount = origin.getCost().intValue(); 
/*  95 */       if (VaultHook.has(player, amount)) {
/*  96 */         VaultHook.withdraw(player, amount);
/*     */       } else {
/*  98 */         String symbol = (String)ConfigManager.getConfigValue(ConfigManager.Option.SWAP_COMMAND_VAULT_CURRENCY_SYMBOL);
/*  99 */         player.sendMessage((Component)Component.text("You need %s%s to swap your origin!".formatted(new Object[] { symbol, Integer.valueOf(amount) })));
/*     */         return;
/*     */       } 
/*     */     } 
/* 103 */     if (reason == PlayerSwapOriginEvent.SwapReason.ORB_OF_ORIGIN) {
/* 104 */       OriginSwapper.orbCooldown.put(player, Long.valueOf(System.currentTimeMillis()));
/*     */     }
/* 106 */     boolean resetPlayer = OriginSwapper.shouldResetPlayer(reason);
/* 107 */     if (origin == null) {
/* 108 */       List<Origin> origins = new ArrayList<>(AddonLoader.getOrigins(layer));
/* 109 */       origins.removeIf(origin1 -> origin1.isUnchoosable(player));
/* 110 */       List<String> excludedOrigins = (List<String>)ConfigManager.getConfigValue(ConfigManager.Option.ORIGIN_SELECTION_RANDOM_OPTION_EXCLUDE);
/* 111 */       origins.removeIf(possibleOrigin -> excludedOrigins.contains(possibleOrigin.getName()));
/* 112 */       origin = origins.get(random.nextInt(origins.size()));
/*     */     } 
/* 114 */     if (reason == PlayerSwapOriginEvent.SwapReason.COMMAND) OriginsReborn.getCooldowns().setCooldown(player, OriginCommand.key, ((Integer)ConfigManager.getConfigValue(ConfigManager.Option.SWAP_COMMAND_COOLDOWN)).intValue()); 
/* 115 */     OriginSwapper.setOrigin(player, origin, reason, resetPlayer, layer);
/*     */   }
/*     */   
/*     */   public static void openOriginInfo(Player player, Origin origin, PlayerSwapOriginEvent.SwapReason reason, boolean displayOnly, boolean cost, String layer) {
/* 119 */     ModalForm.Builder form = ModalForm.builder();
/* 120 */     StringBuilder info = new StringBuilder();
/* 121 */     if (origin != null) {
/* 122 */       form.title(origin.getName());
/* 123 */       for (OriginSwapper.LineData.LineComponent line : (new OriginSwapper.LineData(origin)).getRawLines()) {
/* 124 */         if (line.isEmpty()) {
/* 125 */           info.append("\n\n");
/*     */         } else {
/* 127 */           info.append(line.getRawText());
/*     */         } 
/* 129 */         if (line.getType() == OriginSwapper.LineData.LineComponent.LineType.TITLE) info.append("\n"); 
/*     */       } 
/*     */     } else {
/* 132 */       form.title("Random Origin");
/* 133 */       List<Origin> origins = new ArrayList<>(AddonLoader.getOrigins(layer));
/* 134 */       origins.removeIf(origin1 -> origin1.isUnchoosable(player));
/* 135 */       List<String> excludedOrigins = (List<String>)ConfigManager.getConfigValue(ConfigManager.Option.ORIGIN_SELECTION_RANDOM_OPTION_EXCLUDE);
/* 136 */       info.append("You'll be assigned one of the following:\n\n");
/* 137 */       for (Origin possibleOrigin : origins) {
/* 138 */         if (!excludedOrigins.contains(possibleOrigin.getName())) {
/* 139 */           info.append(possibleOrigin.getName()).append("\n");
/*     */         }
/*     */       } 
/*     */     } 
/* 143 */     if (cost) {
/* 144 */       String symbol = (String)ConfigManager.getConfigValue(ConfigManager.Option.SWAP_COMMAND_VAULT_CURRENCY_SYMBOL);
/* 145 */       int amount = ((Integer)ConfigManager.getConfigValue(ConfigManager.Option.SWAP_COMMAND_VAULT_DEFAULT_COST)).intValue();
/* 146 */       if (origin != null && 
/* 147 */         origin.getCost() != null) amount = origin.getCost().intValue();
/*     */       
/* 149 */       info.append("\n\n\n§eThis will cost you %s%s!".formatted(new Object[] { symbol, Integer.valueOf(amount) }));
/*     */     } 
/* 151 */     form.content(info.toString());
/* 152 */     form.button1("Cancel");
/* 153 */     form.button2("Confirm");
/* 154 */     sendForm(player.getUniqueId(), ((ModalForm.Builder)((ModalForm.Builder)form
/* 155 */         .closedOrInvalidResultHandler(() -> {
/*     */             
/*     */             if (!displayOnly) {
/*     */               openOriginInfo(player, origin, reason, false, cost, layer);
/*     */             }
/* 160 */           })).validResultHandler(response -> {
/*     */             if (displayOnly)
/*     */               return;  if (response.clickedButtonId() == 0) {
/*     */               openOriginSwapper(player, reason, false, cost, layer);
/*     */             } else {
/*     */               Bukkit.getScheduler().runTask((Plugin)OriginsReborn.getInstance(), ());
/*     */             } 
/* 167 */           })).build());
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\geysermc\GeyserSwapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */