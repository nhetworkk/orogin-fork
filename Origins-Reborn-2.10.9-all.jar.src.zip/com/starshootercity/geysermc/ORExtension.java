/*    */ package com.starshootercity.geysermc;
/*    */ import java.io.BufferedOutputStream;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.net.URISyntaxException;
/*    */ import java.nio.file.Path;
/*    */ import java.util.zip.ZipEntry;
/*    */ import java.util.zip.ZipInputStream;
/*    */ import org.geysermc.event.subscribe.Subscribe;
/*    */ import org.geysermc.geyser.api.event.lifecycle.GeyserDefineCustomItemsEvent;
/*    */ import org.geysermc.geyser.api.event.lifecycle.GeyserDefineResourcePacksEvent;
/*    */ import org.geysermc.geyser.api.event.lifecycle.GeyserPreInitializeEvent;
/*    */ import org.geysermc.geyser.api.extension.Extension;
/*    */ import org.geysermc.geyser.api.item.custom.CustomItemData;
/*    */ import org.geysermc.geyser.api.item.custom.CustomItemOptions;
/*    */ import org.geysermc.geyser.api.pack.ResourcePack;
/*    */ 
/*    */ public class ORExtension implements Extension {
/*    */   private static ResourcePack pack;
/*    */   private static final int BUFFER_SIZE = 4096;
/*    */   
/*    */   @Subscribe
/*    */   public void onGeyserDefineCustomItems(GeyserDefineCustomItemsEvent event) {
/* 26 */     CustomItemOptions itemOptions = CustomItemOptions.builder().customModelData(1).build();
/*    */ 
/*    */ 
/*    */     
/* 30 */     CustomItemData data = CustomItemData.builder().name("orb_of_origin").customItemOptions(itemOptions).build();
/* 31 */     event.register("minecraft:nautilus_shell", data);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Subscribe
/*    */   public void onGeyserDefineResourcePacks(GeyserDefineResourcePacksEvent event) {
/* 38 */     event.register(pack, new org.geysermc.geyser.api.pack.option.ResourcePackOption[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   @Subscribe
/*    */   public void onGeyserPreInitialize(GeyserPreInitializeEvent event) throws URISyntaxException {
/* 44 */     File file = new File(getClass().getProtectionDomain().getCodeSource().getLocation().toURI());
/* 45 */     logger().info("Loading Origins-Reborn extension");
/*    */     
/* 47 */     boolean ignored = dataFolder().toFile().mkdirs(); 
/* 48 */     try { ZipInputStream inputStream = new ZipInputStream(new FileInputStream(file)); 
/* 49 */       try { ZipEntry entry = inputStream.getNextEntry();
/* 50 */         while (entry != null) {
/* 51 */           if (entry.getName().equalsIgnoreCase("bedrock.mcpack")) {
/* 52 */             extractFile(inputStream, String.valueOf(dataFolder()) + "/bedrock.mcpack");
/*    */           }
/* 54 */           entry = inputStream.getNextEntry();
/*    */         } 
/* 56 */         inputStream.close(); } catch (Throwable throwable) { try { inputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (IOException e)
/* 57 */     { throw new RuntimeException(e); }
/*    */ 
/*    */     
/* 60 */     pack = ResourcePack.create(
/* 61 */         PackCodec.path(Path.of(String.valueOf(dataFolder()) + "/bedrock.mcpack", new String[0])));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static void extractFile(ZipInputStream zipIn, String filePath) throws IOException {
/* 68 */     BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(filePath));
/* 69 */     byte[] bytesIn = new byte[4096];
/*    */     int read;
/* 71 */     while ((read = zipIn.read(bytesIn)) != -1) {
/* 72 */       bos.write(bytesIn, 0, read);
/*    */     }
/* 74 */     bos.close();
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\geysermc\ORExtension.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */