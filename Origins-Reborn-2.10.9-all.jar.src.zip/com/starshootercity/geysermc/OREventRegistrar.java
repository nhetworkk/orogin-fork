/*    */ package com.starshootercity.geysermc;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.nio.file.Path;
/*    */ import java.util.Objects;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.geysermc.event.subscribe.Subscribe;
/*    */ import org.geysermc.geyser.api.GeyserApi;
/*    */ import org.geysermc.geyser.api.event.EventRegistrar;
/*    */ import org.geysermc.geyser.api.event.lifecycle.GeyserDefineCustomItemsEvent;
/*    */ import org.geysermc.geyser.api.event.lifecycle.GeyserDefineResourcePacksEvent;
/*    */ import org.geysermc.geyser.api.item.custom.CustomItemData;
/*    */ import org.geysermc.geyser.api.item.custom.CustomItemOptions;
/*    */ import org.geysermc.geyser.api.pack.PackCodec;
/*    */ import org.geysermc.geyser.api.pack.ResourcePack;
/*    */ 
/*    */ public class OREventRegistrar
/*    */   implements EventRegistrar {
/*    */   private static ResourcePack resourcePack;
/*    */   
/*    */   @Subscribe
/*    */   public void onGeyserDefineCustomItems(GeyserDefineCustomItemsEvent event) {
/* 23 */     CustomItemOptions itemOptions = CustomItemOptions.builder().customModelData(1).build();
/*    */ 
/*    */ 
/*    */     
/* 27 */     CustomItemData data = CustomItemData.builder().name("orb_of_origin").customItemOptions(itemOptions).build();
/*    */     
/* 29 */     event.register("minecraft:nautilus_shell", data);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Subscribe
/*    */   public void onGeyserLoadResourcePacks(GeyserDefineResourcePacksEvent event) {
/* 36 */     event.register(resourcePack, new org.geysermc.geyser.api.pack.option.ResourcePackOption[0]);
/*    */   }
/*    */   
/*    */   public static void initialize(JavaPlugin plugin) {
/* 40 */     OREventRegistrar orEventRegistrar = new OREventRegistrar();
/* 41 */     Objects.requireNonNull(orEventRegistrar); GeyserApi.api().eventBus().subscribe(orEventRegistrar, GeyserDefineCustomItemsEvent.class, orEventRegistrar::onGeyserDefineCustomItems);
/* 42 */     Objects.requireNonNull(orEventRegistrar); GeyserApi.api().eventBus().subscribe(orEventRegistrar, GeyserDefineResourcePacksEvent.class, orEventRegistrar::onGeyserLoadResourcePacks);
/*    */     
/* 44 */     plugin.saveResource("bedrock.mcpack", true);
/* 45 */     Path path = (new File(plugin.getDataFolder(), "bedrock.mcpack")).toPath();
/*    */     
/* 47 */     resourcePack = ResourcePack.create(PackCodec.path(path));
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\geysermc\OREventRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */