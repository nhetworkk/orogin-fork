/*   */ package com.starshootercity;
/*   */ public final class SavedPotionEffect extends Record { private final PotionEffect effect;
/*   */   private final int currentTime;
/*   */   
/* 5 */   public SavedPotionEffect(PotionEffect effect, int currentTime) { this.effect = effect; this.currentTime = currentTime; } public final String toString() { // Byte code:
/*   */     //   0: aload_0
/*   */     //   1: <illegal opcode> toString : (Lcom/starshootercity/SavedPotionEffect;)Ljava/lang/String;
/*   */     //   6: areturn
/*   */     // Line number table:
/*   */     //   Java source line number -> byte code offset
/*   */     //   #5	-> 0
/*   */     // Local variable table:
/*   */     //   start	length	slot	name	descriptor
/* 5 */     //   0	7	0	this	Lcom/starshootercity/SavedPotionEffect; } public PotionEffect effect() { return this.effect; } public final int hashCode() { // Byte code:
/*   */     //   0: aload_0
/*   */     //   1: <illegal opcode> hashCode : (Lcom/starshootercity/SavedPotionEffect;)I
/*   */     //   6: ireturn
/*   */     // Line number table:
/*   */     //   Java source line number -> byte code offset
/*   */     //   #5	-> 0
/*   */     // Local variable table:
/*   */     //   start	length	slot	name	descriptor
/*   */     //   0	7	0	this	Lcom/starshootercity/SavedPotionEffect; } public final boolean equals(Object o) { // Byte code:
/*   */     //   0: aload_0
/*   */     //   1: aload_1
/*   */     //   2: <illegal opcode> equals : (Lcom/starshootercity/SavedPotionEffect;Ljava/lang/Object;)Z
/*   */     //   7: ireturn
/*   */     // Line number table:
/*   */     //   Java source line number -> byte code offset
/*   */     //   #5	-> 0
/*   */     // Local variable table:
/*   */     //   start	length	slot	name	descriptor
/*   */     //   0	8	0	this	Lcom/starshootercity/SavedPotionEffect;
/* 5 */     //   0	8	1	o	Ljava/lang/Object; } public int currentTime() { return this.currentTime; }
/*   */    }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\SavedPotionEffect.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */