/*   */ package com.starshootercity;
/*   */ 
/*   */ import org.bukkit.plugin.java.JavaPlugin;
/*   */ 
/*   */ public abstract class AbstractScheduleManager {
/*   */   public abstract void delayedTask(JavaPlugin paramJavaPlugin, Runnable paramRunnable, long paramLong);
/*   */   
/*   */   public final void delayedTask(JavaPlugin plugin, Runnable task) {
/* 9 */     delayedTask(plugin, task, 1L);
/*   */   }
/*   */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\AbstractScheduleManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */