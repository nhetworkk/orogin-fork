/*     */ package com.starshootercity.events;
/*     */ 
/*     */ import com.starshootercity.OriginsReborn;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.block.BlockBreakEvent;
/*     */ import org.bukkit.event.player.PlayerDropItemEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEntityEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlayerLeftClickEventListener
/*     */   implements Listener
/*     */ {
/*  75 */   Map<Player, Integer> lastInteractionTickMap = new HashMap<>();
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerInteract(PlayerInteractEvent event) {
/*  79 */     Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)OriginsReborn.getInstance(), () -> {
/*     */           if (((Integer)this.lastInteractionTickMap.getOrDefault(event.getPlayer(), (V)Integer.valueOf(-1))).intValue() >= Bukkit.getCurrentTick())
/*     */             return; 
/*     */           this.lastInteractionTickMap.put(event.getPlayer(), Integer.valueOf(Bukkit.getCurrentTick()));
/*     */           if (!event.getAction().isLeftClick())
/*     */             return; 
/*     */           (new PlayerLeftClickEvent(event)).callEvent();
/*     */         });
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerInteractEntity(PlayerInteractEntityEvent event) {
/*  91 */     Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)OriginsReborn.getInstance(), () -> {
/*     */           if (((Integer)this.lastInteractionTickMap.getOrDefault(event.getPlayer(), (V)Integer.valueOf(-1))).intValue() >= Bukkit.getCurrentTick())
/*     */             return; 
/*     */           this.lastInteractionTickMap.put(event.getPlayer(), Integer.valueOf(Bukkit.getCurrentTick()));
/*     */         });
/*     */   }
/*     */   @EventHandler
/*     */   public void onPlayerDropItem(PlayerDropItemEvent event) {
/*  99 */     this.lastInteractionTickMap.put(event.getPlayer(), Integer.valueOf(Bukkit.getCurrentTick() + 1));
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onBlockBreak(BlockBreakEvent event) {
/* 104 */     this.lastInteractionTickMap.put(event.getPlayer(), Integer.valueOf(Bukkit.getCurrentTick() + 1));
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\events\PlayerLeftClickEvent$PlayerLeftClickEventListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */