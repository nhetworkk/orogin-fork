/*     */ package com.starshootercity.events;
/*     */ 
/*     */ import com.starshootercity.APITarget;
/*     */ import com.starshootercity.OriginsReborn;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.block.BlockFace;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.HandlerList;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.block.BlockBreakEvent;
/*     */ import org.bukkit.event.player.PlayerDropItemEvent;
/*     */ import org.bukkit.event.player.PlayerEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEntityEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ @APITarget
/*     */ public class PlayerLeftClickEvent extends PlayerEvent {
/*     */   private final PlayerInteractEvent playerInteractEvent;
/*     */   
/*     */   public PlayerLeftClickEvent(PlayerInteractEvent event) {
/*  31 */     super(event.getPlayer());
/*  32 */     this.playerInteractEvent = event;
/*     */   }
/*     */   @Nullable
/*     */   public Location getInteractionPoint() {
/*  36 */     return this.playerInteractEvent.getInteractionPoint();
/*     */   }
/*     */   
/*     */   public boolean hasBlock() {
/*  40 */     return this.playerInteractEvent.hasBlock();
/*     */   }
/*     */   
/*     */   public boolean hasItem() {
/*  44 */     return this.playerInteractEvent.hasItem();
/*     */   }
/*     */   @Nullable
/*     */   public ItemStack getItem() {
/*  48 */     return this.playerInteractEvent.getItem();
/*     */   }
/*     */   @NotNull
/*     */   public Material getMaterial() {
/*  52 */     return this.playerInteractEvent.getMaterial();
/*     */   }
/*     */   @Nullable
/*     */   public Block getClickedBlock() {
/*  56 */     return this.playerInteractEvent.getClickedBlock();
/*     */   }
/*     */   @Nullable
/*     */   public BlockFace getBlockFace() {
/*  60 */     return this.playerInteractEvent.getBlockFace();
/*     */   }
/*     */   
/*  63 */   private static final HandlerList HANDLERS = new HandlerList();
/*     */   
/*     */   @NotNull
/*     */   public HandlerList getHandlers() {
/*  67 */     return HANDLERS;
/*     */   }
/*     */   
/*     */   public static HandlerList getHandlerList() {
/*  71 */     return HANDLERS;
/*     */   }
/*     */   
/*     */   public static class PlayerLeftClickEventListener implements Listener {
/*  75 */     Map<Player, Integer> lastInteractionTickMap = new HashMap<>();
/*     */     
/*     */     @EventHandler
/*     */     public void onPlayerInteract(PlayerInteractEvent event) {
/*  79 */       Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)OriginsReborn.getInstance(), () -> {
/*     */             if (((Integer)this.lastInteractionTickMap.getOrDefault(event.getPlayer(), (V)Integer.valueOf(-1))).intValue() >= Bukkit.getCurrentTick())
/*     */               return; 
/*     */             this.lastInteractionTickMap.put(event.getPlayer(), Integer.valueOf(Bukkit.getCurrentTick()));
/*     */             if (!event.getAction().isLeftClick())
/*     */               return; 
/*     */             (new PlayerLeftClickEvent(event)).callEvent();
/*     */           });
/*     */     }
/*     */     
/*     */     @EventHandler
/*     */     public void onPlayerInteractEntity(PlayerInteractEntityEvent event) {
/*  91 */       Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)OriginsReborn.getInstance(), () -> {
/*     */             if (((Integer)this.lastInteractionTickMap.getOrDefault(event.getPlayer(), (V)Integer.valueOf(-1))).intValue() >= Bukkit.getCurrentTick())
/*     */               return; 
/*     */             this.lastInteractionTickMap.put(event.getPlayer(), Integer.valueOf(Bukkit.getCurrentTick()));
/*     */           });
/*     */     }
/*     */     @EventHandler
/*     */     public void onPlayerDropItem(PlayerDropItemEvent event) {
/*  99 */       this.lastInteractionTickMap.put(event.getPlayer(), Integer.valueOf(Bukkit.getCurrentTick() + 1));
/*     */     }
/*     */     
/*     */     @EventHandler
/*     */     public void onBlockBreak(BlockBreakEvent event) {
/* 104 */       this.lastInteractionTickMap.put(event.getPlayer(), Integer.valueOf(Bukkit.getCurrentTick() + 1));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\events\PlayerLeftClickEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */