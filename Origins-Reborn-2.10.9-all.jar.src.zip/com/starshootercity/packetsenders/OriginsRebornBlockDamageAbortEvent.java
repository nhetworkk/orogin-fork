/*    */ package com.starshootercity.packetsenders;
/*    */ 
/*    */ import com.starshootercity.version.MVBlockDamageAbortEvent;
/*    */ import org.bukkit.block.Block;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ @Deprecated(forRemoval = true)
/*    */ public class OriginsRebornBlockDamageAbortEvent extends MVBlockDamageAbortEvent {
/*    */   public OriginsRebornBlockDamageAbortEvent(@NotNull Player player, @NotNull Block block, @NotNull ItemStack itemInHand) {
/* 12 */     super(player, block, itemInHand);
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\packetsenders\OriginsRebornBlockDamageAbortEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */