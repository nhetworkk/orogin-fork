/*    */ package com.starshootercity.packetsenders;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import net.kyori.adventure.text.Component;
/*    */ import net.kyori.adventure.util.TriState;
/*    */ import org.bukkit.GameMode;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.NamespacedKey;
/*    */ import org.bukkit.attribute.Attribute;
/*    */ import org.bukkit.attribute.AttributeInstance;
/*    */ import org.bukkit.attribute.AttributeModifier;
/*    */ import org.bukkit.block.Conduit;
/*    */ import org.bukkit.configuration.file.FileConfiguration;
/*    */ import org.bukkit.enchantments.Enchantment;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.LivingEntity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.inventory.EquipmentSlot;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.bukkit.inventory.meta.ItemMeta;
/*    */ import org.bukkit.potion.PotionEffectType;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class NMSInvoker
/*    */   implements Listener
/*    */ {
/*    */   public abstract void sendEntityData(Player paramPlayer, Entity paramEntity, byte paramByte);
/*    */   
/*    */   public abstract boolean wasTouchingWater(Player paramPlayer);
/*    */   
/*    */   public abstract float getDestroySpeed(ItemStack paramItemStack, Material paramMaterial);
/*    */   
/*    */   public abstract float getDestroySpeed(Material paramMaterial);
/*    */   
/*    */   public abstract void setNoPhysics(Player paramPlayer, boolean paramBoolean);
/*    */   
/*    */   public abstract void sendPhasingGamemodeUpdate(Player paramPlayer, GameMode paramGameMode);
/*    */   
/*    */   @NotNull
/*    */   public abstract PotionEffectType getNauseaEffect();
/*    */   
/*    */   @NotNull
/*    */   public abstract PotionEffectType getMiningFatigueEffect();
/*    */   
/*    */   @NotNull
/*    */   public abstract PotionEffectType getHasteEffect();
/*    */   
/*    */   @NotNull
/*    */   public abstract PotionEffectType getJumpBoostEffect();
/*    */   
/*    */   @NotNull
/*    */   public abstract PotionEffectType getSlownessEffect();
/*    */   
/*    */   @NotNull
/*    */   public abstract PotionEffectType getStrengthEffect();
/*    */   
/*    */   @NotNull
/*    */   public abstract Enchantment getUnbreakingEnchantment();
/*    */   
/*    */   @NotNull
/*    */   public abstract Enchantment getEfficiencyEnchantment();
/*    */   
/*    */   @NotNull
/*    */   public abstract Enchantment getRespirationEnchantment();
/*    */   
/*    */   @NotNull
/*    */   public abstract Enchantment getAquaAffinityEnchantment();
/*    */   
/*    */   @Nullable
/*    */   public Material getOminousBottle() {
/* 98 */     return null;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public abstract Enchantment getBaneOfArthropodsEnchantment();
/*    */   
/*    */   @Nullable
/*    */   public abstract Location getRespawnLocation(Player paramPlayer);
/*    */   
/*    */   public abstract void resetRespawnLocation(Player paramPlayer);
/*    */   
/*    */   @Nullable
/*    */   public abstract AttributeModifier getAttributeModifier(AttributeInstance paramAttributeInstance, Key paramKey);
/*    */   
/*    */   public abstract void dealDryOutDamage(LivingEntity paramLivingEntity, int paramInt);
/*    */   
/*    */   public abstract void dealDrowningDamage(LivingEntity paramLivingEntity, int paramInt);
/*    */   
/*    */   public abstract void dealFreezeDamage(LivingEntity paramLivingEntity, int paramInt);
/*    */   
/*    */   public abstract boolean supportsInfiniteDuration();
/*    */   
/*    */   public abstract boolean isUnderWater(LivingEntity paramLivingEntity);
/*    */   
/*    */   public abstract void knockback(LivingEntity paramLivingEntity, double paramDouble1, double paramDouble2, double paramDouble3);
/*    */   
/*    */   public abstract void setFlyingFallDamage(Player paramPlayer, TriState paramTriState);
/*    */   
/*    */   public abstract void broadcastSlotBreak(Player paramPlayer, EquipmentSlot paramEquipmentSlot, Collection<Player> paramCollection);
/*    */   
/*    */   public abstract void sendBlockDamage(Player paramPlayer, Location paramLocation, float paramFloat, Entity paramEntity);
/*    */   
/*    */   public abstract void addAttributeModifier(AttributeInstance paramAttributeInstance, NamespacedKey paramNamespacedKey, String paramString, double paramDouble, AttributeModifier.Operation paramOperation);
/*    */   
/*    */   public abstract void setWorldBorderOverlay(Player paramPlayer, boolean paramBoolean);
/*    */   
/*    */   public abstract void setComments(FileConfiguration paramFileConfiguration, String paramString, List<String> paramList);
/*    */   
/*    */   public abstract Component applyFont(Component paramComponent, Key paramKey);
/*    */   
/*    */   @NotNull
/*    */   public abstract Attribute getArmorAttribute();
/*    */   
/*    */   @NotNull
/*    */   public abstract Attribute getMaxHealthAttribute();
/*    */   
/*    */   @NotNull
/*    */   public abstract Attribute getMovementSpeedAttribute();
/*    */   
/*    */   @NotNull
/*    */   public abstract Attribute getFlyingSpeedAttribute();
/*    */   
/*    */   @NotNull
/*    */   public abstract Attribute getAttackDamageAttribute();
/*    */   
/*    */   @NotNull
/*    */   public abstract Attribute getAttackKnockbackAttribute();
/*    */   
/*    */   @NotNull
/*    */   public abstract Attribute getAttackSpeedAttribute();
/*    */   
/*    */   @NotNull
/*    */   public abstract Attribute getArmorToughnessAttribute();
/*    */   
/*    */   @NotNull
/*    */   public abstract Attribute getLuckAttribute();
/*    */   
/*    */   @NotNull
/*    */   public abstract Attribute getHorseJumpStrengthAttribute();
/*    */   
/*    */   @NotNull
/*    */   public abstract Attribute getSpawnReinforcementsAttribute();
/*    */   
/*    */   @NotNull
/*    */   public abstract Attribute getFollowRangeAttribute();
/*    */   
/*    */   @NotNull
/*    */   public abstract Attribute getKnockbackResistanceAttribute();
/*    */   
/*    */   @Nullable
/*    */   public abstract Attribute getFallDamageMultiplierAttribute();
/*    */   
/*    */   @Nullable
/*    */   public abstract Attribute getMaxAbsorptionAttribute();
/*    */   
/*    */   @Nullable
/*    */   public abstract Attribute getSafeFallDistanceAttribute();
/*    */   
/*    */   @Nullable
/*    */   public abstract Attribute getScaleAttribute();
/*    */   
/*    */   @Nullable
/*    */   public abstract Attribute getStepHeightAttribute();
/*    */   
/*    */   @Nullable
/*    */   public abstract Attribute getGravityAttribute();
/*    */   
/*    */   @Nullable
/*    */   public abstract Attribute getJumpStrengthAttribute();
/*    */   
/*    */   @Nullable
/*    */   public abstract Attribute getBurningTimeAttribute();
/*    */   
/*    */   @Nullable
/*    */   public abstract Attribute getExplosionKnockbackResistanceAttribute();
/*    */   
/*    */   @Nullable
/*    */   public abstract Attribute getMovementEfficiencyAttribute();
/*    */   
/*    */   @Nullable
/*    */   public abstract Attribute getOxygenBonusAttribute();
/*    */   
/*    */   @Nullable
/*    */   public abstract Attribute getWaterMovementEfficiencyAttribute();
/*    */   
/*    */   @Nullable
/*    */   public abstract Attribute getTemptRangeAttribute();
/*    */   
/*    */   @Nullable
/*    */   public abstract Attribute getBlockInteractionRangeAttribute();
/*    */   
/*    */   @Nullable
/*    */   public abstract Attribute getEntityInteractionRangeAttribute();
/*    */   
/*    */   @Nullable
/*    */   public abstract Attribute getBlockBreakSpeedAttribute();
/*    */   
/*    */   @Nullable
/*    */   public abstract Attribute getMiningEfficiencyAttribute();
/*    */   
/*    */   @Nullable
/*    */   public abstract Attribute getSneakingSpeedAttribute();
/*    */   
/*    */   @Nullable
/*    */   public abstract Attribute getSubmergedMiningSpeedAttribute();
/*    */   
/*    */   @Nullable
/*    */   public abstract Attribute getSweepingDamageRatioAttribute();
/*    */   
/*    */   @NotNull
/*    */   public abstract ItemMeta setCustomModelData(ItemMeta paramItemMeta, int paramInt);
/*    */   
/*    */   public abstract int getConduitRange(Conduit paramConduit);
/*    */   
/*    */   public abstract void setTouchingWater(Player paramPlayer);
/*    */   
/*    */   public abstract void initialize();
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\packetsenders\NMSInvoker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */