/*   */ package com.starshootercity.packetsenders;
/*   */ 
/*   */ import com.starshootercity.version.ResourcePackInfo;
/*   */ 
/*   */ public class OriginsRebornResourcePackInfo extends ResourcePackInfo {
/*   */   public OriginsRebornResourcePackInfo(Object packInfo) {
/* 7 */     super(packInfo);
/*   */   }
/*   */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\packetsenders\OriginsRebornResourcePackInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */