/*     */ package com.starshootercity;
/*     */ import com.starshootercity.events.PlayerSwapOriginEvent;
/*     */ import com.starshootercity.util.config.ConfigManager;
/*     */ import java.util.List;
/*     */ import net.kyori.adventure.text.Component;
/*     */ import net.kyori.adventure.text.TextComponent;
/*     */ import net.kyori.adventure.text.format.NamedTextColor;
/*     */ import net.kyori.adventure.text.format.TextColor;
/*     */ import net.kyori.adventure.text.format.TextDecoration;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.NamespacedKey;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.inventory.PrepareItemCraftEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.inventory.EquipmentSlot;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.Recipe;
/*     */ import org.bukkit.inventory.ShapedRecipe;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class OrbOfOrigin implements Listener {
/*  26 */   public static NamespacedKey orbKey = new NamespacedKey((Plugin)OriginsReborn.getInstance(), "orb-of-origin");
/*  27 */   public static NamespacedKey updatedKey = new NamespacedKey((Plugin)OriginsReborn.getInstance(), "updated-orb");
/*     */   
/*     */   public static ItemStack orb;
/*     */   
/*     */   @EventHandler
/*     */   public void onInventoryClick(InventoryClickEvent event) {
/*  33 */     if (event.getCurrentItem() == null || event.getCurrentItem().getItemMeta() == null)
/*  34 */       return;  ItemMeta meta = event.getCurrentItem().getItemMeta();
/*  35 */     if (meta.getPersistentDataContainer().has(orbKey, OriginSwapper.BooleanPDT.BOOLEAN) && !meta.getPersistentDataContainer().has(updatedKey, OriginSwapper.BooleanPDT.BOOLEAN)) {
/*  36 */       event.getCurrentItem().setItemMeta(orb.getItemMeta());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onPrepareItemCraft(PrepareItemCraftEvent event) {
/*  43 */     Recipe recipe = event.getRecipe();
/*  44 */     if (recipe != null && 
/*  45 */       recipe.getResult().getType() == Material.CONDUIT) {
/*  46 */       for (ItemStack itemStack : event.getInventory().getMatrix()) {
/*  47 */         if (itemStack != null && itemStack.getItemMeta() != null && 
/*  48 */           itemStack.getItemMeta().getPersistentDataContainer().has(orbKey, OriginSwapper.BooleanPDT.BOOLEAN)) {
/*  49 */           event.getInventory().setResult(null);
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OrbOfOrigin() {
/*  59 */     orb = new ItemStack(Material.NAUTILUS_SHELL);
/*     */     
/*  61 */     String orbOfOrigin = "item.orb_of_origin";
/*  62 */     String orbOfOriginDesc = "item.orb_of_origin_description";
/*     */     
/*  64 */     Translator.registerTranslation(orbOfOrigin, "Orb of Origin");
/*  65 */     Translator.registerTranslation(orbOfOriginDesc, "");
/*  66 */     ItemMeta meta = orb.getItemMeta();
/*  67 */     meta.getPersistentDataContainer().set(orbKey, OriginSwapper.BooleanPDT.BOOLEAN, Boolean.valueOf(true));
/*  68 */     meta.getPersistentDataContainer().set(updatedKey, OriginSwapper.BooleanPDT.BOOLEAN, Boolean.valueOf(true));
/*  69 */     meta = OriginsReborn.getMVE().setCustomModelData(meta, 1);
/*  70 */     meta.displayName((
/*  71 */         (TextComponent)Component.text(Translator.translate(orbOfOrigin))
/*  72 */         .color((TextColor)NamedTextColor.AQUA))
/*  73 */         .decoration(TextDecoration.ITALIC, false));
/*     */     
/*  75 */     String desc = Translator.translate(orbOfOriginDesc);
/*  76 */     if (!desc.isBlank()) {
/*  77 */       meta.lore(List.of((
/*  78 */             (TextComponent)Component.text(desc)
/*  79 */             .color((TextColor)NamedTextColor.AQUA))
/*  80 */             .decoration(TextDecoration.ITALIC, false)));
/*     */     }
/*     */     
/*  83 */     orb.setItemMeta(meta);
/*     */ 
/*     */     
/*  86 */     Bukkit.removeRecipe(orbKey);
/*  87 */     FileConfiguration config = OriginsReborn.getInstance().getConfig();
/*  88 */     if (config.getBoolean("orb-of-origin.enable-recipe")) {
/*  89 */       ShapedRecipe shapedRecipe = new ShapedRecipe(orbKey, orb);
/*  90 */       shapedRecipe.shape(new String[] { "012", "345", "678" });
/*  91 */       int i = 0;
/*  92 */       List<?> recipeData = config.getList("orb-of-origin.recipe");
/*  93 */       if (recipeData == null)
/*  94 */         return;  for (Object line : recipeData) {
/*  95 */         for (String name : line) {
/*  96 */           Material material = Material.matchMaterial(name);
/*  97 */           if (material == null) material = Material.AIR; 
/*  98 */           if (material == Material.AIR) {
/*  99 */             i++;
/*     */             continue;
/*     */           } 
/* 102 */           shapedRecipe.setIngredient(String.valueOf(i).charAt(0), material);
/* 103 */           i++;
/*     */         } 
/*     */       } 
/* 106 */       Bukkit.addRecipe((Recipe)shapedRecipe);
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerInteract(PlayerInteractEvent event) {
/* 112 */     if (event.getClickedBlock() != null && 
/* 113 */       event.getClickedBlock().getType().isInteractable())
/*     */       return; 
/* 115 */     if (!event.getAction().isRightClick())
/* 116 */       return;  ItemStack item = event.getItem();
/* 117 */     if (item == null)
/* 118 */       return;  ItemMeta meta = item.getItemMeta();
/* 119 */     if (meta != null && 
/* 120 */       meta.getPersistentDataContainer().has(orbKey, OriginSwapper.BooleanPDT.BOOLEAN)) {
/* 121 */       if (OriginSwapper.orbCooldown.containsKey(event.getPlayer()) && 
/* 122 */         System.currentTimeMillis() - ((Long)OriginSwapper.orbCooldown.get(event.getPlayer())).longValue() < 500L) {
/*     */         return;
/*     */       }
/*     */       
/* 126 */       ItemMeta heldMeta = event.getPlayer().getInventory().getItemInMainHand().getItemMeta();
/* 127 */       EquipmentSlot hand = EquipmentSlot.OFF_HAND;
/* 128 */       if (heldMeta != null && heldMeta.getPersistentDataContainer().has(orbKey, OriginSwapper.BooleanPDT.BOOLEAN)) hand = EquipmentSlot.HAND; 
/* 129 */       if (hand == EquipmentSlot.HAND) { event.getPlayer().swingMainHand(); }
/* 130 */       else { event.getPlayer().swingOffHand(); }
/* 131 */        if (((Boolean)ConfigManager.getConfigValue(ConfigManager.Option.ORB_OF_ORIGIN_CONSUME)).booleanValue()) {
/* 132 */         item.setAmount(item.getAmount() - 1);
/* 133 */         event.getPlayer().getInventory().setItemInMainHand(item);
/*     */       } 
/* 135 */       boolean opened = false;
/* 136 */       for (String layer : AddonLoader.layers) {
/* 137 */         event.getPlayer().getPersistentDataContainer().set(OriginSwapper.awaitingOriginChangeKey, OriginSwapper.BooleanPDT.BOOLEAN, Boolean.valueOf(true));
/* 138 */         OriginSwapper.setOrigin(event.getPlayer(), null, PlayerSwapOriginEvent.SwapReason.ORB_OF_ORIGIN, false, layer);
/* 139 */         if (opened)
/* 140 */           continue;  if (OriginsReborn.getInstance().getConfig().getBoolean("orb-of-origin.random.%s".formatted(new Object[] { layer }))) {
/* 141 */           OriginSwapper.selectRandomOrigin(event.getPlayer(), PlayerSwapOriginEvent.SwapReason.ORB_OF_ORIGIN, layer);
/* 142 */           OriginSwapper.openOriginSwapper(event.getPlayer(), PlayerSwapOriginEvent.SwapReason.ORB_OF_ORIGIN, AddonLoader.getOrigins(layer).indexOf(OriginSwapper.getOrigin(event.getPlayer(), layer)), 0, false, true, layer);
/*     */         } else {
/* 144 */           Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)OriginsReborn.getInstance(), () -> OriginSwapper.openOriginSwapper(event.getPlayer(), PlayerSwapOriginEvent.SwapReason.ORB_OF_ORIGIN, 0, 0, true, layer));
/*     */         } 
/* 146 */         opened = true;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\OrbOfOrigin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */