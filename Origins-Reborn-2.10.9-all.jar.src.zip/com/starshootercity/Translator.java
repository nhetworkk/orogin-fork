/*    */ package com.starshootercity;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.bukkit.configuration.file.FileConfiguration;
/*    */ import org.bukkit.configuration.file.YamlConfiguration;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @APITarget
/*    */ public class Translator
/*    */ {
/*    */   private static File file;
/*    */   private static FileConfiguration fileConfig;
/*    */   
/*    */   public static int getWidth(char character) {
/* 26 */     if (character == '') return 2;
/*    */     
/* 28 */     if (character == ' ') return 4; 
/* 29 */     for (int i = 2; i < 17; i++) {
/* 30 */       if (fileConfig.getString("character-widths.%s".formatted(new Object[] { Integer.valueOf(i) }, ), "").contains(toUnicode(character))) {
/* 31 */         return i;
/*    */       }
/*    */     } 
/* 34 */     return 0;
/*    */   }
/*    */   
/*    */   private static String toUnicode(char ch) {
/* 38 */     return String.format("\\u%04x", new Object[] { Integer.valueOf(ch) });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void registerTranslation(String key, String def) {
/* 51 */     key = "translations." + key;
/* 52 */     if (!fileConfig.contains(key)) {
/* 53 */       fileConfig.set(key, def);
/*    */       try {
/* 55 */         fileConfig.save(file);
/* 56 */       } catch (IOException e) {
/* 57 */         throw new RuntimeException(e);
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/* 62 */   private static final Map<String, String> cache = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String translate(String key) {
/* 70 */     return cache.computeIfAbsent(key, s -> fileConfig.getString("translations." + key));
/*    */   }
/*    */   
/*    */   public static void reloadTranslations() {
/* 74 */     cache.clear();
/*    */     try {
/* 76 */       fileConfig.load(file);
/* 77 */     } catch (IOException|org.bukkit.configuration.InvalidConfigurationException e) {
/* 78 */       throw new RuntimeException(e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public static void initialize(JavaPlugin plugin) {
/* 83 */     file = new File(plugin.getDataFolder(), "translations.yml");
/*    */     
/* 85 */     if (!file.exists()) {
/* 86 */       boolean ignored = file.getParentFile().mkdirs();
/* 87 */       plugin.saveResource("translations.yml", false);
/*    */     } 
/*    */     
/* 90 */     fileConfig = (FileConfiguration)new YamlConfiguration();
/*    */     
/* 92 */     reloadTranslations();
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\Translator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */