/*   */ package com.starshootercity;
/*   */ 
/*   */ import org.bukkit.Bukkit;
/*   */ import org.bukkit.plugin.Plugin;
/*   */ import org.bukkit.plugin.java.JavaPlugin;
/*   */ 
/*   */ public class ScheduleManager extends AbstractScheduleManager {
/*   */   public void delayedTask(JavaPlugin plugin, Runnable task, long delay) {
/* 9 */     Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)plugin, task, delay);
/*   */   }
/*   */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\ScheduleManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */