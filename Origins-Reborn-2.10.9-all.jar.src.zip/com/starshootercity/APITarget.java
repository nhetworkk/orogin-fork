package com.starshootercity;

public @interface APITarget {}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\APITarget.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */