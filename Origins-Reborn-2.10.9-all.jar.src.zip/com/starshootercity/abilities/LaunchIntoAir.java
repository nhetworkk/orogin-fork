/*    */ package com.starshootercity.abilities;
/*    */ import com.starshootercity.abilities.types.Ability;
/*    */ import com.starshootercity.abilities.types.CooldownAbility;
/*    */ import com.starshootercity.abilities.types.TriggerableAbility;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.cooldowns.Cooldowns;
/*    */ import com.starshootercity.util.TriggerManager;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import java.util.Collections;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.bukkit.util.Vector;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class LaunchIntoAir implements Listener, CooldownAbility, VisibleAbility, TriggerableAbility {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 20 */     return Key.key("origins:launch_into_air");
/*    */   }
/*    */   private float launchStrength;
/*    */   
/*    */   public String description() {
/* 25 */     return "Every 30 seconds, you are able to launch about 20 blocks up into the air.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 30 */     return "Gift of the Winds";
/*    */   }
/*    */ 
/*    */   
/*    */   public Cooldowns.CooldownInfo getCooldownInfo() {
/* 35 */     return new Cooldowns.CooldownInfo(600, "launch");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void initialize(JavaPlugin plugin) {
/* 42 */     this.launchStrength = ((Float)registerConfigOption(plugin, "launch_strength", Collections.singletonList("How strong the launch effect should be"), ConfigManager.SettingType.FLOAT, Float.valueOf(2.0F))).floatValue();
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public TriggerableAbility.Trigger getTrigger() {
/* 47 */     return TriggerableAbility.Trigger.builder(TriggerableAbility.TriggerType.SNEAK_ON, (Ability)this)
/*    */ 
/*    */       
/* 50 */       .addConditions(new TriggerableAbility.Condition[] { TriggerableAbility.Condition.GLIDING
/* 51 */         }).build(event -> {
/*    */           Player player = event.player();
/*    */           if (hasCooldown(player))
/*    */             return; 
/*    */           setCooldown(player);
/*    */           player.setVelocity(player.getVelocity().add(new Vector(0.0F, this.launchStrength, 0.0F)));
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\LaunchIntoAir.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */