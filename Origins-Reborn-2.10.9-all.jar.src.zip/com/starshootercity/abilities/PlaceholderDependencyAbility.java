/*    */ package com.starshootercity.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.DependencyAbility;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class PlaceholderDependencyAbility implements DependencyAbility {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 11 */     return Key.key("origins:blank_dependency");
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isEnabled(Player player) {
/* 16 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\PlaceholderDependencyAbility.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */