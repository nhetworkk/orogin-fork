/*    */ package com.starshootercity.abilities;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityDamageEvent;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class FallImmunity implements Listener, VisibleAbility {
/*    */   @EventHandler
/*    */   public void onEntityDamage(EntityDamageEvent event) {
/* 13 */     runForAbility(event.getEntity(), player -> {
/*    */           if (event.getCause() == EntityDamageEvent.DamageCause.FALL) {
/*    */             event.setCancelled(true);
/*    */           }
/*    */         });
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 22 */     return Key.key("origins:fall_immunity");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 27 */     return "You never take fall damage, no matter from which height you fall.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 32 */     return "Acrobatics";
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\FallImmunity.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */