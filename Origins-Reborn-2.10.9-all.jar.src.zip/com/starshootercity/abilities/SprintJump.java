/*    */ package com.starshootercity.abilities;
/*    */ 
/*    */ import com.destroystokyo.paper.event.server.ServerTickEndEvent;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import com.starshootercity.version.MVPotionEffectType;
/*    */ import java.util.Collections;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.bukkit.potion.PotionEffect;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class SprintJump implements Listener, VisibleAbility {
/*    */   @EventHandler
/*    */   public void onServerTickEnd(ServerTickEndEvent event) {
/* 21 */     for (Player p : Bukkit.getOnlinePlayers()) {
/* 22 */       runForAbility((Entity)p, player -> {
/*    */             if (player.isSprinting()) {
/*    */               player.addPotionEffect(new PotionEffect(MVPotionEffectType.JUMP_BOOST.get(), 5, this.jumpStrength, false, false));
/*    */             }
/*    */           });
/*    */     } 
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 32 */     return Key.key("origins:sprint_jump");
/*    */   }
/*    */   private int jumpStrength;
/*    */   
/*    */   public String description() {
/* 37 */     return "You are able to jump higher by jumping while sprinting.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 42 */     return "Strong Ankles";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void initialize(JavaPlugin plugin) {
/* 49 */     this.jumpStrength = ((Integer)registerConfigOption(plugin, "jump_strength", Collections.singletonList("Strength of the Jump Boost effect to give"), ConfigManager.SettingType.INTEGER, Integer.valueOf(1))).intValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\SprintJump.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */