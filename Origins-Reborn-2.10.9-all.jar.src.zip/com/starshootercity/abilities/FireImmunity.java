/*    */ package com.starshootercity.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import java.util.Set;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityDamageEvent;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class FireImmunity implements Listener, VisibleAbility {
/*    */   @EventHandler
/*    */   public void onEntityDamageEvent(EntityDamageEvent event) {
/* 15 */     runForAbility(event.getEntity(), player -> {
/*    */           if (Set.of(EntityDamageEvent.DamageCause.FIRE, EntityDamageEvent.DamageCause.FIRE_TICK, EntityDamageEvent.DamageCause.LAVA, EntityDamageEvent.DamageCause.HOT_FLOOR).contains(event.getCause())) {
/*    */             event.setCancelled(true);
/*    */           }
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 29 */     return Key.key("origins:fire_immunity");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 34 */     return "You are immune to all types of fire damage.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 39 */     return "Fire Immunity";
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\FireImmunity.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */