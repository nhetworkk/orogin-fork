/*    */ package com.starshootercity.abilities;
/*    */ import com.starshootercity.abilities.types.Ability;
/*    */ import com.starshootercity.abilities.types.AttributeModifierAbility;
/*    */ import com.starshootercity.abilities.types.MultiAbility;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import java.util.List;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.attribute.Attribute;
/*    */ import org.bukkit.attribute.AttributeModifier;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class ExtraReach implements MultiAbility, VisibleAbility {
/*    */   private static Attribute blockRange;
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 18 */     return Key.key("origins:extra_reach");
/*    */   }
/*    */   private static Attribute entityRange;
/*    */   
/*    */   public String description() {
/* 23 */     return "You can reach blocks and entities further away.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 28 */     return "Slender Body";
/*    */   }
/*    */ 
/*    */   
/*    */   public List<Ability> getAbilities() {
/* 33 */     return List.of(ExtraReachBlocks.extraReachBlocks, ExtraReachEntities.extraReachEntities);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ExtraReach(Attribute blockRange, Attribute entityRange) {
/* 40 */     ExtraReach.blockRange = blockRange;
/* 41 */     ExtraReach.entityRange = entityRange;
/*    */   }
/*    */   
/*    */   public static class ExtraReachEntities implements AttributeModifierAbility {
/* 45 */     public static ExtraReachEntities extraReachEntities = new ExtraReachEntities();
/*    */     
/*    */     @NotNull
/*    */     public Attribute getAttribute() {
/* 49 */       return ExtraReach.entityRange;
/*    */     }
/*    */ 
/*    */     
/*    */     public double getAmount(Player player) {
/* 54 */       return 1.5D;
/*    */     }
/*    */ 
/*    */     
/*    */     public AttributeModifier.Operation getOperation() {
/* 59 */       return AttributeModifier.Operation.ADD_NUMBER;
/*    */     }
/*    */     
/*    */     @NotNull
/*    */     public Key getKey() {
/* 64 */       return Key.key("origins:extra_reach_entities");
/*    */     }
/*    */   }
/*    */   
/*    */   public static class ExtraReachBlocks implements AttributeModifierAbility {
/* 69 */     public static ExtraReachBlocks extraReachBlocks = new ExtraReachBlocks();
/*    */     
/*    */     @NotNull
/*    */     public Attribute getAttribute() {
/* 73 */       return ExtraReach.blockRange;
/*    */     }
/*    */ 
/*    */     
/*    */     public double getAmount(Player player) {
/* 78 */       return 1.5D;
/*    */     }
/*    */ 
/*    */     
/*    */     public AttributeModifier.Operation getOperation() {
/* 83 */       return AttributeModifier.Operation.ADD_NUMBER;
/*    */     }
/*    */     
/*    */     @NotNull
/*    */     public Key getKey() {
/* 88 */       return Key.key("origins:extra_reach_blocks");
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\ExtraReach.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */