/*    */ package com.starshootercity.abilities;
/*    */ import com.destroystokyo.paper.event.server.ServerTickEndEvent;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.version.MVPotionEffectType;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.block.BlockFace;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerItemConsumeEvent;
/*    */ import org.bukkit.potion.PotionEffect;
/*    */ import org.bukkit.potion.PotionEffectType;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class Claustrophobia implements Listener, VisibleAbility {
/* 22 */   private final Map<Player, Integer> stacks = new HashMap<>();
/*    */   
/*    */   @EventHandler
/*    */   public void onServerTickEnd(ServerTickEndEvent event) {
/* 26 */     for (Iterator<Player> iterator = Bukkit.getOnlinePlayers().iterator(); iterator.hasNext(); ) { Player p = iterator.next();
/* 27 */       runForAbility((Entity)p, player -> {
/*    */             if (player.getLocation().getBlock().getRelative(BlockFace.UP, 2).isSolid()) {
/*    */               this.stacks.put(player, Integer.valueOf(Math.min(((Integer)this.stacks.getOrDefault(player, Integer.valueOf(-200))).intValue() + 1, 3600)));
/*    */             } else {
/*    */               this.stacks.put(player, Integer.valueOf(Math.max(((Integer)this.stacks.getOrDefault(player, Integer.valueOf(-200))).intValue() - 1, -200)));
/*    */             } 
/*    */             int time = ((Integer)this.stacks.getOrDefault(player, Integer.valueOf(-200))).intValue();
/*    */             if (time > 0) {
/*    */               player.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, time, 0, true, true, true));
/*    */               player.addPotionEffect(new PotionEffect(MVPotionEffectType.SLOWNESS.get(), time, 0, true, true, true));
/*    */             } 
/*    */           }); }
/*    */   
/*    */   } @EventHandler
/*    */   public void onPlayerItemConsume(PlayerItemConsumeEvent event) {
/* 42 */     if (event.getItem().getType() == Material.MILK_BUCKET) {
/* 43 */       this.stacks.put(event.getPlayer(), Integer.valueOf(Math.min(((Integer)this.stacks.getOrDefault(event.getPlayer(), Integer.valueOf(-200))).intValue(), 0)));
/*    */     }
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 49 */     return Key.key("origins:claustrophobia");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 54 */     return "Being somewhere with a low ceiling for too long will weaken you and make you slower.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 59 */     return "Claustrophobia";
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\Claustrophobia.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */