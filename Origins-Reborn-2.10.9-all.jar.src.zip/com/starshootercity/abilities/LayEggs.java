/*    */ package com.starshootercity.abilities;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.Sound;
/*    */ import org.bukkit.SoundCategory;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.world.TimeSkipEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class LayEggs implements Listener, VisibleAbility {
/*    */   @EventHandler
/*    */   public void onTimeSkip(TimeSkipEvent event) {
/* 19 */     if (event.getSkipReason() == TimeSkipEvent.SkipReason.NIGHT_SKIP) {
/* 20 */       for (Player p : Bukkit.getOnlinePlayers()) {
/* 21 */         runForAbility((Entity)p, player -> {
/*    */               if (player.isDeeplySleeping()) {
/*    */                 player.getWorld().dropItem(player.getLocation(), new ItemStack(Material.EGG));
/*    */                 player.getWorld().playSound(player.getLocation(), Sound.ENTITY_CHICKEN_EGG, SoundCategory.PLAYERS, 1.0F, 1.0F);
/*    */               } 
/*    */             });
/*    */       } 
/*    */     }
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 33 */     return Key.key("origins:lay_eggs");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 38 */     return "Whenever you wake up in the morning, you will lay an egg.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 43 */     return "Oviparous";
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\LayEggs.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */