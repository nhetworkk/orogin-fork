/*    */ package com.starshootercity.abilities;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.GameEvent;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.world.GenericGameEvent;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class VelvetPaws implements Listener, VisibleAbility {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 14 */     return Key.key("origins:velvet_paws");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 19 */     return "Your footsteps don't cause any vibrations which could otherwise be picked up by nearby lifeforms.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 24 */     return "Velvet Paws";
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onGenericGameEvent(GenericGameEvent event) {
/* 29 */     if (event.getEvent() == GameEvent.STEP)
/* 30 */       runForAbility(event.getEntity(), player -> event.setCancelled(true)); 
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\VelvetPaws.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */