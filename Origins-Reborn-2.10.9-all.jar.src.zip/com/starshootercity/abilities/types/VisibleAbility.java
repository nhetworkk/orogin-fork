/*    */ package com.starshootercity.abilities.types;
/*    */ 
/*    */ import com.starshootercity.APITarget;
/*    */ import com.starshootercity.OriginSwapper;
/*    */ import java.util.List;
/*    */ import org.jetbrains.annotations.ApiStatus.Internal;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @APITarget
/*    */ public interface VisibleAbility
/*    */   extends Ability
/*    */ {
/*    */   @Internal
/*    */   default void setupTranslatedText() {
/* 22 */     registerTranslation("title", title());
/* 23 */     registerTranslation("description", description());
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   default List<OriginSwapper.LineData.LineComponent> getDescription() {
/* 28 */     if (!useTranslator()) return OriginSwapper.LineData.makeLineFor(description(), OriginSwapper.LineData.LineComponent.LineType.DESCRIPTION);
/*    */     
/* 30 */     String value = translate("description");
/*    */     try {
/* 32 */       value = modifyDescription(value);
/* 33 */     } catch (Throwable throwable) {}
/* 34 */     return OriginSwapper.LineData.makeLineFor(value, OriginSwapper.LineData.LineComponent.LineType.DESCRIPTION);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   String description();
/*    */ 
/*    */ 
/*    */   
/*    */   @NotNull
/*    */   default List<OriginSwapper.LineData.LineComponent> getTitle() {
/* 46 */     if (!useTranslator()) return OriginSwapper.LineData.makeLineFor(title(), OriginSwapper.LineData.LineComponent.LineType.TITLE);
/*    */     
/* 48 */     String value = translate("title");
/*    */     try {
/* 50 */       value = modifyDescription(value);
/* 51 */     } catch (Throwable throwable) {}
/* 52 */     return OriginSwapper.LineData.makeLineFor(value, OriginSwapper.LineData.LineComponent.LineType.TITLE);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   String title();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default String modifyDescription(String description) {
/* 68 */     return description;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default String modifyTitle(String title) {
/* 77 */     return title;
/*    */   }
/*    */   
/*    */   default boolean useTranslator() {
/* 81 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\types\VisibleAbility.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */