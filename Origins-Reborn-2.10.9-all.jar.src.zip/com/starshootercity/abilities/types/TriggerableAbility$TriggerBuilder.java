/*     */ package com.starshootercity.abilities.types;
/*     */ 
/*     */ import com.starshootercity.OriginsReborn;
/*     */ import com.starshootercity.util.config.ConfigManager;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TriggerBuilder
/*     */ {
/*     */   private final TriggerableAbility.TriggerType type;
/*     */   private final Set<TriggerableAbility.Condition> conditions;
/*     */   private final Ability ability;
/*     */   
/*     */   public TriggerableAbility.Trigger build(TriggerableAbility.TriggerRunner runner) {
/*  91 */     String typePath = "trigger.type";
/*  92 */     String conditionPath = "trigger.conditions";
/*     */     
/*  94 */     this.ability.registerConfigOption(typePath, 
/*     */         
/*  96 */         List.of("The action (e.g. LEFT_CLICK, RIGHT_CLICK) that triggers this ability", "You can see a full list of actions at https://starshooter.gitbook.io/origins-reborn/configuration#triggerable-ability-configuration"), ConfigManager.SettingType.STRING, this.type
/*     */         
/*  98 */         .toString());
/*     */ 
/*     */     
/* 101 */     List<String> conditionList = new ArrayList<>();
/* 102 */     for (TriggerableAbility.Condition condition : this.conditions) {
/* 103 */       conditionList.add(condition.toString());
/*     */     }
/*     */     
/* 106 */     this.ability.registerConfigOption(conditionPath, 
/*     */         
/* 108 */         List.of("The conditions (e.g. EMPTY_HAND, NO_BLOCK) that are required to trigger this ability", "You can see a full list of conditions at https://starshooter.gitbook.io/origins-reborn/configuration#triggerable-ability-configuration"), ConfigManager.SettingType.STRING_LIST, conditionList);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 113 */     TriggerableAbility.TriggerType usedType = this.type;
/*     */     try {
/* 115 */       usedType = TriggerableAbility.TriggerType.valueOf(this.ability.<String>getConfigOption(typePath, ConfigManager.SettingType.STRING));
/* 116 */     } catch (IllegalArgumentException e) {
/* 117 */       OriginsReborn.getInstance().getLogger().warning("Malformed trigger configuration for ability %s, using default values".formatted(new Object[] { this.ability.getRegisteredKey() }));
/*     */     } 
/*     */     
/* 120 */     Set<TriggerableAbility.Condition> usedConditions = this.conditions;
/*     */     try {
/* 122 */       Set<TriggerableAbility.Condition> newConds = new HashSet<>();
/* 123 */       for (String s : this.ability.<List>getConfigOption(conditionPath, ConfigManager.SettingType.STRING_LIST)) {
/* 124 */         newConds.add(TriggerableAbility.Condition.valueOf(s));
/*     */       }
/* 126 */       usedConditions = newConds;
/* 127 */     } catch (IllegalArgumentException e) {
/* 128 */       OriginsReborn.getInstance().getLogger().warning("Malformed trigger configuration for ability %s, using default values".formatted(new Object[] { this.ability.getRegisteredKey() }));
/*     */     } 
/*     */     
/* 131 */     return new TriggerableAbility.Trigger(usedType, usedConditions, runner, this.ability);
/*     */   }
/*     */   
/*     */   public TriggerBuilder addConditions(TriggerableAbility.Condition... conditions) {
/* 135 */     this.conditions.addAll(Arrays.<TriggerableAbility.Condition>stream(conditions).toList());
/* 136 */     return this;
/*     */   }
/*     */   
/*     */   private TriggerBuilder(TriggerableAbility.TriggerType type, Ability ability) {
/* 140 */     this.type = type;
/* 141 */     this.ability = ability;
/* 142 */     this.conditions = new HashSet<>();
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\types\TriggerableAbility$TriggerBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */