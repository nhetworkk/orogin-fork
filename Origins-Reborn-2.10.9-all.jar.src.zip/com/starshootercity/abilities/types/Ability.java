/*     */ package com.starshootercity.abilities.types;
/*     */ 
/*     */ import com.sk89q.worldedit.bukkit.BukkitAdapter;
/*     */ import com.sk89q.worldedit.util.Location;
/*     */ import com.sk89q.worldguard.WorldGuard;
/*     */ import com.sk89q.worldguard.protection.ApplicableRegionSet;
/*     */ import com.sk89q.worldguard.protection.regions.ProtectedRegion;
/*     */ import com.sk89q.worldguard.protection.regions.RegionContainer;
/*     */ import com.sk89q.worldguard.protection.regions.RegionQuery;
/*     */ import com.starshootercity.APITarget;
/*     */ import com.starshootercity.AddonLoader;
/*     */ import com.starshootercity.Origin;
/*     */ import com.starshootercity.OriginSwapper;
/*     */ import com.starshootercity.OriginsAddon;
/*     */ import com.starshootercity.OriginsReborn;
/*     */ import com.starshootercity.Translator;
/*     */ import com.starshootercity.util.AbilityRegister;
/*     */ import com.starshootercity.util.WorldGuardHook;
/*     */ import com.starshootercity.util.config.ConfigManager;
/*     */ import java.util.List;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import org.bukkit.configuration.ConfigurationSection;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @APITarget
/*     */ public interface Ability
/*     */ {
/*     */   @NotNull
/*     */   default Key getRegisteredKey() {
/*  45 */     return (Key)AbilityRegister.invertedAbilityMap.get(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void runForAbility(Entity entity, @NotNull AbilityRunner runner) {
/*  54 */     runForAbility(entity, runner, (AbilityRunner)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void runForAbility(Entity entity, @Nullable AbilityRunner has, @Nullable AbilityRunner other) {
/*  64 */     if (entity instanceof Player) { Player player = (Player)entity;
/*  65 */       if (hasAbility(player))
/*  66 */       { if (has != null) has.run(player);  }
/*  67 */       else if (other != null) { other.run(player); }
/*     */        }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void runForAbility(Entity entity, @Nullable AbilityRunner has, @Nullable Runnable other) {
/*  78 */     if (entity instanceof Player) { Player player = (Player)entity;
/*  79 */       if (hasAbility(player))
/*  80 */       { if (has != null) has.run(player);  }
/*  81 */       else if (other != null) { other.run(); }  }
/*  82 */     else if (other != null) { other.run(); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean hasAbility(Player player) {
/*  91 */     if (AbilityRegister.disabledWorlds.contains(player.getWorld().getName())) return false;
/*     */     
/*  93 */     for (OriginsAddon.KeyStateGetter keyStateGetter : AddonLoader.abilityOverrideChecks) {
/*  94 */       OriginsAddon.State state = keyStateGetter.get(player, getRegisteredKey());
/*  95 */       if (state == OriginsAddon.State.DENY) return false; 
/*  96 */       if (state == OriginsAddon.State.ALLOW) return true;
/*     */     
/*     */     } 
/*  99 */     if (OriginsReborn.isWorldGuardHookInitialized()) {
/* 100 */       if (WorldGuardHook.isAbilityDisabled(player.getLocation(), this)) return false;
/*     */       
/* 102 */       ConfigurationSection section = OriginsReborn.getInstance().getConfig().getConfigurationSection("prevent-abilities-in");
/* 103 */       Location loc = BukkitAdapter.adapt(player.getLocation());
/* 104 */       if (section != null) {
/* 105 */         RegionContainer container = WorldGuard.getInstance().getPlatform().getRegionContainer();
/* 106 */         RegionQuery query = container.createQuery();
/* 107 */         ApplicableRegionSet set = query.getApplicableRegions(loc);
/* 108 */         for (ProtectedRegion region : set) {
/* 109 */           for (String sectionKey : section.getKeys(false)) {
/* 110 */             if (!section.getStringList(sectionKey).contains(getRegisteredKey().toString()) && !section.getStringList(sectionKey).contains("all"))
/*     */               continue; 
/* 112 */             if (region.getId().equalsIgnoreCase(sectionKey)) {
/* 113 */               return false;
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 120 */     List<Origin> origins = OriginSwapper.getOrigins(player);
/* 121 */     boolean hasAbility = origins.stream().anyMatch(origin -> origin.hasAbility(this));
/*     */     
/* 123 */     Object object = AbilityRegister.abilityMap.get(getRegisteredKey()); if (object instanceof DependantAbility) { DependantAbility dependantAbility = (DependantAbility)object;
/* 124 */       return (hasAbility && ((dependantAbility.getDependencyType() == DependantAbility.DependencyType.REGULAR)) == dependantAbility.getDependency().isEnabled(player)); }
/*     */ 
/*     */     
/* 127 */     return hasAbility;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void initialize(JavaPlugin plugin) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void registerTranslation(String key, String def) {
/* 151 */     Translator.registerTranslation("abilities." + String.valueOf(getRegisteredKey()) + "." + key, def);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default String translate(String key) {
/* 161 */     return Translator.translate("abilities." + String.valueOf(getRegisteredKey()) + "." + key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default <T> T registerConfigOption(JavaPlugin plugin, String path, List<String> comments, ConfigManager.SettingType<T> settingType, T defaultValue) {
/* 175 */     AbilityRegister.registerConfigOption(plugin, this, settingType, path, comments, defaultValue);
/* 176 */     return getConfigOption(plugin, path, settingType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default <T> void registerConfigOption(String path, List<String> comments, ConfigManager.SettingType<T> settingType, T defaultValue) {
/* 189 */     registerConfigOption((OriginsAddon)AbilityRegister.pluginMap.get(getRegisteredKey()), path, comments, settingType, defaultValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default <T> T getConfigOption(JavaPlugin plugin, String path, ConfigManager.SettingType<T> settingType) {
/* 202 */     return (T)AbilityRegister.getConfigOption(plugin, this, settingType, path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   default <T> T getConfigOption(OriginsAddon addon, String path, ConfigManager.SettingType<T> settingType) {
/* 212 */     return (T)AbilityRegister.getConfigOption((JavaPlugin)addon, this, settingType, path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(forRemoval = true)
/*     */   default <T> void registerConfigOption(OriginsAddon addon, String path, List<String> comments, ConfigManager.SettingType<T> settingType, T defaultValue) {
/* 222 */     AbilityRegister.registerConfigOption((JavaPlugin)addon, this, settingType, path, comments, defaultValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default <T> T getConfigOption(String path, ConfigManager.SettingType<T> settingType) {
/* 235 */     return getConfigOption((OriginsAddon)AbilityRegister.pluginMap.get(getRegisteredKey()), path, settingType);
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   Key getKey();
/*     */   
/*     */   public static interface AbilityRunner {
/*     */     void run(Player param1Player);
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\types\Ability.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */