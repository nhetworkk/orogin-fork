/*    */ package com.starshootercity.abilities.types;
/*    */ 
/*    */ import com.starshootercity.APITarget;
/*    */ import com.starshootercity.OriginsReborn;
/*    */ import com.starshootercity.cooldowns.Cooldowns;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import java.util.Collections;
/*    */ import org.bukkit.NamespacedKey;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @APITarget
/*    */ public interface CooldownAbility
/*    */   extends Ability
/*    */ {
/*    */   public static final String COOLDOWN = "cooldown-duration";
/*    */   
/*    */   default NamespacedKey getCooldownKey() {
/* 23 */     return new NamespacedKey((Plugin)OriginsReborn.getInstance(), getRegisteredKey().asString().replace(":", "-"));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default void setCooldown(Player player) {
/* 31 */     if (((Boolean)ConfigManager.getConfigValue(ConfigManager.Option.DISABLE_ALL_COOLDOWNS)).booleanValue())
/* 32 */       return;  OriginsReborn.getCooldowns().setCooldown(player, getCooldownKey());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default void setCooldown(Player player, int amount) {
/* 41 */     if (((Boolean)ConfigManager.getConfigValue(ConfigManager.Option.DISABLE_ALL_COOLDOWNS)).booleanValue())
/* 42 */       return;  OriginsReborn.getCooldowns().setCooldown(player, getCooldownKey(), amount);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default boolean hasCooldown(Player player) {
/* 51 */     if (((Boolean)ConfigManager.getConfigValue(ConfigManager.Option.DISABLE_ALL_COOLDOWNS)).booleanValue()) return false; 
/* 52 */     return OriginsReborn.getCooldowns().hasCooldown(player, getCooldownKey());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default long getCooldown(Player player) {
/* 60 */     return OriginsReborn.getCooldowns().getCooldown(player, getCooldownKey());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   Cooldowns.CooldownInfo getCooldownInfo();
/*    */ 
/*    */   
/*    */   default void setupCooldownConfig(JavaPlugin instance) {
/* 69 */     Cooldowns.CooldownInfo info = getCooldownInfo();
/* 70 */     if (!info.isStatic()) {
/* 71 */       int i = ((Integer)registerConfigOption(instance, "cooldown-duration", Collections.singletonList("The duration of the cooldown (in ticks)"), ConfigManager.SettingType.INTEGER, Integer.valueOf(info.getCooldownTime()))).intValue();
/* 72 */       info.setCooldownTime(i);
/*    */     } 
/* 74 */     OriginsReborn.getCooldowns().registerCooldown(instance, getCooldownKey(), info);
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\types\CooldownAbility.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */