package com.starshootercity.abilities.types;

import com.starshootercity.APITarget;
import org.bukkit.entity.Player;

@APITarget
public interface DependencyAbility extends Ability {
  boolean isEnabled(Player paramPlayer);
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\types\DependencyAbility.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */