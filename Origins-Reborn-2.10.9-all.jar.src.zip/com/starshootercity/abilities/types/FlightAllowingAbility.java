/*    */ package com.starshootercity.abilities.types;
/*    */ 
/*    */ import com.starshootercity.APITarget;
/*    */ import net.kyori.adventure.util.TriState;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @APITarget
/*    */ public interface FlightAllowingAbility
/*    */   extends Ability
/*    */ {
/*    */   boolean canFly(Player paramPlayer);
/*    */   
/*    */   float getFlightSpeed(Player paramPlayer);
/*    */   
/*    */   default boolean forceFly(Player player) {
/* 31 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @NotNull
/*    */   default TriState getFlyingFallDamage(Player player) {
/* 39 */     return TriState.FALSE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default int getPriority() {
/* 46 */     return 1;
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\types\FlightAllowingAbility.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */