/*    */ package com.starshootercity.abilities.types;
/*    */ 
/*    */ import com.starshootercity.APITarget;
/*    */ import com.starshootercity.util.SkinManager;
/*    */ import java.awt.image.BufferedImage;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @APITarget
/*    */ public interface SkinChangingAbility
/*    */   extends Ability
/*    */ {
/*    */   void modifySkin(BufferedImage paramBufferedImage, Player paramPlayer);
/*    */   
/*    */   default int getPriority(Player player) {
/* 34 */     return 0;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default boolean forceEnabled() {
/* 44 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default boolean shouldApply(Player player) {
/* 53 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default void forceUpdate(Player player) {
/* 61 */     SkinManager.updateSkin(player, true);
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\types\SkinChangingAbility.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */