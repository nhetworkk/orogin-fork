package com.starshootercity.abilities.types;

import org.bukkit.entity.Player;

public interface AbilityRunner {
  void run(Player paramPlayer);
}


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\types\Ability$AbilityRunner.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */