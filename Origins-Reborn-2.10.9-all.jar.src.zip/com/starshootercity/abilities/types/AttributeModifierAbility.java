/*    */ package com.starshootercity.abilities.types;
/*    */ 
/*    */ import com.starshootercity.APITarget;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import net.objecthunter.exp4j.ExpressionBuilder;
/*    */ import org.bukkit.attribute.Attribute;
/*    */ import org.bukkit.attribute.AttributeModifier;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @APITarget
/*    */ public interface AttributeModifierAbility
/*    */   extends Ability
/*    */ {
/*    */   public static final String OPERATION = "attribute-modifier.operation";
/*    */   public static final String EXP = "attribute-modifier.expression";
/*    */   
/*    */   @NotNull
/*    */   Attribute getAttribute();
/*    */   
/*    */   double getAmount(Player paramPlayer);
/*    */   
/*    */   AttributeModifier.Operation getOperation();
/*    */   
/*    */   default double getTotalAmount(Player player) {
/* 44 */     double total = getAmount(player);
/*    */     
/* 46 */     if (disallowConfiguration()) return total;
/*    */     
/* 48 */     if (total != 0.0D) {
/* 49 */       String modifiedValue = getConfigOption("attribute-modifier.expression", ConfigManager.SettingType.STRING);
/* 50 */       if (modifiedValue.equals("x")) return total; 
/*    */       try {
/* 52 */         return (new ExpressionBuilder(modifiedValue)).variables(new String[] { "x" }).build().setVariable("x", total).evaluate();
/* 53 */       } catch (Throwable throwable) {}
/*    */     } 
/* 55 */     return total;
/*    */   }
/*    */   
/*    */   default AttributeModifier.Operation getActualOperation() {
/* 59 */     if (disallowConfiguration()) return getOperation();
/*    */     
/* 61 */     String op = ((String)getConfigOption("attribute-modifier.operation", ConfigManager.SettingType.STRING)).toLowerCase();
/* 62 */     switch (op) { case "add_scalar": case "add_number": case "multiply_scalar_1":  }  return 
/*    */ 
/*    */ 
/*    */       
/* 66 */       getOperation();
/*    */   }
/*    */ 
/*    */   
/*    */   default void setupAttributeConfig() {
/* 71 */     if (disallowConfiguration())
/* 72 */       return;  registerConfigOption("attribute-modifier.operation", Collections.singletonList("The operation to use ('ADD_SCALAR', 'ADD_NUMBER' or 'MULTIPLY_SCALAR_1')"), ConfigManager.SettingType.STRING, getOperation().toString());
/* 73 */     registerConfigOption("attribute-modifier.expression", List.of("A mathematical expression used to modify the attribute, where 'x' is a variable representing the default modifier.", "Example: 'x * 3' will triple the value used in the modifier."), ConfigManager.SettingType.STRING, "x");
/*    */   }
/*    */   
/*    */   default boolean disallowConfiguration() {
/* 77 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\types\AttributeModifierAbility.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */