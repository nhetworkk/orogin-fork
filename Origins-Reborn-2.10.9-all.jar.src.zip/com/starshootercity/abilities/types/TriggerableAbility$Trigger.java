/*     */ package com.starshootercity.abilities.types;
/*     */ 
/*     */ import com.starshootercity.util.TriggerManager;
/*     */ import java.util.Set;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Trigger
/*     */ {
/*     */   private final TriggerableAbility.TriggerType type;
/*     */   private final Set<TriggerableAbility.Condition> conditions;
/*     */   private final TriggerableAbility.TriggerRunner runner;
/*     */   private final Ability ability;
/*     */   
/*     */   private Trigger(TriggerableAbility.TriggerType defaultType, Set<TriggerableAbility.Condition> defaultConditions, TriggerableAbility.TriggerRunner runner, Ability ability) {
/* 154 */     this.type = defaultType;
/* 155 */     this.conditions = defaultConditions;
/* 156 */     this.runner = runner;
/* 157 */     this.ability = ability;
/*     */   }
/*     */   
/*     */   public TriggerableAbility.TriggerType getType() {
/* 161 */     return this.type;
/*     */   }
/*     */   
/*     */   public static TriggerableAbility.TriggerBuilder builder(TriggerableAbility.TriggerType type, Ability ability) {
/* 165 */     return new TriggerableAbility.TriggerBuilder(type, ability);
/*     */   }
/*     */   
/*     */   public void run(TriggerManager.TriggerEvent event) {
/* 169 */     for (TriggerableAbility.Condition condition : this.conditions) {
/* 170 */       if (!condition.predicate.test(event))
/*     */         return; 
/* 172 */     }  this.ability.runForAbility((Entity)event.player(), player -> this.runner.run(event));
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\types\TriggerableAbility$Trigger.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */