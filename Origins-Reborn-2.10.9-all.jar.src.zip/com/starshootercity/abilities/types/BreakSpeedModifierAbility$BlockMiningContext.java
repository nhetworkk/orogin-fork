/*    */ package com.starshootercity.abilities.types;
/*    */ 
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.bukkit.potion.PotionEffect;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BlockMiningContext
/*    */   extends Record
/*    */ {
/*    */   private final ItemStack heldItem;
/*    */   @Nullable
/*    */   private final PotionEffect slowDigging;
/*    */   @Nullable
/*    */   private final PotionEffect fastDigging;
/*    */   @Nullable
/*    */   private final PotionEffect conduitPower;
/*    */   private final boolean underwater;
/*    */   private final boolean aquaAffinity;
/*    */   private final boolean onGround;
/*    */   
/*    */   public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lcom/starshootercity/abilities/types/BreakSpeedModifierAbility$BlockMiningContext;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #67	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lcom/starshootercity/abilities/types/BreakSpeedModifierAbility$BlockMiningContext;
/*    */   }
/*    */   
/*    */   public final int hashCode() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lcom/starshootercity/abilities/types/BreakSpeedModifierAbility$BlockMiningContext;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #67	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lcom/starshootercity/abilities/types/BreakSpeedModifierAbility$BlockMiningContext;
/*    */   }
/*    */   
/*    */   public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lcom/starshootercity/abilities/types/BreakSpeedModifierAbility$BlockMiningContext;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #67	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lcom/starshootercity/abilities/types/BreakSpeedModifierAbility$BlockMiningContext;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/*    */   }
/*    */   
/*    */   public BlockMiningContext(ItemStack heldItem, @Nullable PotionEffect slowDigging, @Nullable PotionEffect fastDigging, @Nullable PotionEffect conduitPower, boolean underwater, boolean aquaAffinity, boolean onGround) {
/* 67 */     this.heldItem = heldItem; this.slowDigging = slowDigging; this.fastDigging = fastDigging; this.conduitPower = conduitPower; this.underwater = underwater; this.aquaAffinity = aquaAffinity; this.onGround = onGround; } public ItemStack heldItem() { return this.heldItem; } @Nullable public PotionEffect slowDigging() { return this.slowDigging; } @Nullable public PotionEffect fastDigging() { return this.fastDigging; } @Nullable public PotionEffect conduitPower() { return this.conduitPower; } public boolean underwater() { return this.underwater; } public boolean aquaAffinity() { return this.aquaAffinity; } public boolean onGround() { return this.onGround; }
/*    */   
/*    */   public boolean hasDigSpeed() {
/* 70 */     return (this.fastDigging != null || this.conduitPower != null);
/*    */   }
/*    */   
/*    */   public boolean hasDigSlowdown() {
/* 74 */     return (this.slowDigging != null);
/*    */   }
/*    */   
/*    */   public int getDigSlowdown() {
/* 78 */     if (this.slowDigging == null) return 0; 
/* 79 */     return this.slowDigging.getAmplifier();
/*    */   }
/*    */   
/*    */   public int getDigSpeedAmplification() {
/* 83 */     int i = 0;
/* 84 */     int j = 0;
/* 85 */     if (this.fastDigging != null) {
/* 86 */       i = this.fastDigging.getAmplifier();
/*    */     }
/* 88 */     if (this.conduitPower != null) {
/* 89 */       j = this.conduitPower.getAmplifier();
/*    */     }
/* 91 */     return Math.max(i, j);
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\types\BreakSpeedModifierAbility$BlockMiningContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */