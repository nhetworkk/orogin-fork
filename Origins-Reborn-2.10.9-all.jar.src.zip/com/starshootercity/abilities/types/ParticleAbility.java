/*    */ package com.starshootercity.abilities.types;
/*    */ 
/*    */ import com.destroystokyo.paper.event.server.ServerTickEndEvent;
/*    */ import com.starshootercity.APITarget;
/*    */ import com.starshootercity.Origin;
/*    */ import com.starshootercity.OriginSwapper;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.GameMode;
/*    */ import org.bukkit.Particle;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @APITarget
/*    */ public interface ParticleAbility
/*    */   extends Ability
/*    */ {
/*    */   Particle getParticle();
/*    */   
/*    */   default int getFrequency() {
/* 32 */     return 4;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default int getExtra() {
/* 39 */     return 0;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default Object getData() {
/* 46 */     return null;
/*    */   }
/*    */   
/*    */   public static class ParticleAbilityListener implements Listener {
/*    */     @EventHandler
/*    */     public void onServerTickEnd(ServerTickEndEvent event) {
/* 52 */       for (Player player : Bukkit.getOnlinePlayers()) {
/* 53 */         if (player.getGameMode().equals(GameMode.SPECTATOR))
/* 54 */           continue;  List<Origin> origins = OriginSwapper.getOrigins(player);
/* 55 */         List<Ability> abilities = new ArrayList<>();
/* 56 */         for (Origin origin : origins) abilities.addAll(origin.getAbilities()); 
/* 57 */         for (Ability ability : abilities) {
/* 58 */           if (ability instanceof ParticleAbility) { ParticleAbility particleAbility = (ParticleAbility)ability;
/* 59 */             if (event.getTickNumber() % particleAbility.getFrequency() == 0)
/* 60 */               player.getWorld().spawnParticle(particleAbility.getParticle(), player.getLocation(), 1, 0.5D, 1.0D, 0.5D, particleAbility.getExtra(), particleAbility.getData());  }
/*    */         
/*    */         } 
/*    */       } 
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\types\ParticleAbility.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */