/*     */ package com.starshootercity.abilities;
/*     */ 
/*     */ import com.destroystokyo.paper.MaterialTags;
/*     */ import com.starshootercity.OriginsReborn;
/*     */ import com.starshootercity.abilities.types.BreakSpeedModifierAbility;
/*     */ import com.starshootercity.version.MVEnchantment;
/*     */ import com.starshootercity.version.MVPotionEffectType;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import org.bukkit.FluidCollisionMode;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.entity.LivingEntity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StrongArmsBreakSpeed
/*     */   implements BreakSpeedModifierAbility, Listener
/*     */ {
/*  94 */   public static StrongArmsBreakSpeed strongArmsBreakSpeed = new StrongArmsBreakSpeed();
/*     */   
/*     */   @NotNull
/*     */   public Key getKey() {
/*  98 */     return Key.key("origins:strong_arms_break_speed");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BreakSpeedModifierAbility.BlockMiningContext getMiningContext(Player player) {
/* 104 */     boolean aquaAffinity = false;
/* 105 */     ItemStack helmet = player.getInventory().getHelmet();
/* 106 */     if (helmet != null && 
/* 107 */       helmet.containsEnchantment(MVEnchantment.AQUA_AFFINITY.get())) aquaAffinity = true;
/*     */     
/* 109 */     return new BreakSpeedModifierAbility.BlockMiningContext(new ItemStack(Material.IRON_PICKAXE), player
/*     */         
/* 111 */         .getPotionEffect(MVPotionEffectType.MINING_FATIGUE.get()), player
/* 112 */         .getPotionEffect(MVPotionEffectType.HASTE.get()), player
/* 113 */         .getPotionEffect(MVPotionEffectType.CONDUIT_POWER.get()), 
/* 114 */         OriginsReborn.getMVE().isUnderWater((LivingEntity)player), aquaAffinity, player
/*     */         
/* 116 */         .isOnGround());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldActivate(Player player) {
/* 122 */     Block target = player.getTargetBlockExact(8, FluidCollisionMode.NEVER);
/* 123 */     return (!MaterialTags.PICKAXES.isTagged(player.getInventory().getItemInMainHand().getType()) && target != null && StrongArms.naturalStones.contains(target.getType()));
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\StrongArms$StrongArmsBreakSpeed.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */