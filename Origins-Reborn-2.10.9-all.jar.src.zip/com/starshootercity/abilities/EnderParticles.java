/*    */ package com.starshootercity.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.ParticleAbility;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import java.util.Collections;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.Particle;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class EnderParticles
/*    */   implements ParticleAbility {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 15 */     return Key.key("origins:ender_particles");
/*    */   }
/*    */   private int frequency;
/*    */   
/*    */   public Particle getParticle() {
/* 20 */     return Particle.PORTAL;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getFrequency() {
/* 25 */     return this.frequency;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void initialize(JavaPlugin plugin) {
/* 32 */     this.frequency = ((Integer)registerConfigOption(plugin, "frequency", Collections.singletonList("How often (in ticks) the particles should appear"), ConfigManager.SettingType.INTEGER, Integer.valueOf(4))).intValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\EnderParticles.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */