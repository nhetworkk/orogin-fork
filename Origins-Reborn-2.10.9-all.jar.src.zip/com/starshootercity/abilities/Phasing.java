/*     */ package com.starshootercity.abilities;
/*     */ import com.destroystokyo.paper.event.server.ServerTickEndEvent;
/*     */ import com.starshootercity.OriginsReborn;
/*     */ import com.starshootercity.abilities.types.BreakSpeedModifierAbility;
/*     */ import com.starshootercity.abilities.types.DependantAbility;
/*     */ import com.starshootercity.abilities.types.FlightAllowingAbility;
/*     */ import com.starshootercity.abilities.types.VisibleAbility;
/*     */ import com.starshootercity.util.ShortcutUtils;
/*     */ import com.starshootercity.util.config.ConfigManager;
/*     */ import com.starshootercity.version.MVPotionEffectType;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.function.Predicate;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.block.BlockFace;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.LivingEntity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.entity.EntityDamageEvent;
/*     */ import org.bukkit.event.player.PlayerMoveEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ import org.bukkit.potion.PotionEffect;
/*     */ import org.bukkit.potion.PotionEffectType;
/*     */ import org.bukkit.util.Vector;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ public class Phasing implements DependantAbility, FlightAllowingAbility, BreakSpeedModifierAbility, Listener, VisibleAbility {
/*     */   private boolean giveBlindness;
/*     */   
/*     */   @NotNull
/*     */   public Key getKey() {
/*  43 */     return Key.key("origins:phasing");
/*     */   }
/*     */   private float phasingSpeed; private List<Material> impassable;
/*     */   @NotNull
/*     */   public Key getDependencyKey() {
/*  48 */     return Key.key("origins:phantomize");
/*     */   }
/*     */ 
/*     */   
/*     */   public String description() {
/*  53 */     return "While phantomized, you can walk through solid material, except Obsidian.";
/*     */   }
/*     */ 
/*     */   
/*     */   public String title() {
/*  58 */     return "Phasing";
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onServerTick(ServerTickEndEvent event) {
/*  64 */     for (Iterator<Player> iterator = Bukkit.getOnlinePlayers().iterator(); iterator.hasNext(); ) { Player p = iterator.next();
/*  65 */       runForAbility((Entity)p, player -> {
/*  66 */             boolean begins = (player.isSneaking() && player.isOnGround() && !this.impassable.contains(player.getLocation().getBlock().getRelative(BlockFace.DOWN).getType()));
/*  67 */             setPhasing(player, (begins || isInBlock((Entity)player)), begins);
/*  68 */             OriginsReborn.getMVE().setNoPhysics(player, (player.getGameMode() == GameMode.SPECTATOR || ((Boolean)this.isPhasing.computeIfAbsent(player, ())).booleanValue()));
/*     */             if (((Boolean)this.isPhasing.computeIfAbsent(player, ())).booleanValue()) {
/*     */               player.setFallDistance(0.0F);
/*     */               if (player.getAllowFlight())
/*     */                 player.setFlying(true); 
/*     */             } 
/*     */           }player -> {
/*     */             if (((Boolean)this.isPhasing.computeIfAbsent(player, ())).booleanValue())
/*     */               setPhasing(player, false, false); 
/*     */           }); }
/*     */   
/*     */   } @EventHandler
/*     */   public void onPlayerMove(PlayerMoveEvent event) {
/*  81 */     if (((Boolean)this.isPhasing.computeIfAbsent(event.getPlayer(), pl -> Boolean.valueOf(false))).booleanValue() && isInBlock(event.getTo(), block -> this.impassable.contains(block.getType()))) {
/*  82 */       event.setCancelled(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize(JavaPlugin plugin) {
/*  91 */     this.impassable = (List<Material>)registerConfigOption(plugin, "impassable_blocks", Collections.singletonList("Blocks you cannot pass through when phasing"), ConfigManager.SettingType.MATERIAL_LIST, List.of(Material.OBSIDIAN, Material.CRYING_OBSIDIAN, Material.BEDROCK));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  96 */     this.giveBlindness = ((Boolean)registerConfigOption(plugin, "give_blindness", Collections.singletonList("Apply Blindness when Phasing"), ConfigManager.SettingType.BOOLEAN, Boolean.valueOf(true))).booleanValue();
/*  97 */     this.phasingSpeed = ((Float)registerConfigOption(plugin, "phasing_speed", Collections.singletonList("Speed at which the player should move when phasing"), ConfigManager.SettingType.FLOAT, Float.valueOf(0.1F))).floatValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInBlock(Entity entity) {
/* 103 */     return isInBlock(entity.getLocation(), block -> (block.getType().isSolid() && !this.impassable.contains(block.getType())));
/*     */   }
/*     */   
/*     */   public boolean isInBlock(Location location, Predicate<Block> predicate) {
/* 107 */     boolean isInsideBlock = false;
/* 108 */     for (Location currentLocation : List.of(location.clone().add(0.0D, 1.0D, 0.0D), location.clone())) {
/* 109 */       List<Double> values = List.of(Double.valueOf(0.4D), Double.valueOf(-0.4D));
/* 110 */       for (Iterator<Double> iterator = values.iterator(); iterator.hasNext(); ) { double x = ((Double)iterator.next()).doubleValue();
/* 111 */         for (Iterator<Double> iterator1 = values.iterator(); iterator1.hasNext(); ) { double z = ((Double)iterator1.next()).doubleValue();
/* 112 */           if (predicate.test(currentLocation.clone().add(x, 0.0D, z).getBlock())) {
/* 113 */             isInsideBlock = true;
/*     */             break;
/*     */           }  }
/*     */         
/* 117 */         if (isInsideBlock)
/*     */           break;  }
/* 119 */        if (isInsideBlock)
/*     */         break; 
/* 121 */     }  return isInsideBlock;
/*     */   }
/*     */   
/* 124 */   private final Map<Player, Boolean> isPhasing = new HashMap<>();
/*     */ 
/*     */   
/*     */   public boolean canFly(Player player) {
/* 128 */     return (getDependency().isEnabled(player) && ((Boolean)this.isPhasing.computeIfAbsent(player, pl -> Boolean.valueOf(false))).booleanValue());
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onEntityDamage(EntityDamageEvent event) {
/* 133 */     runForAbility(event.getEntity(), player -> {
/*     */           if (!((Boolean)this.isPhasing.getOrDefault(player, Boolean.valueOf(false))).booleanValue()) {
/*     */             return;
/*     */           }
/*     */           if (event.getCause() == EntityDamageEvent.DamageCause.SUFFOCATION)
/*     */             event.setCancelled(true); 
/*     */         });
/*     */   }
/*     */   
/*     */   public float getFlightSpeed(Player player) {
/* 143 */     return this.phasingSpeed;
/*     */   }
/*     */ 
/*     */   
/*     */   public BreakSpeedModifierAbility.BlockMiningContext getMiningContext(Player player) {
/* 148 */     ItemStack helmet = player.getInventory().getHelmet();
/* 149 */     boolean aquaAffinity = false;
/* 150 */     if (helmet != null) {
/* 151 */       aquaAffinity = helmet.containsEnchantment(MVEnchantment.AQUA_AFFINITY.get());
/*     */     }
/* 153 */     return new BreakSpeedModifierAbility.BlockMiningContext(player
/* 154 */         .getInventory().getItemInMainHand(), player
/* 155 */         .getPotionEffect(MVPotionEffectType.HASTE.get()), player
/* 156 */         .getPotionEffect(MVPotionEffectType.MINING_FATIGUE.get()), player
/* 157 */         .getPotionEffect(MVPotionEffectType.CONDUIT_POWER.get()), 
/* 158 */         OriginsReborn.getMVE().isUnderWater((LivingEntity)player), aquaAffinity, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldActivate(Player player) {
/* 166 */     return (getDependency().isEnabled(player) && ((Boolean)this.isPhasing.computeIfAbsent(player, pl -> Boolean.valueOf(false))).booleanValue());
/*     */   }
/*     */   
/*     */   private void setPhasing(Player player, boolean enabled, boolean begins) {
/* 170 */     enabled = (hasAbility(player) && enabled);
/* 171 */     Block block = player.getEyeLocation().getBlock();
/* 172 */     if (block.getType().isCollidable() && enabled) {
/* 173 */       if (this.giveBlindness) player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, ShortcutUtils.infiniteDuration(), 0, false, false)); 
/*     */     } else {
/* 175 */       PotionEffect pot = player.getPotionEffect(PotionEffectType.BLINDNESS);
/* 176 */       if (pot != null && ShortcutUtils.isInfinite(pot)) player.removePotionEffect(PotionEffectType.BLINDNESS); 
/*     */     } 
/* 178 */     if (((Boolean)this.isPhasing.computeIfAbsent(player, pl -> Boolean.valueOf(false))).booleanValue() == enabled)
/* 179 */       return;  Vector vector = player.getVelocity();
/* 180 */     GameMode gameMode = enabled ? GameMode.SPECTATOR : player.getGameMode();
/* 181 */     if (ShortcutUtils.isBedrockPlayer(player.getUniqueId()))
/* 182 */     { if (begins) player.teleport(player.getLocation().subtract(0.0D, 1.0D, 0.0D)); 
/* 183 */       OriginsReborn.getMVE().sendGamemodeUpdate(player, gameMode, true); }
/* 184 */     else { OriginsReborn.getMVE().sendGamemodeUpdate(player, gameMode, false); }
/* 185 */      Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)OriginsReborn.getInstance(), () -> player.setVelocity(vector));
/* 186 */     this.isPhasing.put(player, Boolean.valueOf(enabled));
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\Phasing.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */