/*     */ package com.starshootercity.abilities;
/*     */ import com.destroystokyo.paper.event.entity.EntityKnockbackByEntityEvent;
/*     */ import com.destroystokyo.paper.event.server.ServerTickEndEvent;
/*     */ import com.starshootercity.OriginsReborn;
/*     */ import com.starshootercity.cooldowns.Cooldowns;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.NamespacedKey;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.block.BlockFace;
/*     */ import org.bukkit.block.BlockState;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.HumanEntity;
/*     */ import org.bukkit.entity.LivingEntity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.block.BlockDropItemEvent;
/*     */ import org.bukkit.event.block.BlockFromToEvent;
/*     */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*     */ import org.bukkit.event.inventory.PrepareItemCraftEvent;
/*     */ import org.bukkit.inventory.Recipe;
/*     */ import org.bukkit.inventory.ShapelessRecipe;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ public class MasterOfWebs implements CooldownAbility, FlightAllowingAbility, Listener, VisibleAbility {
/*  36 */   private final Map<Player, List<Entity>> glowingEntities = new HashMap<>();
/*     */   
/*  38 */   private final List<Location> temporaryCobwebs = new ArrayList<>();
/*     */   
/*  40 */   private final Map<Location, BlockState> replacedBlocks = new HashMap<>();
/*     */   
/*     */   @EventHandler
/*     */   public void onBlockDropItem(BlockDropItemEvent event) {
/*  44 */     if (this.temporaryCobwebs.contains(event.getBlock().getLocation())) {
/*  45 */       event.setCancelled(true);
/*  46 */       this.temporaryCobwebs.remove(event.getBlock().getLocation());
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onBlockFromTo(BlockFromToEvent event) {
/*  52 */     if (this.temporaryCobwebs.contains(event.getToBlock().getLocation())) {
/*  53 */       event.setCancelled(true);
/*  54 */       event.getToBlock().setType(Material.AIR);
/*  55 */       this.temporaryCobwebs.remove(event.getToBlock().getLocation());
/*     */     } 
/*     */   }
/*     */   
/*  59 */   private final Map<UUID, Integer> lastKnockback = new HashMap<>();
/*     */   
/*     */   @EventHandler
/*     */   public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
/*  63 */     runForAbility(event.getDamager(), player -> {
/*     */           if (hasCooldown(player)) {
/*     */             return;
/*     */           }
/*     */           if (!event.getEntity().getLocation().getBlock().isSolid()) {
/*     */             setCooldown(player);
/*     */             Location location = event.getEntity().getLocation().getBlock().getLocation();
/*     */             this.temporaryCobwebs.add(location);
/*     */             Block block = location.getBlock();
/*     */             BlockState originalState = block.getState();
/*     */             this.replacedBlocks.put(location, originalState);
/*     */             block.setType(Material.COBWEB);
/*     */             int tick = Bukkit.getCurrentTick();
/*     */             UUID uuid = event.getEntity().getUniqueId();
/*     */             this.lastKnockback.put(uuid, Integer.valueOf(tick));
/*     */             Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)OriginsReborn.getInstance(), (), 60L);
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onEntityKnockbackByEntity(EntityKnockbackByEntityEvent event) {
/*  92 */     if (((Integer)this.lastKnockback.getOrDefault(event.getEntity().getUniqueId(), Integer.valueOf(0))).intValue() == Bukkit.getCurrentTick()) {
/*  93 */       event.setCancelled(true);
/*     */     }
/*     */   }
/*     */   
/*     */   private void setCanFly(Player player, boolean setFly) {
/*  98 */     this.canFly.put(player, Boolean.valueOf(setFly));
/*     */   }
/*     */   
/* 101 */   private final Map<Player, Boolean> canFly = new HashMap<>();
/*     */   
/*     */   @EventHandler
/*     */   public void onServerTickEnd(ServerTickEndEvent event) {
/* 105 */     for (Iterator<Player> iterator = Bukkit.getOnlinePlayers().iterator(); iterator.hasNext(); ) { Player player = iterator.next();
/* 106 */       runForAbility((Entity)player, webMaster -> {
/*     */             setCanFly(webMaster, isInCobweb((Entity)webMaster));
/*     */             List<Entity> entities = webMaster.getNearbyEntities(16.0D, 16.0D, 16.0D);
/*     */             entities.removeIf(());
/*     */             if (entities.size() > 16) {
/*     */               entities = entities.subList(0, 16);
/*     */             }
/*     */             entities.addAll(Bukkit.getOnlinePlayers());
/*     */             entities.removeIf(());
/*     */             entities.removeIf(());
/*     */             for (Entity entity : entities) {
/*     */               runForAbility(entity, null, ());
/*     */             }
/*     */           }); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte getData(Entity entity) {
/* 139 */     byte data = 0;
/* 140 */     data = (byte)(data | 0x40);
/* 141 */     if (entity.getFireTicks() > 0) {
/* 142 */       data = (byte)(data | 0x1);
/*     */     }
/* 144 */     if (entity instanceof LivingEntity) { LivingEntity livingEntity = (LivingEntity)entity;
/* 145 */       if (livingEntity.isInvisible()) data = (byte)(data + 32);  }
/*     */     
/* 147 */     if (entity instanceof Player) { Player stuckPlayer = (Player)entity;
/* 148 */       if (stuckPlayer.isSneaking()) {
/* 149 */         data = (byte)(data | 0x2);
/*     */       }
/* 151 */       if (stuckPlayer.isSprinting()) {
/* 152 */         data = (byte)(data | 0x8);
/*     */       }
/* 154 */       if (stuckPlayer.isSwimming()) {
/* 155 */         data = (byte)(data | 0x10);
/*     */       }
/* 157 */       if (stuckPlayer.isGliding()) {
/* 158 */         data = (byte)(data | Byte.MIN_VALUE);
/*     */       } }
/*     */     
/* 161 */     return data;
/*     */   }
/*     */   
/*     */   public MasterOfWebs() {
/* 165 */     NamespacedKey recipeKey = new NamespacedKey((Plugin)OriginsReborn.getInstance(), "web-recipe");
/* 166 */     ShapelessRecipe webRecipe = new ShapelessRecipe(recipeKey, new ItemStack(Material.COBWEB));
/* 167 */     if (Bukkit.getRecipe(recipeKey) == null) {
/* 168 */       webRecipe.addIngredient(Material.STRING);
/* 169 */       webRecipe.addIngredient(Material.STRING);
/* 170 */       Bukkit.addRecipe((Recipe)webRecipe);
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPrepareItemCraft(PrepareItemCraftEvent event) {
/* 176 */     if (event.getRecipe() != null && 
/* 177 */       event.getRecipe().getResult().getType() == Material.COBWEB) {
/* 178 */       for (HumanEntity entity : event.getInventory().getViewers()) {
/* 179 */         runForAbility((Entity)entity, null, player -> event.getInventory().setResult(null));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public Key getKey() {
/* 187 */     return Key.key("origins:master_of_webs");
/*     */   }
/*     */ 
/*     */   
/*     */   public String description() {
/* 192 */     return "You navigate cobweb perfectly, and are able to climb in them. When you hit an enemy in melee, they get stuck in cobweb for a while. Non-arthropods stuck in cobweb will be sensed by you. You are able to craft cobweb from string.";
/*     */   }
/*     */ 
/*     */   
/*     */   public String title() {
/* 197 */     return "Master of Webs";
/*     */   }
/*     */   
/*     */   public boolean isInCobweb(Entity entity) {
/* 201 */     for (Block start : Set.of(entity.getLocation().getBlock().getRelative(BlockFace.UP), entity.getLocation().getBlock())) {
/* 202 */       if (start.getType() == Material.COBWEB) return true; 
/* 203 */       for (BlockFace face : BlockFace.values()) {
/* 204 */         Block block = start.getRelative(face);
/* 205 */         if (block.getType() == Material.COBWEB && 
/* 206 */           entity.getBoundingBox().overlaps(block.getBoundingBox())) {
/* 207 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 211 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canFly(Player player) {
/* 216 */     return ((Boolean)this.canFly.getOrDefault(player, Boolean.valueOf(false))).booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean forceFly(Player player) {
/* 221 */     return ((Boolean)this.canFly.getOrDefault(player, Boolean.valueOf(false))).booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public float getFlightSpeed(Player player) {
/* 226 */     return 0.04F;
/*     */   }
/*     */ 
/*     */   
/*     */   public Cooldowns.CooldownInfo getCooldownInfo() {
/* 231 */     return new Cooldowns.CooldownInfo(120, "web");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPriority() {
/* 236 */     return 2;
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\MasterOfWebs.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */