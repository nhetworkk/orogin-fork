/*    */ package com.starshootercity.abilities;
/*    */ 
/*    */ import com.destroystokyo.paper.event.server.ServerTickEndEvent;
/*    */ import com.starshootercity.abilities.types.DependantAbility;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import java.util.Collections;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class HungerOverTime implements DependantAbility, Listener, VisibleAbility {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 20 */     return Key.key("origins:hunger_over_time");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 25 */     return "Being phantomized causes you to become hungry.";
/*    */   }
/*    */   private float metabolismIncrease;
/*    */   
/*    */   public String title() {
/* 30 */     return "Fast Metabolism";
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onServerTickEnd(ServerTickEndEvent event) {
/* 35 */     if (event.getTickNumber() % 20 != 0)
/* 36 */       return;  for (Player p : Bukkit.getOnlinePlayers()) {
/* 37 */       runForAbility((Entity)p, player -> player.setExhaustion(player.getExhaustion() + this.metabolismIncrease));
/*    */     }
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getDependencyKey() {
/* 43 */     return Key.key("origins:phantomize");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void initialize(JavaPlugin plugin) {
/* 50 */     this.metabolismIncrease = ((Float)registerConfigOption(plugin, "metabolism_increase", Collections.singletonList("The amount to add to the player's exhaustion each second"), ConfigManager.SettingType.FLOAT, Float.valueOf(0.812F))).floatValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\HungerOverTime.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */