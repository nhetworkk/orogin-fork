/*    */ package com.starshootercity.abilities;
/*    */ 
/*    */ import com.destroystokyo.paper.event.player.PlayerPostRespawnEvent;
/*    */ import com.starshootercity.OriginsReborn;
/*    */ import com.starshootercity.abilities.types.DependantAbility;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerJoinEvent;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class PhantomizeOverlay implements DependantAbility, Listener {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 16 */     return Key.key("origins:phantomize_overlay");
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getDependencyKey() {
/* 21 */     return Key.key("origins:phantomize");
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPhantomizeToggle(Phantomize.PhantomizeToggleEvent event) {
/* 26 */     updatePhantomizeOverlay(event.getPlayer());
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerPostRespawn(PlayerPostRespawnEvent event) {
/* 31 */     updatePhantomizeOverlay(event.getPlayer());
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerJoin(PlayerJoinEvent event) {
/* 36 */     updatePhantomizeOverlay(event.getPlayer());
/*    */   }
/*    */   
/*    */   private void updatePhantomizeOverlay(Player player) {
/* 40 */     OriginsReborn.getMVE().setWorldBorderOverlay(player, getDependency().isEnabled(player));
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\PhantomizeOverlay.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */