/*    */ package com.starshootercity.abilities;
/*    */ import com.starshootercity.OriginSwapper;
/*    */ import com.starshootercity.OriginsReborn;
/*    */ import com.starshootercity.abilities.types.Ability;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import java.util.Collections;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.NamespacedKey;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerItemConsumeEvent;
/*    */ import org.bukkit.persistence.PersistentDataType;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class AirFromPotions implements Ability, Listener {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 21 */     return Key.key("origins:air_from_potions");
/*    */   }
/*    */   
/* 24 */   NamespacedKey dehydrationKey = new NamespacedKey((Plugin)OriginsReborn.getInstance(), "dehydrating"); private int airIncrease;
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerItemConsume(PlayerItemConsumeEvent event) {
/* 28 */     if (event.getItem().getType() == Material.POTION) {
/* 29 */       event.getPlayer().getPersistentDataContainer().set(this.dehydrationKey, (PersistentDataType)OriginSwapper.BooleanPDT.BOOLEAN, Boolean.valueOf(true));
/* 30 */       event.getPlayer().setRemainingAir(Math.min(event.getPlayer().getRemainingAir() + this.airIncrease, event.getPlayer().getMaximumAir()));
/* 31 */       event.getPlayer().getPersistentDataContainer().set(this.dehydrationKey, (PersistentDataType)OriginSwapper.BooleanPDT.BOOLEAN, Boolean.valueOf(false));
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void initialize(JavaPlugin plugin) {
/* 39 */     this.airIncrease = ((Integer)registerConfigOption(plugin, "air_increase", Collections.singletonList("Amount to increase air by when drinking a potion"), ConfigManager.SettingType.INTEGER, Integer.valueOf(60))).intValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\AirFromPotions.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */