/*    */ package com.starshootercity.abilities.examples;
/*    */ 
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class ExampleCustomAbility implements VisibleAbility {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 10 */     return Key.key("my_cool_addon", "my_ability");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 15 */     return "My Description";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 20 */     return "My Title";
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\examples\ExampleCustomAbility.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */