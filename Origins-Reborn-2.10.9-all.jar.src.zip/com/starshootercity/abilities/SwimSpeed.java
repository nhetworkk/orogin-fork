/*    */ package com.starshootercity.abilities;
/*    */ import com.destroystokyo.paper.event.server.ServerTickEndEvent;
/*    */ import com.starshootercity.OriginsReborn;
/*    */ import com.starshootercity.SavedPotionEffect;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.util.ShortcutUtils;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.LivingEntity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.player.PlayerItemConsumeEvent;
/*    */ import org.bukkit.potion.PotionEffect;
/*    */ import org.bukkit.potion.PotionEffectType;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class SwimSpeed implements Listener, VisibleAbility {
/* 23 */   Map<Player, SavedPotionEffect> storedEffects = new HashMap<>();
/*    */   
/*    */   @EventHandler
/*    */   public void onServerTickEnd(ServerTickEndEvent event) {
/* 27 */     for (Iterator<Player> iterator = Bukkit.getOnlinePlayers().iterator(); iterator.hasNext(); ) { Player p = iterator.next();
/* 28 */       runForAbility((Entity)p, player -> {
/*    */             if (OriginsReborn.getMVE().isUnderWater((LivingEntity)player)) {
/*    */               PotionEffect effect = player.getPotionEffect(PotionEffectType.DOLPHINS_GRACE);
/*    */               boolean ambient = false;
/*    */               boolean showParticles = false;
/*    */               if (effect != null) {
/*    */                 ambient = effect.isAmbient();
/*    */                 showParticles = effect.hasParticles();
/*    */                 if (!ShortcutUtils.isInfinite(effect)) {
/*    */                   this.storedEffects.put(player, new SavedPotionEffect(effect, Bukkit.getCurrentTick()));
/*    */                   player.removePotionEffect(PotionEffectType.DOLPHINS_GRACE);
/*    */                 } 
/*    */               } 
/*    */               player.addPotionEffect(new PotionEffect(PotionEffectType.DOLPHINS_GRACE, ShortcutUtils.infiniteDuration(), 0, ambient, showParticles));
/*    */             } else {
/*    */               if (player.hasPotionEffect(PotionEffectType.DOLPHINS_GRACE)) {
/*    */                 PotionEffect effect = player.getPotionEffect(PotionEffectType.DOLPHINS_GRACE);
/*    */                 if (effect != null && ShortcutUtils.isInfinite(effect)) {
/*    */                   player.removePotionEffect(PotionEffectType.DOLPHINS_GRACE);
/*    */                 }
/*    */               } 
/*    */               if (this.storedEffects.containsKey(player)) {
/*    */                 SavedPotionEffect effect = this.storedEffects.get(player);
/*    */                 this.storedEffects.remove(player);
/*    */                 PotionEffect potionEffect = effect.effect();
/*    */                 int time = potionEffect.getDuration() - Bukkit.getCurrentTick() - effect.currentTime();
/*    */                 if (time > 0) {
/*    */                   player.addPotionEffect(new PotionEffect(potionEffect.getType(), time, potionEffect.getAmplifier(), potionEffect.isAmbient(), potionEffect.hasParticles()));
/*    */                 }
/*    */               } 
/*    */             } 
/*    */           }); }
/*    */   
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerItemConsume(PlayerItemConsumeEvent event) {
/* 71 */     if (event.getItem().getType() == Material.MILK_BUCKET) {
/* 72 */       this.storedEffects.remove(event.getPlayer());
/*    */     }
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 78 */     return Key.key("origins:swim_speed");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 83 */     return "Your underwater speed is increased.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 88 */     return "Fins";
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\SwimSpeed.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */