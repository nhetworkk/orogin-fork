/*     */ package com.starshootercity.abilities;
/*     */ import com.destroystokyo.paper.event.server.ServerTickEndEvent;
/*     */ import com.starshootercity.abilities.types.Ability;
/*     */ import com.starshootercity.abilities.types.DependencyAbility;
/*     */ import com.starshootercity.abilities.types.TriggerableAbility;
/*     */ import com.starshootercity.util.TriggerManager;
/*     */ import com.starshootercity.util.config.ConfigManager;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.HandlerList;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.entity.EntityDamageEvent;
/*     */ import org.bukkit.event.player.PlayerEvent;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ public class Phantomize implements DependencyAbility, Listener, TriggerableAbility {
/*     */   @EventHandler
/*     */   public void onServerTickEnd(ServerTickEndEvent event) {
/*  26 */     for (Player player : Bukkit.getOnlinePlayers()) {
/*  27 */       if (isEnabled(player) && player.getFoodLevel() <= this.foodLevel) {
/*  28 */         this.phantomizedPlayers.put(player.getUniqueId(), Boolean.valueOf(false));
/*  29 */         PhantomizeToggleEvent phantomizeToggleEvent = new PhantomizeToggleEvent(player, false);
/*  30 */         phantomizeToggleEvent.callEvent();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private int foodLevel;
/*     */   private boolean disableOnDamage;
/*     */   
/*     */   public void initialize(JavaPlugin plugin) {
/*  40 */     this.foodLevel = ((Integer)registerConfigOption(plugin, "minimum_food_level", Collections.singletonList("The food level at which you can no longer enter Phantom Form"), ConfigManager.SettingType.INTEGER, Integer.valueOf(6))).intValue();
/*  41 */     this.disableOnDamage = ((Boolean)registerConfigOption(plugin, "disable_on_damage", Collections.singletonList("Whether to disable Phantom Form when taking damage"), ConfigManager.SettingType.BOOLEAN, Boolean.valueOf(false))).booleanValue();
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onEntityDamage(EntityDamageEvent event) {
/*  46 */     if (!this.disableOnDamage)
/*  47 */       return;  if (event.getCause().equals(EntityDamageEvent.DamageCause.SUFFOCATION))
/*  48 */       return;  runForAbility(event.getEntity(), player -> {
/*     */           if (((Boolean)this.phantomizedPlayers.getOrDefault(player.getUniqueId(), Boolean.valueOf(false))).booleanValue()) {
/*     */             setPhasing(player, false);
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   private void setPhasing(Player player, boolean enabling) {
/*  56 */     this.phantomizedPlayers.put(player.getUniqueId(), Boolean.valueOf(enabling));
/*  57 */     PhantomizeToggleEvent phantomizeToggleEvent = new PhantomizeToggleEvent(player, enabling);
/*  58 */     phantomizeToggleEvent.callEvent();
/*     */   }
/*     */   
/*  61 */   private final Map<UUID, Boolean> phantomizedPlayers = new HashMap<>();
/*     */   
/*     */   @NotNull
/*     */   public Key getKey() {
/*  65 */     return Key.key("origins:phantomize");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Player player) {
/*  70 */     return ((Boolean)this.phantomizedPlayers.getOrDefault(player.getUniqueId(), Boolean.valueOf(false))).booleanValue();
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public TriggerableAbility.Trigger getTrigger() {
/*  75 */     return TriggerableAbility.Trigger.builder(TriggerableAbility.TriggerType.LEFT_CLICK, (Ability)this)
/*     */ 
/*     */       
/*  78 */       .addConditions(new TriggerableAbility.Condition[] { TriggerableAbility.Condition.EMPTY_HAND, TriggerableAbility.Condition.NO_BLOCK
/*  79 */         }).build(event -> {
/*     */           Player player = event.player();
/*     */           if (player.getFoodLevel() <= 6)
/*     */             return; 
/*     */           boolean enabling = !((Boolean)this.phantomizedPlayers.getOrDefault(player.getUniqueId(), Boolean.valueOf(false))).booleanValue();
/*     */           setPhasing(player, enabling);
/*     */         });
/*     */   }
/*     */   
/*     */   public static class PhantomizeToggleEvent extends PlayerEvent {
/*     */     private final boolean enabling;
/*     */     
/*     */     public PhantomizeToggleEvent(Player who, boolean enabling) {
/*  92 */       super(who);
/*  93 */       this.enabling = enabling;
/*     */     }
/*     */     
/*     */     public boolean isEnabling() {
/*  97 */       return this.enabling;
/*     */     }
/*     */     
/* 100 */     private static final HandlerList HANDLERS = new HandlerList();
/*     */     
/*     */     @NotNull
/*     */     public HandlerList getHandlers() {
/* 104 */       return HANDLERS;
/*     */     }
/*     */     
/*     */     public static HandlerList getHandlerList() {
/* 108 */       return HANDLERS;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\Phantomize.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */