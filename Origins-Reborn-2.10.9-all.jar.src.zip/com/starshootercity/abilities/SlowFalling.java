/*    */ package com.starshootercity.abilities;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.util.ShortcutUtils;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerMoveEvent;
/*    */ import org.bukkit.potion.PotionEffect;
/*    */ import org.bukkit.potion.PotionEffectType;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class SlowFalling implements Listener, VisibleAbility {
/*    */   @EventHandler
/*    */   public void onPlayerMove(PlayerMoveEvent event) {
/* 16 */     runForAbility((Entity)event.getPlayer(), player -> {
/*    */           if (player.isSneaking()) {
/*    */             player.removePotionEffect(PotionEffectType.SLOW_FALLING);
/*    */           } else {
/*    */             player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, ShortcutUtils.infiniteDuration(), 0, false, false));
/*    */           } 
/*    */         });
/*    */   } @NotNull
/*    */   public Key getKey() {
/* 25 */     return Key.key("origins:slow_falling");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 30 */     return "You fall as gently to the ground as a feather would, unless you sneak.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 35 */     return "Featherweight";
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\SlowFalling.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */