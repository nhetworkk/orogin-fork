/*    */ package com.starshootercity.abilities;
/*    */ import com.destroystokyo.paper.event.server.ServerTickEndEvent;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class NoShield implements Listener, VisibleAbility {
/*    */   @EventHandler
/*    */   public void onServerTickEnd(ServerTickEndEvent event) {
/* 16 */     for (Player p : Bukkit.getOnlinePlayers())
/* 17 */       runForAbility((Entity)p, player -> player.setCooldown(Material.SHIELD, 1000)); 
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 22 */     return Key.key("origins:no_shield");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 27 */     return "The way your hands are formed provide no way of holding a shield upright.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 32 */     return "Unwieldy";
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\NoShield.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */