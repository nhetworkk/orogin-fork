/*    */ package com.starshootercity.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.AttributeModifierAbility;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.attribute.Attribute;
/*    */ import org.bukkit.attribute.AttributeModifier;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExtraReachEntities
/*    */   implements AttributeModifierAbility
/*    */ {
/* 45 */   public static ExtraReachEntities extraReachEntities = new ExtraReachEntities();
/*    */   
/*    */   @NotNull
/*    */   public Attribute getAttribute() {
/* 49 */     return ExtraReach.entityRange;
/*    */   }
/*    */ 
/*    */   
/*    */   public double getAmount(Player player) {
/* 54 */     return 1.5D;
/*    */   }
/*    */ 
/*    */   
/*    */   public AttributeModifier.Operation getOperation() {
/* 59 */     return AttributeModifier.Operation.ADD_NUMBER;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 64 */     return Key.key("origins:extra_reach_entities");
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\ExtraReach$ExtraReachEntities.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */