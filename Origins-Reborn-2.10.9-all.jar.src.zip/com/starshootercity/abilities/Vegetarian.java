/*    */ package com.starshootercity.abilities;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerItemConsumeEvent;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.bukkit.potion.PotionEffect;
/*    */ import org.bukkit.potion.PotionEffectType;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class Vegetarian implements Listener, VisibleAbility {
/*    */   private List<Material> meat;
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerItemConsume(PlayerItemConsumeEvent event) {
/* 23 */     if (event.getItem().getType() == Material.POTION)
/* 24 */       return;  runForAbility((Entity)event.getPlayer(), player -> {
/*    */           if (this.meat.contains(event.getItem().getType())) {
/*    */             event.setCancelled(true);
/*    */             if (this.poison) {
/*    */               event.getItem().setAmount(event.getItem().getAmount() - 1);
/*    */               player.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 300, 1, false, true));
/*    */             } 
/*    */           } 
/*    */         });
/*    */   }
/*    */   private boolean poison;
/*    */   
/*    */   public String description() {
/* 37 */     return "You can't digest any meat.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 42 */     return "Vegetarian";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 47 */     return Key.key("origins:vegetarian");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void initialize(JavaPlugin plugin) {
/* 54 */     this.poison = ((Boolean)registerConfigOption(plugin, "consume_and_poison", Collections.singletonList("Poison the player when consuming meat rather than preventing them from eating it"), ConfigManager.SettingType.BOOLEAN, Boolean.valueOf(false))).booleanValue();
/*    */     
/* 56 */     String meatContents = "meat";
/* 57 */     this.meat = (List<Material>)registerConfigOption(plugin, meatContents, Collections.singletonList("Items that count as meat"), ConfigManager.SettingType.MATERIAL_LIST, List.of((Object[])new Material[] { Material.PORKCHOP, Material.COOKED_PORKCHOP, Material.BEEF, Material.COOKED_BEEF, Material.CHICKEN, Material.COOKED_CHICKEN, Material.RABBIT, Material.COOKED_RABBIT, Material.MUTTON, Material.COOKED_MUTTON, Material.RABBIT_STEW, Material.COD, Material.COOKED_COD, Material.TROPICAL_FISH, Material.SALMON, Material.COOKED_SALMON, Material.PUFFERFISH, Material.ROTTEN_FLESH, Material.SPIDER_EYE }));
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\Vegetarian.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */