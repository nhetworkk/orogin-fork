/*     */ package com.starshootercity.abilities;
/*     */ import com.destroystokyo.paper.event.server.ServerTickEndEvent;
/*     */ import com.starshootercity.OriginsReborn;
/*     */ import com.starshootercity.events.PlayerSwapOriginEvent;
/*     */ import com.starshootercity.util.config.ConfigManager;
/*     */ import com.starshootercity.version.MVPotionEffectType;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.LivingEntity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.player.PlayerItemConsumeEvent;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.event.player.PlayerQuitEvent;
/*     */ import org.bukkit.inventory.EquipmentSlot;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ import org.bukkit.potion.PotionEffect;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ public class PumpkinHate implements Listener, VisibleAbility {
/*  28 */   private final Map<Player, List<Player>> ignoringPlayers = new HashMap<>();
/*  29 */   private final Set<Player> pumpkinHaters = new HashSet<>(); private boolean poison;
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerJoin(PlayerJoinEvent event) {
/*  33 */     Objects.requireNonNull(this.pumpkinHaters); runForAbility((Entity)event.getPlayer(), this.pumpkinHaters::add);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerQuit(PlayerQuitEvent event) {
/*  38 */     this.pumpkinHaters.remove(event.getPlayer());
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerSwapOrigin(PlayerSwapOriginEvent event) {
/*  43 */     Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)OriginsReborn.getInstance(), () -> {
/*     */           Objects.requireNonNull(this.pumpkinHaters);
/*     */           Objects.requireNonNull(this.pumpkinHaters);
/*     */           runForAbility((Entity)event.getPlayer(), this.pumpkinHaters::add, this.pumpkinHaters::remove);
/*     */         }); } @EventHandler
/*  48 */   public void onServerTickEnd(ServerTickEndEvent event) { for (Player pumpkinHater : this.pumpkinHaters) {
/*  49 */       for (Player pumpkinWearer : pumpkinHater.getLocation().getNearbyPlayers(64.0D)) {
/*  50 */         if (pumpkinWearer == pumpkinHater)
/*     */           continue; 
/*  52 */         List<Player> ignoring = this.ignoringPlayers.computeIfAbsent(pumpkinHater, p -> new ArrayList());
/*     */         
/*  54 */         ItemStack helmet = pumpkinWearer.getInventory().getHelmet();
/*  55 */         if (helmet != null && helmet.getType() == Material.CARVED_PUMPKIN) {
/*  56 */           if (ignoring.contains(pumpkinWearer))
/*  57 */             continue;  ignoring.add(pumpkinWearer);
/*     */           
/*  59 */           byte data = getData(pumpkinWearer);
/*     */           
/*  61 */           OriginsReborn.getMVE().sendEntityData(pumpkinHater, (Entity)pumpkinWearer, data);
/*     */           
/*  63 */           for (EquipmentSlot equipmentSlot : EquipmentSlot.values())
/*  64 */             pumpkinHater.sendEquipmentChange((LivingEntity)pumpkinWearer, equipmentSlot, new ItemStack(Material.AIR));  continue;
/*     */         } 
/*  66 */         if (ignoring.contains(pumpkinWearer)) {
/*  67 */           ignoring.remove(pumpkinWearer);
/*  68 */           AbilityRegister.updateEntity(pumpkinHater, (Entity)pumpkinWearer);
/*     */         } 
/*     */       } 
/*     */     }  }
/*     */ 
/*     */   
/*     */   private static byte getData(Player pumpkinWearer) {
/*  75 */     byte data = 32;
/*  76 */     if (pumpkinWearer.getFireTicks() > 0) {
/*  77 */       data = (byte)(data + 1);
/*     */     }
/*  79 */     if (pumpkinWearer.isSneaking()) {
/*  80 */       data = (byte)(data + 2);
/*     */     }
/*  82 */     if (pumpkinWearer.isSprinting()) {
/*  83 */       data = (byte)(data + 8);
/*     */     }
/*  85 */     if (pumpkinWearer.isSwimming()) {
/*  86 */       data = (byte)(data + 16);
/*     */     }
/*  88 */     if (pumpkinWearer.isGlowing()) {
/*  89 */       data = (byte)(data + 64);
/*     */     }
/*  91 */     if (pumpkinWearer.isGliding()) {
/*  92 */       data = (byte)(data - 128);
/*     */     }
/*  94 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize(JavaPlugin plugin) {
/* 101 */     this.poison = ((Boolean)registerConfigOption(plugin, "consume_and_poison", Collections.singletonList("Poison the player when consuming pumpkin pie rather than preventing them from eating it"), ConfigManager.SettingType.BOOLEAN, Boolean.valueOf(false))).booleanValue();
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerItemConsume(PlayerItemConsumeEvent event) {
/* 106 */     runForAbility((Entity)event.getPlayer(), player -> {
/*     */           if (event.getItem().getType() == Material.PUMPKIN_PIE) {
/*     */             event.setCancelled(true);
/*     */             event.getItem().setAmount(event.getItem().getAmount() - 1);
/*     */             if (this.poison) {
/*     */               player.addPotionEffect(new PotionEffect(MVPotionEffectType.HUNGER.get(), 300, 2, false, true));
/*     */               player.addPotionEffect(new PotionEffect(MVPotionEffectType.NAUSEA.get(), 300, 1, false, true));
/*     */               player.addPotionEffect(new PotionEffect(MVPotionEffectType.POISON.get(), 1200, 1, false, true));
/*     */             } 
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public String description() {
/* 121 */     return "You are afraid of pumpkins. For a good reason.";
/*     */   }
/*     */ 
/*     */   
/*     */   public String title() {
/* 126 */     return "Scared of Gourds";
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Key getKey() {
/* 131 */     return Key.key("origins:pumpkin_hate");
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\PumpkinHate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */