/*     */ package com.starshootercity.abilities;
/*     */ 
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.HandlerList;
/*     */ import org.bukkit.event.player.PlayerEvent;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PhantomizeToggleEvent
/*     */   extends PlayerEvent
/*     */ {
/*     */   private final boolean enabling;
/*     */   
/*     */   public PhantomizeToggleEvent(Player who, boolean enabling) {
/*  92 */     super(who);
/*  93 */     this.enabling = enabling;
/*     */   }
/*     */   
/*     */   public boolean isEnabling() {
/*  97 */     return this.enabling;
/*     */   }
/*     */   
/* 100 */   private static final HandlerList HANDLERS = new HandlerList();
/*     */   
/*     */   @NotNull
/*     */   public HandlerList getHandlers() {
/* 104 */     return HANDLERS;
/*     */   }
/*     */   
/*     */   public static HandlerList getHandlerList() {
/* 108 */     return HANDLERS;
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\Phantomize$PhantomizeToggleEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */