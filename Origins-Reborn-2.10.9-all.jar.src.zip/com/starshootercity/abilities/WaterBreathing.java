/*     */ package com.starshootercity.abilities;
/*     */ import com.destroystokyo.paper.event.server.ServerTickEndEvent;
/*     */ import com.starshootercity.OriginSwapper;
/*     */ import com.starshootercity.OriginsReborn;
/*     */ import com.starshootercity.abilities.types.VisibleAbility;
/*     */ import java.util.Iterator;
/*     */ import java.util.Random;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import net.kyori.adventure.text.Component;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.NamespacedKey;
/*     */ import org.bukkit.entity.LivingEntity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.entity.EntityAirChangeEvent;
/*     */ import org.bukkit.event.entity.EntityPotionEffectEvent;
/*     */ import org.bukkit.event.entity.PlayerDeathEvent;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.persistence.PersistentDataType;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ import org.bukkit.potion.PotionEffect;
/*     */ import org.bukkit.potion.PotionEffectType;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ public class WaterBreathing implements Listener, VisibleAbility {
/*     */   @EventHandler
/*     */   public void onEntityAirChange(EntityAirChangeEvent event) {
/*  32 */     runForAbility(event.getEntity(), player -> {
/*     */           if (Boolean.TRUE.equals(player.getPersistentDataContainer().get(this.airKey, (PersistentDataType)OriginSwapper.BooleanPDT.BOOLEAN)))
/*     */             return; 
/*     */           if (Boolean.TRUE.equals(player.getPersistentDataContainer().get(this.dehydrationKey, (PersistentDataType)OriginSwapper.BooleanPDT.BOOLEAN)))
/*     */             return; 
/*     */           if (player.getRemainingAir() - event.getAmount() > 0) {
/*     */             if (!OriginsReborn.getMVE().isUnderWater((LivingEntity)player) && !hasWaterBreathing(player))
/*     */               return; 
/*     */           } else if (OriginsReborn.getMVE().isUnderWater((LivingEntity)player) || hasWaterBreathing(player)) {
/*     */             return;
/*     */           } 
/*     */           event.setCancelled(true);
/*     */         });
/*     */   }
/*     */   private String deathMessage;
/*     */   public void initialize(JavaPlugin plugin) {
/*  48 */     String deathMessageKey = "death-message";
/*  49 */     registerTranslation(deathMessageKey, "%player% didn't manage to keep wet");
/*  50 */     this.deathMessage = translate(deathMessageKey);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onEntityPotionEffect(EntityPotionEffectEvent event) {
/*  55 */     if (event.getCause() != EntityPotionEffectEvent.Cause.TURTLE_HELMET)
/*  56 */       return;  runForAbility(event.getEntity(), player -> event.setCancelled(true));
/*     */   }
/*     */   
/*     */   public boolean hasWaterBreathing(Player player) {
/*  60 */     return (player.hasPotionEffect(PotionEffectType.CONDUIT_POWER) || player.hasPotionEffect(PotionEffectType.WATER_BREATHING));
/*     */   }
/*     */   
/*  63 */   NamespacedKey airKey = new NamespacedKey((Plugin)OriginsReborn.getInstance(), "fullair");
/*  64 */   NamespacedKey dehydrationKey = new NamespacedKey((Plugin)OriginsReborn.getInstance(), "dehydrating");
/*  65 */   NamespacedKey damageKey = new NamespacedKey((Plugin)OriginsReborn.getInstance(), "ignore-item-damage");
/*     */   
/*     */   @EventHandler
/*     */   public void onServerTickEnd(ServerTickEndEvent ignored) {
/*  69 */     for (Iterator<Player> iterator = Bukkit.getOnlinePlayers().iterator(); iterator.hasNext(); ) { Player p = iterator.next();
/*  70 */       runForAbility((Entity)p, player -> {
/*     */             if (OriginsReborn.getMVE().isUnderWater((LivingEntity)player) || hasWaterBreathing(player) || player.isInRain()) {
/*     */               ItemStack helmet = player.getInventory().getHelmet();
/*     */               if (helmet != null && OriginsReborn.getMVE().isUnderWater((LivingEntity)player) && helmet.getType() == Material.TURTLE_HELMET) {
/*     */                 player.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING, 200, 0, false, false, true));
/*     */               }
/*     */               if (Boolean.TRUE.equals(player.getPersistentDataContainer().get(this.airKey, (PersistentDataType)OriginSwapper.BooleanPDT.BOOLEAN))) {
/*     */                 player.setRemainingAir(player.getMaximumAir());
/*     */                 return;
/*     */               } 
/*     */               player.setRemainingAir(Math.min(Math.max(player.getRemainingAir() + 4, 4), player.getMaximumAir()));
/*     */               if (player.getRemainingAir() == player.getMaximumAir()) {
/*     */                 player.setRemainingAir(player.getMaximumAir());
/*     */                 player.getPersistentDataContainer().set(this.airKey, (PersistentDataType)OriginSwapper.BooleanPDT.BOOLEAN, Boolean.valueOf(true));
/*     */               } 
/*     */             } else {
/*     */               if (Boolean.TRUE.equals(player.getPersistentDataContainer().get(this.airKey, (PersistentDataType)OriginSwapper.BooleanPDT.BOOLEAN))) {
/*     */                 player.setRemainingAir(player.getMaximumAir());
/*     */                 player.getPersistentDataContainer().set(this.airKey, (PersistentDataType)OriginSwapper.BooleanPDT.BOOLEAN, Boolean.valueOf(false));
/*     */               } 
/*     */               decreaseAir(player);
/*     */               if (player.getRemainingAir() < -25) {
/*     */                 player.getPersistentDataContainer().set(this.dehydrationKey, (PersistentDataType)OriginSwapper.BooleanPDT.BOOLEAN, Boolean.valueOf(true));
/*     */                 player.setRemainingAir(-5);
/*     */                 player.getPersistentDataContainer().set(this.dehydrationKey, (PersistentDataType)OriginSwapper.BooleanPDT.BOOLEAN, Boolean.valueOf(false));
/*     */                 player.getPersistentDataContainer().set(this.damageKey, PersistentDataType.INTEGER, Integer.valueOf(Bukkit.getCurrentTick()));
/*     */                 OriginsReborn.getMVE().dealDrowningDamage((LivingEntity)player, 2);
/*     */               } 
/*     */             } 
/*     */           }player -> {
/*     */             if (player.getPersistentDataContainer().has(this.airKey, (PersistentDataType)OriginSwapper.BooleanPDT.BOOLEAN)) {
/*     */               player.setRemainingAir(player.getMaximumAir());
/*     */               player.getPersistentDataContainer().remove(this.airKey);
/*     */             } 
/*     */           }); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerDeath(PlayerDeathEvent event) {
/* 112 */     if (((Integer)event.getPlayer().getPersistentDataContainer().getOrDefault(this.damageKey, PersistentDataType.INTEGER, Integer.valueOf(0))).intValue() >= Bukkit.getCurrentTick()) {
/* 113 */       event.deathMessage((Component)Component.text(this.deathMessage.replaceFirst("%player%", event.getPlayer().getName())));
/*     */     }
/*     */   }
/*     */   
/* 117 */   private final Random random = new Random();
/*     */   
/*     */   public void decreaseAir(Player player) {
/* 120 */     ItemStack helmet = player.getInventory().getHelmet();
/* 121 */     if (helmet != null && helmet.getItemMeta() != null) {
/* 122 */       int respirationLevel = helmet.getItemMeta().getEnchantLevel(MVEnchantment.RESPIRATION.get());
/* 123 */       if (respirationLevel > 0 && 
/* 124 */         this.random.nextInt(respirationLevel + 1) > 0)
/*     */         return; 
/*     */     } 
/* 127 */     player.setRemainingAir(player.getRemainingAir() - 1);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerJoin(PlayerJoinEvent event) {
/* 132 */     event.getPlayer().getPersistentDataContainer().set(this.damageKey, PersistentDataType.INTEGER, Integer.valueOf(-1));
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Key getKey() {
/* 137 */     return Key.key("origins:water_breathing");
/*     */   }
/*     */ 
/*     */   
/*     */   public String description() {
/* 142 */     return "You can breathe underwater, but not on land.";
/*     */   }
/*     */ 
/*     */   
/*     */   public String title() {
/* 147 */     return "Gills";
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\WaterBreathing.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */