/*    */ package com.starshootercity.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.DependantAbility;
/*    */ import com.starshootercity.abilities.types.VisibilityChangingAbility;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class Invisibility implements DependantAbility, VisibilityChangingAbility, VisibleAbility {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 13 */     return Key.key("origins:invisibility");
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getDependencyKey() {
/* 18 */     return Key.key("origins:phantomize");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 23 */     return "While phantomized, you are invisible.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 28 */     return "Invisibility";
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isInvisible(Player player) {
/* 33 */     return getDependency().isEnabled(player);
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\Invisibility.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */