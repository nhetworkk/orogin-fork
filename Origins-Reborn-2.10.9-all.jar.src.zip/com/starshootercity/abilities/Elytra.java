/*    */ package com.starshootercity.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.FlightAllowingAbility;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.commands.FlightToggleCommand;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import java.util.Collections;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import net.kyori.adventure.util.TriState;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityToggleGlideEvent;
/*    */ import org.bukkit.event.player.PlayerToggleFlightEvent;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class Elytra implements FlightAllowingAbility, Listener, VisibleAbility {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 22 */     return Key.key("origins:elytra");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 27 */     return "You have Elytra wings without needing to equip any.";
/*    */   }
/*    */   private boolean disableDisengage;
/*    */   
/*    */   public String title() {
/* 32 */     return "Winged";
/*    */   }
/*    */ 
/*    */   
/*    */   @EventHandler
/*    */   public void onEntityToggleGlide(EntityToggleGlideEvent event) {
/* 38 */     runForAbility(event.getEntity(), player -> {
/*    */           if (!player.isOnGround() && !event.isGliding()) {
/*    */             event.setCancelled(true);
/*    */           }
/*    */         });
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean canFly(Player player) {
/* 47 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public float getFlightSpeed(Player player) {
/* 52 */     return player.getFlySpeed();
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerToggleFlight(PlayerToggleFlightEvent event) {
/* 57 */     if (FlightToggleCommand.canFly(event.getPlayer()))
/* 58 */       return;  runForAbility((Entity)event.getPlayer(), player -> {
/*    */           if (event.isFlying()) {
/*    */             event.setCancelled(true);
/*    */             if (player.isGliding() && this.disableDisengage)
/*    */               return; 
/*    */             player.setGliding(!player.isGliding());
/*    */           } 
/*    */         });
/*    */   }
/*    */   @NotNull
/*    */   public TriState getFlyingFallDamage(Player player) {
/* 69 */     return TriState.TRUE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void initialize(JavaPlugin plugin) {
/* 76 */     this.disableDisengage = ((Boolean)registerConfigOption(plugin, "disable_disengage_trigger", Collections.singletonList("Disable the ability to disengage the elytra by double tapping again"), ConfigManager.SettingType.BOOLEAN, Boolean.valueOf(true))).booleanValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\Elytra.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */