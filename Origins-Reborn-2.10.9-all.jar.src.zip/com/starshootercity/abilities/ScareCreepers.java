/*    */ package com.starshootercity.abilities;
/*    */ import com.starshootercity.OriginsReborn;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.NamespacedKey;
/*    */ import org.bukkit.entity.Creeper;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.EntityType;
/*    */ import org.bukkit.entity.LivingEntity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.entity.Projectile;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*    */ import org.bukkit.event.entity.EntitySpawnEvent;
/*    */ import org.bukkit.event.entity.EntityTargetLivingEntityEvent;
/*    */ import org.bukkit.event.world.EntitiesLoadEvent;
/*    */ import org.bukkit.persistence.PersistentDataType;
/*    */ import org.bukkit.projectiles.ProjectileSource;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class ScareCreepers implements Listener, VisibleAbility {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 24 */     return Key.key("origins:scare_creepers");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 29 */     return "Creepers are scared of you and will only explode if you attack them first.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 34 */     return "Catlike Appearance";
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onEntitySpawn(EntitySpawnEvent event) {
/* 39 */     Entity entity = event.getEntity(); if (entity instanceof Creeper) { Creeper creeper = (Creeper)entity;
/* 40 */       fixCreeper(creeper); }
/*    */   
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onEntitiesLoad(EntitiesLoadEvent event) {
/* 46 */     for (Entity entity : event.getEntities()) {
/* 47 */       if (entity instanceof Creeper) { Creeper creeper = (Creeper)entity;
/* 48 */         fixCreeper(creeper); }
/*    */     
/*    */     } 
/*    */   }
/*    */   
/*    */   public void fixCreeper(Creeper creeper) {
/* 54 */     Bukkit.getMobGoals().addGoal((Mob)creeper, 0, OriginsReborn.getMVE().getCreeperAfraidGoal((LivingEntity)creeper, (entity, player) -> {
/*    */             if (hasAbility(player)) {
/*    */               String data = (String)entity.getPersistentDataContainer().get(this.hitByPlayerKey, PersistentDataType.STRING);
/*    */               return (data == null) ? true : (!data.equals(player.getUniqueId().toString()));
/*    */             } 
/*    */             return false;
/*    */           }));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 65 */   private final NamespacedKey hitByPlayerKey = new NamespacedKey((Plugin)OriginsReborn.getInstance(), "hit-by-player");
/*    */   
/*    */   @EventHandler
/*    */   public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
/* 69 */     if (event.getEntity().getType() == EntityType.CREEPER) {
/*    */       Player player;
/* 71 */       Entity entity = event.getDamager(); if (entity instanceof Projectile) { Projectile projectile = (Projectile)entity;
/* 72 */         ProjectileSource projectileSource = projectile.getShooter(); if (projectileSource instanceof Player) { Player shooter = (Player)projectileSource; } else { return; }
/*    */          }
/* 74 */       else { entity = event.getDamager(); if (entity instanceof Player) { Player damager = (Player)entity; } else { return; }
/*    */          }
/* 76 */        runForAbility((Entity)player, p -> event.getEntity().getPersistentDataContainer().set(this.hitByPlayerKey, PersistentDataType.STRING, p.getUniqueId().toString()));
/*    */     } 
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onEntityTargetLivingEntity(EntityTargetLivingEntityEvent event) {
/* 82 */     if (event.getEntity().getType() == EntityType.CREEPER)
/* 83 */       runForAbility((Entity)event.getTarget(), player -> {
/*    */             String data = (String)event.getEntity().getPersistentDataContainer().get(this.hitByPlayerKey, PersistentDataType.STRING);
/*    */             if (data == null) {
/*    */               event.setCancelled(true);
/*    */               return;
/*    */             } 
/*    */             if (!data.equals(player.getUniqueId().toString()))
/*    */               event.setCancelled(true); 
/*    */           }); 
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\ScareCreepers.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */