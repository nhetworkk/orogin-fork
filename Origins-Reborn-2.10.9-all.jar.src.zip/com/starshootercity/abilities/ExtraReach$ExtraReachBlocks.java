/*    */ package com.starshootercity.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.AttributeModifierAbility;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.attribute.Attribute;
/*    */ import org.bukkit.attribute.AttributeModifier;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExtraReachBlocks
/*    */   implements AttributeModifierAbility
/*    */ {
/* 69 */   public static ExtraReachBlocks extraReachBlocks = new ExtraReachBlocks();
/*    */   
/*    */   @NotNull
/*    */   public Attribute getAttribute() {
/* 73 */     return ExtraReach.blockRange;
/*    */   }
/*    */ 
/*    */   
/*    */   public double getAmount(Player player) {
/* 78 */     return 1.5D;
/*    */   }
/*    */ 
/*    */   
/*    */   public AttributeModifier.Operation getOperation() {
/* 83 */     return AttributeModifier.Operation.ADD_NUMBER;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 88 */     return Key.key("origins:extra_reach_blocks");
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\ExtraReach$ExtraReachBlocks.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */