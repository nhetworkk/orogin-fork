/*    */ package com.starshootercity.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.AttributeModifierAbility;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.version.MVAttribute;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.attribute.Attribute;
/*    */ import org.bukkit.attribute.AttributeModifier;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class NaturalArmor implements AttributeModifierAbility, VisibleAbility {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 15 */     return Key.key("origins:natural_armor");
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Attribute getAttribute() {
/* 20 */     return MVAttribute.ARMOR.get();
/*    */   }
/*    */ 
/*    */   
/*    */   public double getAmount(Player player) {
/* 25 */     return 8.0D;
/*    */   }
/*    */ 
/*    */   
/*    */   public AttributeModifier.Operation getOperation() {
/* 30 */     return AttributeModifier.Operation.ADD_NUMBER;
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 35 */     return "Even without wearing armor, your skin provides natural protection.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 40 */     return "Sturdy Skin";
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\NaturalArmor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */