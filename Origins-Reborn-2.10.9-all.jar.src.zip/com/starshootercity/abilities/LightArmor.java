/*     */ package com.starshootercity.abilities;
/*     */ import com.destroystokyo.paper.MaterialTags;
/*     */ import com.starshootercity.events.PlayerSwapOriginEvent;
/*     */ import com.starshootercity.util.ShortcutUtils;
/*     */ import com.starshootercity.util.config.ConfigManager;
/*     */ import java.util.List;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.HumanEntity;
/*     */ import org.bukkit.entity.LivingEntity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Cancellable;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.block.BlockDispenseArmorEvent;
/*     */ import org.bukkit.event.inventory.ClickType;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.inventory.InventoryDragEvent;
/*     */ import org.bukkit.event.inventory.InventoryType;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ public class LightArmor implements Listener, VisibleAbility {
/*     */   @NotNull
/*     */   public Key getKey() {
/*  27 */     return Key.key("origins:light_armor");
/*     */   }
/*     */   private List<Material> allowedTypes;
/*     */   
/*     */   public String description() {
/*  32 */     return "You can not wear any heavy armor (armor with protection values higher than chainmail).";
/*     */   }
/*     */ 
/*     */   
/*     */   public String title() {
/*  37 */     return "Need for Mobility";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerSwapOrigin(PlayerSwapOriginEvent event) {
/*  44 */     if (event.getNewOrigin() == null)
/*  45 */       return;  runForAbility((Entity)event.getPlayer(), player -> {
/*     */           ItemStack helmet = event.getPlayer().getInventory().getHelmet();
/*     */           ItemStack chestplate = event.getPlayer().getInventory().getChestplate();
/*     */           ItemStack leggings = event.getPlayer().getInventory().getLeggings();
/*     */           ItemStack boots = event.getPlayer().getInventory().getBoots();
/*     */           if (helmet != null && !this.allowedTypes.contains(helmet.getType())) {
/*     */             event.getPlayer().getInventory().setHelmet(null);
/*     */             ShortcutUtils.giveItemWithDrops(event.getPlayer(), new ItemStack[] { helmet });
/*     */           } 
/*     */           if (chestplate != null && !this.allowedTypes.contains(chestplate.getType())) {
/*     */             event.getPlayer().getInventory().setChestplate(null);
/*     */             ShortcutUtils.giveItemWithDrops(event.getPlayer(), new ItemStack[] { chestplate });
/*     */           } 
/*     */           if (leggings != null && !this.allowedTypes.contains(leggings.getType())) {
/*     */             event.getPlayer().getInventory().setLeggings(null);
/*     */             ShortcutUtils.giveItemWithDrops(event.getPlayer(), new ItemStack[] { leggings });
/*     */           } 
/*     */           if (boots != null && !this.allowedTypes.contains(boots.getType())) {
/*     */             event.getPlayer().getInventory().setBoots(null);
/*     */             ShortcutUtils.giveItemWithDrops(event.getPlayer(), new ItemStack[] { boots });
/*     */           } 
/*     */         });
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onInventoryDrag(InventoryDragEvent event) {
/*  71 */     if (event.getInventorySlots().contains(Integer.valueOf(38))) {
/*  72 */       HumanEntity humanEntity = event.getWhoClicked(); if (humanEntity instanceof Player) { Player player = (Player)humanEntity;
/*  73 */         checkArmorEvent((Cancellable)event, player, event.getOldCursor()); }
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onInventoryClick(InventoryClickEvent event) {
/*  80 */     HumanEntity humanEntity = event.getWhoClicked(); if (humanEntity instanceof Player) { Player player = (Player)humanEntity;
/*  81 */       if (event.getCursor() != null && 
/*  82 */         isArmor(event.getCursor().getType()) && 
/*  83 */         event.getSlotType() == InventoryType.SlotType.ARMOR) {
/*  84 */         checkArmorEvent((Cancellable)event, player, event.getCursor());
/*     */       }
/*     */ 
/*     */       
/*  88 */       if (event.isShiftClick()) {
/*  89 */         if (event.getCurrentItem() == null)
/*  90 */           return;  if (event.getInventory().getType() != InventoryType.CRAFTING)
/*  91 */           return;  if (MaterialTags.HELMETS.isTagged(event.getCurrentItem().getType()) && isNull(player.getEquipment().getHelmet())) {
/*  92 */           checkArmorEvent((Cancellable)event, player, event.getCurrentItem());
/*     */         }
/*  94 */         if (MaterialTags.CHESTPLATES.isTagged(event.getCurrentItem().getType()) && isNull(player.getEquipment().getChestplate())) {
/*  95 */           checkArmorEvent((Cancellable)event, player, event.getCurrentItem());
/*     */         }
/*  97 */         if (MaterialTags.LEGGINGS.isTagged(event.getCurrentItem().getType()) && isNull(player.getEquipment().getLeggings())) {
/*  98 */           checkArmorEvent((Cancellable)event, player, event.getCurrentItem());
/*     */         }
/* 100 */         if (MaterialTags.BOOTS.isTagged(event.getCurrentItem().getType()) && isNull(player.getEquipment().getBoots())) {
/* 101 */           checkArmorEvent((Cancellable)event, player, event.getCurrentItem());
/*     */         }
/*     */       } 
/* 104 */       if (event.getAction() == InventoryAction.HOTBAR_SWAP && 
/* 105 */         event.getHotbarButton() == -1 && 
/* 106 */         event.getSlotType() == InventoryType.SlotType.ARMOR) {
/* 107 */         checkArmorEvent((Cancellable)event, player, player.getInventory().getItemInOffHand());
/*     */       }
/*     */ 
/*     */       
/* 111 */       if (event.getClick() == ClickType.NUMBER_KEY && 
/* 112 */         event.getSlotType() == InventoryType.SlotType.ARMOR) {
/* 113 */         ItemStack item = player.getInventory().getItem(event.getHotbarButton());
/* 114 */         if (item != null) {
/* 115 */           checkArmorEvent((Cancellable)event, player, item);
/*     */         }
/*     */       }  }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNull(ItemStack item) {
/* 123 */     if (item == null) return true; 
/* 124 */     return item.getType().isAir();
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerInteract(PlayerInteractEvent event) {
/* 129 */     if (event.getAction().isRightClick()) {
/* 130 */       if (event.getItem() == null)
/* 131 */         return;  if (MaterialTags.HELMETS.isTagged(event.getItem().getType())) {
/* 132 */         checkArmorEvent((Cancellable)event, event.getPlayer(), event.getItem());
/*     */       }
/* 134 */       if (MaterialTags.CHESTPLATES.isTagged(event.getItem().getType())) {
/* 135 */         checkArmorEvent((Cancellable)event, event.getPlayer(), event.getItem());
/*     */       }
/* 137 */       if (MaterialTags.LEGGINGS.isTagged(event.getItem().getType())) {
/* 138 */         checkArmorEvent((Cancellable)event, event.getPlayer(), event.getItem());
/*     */       }
/* 140 */       if (MaterialTags.BOOTS.isTagged(event.getItem().getType()))
/* 141 */         checkArmorEvent((Cancellable)event, event.getPlayer(), event.getItem()); 
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onBlockDispenseArmor(BlockDispenseArmorEvent event) {
/* 147 */     LivingEntity livingEntity = event.getTargetEntity(); if (livingEntity instanceof Player) { Player player = (Player)livingEntity;
/* 148 */       checkArmorEvent((Cancellable)event, player, event.getItem()); }
/*     */   
/*     */   }
/*     */   
/*     */   public void checkArmorEvent(Cancellable event, Player p, ItemStack armor) {
/* 153 */     runForAbility((Entity)p, player -> {
/*     */           if (this.allowedTypes.contains(armor.getType()))
/*     */             return; 
/*     */           event.setCancelled(true);
/*     */         });
/*     */   }
/*     */   public boolean isArmor(Material material) {
/* 160 */     return (MaterialTags.HELMETS.isTagged(material) || MaterialTags.CHESTPLATES.isTagged(material) || MaterialTags.LEGGINGS.isTagged(material) || MaterialTags.BOOTS.isTagged(material));
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize(JavaPlugin plugin) {
/* 165 */     this.allowedTypes = (List<Material>)registerConfigOption(plugin, "allowed_armor", Collections.singletonList("Armor allowed to be equipped"), ConfigManager.SettingType.MATERIAL_LIST, List.of((Object[])new Material[] { Material.CHAINMAIL_HELMET, Material.CHAINMAIL_CHESTPLATE, Material.CHAINMAIL_LEGGINGS, Material.CHAINMAIL_BOOTS, Material.LEATHER_HELMET, Material.LEATHER_CHESTPLATE, Material.LEATHER_LEGGINGS, Material.LEATHER_BOOTS, Material.GOLDEN_HELMET, Material.GOLDEN_CHESTPLATE, Material.GOLDEN_LEGGINGS, Material.GOLDEN_BOOTS }));
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\LightArmor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */