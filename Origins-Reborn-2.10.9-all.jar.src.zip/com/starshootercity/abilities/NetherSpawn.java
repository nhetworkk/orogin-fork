/*    */ package com.starshootercity.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.DefaultSpawnAbility;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.World;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ public class NetherSpawn implements DefaultSpawnAbility, VisibleAbility {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 15 */     return Key.key("origins:nether_spawn");
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public World getWorld() {
/* 20 */     String nether = (String)ConfigManager.getConfigValue(ConfigManager.Option.NETHER_DIMENSION);
/* 21 */     World world = Bukkit.getWorld(nether);
/* 22 */     if (world == null)
/* 23 */       for (World w : Bukkit.getWorlds()) {
/* 24 */         if (w.getEnvironment().equals(World.Environment.NETHER)) world = w;
/*    */       
/*    */       }  
/* 27 */     return world;
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 32 */     return "Your natural spawn will be in the Nether.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 37 */     return "Nether Inhabitant";
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\NetherSpawn.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */