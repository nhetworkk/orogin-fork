/*    */ package com.starshootercity.abilities;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import java.util.Collections;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityExhaustionEvent;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class MoreExhaustion implements Listener, VisibleAbility {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 17 */     return Key.key("origins:more_exhaustion");
/*    */   }
/*    */   private float exhaustionMultiplier;
/*    */   
/*    */   public String description() {
/* 22 */     return "You exhaust much quicker than others, thus requiring you to eat more.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 27 */     return "Large Appetite";
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onEntityExhaustion(EntityExhaustionEvent event) {
/* 32 */     runForAbility((Entity)event.getEntity(), player -> event.setExhaustion(event.getExhaustion() * this.exhaustionMultiplier));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void initialize(JavaPlugin plugin) {
/* 39 */     this.exhaustionMultiplier = ((Float)registerConfigOption(plugin, "exhaustion_multiplier", Collections.singletonList("Amount to multiply exhaustion by"), ConfigManager.SettingType.FLOAT, Float.valueOf(1.6F))).floatValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\MoreExhaustion.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */