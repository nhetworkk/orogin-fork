/*    */ package com.starshootercity.abilities;
/*    */ import com.starshootercity.OriginsReborn;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import java.util.Collections;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.entity.EntityType;
/*    */ import org.bukkit.entity.LivingEntity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.entity.ProjectileHitEvent;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.bukkit.util.Vector;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class DamageFromSnowballs implements Ability, Listener {
/*    */   private int damageAmount;
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 20 */     return Key.key("origins:damage_from_snowballs");
/*    */   }
/*    */   private boolean knockback;
/*    */   @EventHandler
/*    */   public void onProjectileHit(ProjectileHitEvent event) {
/* 25 */     if (event.getEntity().getType() != EntityType.SNOWBALL)
/* 26 */       return;  runForAbility(event.getHitEntity(), player -> {
/*    */           OriginsReborn.getMVE().dealFreezeDamage((LivingEntity)player, this.damageAmount);
/*    */           Vector vector = event.getEntity().getLocation().getDirection();
/*    */           if (this.knockback) {
/*    */             OriginsReborn.getMVE().knockback((LivingEntity)player, 0.5D, -vector.getX(), -vector.getZ());
/*    */           }
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void initialize(JavaPlugin plugin) {
/* 41 */     this.damageAmount = ((Integer)registerConfigOption(plugin, "damage_amount", Collections.singletonList("Amount of damage the player should take when hit with a snowball"), ConfigManager.SettingType.INTEGER, Integer.valueOf(3))).intValue();
/* 42 */     this.knockback = ((Boolean)registerConfigOption(plugin, "knockback", Collections.singletonList("Whether snowballs should deal knockback too"), ConfigManager.SettingType.BOOLEAN, Boolean.valueOf(true))).booleanValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\DamageFromSnowballs.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */