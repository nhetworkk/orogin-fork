/*    */ package com.starshootercity.abilities.impossible;
/*    */ 
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class LikeAir
/*    */   implements VisibleAbility, Listener {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 12 */     return Key.key("origins:like_air");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 17 */     return "Modifiers to your walking speed also apply while you're airborne.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 22 */     return "Like Air";
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\impossible\LikeAir.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */