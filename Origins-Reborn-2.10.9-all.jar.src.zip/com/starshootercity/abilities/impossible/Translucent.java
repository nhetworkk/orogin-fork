/*    */ package com.starshootercity.abilities.impossible;
/*    */ 
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class Translucent
/*    */   implements VisibleAbility {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 11 */     return Key.key("origins:translucent");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 16 */     return "Your skin is translucent.";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public String title() {
/* 21 */     return "Translucent";
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\impossible\Translucent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */