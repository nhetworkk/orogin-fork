/*    */ package com.starshootercity.abilities;
/*    */ import com.starshootercity.OriginsReborn;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import java.util.Collections;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.LivingEntity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerItemConsumeEvent;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class DamageFromPotions implements Ability, Listener {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 19 */     return Key.key("origins:damage_from_potions");
/*    */   }
/*    */   private int damageAmount;
/*    */   @EventHandler
/*    */   public void onPlayerItemConsume(PlayerItemConsumeEvent event) {
/* 24 */     runForAbility((Entity)event.getPlayer(), player -> {
/*    */           if (event.getItem().getType() == Material.POTION) {
/*    */             OriginsReborn.getMVE().dealFreezeDamage((LivingEntity)player, this.damageAmount);
/*    */           }
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void initialize(JavaPlugin plugin) {
/* 35 */     this.damageAmount = ((Integer)registerConfigOption(plugin, "damage_amount", Collections.singletonList("Amount of damage the player should take when drinking a potion"), ConfigManager.SettingType.INTEGER, Integer.valueOf(2))).intValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\DamageFromPotions.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */