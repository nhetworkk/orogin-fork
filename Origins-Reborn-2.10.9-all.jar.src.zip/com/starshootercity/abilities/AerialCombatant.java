/*    */ package com.starshootercity.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import java.util.Collections;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class AerialCombatant
/*    */   implements VisibleAbility, Listener {
/*    */   @EventHandler
/*    */   public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
/* 18 */     runForAbility(event.getDamager(), player -> {
/*    */           if (player.isGliding())
/*    */             event.setDamage(event.getDamage() * this.damageMultiplier); 
/*    */         });
/*    */   } private float damageMultiplier;
/*    */   @NotNull
/*    */   public Key getKey() {
/* 25 */     return Key.key("origins:aerial_combatant");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 30 */     return "You deal substantially more damage while in Elytra flight.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 35 */     return "Aerial Combatant";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void initialize(JavaPlugin plugin) {
/* 42 */     this.damageMultiplier = ((Float)registerConfigOption(plugin, "damage_multiplier", Collections.singletonList("Amount to multiply the damage by when gliding"), ConfigManager.SettingType.FLOAT, Float.valueOf(2.0F))).floatValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\AerialCombatant.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */