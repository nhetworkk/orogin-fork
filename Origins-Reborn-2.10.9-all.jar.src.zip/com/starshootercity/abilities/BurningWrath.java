/*    */ package com.starshootercity.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import java.util.Collections;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class BurningWrath implements Listener, VisibleAbility {
/*    */   @EventHandler
/*    */   public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
/* 17 */     runForAbility(event.getDamager(), player -> {
/*    */           if (player.getFireTicks() > 0)
/*    */             event.setDamage(event.getDamage() + this.damageIncrease); 
/*    */         });
/*    */   } private int damageIncrease;
/*    */   @NotNull
/*    */   public Key getKey() {
/* 24 */     return Key.key("origins:burning_wrath");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 29 */     return "When on fire, you deal additional damage with your attacks.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 34 */     return "Burning Wrath";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void initialize(JavaPlugin plugin) {
/* 41 */     this.damageIncrease = ((Integer)registerConfigOption(plugin, "damage_increase", Collections.singletonList("How much to increase damage dealt when on fire"), ConfigManager.SettingType.INTEGER, Integer.valueOf(3))).intValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\BurningWrath.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */