/*    */ package com.starshootercity.abilities;
/*    */ 
/*    */ import com.destroystokyo.paper.MaterialTags;
/*    */ import com.destroystokyo.paper.event.server.ServerTickEndEvent;
/*    */ import com.starshootercity.abilities.types.DependantAbility;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.block.Block;
/*    */ import org.bukkit.block.BlockFace;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class BurnInDaylight implements DependantAbility, Listener, VisibleAbility {
/*    */   public DependantAbility.DependencyType getDependencyType() {
/* 25 */     return DependantAbility.DependencyType.INVERSE;
/*    */   }
/*    */   private boolean burnWithHelmet;
/*    */   @EventHandler
/*    */   public void onServerTickEnd(ServerTickEndEvent event) {
/* 30 */     if (event.getTickNumber() % 20 != 0)
/* 31 */       return;  for (Iterator<Player> iterator = Bukkit.getOnlinePlayers().iterator(); iterator.hasNext(); ) { Player p = iterator.next();
/* 32 */       runForAbility((Entity)p, player -> {
/*    */             Block block = player.getWorld().getHighestBlockAt(player.getLocation());
/*    */             while (MaterialTags.GLASS.isTagged(block) || (MaterialTags.GLASS_PANES.isTagged(block) && block.getY() >= player.getLocation().getY())) {
/*    */               block = block.getRelative(BlockFace.DOWN);
/*    */             }
/*    */             boolean height = (block.getY() < player.getLocation().getY());
/*    */             boolean isInOverworld = (player.getWorld().getEnvironment() == World.Environment.NORMAL);
/*    */             boolean day = player.getWorld().isDayTime();
/*    */             if (!this.burnWithHelmet) {
/*    */               ItemStack helm = player.getInventory().getHelmet();
/*    */               if (helm != null && !helm.getType().isAir()) {
/*    */                 return;
/*    */               }
/*    */             } 
/*    */             if (height && isInOverworld && day && !player.isInWaterOrRainOrBubbleColumn()) {
/*    */               player.setFireTicks(Math.max(player.getFireTicks(), 60));
/*    */             }
/*    */           }); }
/*    */   
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 58 */     return Key.key("origins:burn_in_daylight");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 63 */     return "You begin to burn in daylight if you are not invisible.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 68 */     return "Photoallergic";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getDependencyKey() {
/* 73 */     return Key.key("origins:phantomize");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void initialize(JavaPlugin plugin) {
/* 80 */     this.burnWithHelmet = ((Boolean)registerConfigOption(plugin, "burn_with_helmet", List.of("Whether the player should burn even when wearing a helmet"), ConfigManager.SettingType.BOOLEAN, Boolean.valueOf(true))).booleanValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\BurnInDaylight.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */