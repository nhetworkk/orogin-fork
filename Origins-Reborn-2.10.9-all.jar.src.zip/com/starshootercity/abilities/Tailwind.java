/*    */ package com.starshootercity.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.AttributeModifierAbility;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.version.MVAttribute;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.attribute.Attribute;
/*    */ import org.bukkit.attribute.AttributeModifier;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class Tailwind implements AttributeModifierAbility, VisibleAbility {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 15 */     return Key.key("origins:tailwind");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 20 */     return "You are a little bit quicker on foot than others.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 25 */     return "Tailwind";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Attribute getAttribute() {
/* 30 */     return MVAttribute.MOVEMENT_SPEED.get();
/*    */   }
/*    */ 
/*    */   
/*    */   public double getAmount(Player player) {
/* 35 */     return 0.2D;
/*    */   }
/*    */ 
/*    */   
/*    */   public AttributeModifier.Operation getOperation() {
/* 40 */     return AttributeModifier.Operation.MULTIPLY_SCALAR_1;
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\Tailwind.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */