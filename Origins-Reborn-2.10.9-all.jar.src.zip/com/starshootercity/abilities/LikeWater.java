/*    */ package com.starshootercity.abilities;
/*    */ import com.starshootercity.abilities.types.FlightAllowingAbility;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerMoveEvent;
/*    */ import org.bukkit.event.player.PlayerToggleFlightEvent;
/*    */ import org.bukkit.event.player.PlayerToggleSneakEvent;
/*    */ import org.bukkit.event.player.PlayerToggleSprintEvent;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class LikeWater implements FlightAllowingAbility, Listener, VisibleAbility {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 18 */     return Key.key("origins:like_water");
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean canFly(Player player) {
/* 23 */     return (player.isInWater() && !player.isInBubbleColumn());
/*    */   }
/*    */ 
/*    */   
/*    */   public float getFlightSpeed(Player player) {
/* 28 */     return 0.06F;
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerToggleSneak(PlayerToggleSneakEvent event) {
/* 33 */     runForAbility((Entity)event.getPlayer(), player -> {
/*    */           if (player.isInWater())
/*    */             player.setFlying(false); 
/*    */         });
/*    */   }
/*    */   @EventHandler
/*    */   public void onPlayerMove(PlayerMoveEvent event) {
/* 40 */     if (event.getPlayer().isSwimming())
/* 41 */       return;  if (event.getPlayer().isSprinting())
/* 42 */       return;  if (event.getPlayer().isFlying())
/* 43 */       return;  if (!event.getPlayer().isInWater())
/* 44 */       return;  runForAbility((Entity)event.getPlayer(), player -> {
/* 45 */           boolean fly = (event.getTo().getY() > event.getFrom().getY() && !player.isInBubbleColumn());
/*    */           player.setAllowFlight(fly);
/*    */           player.setFlying(fly);
/*    */         });
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerToggleSprint(PlayerToggleSprintEvent event) {
/* 53 */     if (!event.getPlayer().isFlying())
/* 54 */       return;  runForAbility((Entity)event.getPlayer(), player -> {
/*    */           if (player.isInWater()) {
/*    */             player.setFlying(false);
/*    */           }
/*    */         });
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerToggleFlight(PlayerToggleFlightEvent event) {
/* 63 */     runForAbility((Entity)event.getPlayer(), player -> {
/*    */           if (player.isInWater())
/*    */             event.setCancelled(true); 
/*    */         });
/*    */   }
/*    */   
/*    */   public String description() {
/* 70 */     return "When underwater, you do not sink to the ground unless you want to.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 75 */     return "Like Water";
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\LikeWater.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */