/*    */ package com.starshootercity.abilities;
/*    */ 
/*    */ import com.destroystokyo.paper.MaterialTags;
/*    */ import com.starshootercity.abilities.types.Ability;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.block.BlockBreakEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StrongArmsDrops
/*    */   implements Ability, Listener
/*    */ {
/* 71 */   public static StrongArmsDrops strongArmsDrops = new StrongArmsDrops();
/*    */   
/*    */   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
/*    */   public void onBlockBreak(BlockBreakEvent event) {
/* 75 */     runForAbility((Entity)event.getPlayer(), player -> {
/*    */           if (StrongArms.naturalStones.contains(event.getBlock().getType()) && !MaterialTags.PICKAXES.isTagged(player.getInventory().getItemInMainHand().getType())) {
/*    */             event.setCancelled(true);
/*    */             ItemStack item = new ItemStack(Material.IRON_PICKAXE);
/*    */             item.addUnsafeEnchantments(player.getInventory().getItemInMainHand().getEnchantments());
/*    */             event.getBlock().breakNaturally(item, event instanceof com.starshootercity.abilities.types.BreakSpeedModifierAbility.ModifiedBlockBreakEvent);
/*    */           } 
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 89 */     return Key.key("origins:strong_arms_drops");
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\StrongArms$StrongArmsDrops.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */