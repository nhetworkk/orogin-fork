/*    */ package com.starshootercity.abilities;
/*    */ import com.starshootercity.OriginsReborn;
/*    */ import com.starshootercity.abilities.types.CooldownAbility;
/*    */ import com.starshootercity.abilities.types.TriggerableAbility;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.cooldowns.Cooldowns;
/*    */ import com.starshootercity.util.TriggerManager;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.NamespacedKey;
/*    */ import org.bukkit.entity.EnderPearl;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.entity.Projectile;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.ProjectileHitEvent;
/*    */ import org.bukkit.persistence.PersistentDataType;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.bukkit.util.Vector;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class ThrowEnderPearl implements Listener, CooldownAbility, VisibleAbility, TriggerableAbility {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 25 */     return Key.key("origins:throw_ender_pearl");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 30 */     return "Whenever you want, you may throw an ender pearl which deals no damage, allowing you to teleport.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 35 */     return "Teleportation";
/*    */   }
/*    */   
/* 38 */   private final NamespacedKey falseEnderPearlKey = new NamespacedKey((Plugin)OriginsReborn.getInstance(), "false-ender-pearl");
/*    */   
/*    */   @EventHandler
/*    */   public void onProjectileHit(ProjectileHitEvent event) {
/* 42 */     if (event.getEntity().getPersistentDataContainer().has(this.falseEnderPearlKey, PersistentDataType.STRING)) {
/* 43 */       event.setCancelled(true);
/* 44 */       String name = (String)event.getEntity().getPersistentDataContainer().get(this.falseEnderPearlKey, PersistentDataType.STRING);
/* 45 */       if (name == null)
/* 46 */         return;  Player player = Bukkit.getPlayer(name);
/* 47 */       if (player == null)
/* 48 */         return;  Location loc = event.getEntity().getLocation();
/* 49 */       loc.setPitch(player.getLocation().getPitch());
/* 50 */       loc.setYaw(player.getLocation().getYaw());
/* 51 */       player.setFallDistance(0.0F);
/* 52 */       player.setVelocity(new Vector());
/* 53 */       player.teleport(loc);
/* 54 */       event.getEntity().remove();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Cooldowns.CooldownInfo getCooldownInfo() {
/* 60 */     return new Cooldowns.CooldownInfo(30, "ender_pearl");
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public TriggerableAbility.Trigger getTrigger() {
/* 65 */     return TriggerableAbility.Trigger.builder(TriggerableAbility.TriggerType.LEFT_CLICK, (Ability)this).addConditions(new TriggerableAbility.Condition[] { TriggerableAbility.Condition.EMPTY_HAND, TriggerableAbility.Condition.NO_BLOCK
/* 66 */         }).build(event -> {
/*    */           Player player = event.player();
/*    */           if (hasCooldown(player))
/*    */             return; 
/*    */           setCooldown(player);
/*    */           Projectile projectile = player.launchProjectile(EnderPearl.class);
/*    */           projectile.getPersistentDataContainer().set(this.falseEnderPearlKey, PersistentDataType.STRING, player.getName());
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\ThrowEnderPearl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */