/*     */ package com.starshootercity.abilities;
/*     */ import com.starshootercity.OriginsReborn;
/*     */ import com.starshootercity.abilities.types.TriggerableAbility;
/*     */ import com.starshootercity.events.PlayerLeftClickEvent;
/*     */ import com.starshootercity.util.CustomGUI;
/*     */ import com.starshootercity.util.TriggerManager;
/*     */ import com.starshootercity.util.config.ConfigManager;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import net.kyori.adventure.text.Component;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.NamespacedKey;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.HumanEntity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.entity.PlayerDeathEvent;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.inventory.InventoryDragEvent;
/*     */ import org.bukkit.event.inventory.InventoryType;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.persistence.PersistentDataContainer;
/*     */ import org.bukkit.persistence.PersistentDataType;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ public class ShulkerInventory implements Listener, VisibleAbility, TriggerableAbility {
/*     */   private NamespacedKey inventoryKey;
/*     */   private List<NamespacedKey> keys;
/*     */   private boolean dropItemsOnDeath;
/*     */   
/*     */   @NotNull
/*     */   public Key getKey() {
/*  41 */     return Key.key("origins:shulker_inventory");
/*     */   }
/*     */   private static File inventories; private static FileConfiguration inventoriesConfig; private boolean supportLegacyInventoryFile;
/*     */   
/*     */   public String description() {
/*  46 */     return "You have access to an additional 9 slots of inventory, which keep the items on death.";
/*     */   }
/*     */ 
/*     */   
/*     */   public String title() {
/*  51 */     return "Hoarder";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerLeftClick(PlayerLeftClickEvent event) {
/*  59 */     if (event.hasBlock())
/*  60 */       return;  if (event.hasItem())
/*  61 */       return;  if (ShortcutUtils.isBedrockPlayer(event.getPlayer().getUniqueId())) {
/*  62 */       runForAbility((Entity)event.getPlayer(), this::openInventory);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize(JavaPlugin plugin) {
/*  70 */     registerTranslation("container", "Shulker Inventory");
/*  71 */     this.inventoryKey = new NamespacedKey((Plugin)plugin, "shulker_inventory_contents");
/*  72 */     this.keys = new ArrayList<>();
/*     */     
/*  74 */     for (int i = 0; i < 9; i++) {
/*  75 */       this.keys.add(new NamespacedKey((Plugin)plugin, String.valueOf(i)));
/*     */     }
/*     */     
/*  78 */     this.dropItemsOnDeath = ((Boolean)registerConfigOption(plugin, "drop_on_death", Collections.singletonList("Drop items in the inventory on death (will not change ability description, for that edit the translations.yml file)"), ConfigManager.SettingType.BOOLEAN, Boolean.valueOf(false))).booleanValue();
/*     */     
/*  80 */     prepareLegacyInventoryData();
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerDeath(PlayerDeathEvent event) {
/*  85 */     if (!this.dropItemsOnDeath)
/*  86 */       return;  runForAbility((Entity)event.getPlayer(), player -> {
/*     */           PersistentDataContainer pdc = getShulkerInventory(player);
/*     */           for (NamespacedKey key : pdc.getKeys()) {
/*     */             byte[] bytes = (byte[])pdc.get(key, PersistentDataType.BYTE_ARRAY);
/*     */             pdc.remove(key);
/*     */             if (bytes == null)
/*     */               continue; 
/*     */             ItemStack item = ItemStack.deserializeBytes(bytes);
/*     */             event.getDrops().add(item);
/*     */           } 
/*     */           setShulkerInventory(player, pdc);
/*     */         });
/*     */   }
/*     */   @NotNull
/*     */   public TriggerableAbility.Trigger getTrigger() {
/* 101 */     return TriggerableAbility.Trigger.builder(TriggerableAbility.TriggerType.RIGHT_CLICK_CHESTPLATE, (Ability)this)
/* 102 */       .build(event -> {
/*     */           event.setCancelled(true);
/*     */           openInventory(event.player());
/*     */         });
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onInventoryClick(InventoryClickEvent event) {
/* 110 */     HumanEntity humanEntity = event.getWhoClicked(); if (humanEntity instanceof Player) { Player p = (Player)humanEntity;
/* 111 */       saveInventory(p, event.getInventory()); }
/*     */   
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onInventoryDrag(InventoryDragEvent event) {
/* 117 */     HumanEntity humanEntity = event.getWhoClicked(); if (humanEntity instanceof Player) { Player p = (Player)humanEntity;
/* 118 */       saveInventory(p, event.getInventory()); }
/*     */   
/*     */   }
/*     */   
/*     */   public void saveInventory(Player p, Inventory inventory) {
/* 123 */     runForAbility((Entity)p, player -> Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)OriginsReborn.getInstance(), ()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void openInventory(Player player) {
/* 140 */     Inventory inventory = CustomGUI.createInventory(CustomGUI.CustomInventoryType.SHULKER_INVENTORY, InventoryType.DISPENSER, (Component)Component.text(translate("container")));
/* 141 */     player.openInventory(inventory);
/* 142 */     PersistentDataContainer container = getShulkerInventory(player);
/* 143 */     for (int i = 0; i < 9; i++) {
/* 144 */       if (container.has(this.keys.get(i), PersistentDataType.BYTE_ARRAY)) {
/*     */         
/* 146 */         byte[] bytes = (byte[])container.get(this.keys.get(i), PersistentDataType.BYTE_ARRAY);
/*     */         
/* 148 */         ItemStack item = ItemStack.deserializeBytes(bytes);
/* 149 */         inventory.setItem(i, item);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   public PersistentDataContainer getShulkerInventory(Player player) {
/* 154 */     PersistentDataContainer container = (PersistentDataContainer)player.getPersistentDataContainer().get(this.inventoryKey, PersistentDataType.TAG_CONTAINER);
/* 155 */     if (container == null) container = player.getPersistentDataContainer().getAdapterContext().newPersistentDataContainer(); 
/* 156 */     return container;
/*     */   }
/*     */   
/*     */   public void setShulkerInventory(Player player, PersistentDataContainer container) {
/* 160 */     player.getPersistentDataContainer().set(this.inventoryKey, PersistentDataType.TAG_CONTAINER, container);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void prepareLegacyInventoryData() {
/* 169 */     inventories = new File(OriginsReborn.getInstance().getDataFolder(), "internals/inventories.yml");
/* 170 */     this.supportLegacyInventoryFile = inventories.exists();
/* 171 */     if (!this.supportLegacyInventoryFile)
/* 172 */       return;  inventoriesConfig = (FileConfiguration)new YamlConfiguration();
/*     */     try {
/* 174 */       inventoriesConfig.load(inventories);
/* 175 */     } catch (IOException|org.bukkit.configuration.InvalidConfigurationException e) {
/* 176 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerJoin(PlayerJoinEvent event) throws IOException {
/* 182 */     if (!this.supportLegacyInventoryFile)
/*     */       return; 
/* 184 */     if (!inventoriesConfig.contains(event.getPlayer().getUniqueId().toString()))
/* 185 */       return;  PersistentDataContainer container = getShulkerInventory(event.getPlayer());
/* 186 */     for (int i = 0; i < 9; i++) {
/* 187 */       String path = "%s.%s".formatted(new Object[] { event.getPlayer().getUniqueId().toString(), Integer.valueOf(i) });
/* 188 */       if (inventoriesConfig.contains(path)) {
/* 189 */         ItemStack item = inventoriesConfig.getItemStack(path);
/* 190 */         if (item != null)
/* 191 */           container.set(this.keys.get(i), PersistentDataType.BYTE_ARRAY, item.serializeAsBytes()); 
/*     */       } 
/* 193 */     }  setShulkerInventory(event.getPlayer(), container);
/*     */     
/* 195 */     inventoriesConfig.set(event.getPlayer().getUniqueId().toString(), null);
/* 196 */     inventoriesConfig.save(inventories);
/* 197 */     if (inventoriesConfig.getKeys(false).isEmpty()) {
/* 198 */       boolean ignored = inventories.delete();
/* 199 */       this.supportLegacyInventoryFile = false;
/* 200 */       inventoriesConfig = null;
/* 201 */       inventories = null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\ShulkerInventory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */