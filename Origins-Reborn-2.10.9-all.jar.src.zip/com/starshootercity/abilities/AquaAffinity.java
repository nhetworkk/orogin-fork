/*    */ package com.starshootercity.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.BreakSpeedModifierAbility;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.version.MVPotionEffectType;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class AquaAffinity implements BreakSpeedModifierAbility, VisibleAbility {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 13 */     return Key.key("origins:aqua_affinity");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 18 */     return "You may break blocks underwater as others do on land.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 23 */     return "Aqua Affinity";
/*    */   }
/*    */ 
/*    */   
/*    */   public BreakSpeedModifierAbility.BlockMiningContext getMiningContext(Player player) {
/* 28 */     return new BreakSpeedModifierAbility.BlockMiningContext(player
/* 29 */         .getInventory().getItemInMainHand(), player
/* 30 */         .getPotionEffect(MVPotionEffectType.MINING_FATIGUE.get()), player
/* 31 */         .getPotionEffect(MVPotionEffectType.HASTE.get()), player
/* 32 */         .getPotionEffect(MVPotionEffectType.CONDUIT_POWER.get()), true, true, true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean shouldActivate(Player player) {
/* 41 */     return player.isInWater();
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\AquaAffinity.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */