/*    */ package com.starshootercity.abilities;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import java.util.Collections;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.enchantments.Enchantment;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.LivingEntity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.entity.Trident;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class Aquatic implements Ability, Listener {
/*    */   private float damageMultiplier;
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 20 */     return Key.key("origins:aquatic");
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
/* 25 */     runForAbility(event.getEntity(), player -> {
/*    */           Entity patt0$temp = event.getDamager();
/*    */           if (patt0$temp instanceof Trident) {
/*    */             Trident trident = (Trident)patt0$temp;
/*    */             event.setDamage(event.getDamage() + (trident.getItem().getEnchantmentLevel(Enchantment.IMPALING) * this.damageMultiplier));
/*    */           } else {
/*    */             Entity patt1$temp = event.getDamager();
/*    */             if (patt1$temp instanceof LivingEntity) {
/*    */               LivingEntity entity = (LivingEntity)patt1$temp;
/*    */               if (entity.getEquipment() == null)
/*    */                 return; 
/*    */               event.setDamage(event.getDamage() + (entity.getEquipment().getItemInMainHand().getEnchantmentLevel(Enchantment.IMPALING) * this.damageMultiplier));
/*    */             } 
/*    */           } 
/* 39 */         }); } public void initialize(JavaPlugin plugin) { this.damageMultiplier = ((Float)registerConfigOption(plugin, "impaling_damage_increase", Collections.singletonList("Amount to increase damage by per level of Impaling"), ConfigManager.SettingType.FLOAT, Float.valueOf(2.5F))).floatValue(); }
/*    */ 
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\Aquatic.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */