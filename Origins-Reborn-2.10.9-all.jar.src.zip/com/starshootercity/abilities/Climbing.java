/*     */ package com.starshootercity.abilities;
/*     */ import com.destroystokyo.paper.event.player.PlayerJumpEvent;
/*     */ import com.destroystokyo.paper.event.server.ServerTickEndEvent;
/*     */ import com.starshootercity.OriginSwapper;
/*     */ import com.starshootercity.OriginsReborn;
/*     */ import com.starshootercity.abilities.types.FlightAllowingAbility;
/*     */ import com.starshootercity.abilities.types.VisibleAbility;
/*     */ import java.time.Instant;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import net.kyori.adventure.util.TriState;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.NamespacedKey;
/*     */ import org.bukkit.block.BlockFace;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.player.PlayerToggleFlightEvent;
/*     */ import org.bukkit.persistence.PersistentDataType;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ public class Climbing implements FlightAllowingAbility, Listener, VisibleAbility {
/*  28 */   NamespacedKey stoppedClimbingKey = new NamespacedKey((Plugin)OriginsReborn.getInstance(), "stoppedclimbing");
/*  29 */   NamespacedKey startedClimbingKey = new NamespacedKey((Plugin)OriginsReborn.getInstance(), "startedclimbing");
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onServerTickEnd(ServerTickEndEvent ignored) {
/*  34 */     for (Iterator<Player> iterator = Bukkit.getOnlinePlayers().iterator(); iterator.hasNext(); ) { Player p = iterator.next();
/*  35 */       runForAbility((Entity)p, player -> {
/*     */             boolean anySolid = false;
/*     */             boolean anysolidAbove = false;
/*     */             for (BlockFace face : List.of(BlockFace.WEST, BlockFace.EAST, BlockFace.NORTH, BlockFace.SOUTH)) {
/*     */               anySolid = player.getLocation().getBlock().getRelative(face).isSolid();
/*     */               anysolidAbove = player.getLocation().getBlock().getRelative(BlockFace.UP).getRelative(face).isSolid();
/*     */               if (anySolid) {
/*     */                 break;
/*     */               }
/*     */             } 
/*     */             setCanFly(player, anySolid);
/*     */             if (anySolid) {
/*     */               OriginsReborn.getMVE().setFlyingFallDamage(player, TriState.TRUE);
/*     */             }
/*     */             if (player.getAllowFlight() && anysolidAbove) {
/*     */               if (!Boolean.TRUE.equals(player.getPersistentDataContainer().get(this.stoppedClimbingKey, (PersistentDataType)OriginSwapper.BooleanPDT.BOOLEAN))) {
/*     */                 if (!player.isOnGround()) {
/*     */                   player.setFlying(true);
/*     */                 }
/*     */               } else if (player.isOnGround()) {
/*     */                 player.getPersistentDataContainer().set(this.stoppedClimbingKey, (PersistentDataType)OriginSwapper.BooleanPDT.BOOLEAN, Boolean.valueOf(false));
/*     */               } 
/*     */             }
/*     */           }); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   private void setCanFly(Player player, boolean setFly) {
/*  64 */     this.canFly.put(player, Boolean.valueOf(setFly));
/*     */   }
/*     */   
/*  67 */   private final Map<Player, Boolean> canFly = new HashMap<>();
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerToggleFlight(PlayerToggleFlightEvent event) {
/*  71 */     if (!event.isFlying()) {
/*  72 */       Long time = (Long)event.getPlayer().getPersistentDataContainer().get(this.startedClimbingKey, PersistentDataType.LONG);
/*  73 */       if (time != null && 
/*  74 */         Instant.now().getEpochSecond() - time.longValue() < 2L) {
/*  75 */         event.setCancelled(true);
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*  80 */     event.getPlayer().getPersistentDataContainer().set(this.stoppedClimbingKey, (PersistentDataType)OriginSwapper.BooleanPDT.BOOLEAN, Boolean.valueOf(!event.isFlying()));
/*     */   }
/*     */   @EventHandler
/*     */   public void onPlayerJump(PlayerJumpEvent event) {
/*  84 */     event.getPlayer().getPersistentDataContainer().set(this.startedClimbingKey, PersistentDataType.LONG, Long.valueOf(Instant.now().getEpochSecond()));
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Key getKey() {
/*  89 */     return Key.key("origins:climbing");
/*     */   }
/*     */ 
/*     */   
/*     */   public String description() {
/*  94 */     return "You are able to climb up any kind of wall, not just ladders.";
/*     */   }
/*     */ 
/*     */   
/*     */   public String title() {
/*  99 */     return "Climbing";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canFly(Player player) {
/* 104 */     return ((Boolean)this.canFly.getOrDefault(player, Boolean.valueOf(false))).booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public float getFlightSpeed(Player player) {
/* 109 */     return 0.05F;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public TriState getFlyingFallDamage(Player player) {
/* 114 */     return TriState.TRUE;
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\Climbing.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */