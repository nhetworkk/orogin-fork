/*     */ package com.starshootercity.abilities;
/*     */ 
/*     */ import com.destroystokyo.paper.MaterialTags;
/*     */ import com.starshootercity.OriginsReborn;
/*     */ import com.starshootercity.abilities.types.Ability;
/*     */ import com.starshootercity.abilities.types.BreakSpeedModifierAbility;
/*     */ import com.starshootercity.abilities.types.MultiAbility;
/*     */ import com.starshootercity.abilities.types.VisibleAbility;
/*     */ import com.starshootercity.util.config.ConfigManager;
/*     */ import com.starshootercity.version.MVEnchantment;
/*     */ import com.starshootercity.version.MVPotionEffectType;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import org.bukkit.FluidCollisionMode;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.LivingEntity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.block.BlockBreakEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ public class StrongArms implements MultiAbility, Listener, VisibleAbility {
/*     */   @NotNull
/*     */   public Key getKey() {
/*  32 */     return Key.key("origins:strong_arms");
/*     */   }
/*     */ 
/*     */   
/*     */   public String description() {
/*  37 */     return "You are strong enough to break natural stones without using a pickaxe.";
/*     */   }
/*     */   private static List<Material> naturalStones;
/*     */   
/*     */   public String title() {
/*  42 */     return "Strong Arms";
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Ability> getAbilities() {
/*  47 */     return List.of(StrongArmsDrops.strongArmsDrops, StrongArmsBreakSpeed.strongArmsBreakSpeed);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize(JavaPlugin plugin) {
/*  54 */     naturalStones = (List<Material>)registerConfigOption(plugin, "natural_stones", Collections.singletonList("Blocks that count as natural stone"), ConfigManager.SettingType.MATERIAL_LIST, List.of((Object[])new Material[] { Material.STONE, Material.TUFF, Material.GRANITE, Material.DIORITE, Material.ANDESITE, Material.SANDSTONE, Material.SMOOTH_SANDSTONE, Material.RED_SANDSTONE, Material.SMOOTH_RED_SANDSTONE, Material.DEEPSLATE, Material.BLACKSTONE, Material.NETHERRACK }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class StrongArmsDrops
/*     */     implements Ability, Listener
/*     */   {
/*  71 */     public static StrongArmsDrops strongArmsDrops = new StrongArmsDrops();
/*     */     
/*     */     @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
/*     */     public void onBlockBreak(BlockBreakEvent event) {
/*  75 */       runForAbility((Entity)event.getPlayer(), player -> {
/*     */             if (StrongArms.naturalStones.contains(event.getBlock().getType()) && !MaterialTags.PICKAXES.isTagged(player.getInventory().getItemInMainHand().getType())) {
/*     */               event.setCancelled(true);
/*     */               ItemStack item = new ItemStack(Material.IRON_PICKAXE);
/*     */               item.addUnsafeEnchantments(player.getInventory().getItemInMainHand().getEnchantments());
/*     */               event.getBlock().breakNaturally(item, event instanceof BreakSpeedModifierAbility.ModifiedBlockBreakEvent);
/*     */             } 
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @NotNull
/*     */     public Key getKey() {
/*  89 */       return Key.key("origins:strong_arms_drops");
/*     */     }
/*     */   }
/*     */   
/*     */   public static class StrongArmsBreakSpeed implements BreakSpeedModifierAbility, Listener {
/*  94 */     public static StrongArmsBreakSpeed strongArmsBreakSpeed = new StrongArmsBreakSpeed();
/*     */     
/*     */     @NotNull
/*     */     public Key getKey() {
/*  98 */       return Key.key("origins:strong_arms_break_speed");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public BreakSpeedModifierAbility.BlockMiningContext getMiningContext(Player player) {
/* 104 */       boolean aquaAffinity = false;
/* 105 */       ItemStack helmet = player.getInventory().getHelmet();
/* 106 */       if (helmet != null && 
/* 107 */         helmet.containsEnchantment(MVEnchantment.AQUA_AFFINITY.get())) aquaAffinity = true;
/*     */       
/* 109 */       return new BreakSpeedModifierAbility.BlockMiningContext(new ItemStack(Material.IRON_PICKAXE), player
/*     */           
/* 111 */           .getPotionEffect(MVPotionEffectType.MINING_FATIGUE.get()), player
/* 112 */           .getPotionEffect(MVPotionEffectType.HASTE.get()), player
/* 113 */           .getPotionEffect(MVPotionEffectType.CONDUIT_POWER.get()), 
/* 114 */           OriginsReborn.getMVE().isUnderWater((LivingEntity)player), aquaAffinity, player
/*     */           
/* 116 */           .isOnGround());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean shouldActivate(Player player) {
/* 122 */       Block target = player.getTargetBlockExact(8, FluidCollisionMode.NEVER);
/* 123 */       return (!MaterialTags.PICKAXES.isTagged(player.getInventory().getItemInMainHand().getType()) && target != null && StrongArms.naturalStones.contains(target.getType()));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\StrongArms.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */