/*    */ package com.starshootercity.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class MoreKineticDamage implements Listener, VisibleAbility {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 11 */     return Key.key("origins:more_kinetic_damage");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 16 */     return "You take more damage from falling and flying into blocks.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 21 */     return "Brittle Bones";
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\MoreKineticDamage.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */