/*    */ package com.starshootercity.abilities;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityPotionEffectEvent;
/*    */ import org.bukkit.potion.PotionEffectType;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class Hotblooded implements Listener, VisibleAbility {
/*    */   @EventHandler
/*    */   public void onEntityPotionEffect(EntityPotionEffectEvent event) {
/* 14 */     runForAbility(event.getEntity(), player -> {
/*    */           if (event.getNewEffect() != null && (event.getNewEffect().getType().equals(PotionEffectType.POISON) || event.getNewEffect().getType().equals(PotionEffectType.HUNGER))) {
/*    */             event.setCancelled(true);
/*    */           }
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 25 */     return Key.key("origins:hotblooded");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 30 */     return "Due to your hot body, venoms burn up, making you immune to poison and hunger status effects.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 35 */     return "Hotblooded";
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\Hotblooded.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */