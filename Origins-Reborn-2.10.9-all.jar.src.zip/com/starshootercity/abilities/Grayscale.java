/*    */ package com.starshootercity.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.SkinChangingAbility;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import java.awt.image.BufferedImage;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ public class Grayscale
/*    */   implements SkinChangingAbility, VisibleAbility
/*    */ {
/*    */   public void modifySkin(BufferedImage image, Player player) {
/* 15 */     for (int x = 0; x < image.getWidth(); x++) {
/* 16 */       for (int y = 0; y < image.getHeight(); y++) {
/* 17 */         image.setRGB(x, y, grayscale(image.getRGB(x, y)));
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   public int grayscale(int decimalRGB) {
/* 23 */     int a = decimalRGB >> 24 & 0xFF;
/* 24 */     int r = decimalRGB >> 16 & 0xFF;
/* 25 */     int g = decimalRGB >> 8 & 0xFF;
/* 26 */     int b = decimalRGB & 0xFF;
/*    */     
/* 28 */     int grayscale = (int)Math.min(255.0D, Math.max(0.0D, 0.299D * r + 0.587D * g + 0.114D * b));
/*    */     
/* 30 */     return a << 24 | grayscale << 16 | grayscale << 8 | grayscale;
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 35 */     return "You appear faded, the color drained from your body.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 40 */     return "Faded";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 45 */     return Key.key("origins:grayscale");
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\Grayscale.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */