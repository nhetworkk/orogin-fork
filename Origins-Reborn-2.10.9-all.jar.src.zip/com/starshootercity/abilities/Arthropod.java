/*    */ package com.starshootercity.abilities;
/*    */ import com.starshootercity.abilities.types.Ability;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import com.starshootercity.version.MVEnchantment;
/*    */ import com.starshootercity.version.MVPotionEffectType;
/*    */ import java.util.Collections;
/*    */ import java.util.Random;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.LivingEntity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.bukkit.potion.PotionEffect;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class Arthropod implements Ability, Listener {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 22 */     return Key.key("origins:arthropod");
/*    */   }
/*    */   
/* 25 */   private final Random random = new Random(); private boolean applySlowness;
/*    */   
/*    */   @EventHandler
/*    */   public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
/* 29 */     Entity entity = event.getDamager(); if (entity instanceof LivingEntity) { LivingEntity livingEntity = (LivingEntity)entity;
/* 30 */       if (livingEntity.getEquipment() == null)
/* 31 */         return;  if (livingEntity.getEquipment().getItemInMainHand().containsEnchantment(MVEnchantment.BANE_OF_ARTHROPODS.get())) {
/* 32 */         runForAbility(event.getEntity(), player -> {
/*    */               int level = entity.getEquipment().getItemInMainHand().getEnchantmentLevel(MVEnchantment.BANE_OF_ARTHROPODS.get());
/*    */               event.setDamage(event.getDamage() + 1.25D * level);
/*    */               if (this.applySlowness) {
/*    */                 player.addPotionEffect(new PotionEffect(MVPotionEffectType.SLOWNESS.get(), (int)(20.0D * this.random.nextDouble(1.0D, 1.0D + 0.5D * level)), 3, false, true));
/*    */               }
/*    */             });
/*    */       } }
/*    */   
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void initialize(JavaPlugin plugin) {
/* 47 */     this.applySlowness = ((Boolean)registerConfigOption(plugin, "apply_slowness", Collections.singletonList("Apply Slowness when using Bane of Arthropods on players with the Arthropod ability"), ConfigManager.SettingType.BOOLEAN, Boolean.valueOf(true))).booleanValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\Arthropod.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */