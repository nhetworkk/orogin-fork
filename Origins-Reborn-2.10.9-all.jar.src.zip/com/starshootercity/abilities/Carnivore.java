/*    */ package com.starshootercity.abilities;
/*    */ 
/*    */ import com.starshootercity.OriginsReborn;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerItemConsumeEvent;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.bukkit.potion.PotionEffect;
/*    */ import org.bukkit.potion.PotionEffectType;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class Carnivore implements VisibleAbility, Listener {
/*    */   List<Material> meat;
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerItemConsume(PlayerItemConsumeEvent event) {
/* 25 */     if (event.getItem().getType() == Material.POTION)
/* 26 */       return;  runForAbility((Entity)event.getPlayer(), player -> {
/*    */           if (!this.meat.contains(event.getItem().getType())) {
/*    */             if (OriginsReborn.getMVE().getOminousBottle() != null && event.getItem().getType() == OriginsReborn.getMVE().getOminousBottle()) {
/*    */               return;
/*    */             }
/*    */             event.setCancelled(true);
/*    */             if (this.poison) {
/*    */               event.getItem().setAmount(event.getItem().getAmount() - 1);
/*    */               player.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 300, 1, false, true));
/*    */             } 
/*    */           } 
/*    */         });
/*    */   }
/*    */   
/*    */   private boolean poison;
/*    */   
/*    */   public String description() {
/* 43 */     return "Your diet is restricted to meat, you can't eat vegetables.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 48 */     return "Carnivore";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 53 */     return Key.key("origins:carnivore");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void initialize(JavaPlugin plugin) {
/* 60 */     this.poison = ((Boolean)registerConfigOption(plugin, "consume_and_poison", Collections.singletonList("Poison the player when consuming non-meat rather than preventing them from eating it"), ConfigManager.SettingType.BOOLEAN, Boolean.valueOf(false))).booleanValue();
/*    */     
/* 62 */     this.meat = (List<Material>)registerConfigOption(plugin, "meat", Collections.singletonList("Items that count as meat"), ConfigManager.SettingType.MATERIAL_LIST, List.of((Object[])new Material[] { Material.PORKCHOP, Material.COOKED_PORKCHOP, Material.BEEF, Material.COOKED_BEEF, Material.CHICKEN, Material.COOKED_CHICKEN, Material.RABBIT, Material.COOKED_RABBIT, Material.MUTTON, Material.COOKED_MUTTON, Material.RABBIT_STEW, Material.COD, Material.COOKED_COD, Material.TROPICAL_FISH, Material.SALMON, Material.COOKED_SALMON, Material.PUFFERFISH }));
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\Carnivore.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */