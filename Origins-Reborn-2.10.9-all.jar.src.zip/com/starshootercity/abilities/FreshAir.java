/*    */ package com.starshootercity.abilities;
/*    */ import com.starshootercity.OriginsReborn;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import java.util.Collections;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import net.kyori.adventure.text.Component;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Keyed;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.Tag;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerInteractEvent;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class FreshAir implements Listener, VisibleAbility {
/*    */   @EventHandler
/*    */   public void onPlayerInteract(PlayerInteractEvent event) {
/* 23 */     if (event.getClickedBlock() == null)
/* 24 */       return;  if (!event.getAction().isRightClick())
/* 25 */       return;  if (event
/* 26 */       .getPlayer().isSneaking() && event
/* 27 */       .getPlayer().getInventory().getItemInOffHand().getType() != Material.AIR && event
/* 28 */       .getPlayer().getInventory().getItemInMainHand().getType() != Material.AIR)
/*    */       return; 
/* 30 */     if (Tag.BEDS.isTagged((Keyed)event.getClickedBlock().getType()))
/* 31 */       runForAbility((Entity)event.getPlayer(), player -> {
/*    */             if (event.getClickedBlock().getY() < minHeight) {
/*    */               String overworld = OriginsReborn.getInstance().getConfig().getString("worlds.world");
/*    */               if (overworld == null) {
/*    */                 overworld = "world";
/*    */                 OriginsReborn.getInstance().getConfig().set("worlds.world", "world");
/*    */                 OriginsReborn.getInstance().saveConfig();
/*    */               } 
/*    */               boolean isInOverworld = (player.getWorld() == Bukkit.getWorld(overworld));
/*    */               if (!isInOverworld)
/*    */                 return; 
/*    */               if (event.getClickedBlock().getWorld().isDayTime() && event.getClickedBlock().getWorld().isClearWeather())
/*    */                 return; 
/*    */               event.setCancelled(true);
/*    */               player.swingMainHand();
/*    */               player.sendActionBar((Component)Component.text(translate("avian_sleep_fail")));
/*    */             } 
/*    */           }); 
/*    */   }
/*    */   public static int minHeight;
/*    */   @NotNull
/*    */   public Key getKey() {
/* 53 */     return Key.key("origins:fresh_air");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 58 */     return "When sleeping, your bed needs to be at an altitude of at least %s blocks, so you can breathe fresh air.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String modifyDescription(String description) {
/* 63 */     return description.formatted(new Object[] { Integer.valueOf(minHeight) });
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 68 */     return "Fresh Air";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void initialize(JavaPlugin plugin) {
/* 75 */     registerTranslation("avian_sleep_fail", "You need fresh air to sleep");
/* 76 */     minHeight = ((Integer)registerConfigOption(plugin, "minimum_altitude", Collections.singletonList("Minimum altitude the player can sleep at"), ConfigManager.SettingType.INTEGER, Integer.valueOf(86))).intValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\abilities\FreshAir.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */