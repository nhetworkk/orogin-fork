/*    */ package com.starshootercity.commands;
/*    */ 
/*    */ import com.starshootercity.OriginsReborn;
/*    */ import com.starshootercity.util.WorldGuardHook;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import net.kyori.adventure.text.Component;
/*    */ import net.kyori.adventure.text.format.NamedTextColor;
/*    */ import net.kyori.adventure.text.format.TextColor;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class FlightToggleCommand
/*    */   implements CommandExecutor {
/* 18 */   private static final Map<Player, Boolean> canFly = new HashMap<>();
/*    */   
/*    */   public static boolean canFly(Player player) {
/* 21 */     if (OriginsReborn.isWorldGuardHookInitialized() && 
/* 22 */       WorldGuardHook.isFlightDisabled(player.getLocation())) return false;
/*    */     
/* 24 */     return ((Boolean)canFly.getOrDefault(player, Boolean.valueOf(false))).booleanValue();
/*    */   }
/*    */   
/*    */   public static void setCanFly(Player player, boolean b) {
/* 28 */     canFly.put(player, Boolean.valueOf(b));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
/* 33 */     if (sender instanceof Player) { Player player = (Player)sender;
/* 34 */       if (canFly(player)) {
/* 35 */         setCanFly(player, false);
/* 36 */         player.sendMessage(Component.text("Disabled flight").color((TextColor)NamedTextColor.AQUA));
/*    */       } else {
/* 38 */         setCanFly(player, true);
/* 39 */         player.sendMessage(Component.text("Enabled flight").color((TextColor)NamedTextColor.AQUA));
/*    */       }  }
/* 41 */     else { sender.sendMessage(Component.text("This command can only be used by players!").color((TextColor)NamedTextColor.RED)); }
/* 42 */      return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\commands\FlightToggleCommand.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */