/*    */ package com.starshootercity.commands;
/*    */ import net.kyori.adventure.text.Component;
/*    */ import net.kyori.adventure.text.ComponentLike;
/*    */ import net.kyori.adventure.text.TextComponent;
/*    */ import net.kyori.adventure.text.event.ClickEvent;
/*    */ import net.kyori.adventure.text.format.NamedTextColor;
/*    */ import net.kyori.adventure.text.format.TextColor;
/*    */ import net.kyori.adventure.text.format.TextDecoration;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class DiscordCommand implements CommandExecutor {
/*    */   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
/* 16 */     sendURL(sender);
/* 17 */     return true;
/*    */   }
/*    */   
/*    */   public static void sendURL(CommandSender sender) {
/* 21 */     String discordURL = "https://discord.gg/PyH6uGBTFG";
/* 22 */     sender.sendMessage((ComponentLike)Component.text().append(((TextComponent)Component.text(discordURL).color((TextColor)NamedTextColor.AQUA)).decorate(TextDecoration.UNDERLINED).clickEvent(ClickEvent.openUrl(discordURL))));
/* 23 */     sender.sendMessage(Component.text("Note: This discord server is specifically for help with the Origins-Reborn plugin").color((TextColor)NamedTextColor.AQUA));
/* 24 */     sender.sendMessage(Component.text("It is NOT for the Minecraft server you are currently playing on").color((TextColor)NamedTextColor.AQUA));
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\commands\DiscordCommand.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */