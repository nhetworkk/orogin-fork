/*     */ package com.starshootercity;
/*     */ 
/*     */ import com.starshootercity.abilities.types.Ability;
/*     */ import com.starshootercity.abilities.types.MultiAbility;
/*     */ import com.starshootercity.abilities.types.VisibleAbility;
/*     */ import com.starshootercity.util.AbilityRegister;
/*     */ import com.starshootercity.util.config.ConfigManager;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Stream;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import net.kyori.adventure.text.Component;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.scoreboard.Scoreboard;
/*     */ import org.bukkit.scoreboard.Team;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ @APITarget
/*     */ public class Origin {
/*     */   private final ItemStack icon;
/*     */   private final int position;
/*     */   private final char impact;
/*     */   private final String name;
/*     */   @NotNull
/*     */   private final String displayName;
/*     */   private final int priority;
/*     */   private final String unchoosable;
/*     */   private final OriginsAddon addon;
/*     */   private final List<Key> abilityKeys;
/*  33 */   private List<Ability> abilities = null;
/*     */   
/*     */   private final String description;
/*     */   private final String permission;
/*     */   private final Integer cost;
/*     */   private final int max;
/*     */   private final String layer;
/*     */   private final Team team;
/*     */   
/*     */   public Integer getCost() {
/*  43 */     return this.cost;
/*     */   }
/*     */   
/*     */   public boolean isUnchoosable(Player player) {
/*  47 */     return isUnchoosable(player, false);
/*     */   }
/*     */   
/*     */   public boolean isUnchoosable(Player player, boolean random) {
/*  51 */     if (this.unchoosable.equals("true")) return true; 
/*  52 */     if (!random && this.unchoosable.equals("random")) return true; 
/*  53 */     String mode = (String)ConfigManager.getConfigValue(ConfigManager.Option.REUSING_ORIGINS);
/*  54 */     boolean same = ((Boolean)ConfigManager.getConfigValue(ConfigManager.Option.PREVENT_SAME_ORIGINS)).booleanValue();
/*  55 */     if (this.max != -1) {
/*  56 */       int num = 0;
/*  57 */       for (String p : OriginSwapper.getOriginFileConfiguration().getKeys(false)) {
/*  58 */         if (OriginSwapper.getOriginFileConfiguration().getString(p + "." + p, "").equals(getName().toLowerCase())) {
/*  59 */           num++;
/*     */         }
/*     */       } 
/*  62 */       if (num >= this.max) return true; 
/*     */     } 
/*  64 */     if (same) {
/*  65 */       for (String p : OriginSwapper.getOriginFileConfiguration().getKeys(false)) {
/*  66 */         if (OriginSwapper.getOriginFileConfiguration().getString(p + "." + p, "").equals(getName().toLowerCase())) {
/*  67 */           return true;
/*     */         }
/*     */       } 
/*     */     }
/*  71 */     if (mode.equals("PERPLAYER"))
/*  72 */       return OriginSwapper.getUsedOriginFileConfiguration().getStringList(player.getUniqueId().toString()).contains(getName().toLowerCase()); 
/*  73 */     if (mode.equals("ALL")) {
/*  74 */       for (String p : OriginSwapper.getUsedOriginFileConfiguration().getKeys(false)) {
/*  75 */         if (OriginSwapper.getUsedOriginFileConfiguration().getStringList(p).contains(getName().toLowerCase())) {
/*  76 */           return true;
/*     */         }
/*     */       } 
/*     */     }
/*  80 */     return false;
/*     */   }
/*     */   
/*     */   public int getPriority() {
/*  84 */     return this.priority;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Team getTeam() {
/*  90 */     return this.team;
/*     */   }
/*     */   
/*     */   public String getPermission() {
/*  94 */     return this.permission;
/*     */   }
/*     */   
/*     */   public boolean hasPermission() {
/*  98 */     return (this.permission != null);
/*     */   }
/*     */   
/*     */   public String getLayer() {
/* 102 */     return this.layer;
/*     */   }
/*     */   
/*     */   public String getNameForDisplay() {
/* 106 */     return this.displayName;
/*     */   }
/*     */   
/*     */   static {
/* 110 */     Translator.registerTranslation("team_format", "§7[§r%s§7] ");
/*     */   }
/*     */   
/*     */   public Origin(String name, ItemStack icon, int position, int impact, @NotNull String displayName, List<Key> abilities, String description, OriginsAddon addon, String unchoosable, int priority, String permission, Integer cost, int max, String layer) {
/* 114 */     this.displayName = displayName;
/* 115 */     this.description = description;
/* 116 */     this.name = name;
/* 117 */     this.permission = permission;
/* 118 */     this.cost = cost;
/* 119 */     this.max = max;
/* 120 */     this.layer = layer;
/* 121 */     if (((Boolean)ConfigManager.getConfigValue(ConfigManager.Option.DISPLAY_ENABLE_PREFIXES)).booleanValue())
/* 122 */     { Scoreboard scoreboard = Bukkit.getScoreboardManager().getMainScoreboard();
/* 123 */       Team oldTeam = scoreboard.getTeam(name);
/* 124 */       if (oldTeam != null) oldTeam.unregister(); 
/* 125 */       this.team = scoreboard.registerNewTeam(name);
/* 126 */       this.team.displayName((Component)Component.text(Translator.translate("team_format").formatted(new Object[] { name }))); }
/* 127 */     else { this.team = null; }
/* 128 */      this.abilityKeys = abilities;
/* 129 */     this.icon = icon;
/* 130 */     this.position = position;
/* 131 */     this.unchoosable = unchoosable;
/* 132 */     switch (impact) { case 0: case 1: case 2: default: break; }  this
/*     */ 
/*     */ 
/*     */       
/* 136 */       .impact = '';
/*     */     
/* 138 */     this.addon = addon;
/* 139 */     this.priority = priority;
/*     */   }
/*     */   
/*     */   public List<VisibleAbility> getVisibleAbilities() {
/* 143 */     List<VisibleAbility> result = new ArrayList<>();
/* 144 */     for (Ability ability : getAbilities()) {
/* 145 */       if (ability instanceof VisibleAbility) { VisibleAbility visibleAbility = (VisibleAbility)ability;
/* 146 */         result.add(visibleAbility); }
/*     */     
/*     */     } 
/* 149 */     return result;
/*     */   }
/*     */   
/*     */   public OriginsAddon getAddon() {
/* 153 */     return this.addon;
/*     */   }
/*     */   
/*     */   public List<Ability> getAbilities() {
/* 157 */     if (this.abilities == null) {
/*     */       
/* 159 */       Objects.requireNonNull(AbilityRegister.abilityMap);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 166 */       this.abilities = this.abilityKeys.stream().map(AbilityRegister.abilityMap::get).flatMap(ability -> { if (ability instanceof MultiAbility) { MultiAbility multiAbility = (MultiAbility)ability; return Stream.concat(Stream.of(ability), multiAbility.getAbilities().stream()); }  return Stream.of(ability); }).toList();
/*     */     } 
/* 168 */     return this.abilities;
/*     */   }
/*     */   
/*     */   public boolean hasAbility(Ability ability) {
/* 172 */     return getAbilities().contains(ability);
/*     */   }
/*     */   
/*     */   public char getImpact() {
/* 176 */     return this.impact;
/*     */   }
/*     */   
/*     */   public int getPosition() {
/* 180 */     return this.position;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 184 */     return this.name;
/*     */   }
/*     */   
/*     */   public String getDescription() {
/* 188 */     return this.description;
/*     */   }
/*     */   
/*     */   public ItemStack getIcon() {
/* 192 */     return this.icon;
/*     */   }
/*     */   
/*     */   public String getResourceURL() {
/* 196 */     String key = this.icon.getType().getKey().value();
/* 197 */     return "https://assets.mcasset.cloud/1.21.4/assets/minecraft/textures/%s/%s.png".formatted(new Object[] { this.icon.getType().isBlock() ? "block" : "item", key });
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\Origin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */