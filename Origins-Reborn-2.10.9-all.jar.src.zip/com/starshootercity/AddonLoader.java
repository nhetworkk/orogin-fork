/*     */ package com.starshootercity;
/*     */ import com.starshootercity.events.PlayerSwapOriginEvent;
/*     */ import com.starshootercity.util.config.ConfigManager;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ import java.util.Scanner;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipInputStream;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.NamespacedKey;
/*     */ import org.bukkit.configuration.ConfigurationSection;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.json.JSONArray;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ public class AddonLoader {
/*  26 */   private static final List<Origin> origins = new ArrayList<>();
/*  27 */   private static final Map<String, Origin> originNameMap = new HashMap<>();
/*  28 */   private static final Map<String, Origin> originFileNameMap = new HashMap<>();
/*  29 */   public static final List<OriginsAddon> registeredAddons = new ArrayList<>();
/*  30 */   public static Map<String, List<File>> originFiles = new HashMap<>();
/*  31 */   public static List<String> layers = new ArrayList<>();
/*  32 */   public static Map<String, NamespacedKey> layerKeys = new HashMap<>();
/*     */   
/*  34 */   private static final Random random = new Random();
/*     */   @Nullable
/*     */   public static String getFirstUnselectedLayer(Player player) {
/*  37 */     for (String layer : layers) {
/*  38 */       if (OriginSwapper.getOrigin(player, layer) == null) return layer; 
/*     */     } 
/*  40 */     return null;
/*     */   }
/*     */   
/*     */   public static Origin getOrigin(String name) {
/*  44 */     return originNameMap.get(name);
/*     */   }
/*     */   
/*     */   public static Origin getOriginByFilename(String name) {
/*  48 */     return originFileNameMap.get(name);
/*     */   }
/*     */   
/*     */   public static List<Origin> getOrigins(String layer) {
/*  52 */     List<Origin> o = new ArrayList<>(origins);
/*  53 */     o.removeIf(or -> !or.getLayer().equals(layer));
/*  54 */     return o;
/*     */   }
/*     */   
/*     */   public static Origin getFirstOrigin(String layer) {
/*  58 */     return getOrigins(layer).get(0);
/*     */   }
/*     */   
/*     */   public static Origin getRandomOrigin(String layer) {
/*  62 */     List<Origin> o = getOrigins(layer);
/*  63 */     return o.get(random.nextInt(o.size()));
/*     */   }
/*     */   
/*     */   public static void register(OriginsAddon addon) {
/*  67 */     if (registeredAddons.contains(addon)) {
/*  68 */       registeredAddons.remove(addon);
/*  69 */       origins.removeIf(origin -> origin.getAddon().getNamespace().equals(addon.getNamespace()));
/*     */     } 
/*  71 */     registeredAddons.add(addon);
/*  72 */     loadOriginsFor(addon);
/*  73 */     if (addon.shouldAllowOriginSwapCommand() != null) allowOriginSwapChecks.add(addon.shouldAllowOriginSwapCommand()); 
/*  74 */     if (addon.shouldOpenSwapMenu() != null) openSwapMenuChecks.add(addon.shouldOpenSwapMenu()); 
/*  75 */     if (addon.getAbilityOverride() != null) abilityOverrideChecks.add(addon.getAbilityOverride()); 
/*  76 */     sortOrigins();
/*     */   }
/*     */   
/*     */   public static boolean shouldOpenSwapMenu(Player player, PlayerSwapOriginEvent.SwapReason reason) {
/*  80 */     for (OriginsAddon.SwapStateGetter getter : openSwapMenuChecks) {
/*  81 */       OriginsAddon.State v = getter.get(player, reason);
/*  82 */       if (v == OriginsAddon.State.DENY) return false; 
/*     */     } 
/*  84 */     return true;
/*     */   }
/*     */   
/*     */   public static boolean allowOriginSwapCommand(Player player) {
/*  88 */     boolean allowed = false;
/*  89 */     for (OriginsAddon.SwapStateGetter getter : allowOriginSwapChecks) {
/*  90 */       OriginsAddon.State v = getter.get(player, PlayerSwapOriginEvent.SwapReason.COMMAND);
/*  91 */       if (v == OriginsAddon.State.DENY) return false; 
/*  92 */       if (v == OriginsAddon.State.ALLOW) allowed = true; 
/*     */     } 
/*  94 */     return (allowed || player.hasPermission((String)ConfigManager.getConfigValue(ConfigManager.Option.SWAP_COMMAND_PERMISSION)));
/*     */   }
/*     */   
/*  97 */   public static final List<OriginsAddon.SwapStateGetter> allowOriginSwapChecks = new ArrayList<>();
/*  98 */   public static final List<OriginsAddon.SwapStateGetter> openSwapMenuChecks = new ArrayList<>();
/*  99 */   public static final List<OriginsAddon.KeyStateGetter> abilityOverrideChecks = new ArrayList<>(); private static final int BUFFER_SIZE = 4096;
/*     */   
/*     */   public static void reloadAddons() {
/* 102 */     origins.clear();
/* 103 */     originNameMap.clear();
/* 104 */     originFiles.clear();
/* 105 */     for (OriginsAddon addon : registeredAddons) {
/* 106 */       loadOriginsFor(addon);
/*     */     }
/* 108 */     sortOrigins();
/*     */   }
/*     */   
/*     */   public static void sortOrigins() {
/* 112 */     origins.sort((o1, o2) -> (o1.getImpact() == o2.getImpact()) ? ((o1.getPosition() == o2.getPosition()) ? 0 : ((o1.getPosition() > o2.getPosition()) ? 1 : -1)) : ((o1.getImpact() > o2.getImpact()) ? 1 : -1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void extractFile(ZipInputStream zipIn, String filePath) throws IOException {
/* 125 */     BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(filePath));
/* 126 */     byte[] bytesIn = new byte[4096];
/*     */     int read;
/* 128 */     while ((read = zipIn.read(bytesIn)) != -1) {
/* 129 */       bos.write(bytesIn, 0, read);
/*     */     }
/* 131 */     bos.close();
/*     */   }
/*     */   
/*     */   private static void loadOriginsFor(OriginsAddon addon) {
/* 135 */     List<File> addonFiles = new ArrayList<>();
/* 136 */     originFiles.put(addon.getNamespace(), addonFiles);
/* 137 */     File originFolder = new File(addon.getDataFolder(), "origins");
/* 138 */     if (!originFolder.exists()) {
/* 139 */       boolean ignored = originFolder.mkdirs(); 
/* 140 */       try { ZipInputStream inputStream = new ZipInputStream(new FileInputStream(addon.getFile())); 
/* 141 */         try { ZipEntry entry = inputStream.getNextEntry();
/* 142 */           while (entry != null) {
/* 143 */             if (entry.getName().startsWith("origins/") && entry.getName().endsWith(".json")) {
/* 144 */               extractFile(inputStream, originFolder.getParentFile().getAbsolutePath() + "/" + originFolder.getParentFile().getAbsolutePath());
/*     */             }
/* 146 */             entry = inputStream.getNextEntry();
/*     */           } 
/* 148 */           inputStream.close(); } catch (Throwable throwable) { try { inputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (IOException e)
/* 149 */       { throw new RuntimeException(e); }
/*     */     
/*     */     } 
/*     */     
/* 153 */     File[] files = originFolder.listFiles();
/* 154 */     if (files == null)
/* 155 */       return;  for (File file : files) {
/* 156 */       if (file.getName().endsWith(".json")) {
/* 157 */         addonFiles.add(file);
/*     */         try {
/* 159 */           loadOrigin(file, addon);
/* 160 */         } catch (Exception e) {
/* 161 */           addon.getLogger().severe("An error has occurred when loading the origin %s".formatted(new Object[] { file.getName() }));
/* 162 */           addon.getLogger().severe("Check that the json file is formatted correctly, and has all required settings listed at https://starshooter.gitbook.io/origins-reborn/custom-origins");
/* 163 */           addon.getLogger().severe("Join the Discord server at /origin discord for more help");
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   private static void sortLayers() {
/* 169 */     Map<String, Integer> data = (Map<String, Integer>)ConfigManager.getConfigValue(ConfigManager.Option.ORIGIN_SELECTION_LAYER_ORDERS);
/* 170 */     layers.sort((o1, o2) -> {
/*     */           int a1 = ((Integer)data.get(o1)).intValue();
/*     */           int a2 = ((Integer)data.get(o2)).intValue();
/*     */           return a1 - a2;
/*     */         });
/*     */   }
/*     */   
/*     */   public static void registerLayer(String layer, int priority, OriginsAddon addon) {
/* 178 */     if (layers.contains(layer))
/* 179 */       return;  layers.add(layer);
/* 180 */     layerKeys.put(layer, new NamespacedKey((Plugin)addon, layer.toLowerCase().replace(" ", "_")));
/*     */     
/* 182 */     if (!OriginsReborn.getInstance().getConfig().contains("origin-selection.default-origin.%s".formatted(new Object[] { layer }))) {
/* 183 */       OriginsReborn.getInstance().getConfig().set("origin-selection.default-origin.%s".formatted(new Object[] { layer }, ), "NONE");
/* 184 */       OriginsReborn.getInstance().setComments("origin-selection.default-origin", List.of("Default origin, automatically gives players this origin rather than opening the GUI when the player has no origin", "Should be the name of the origin file without the ending, e.g. for 'origin_name.json' the value should be 'origin_name'", "Disabled if set to an invalid name such as \"NONE\""));
/* 185 */       OriginsReborn.getInstance().saveConfig();
/*     */     } 
/*     */     
/* 188 */     if (!OriginsReborn.getInstance().getConfig().contains("origin-selection.layer-orders.%s".formatted(new Object[] { layer }))) {
/* 189 */       OriginsReborn.getInstance().getConfig().set("origin-selection.layer-orders.%s".formatted(new Object[] { layer }, ), Integer.valueOf(priority));
/* 190 */       OriginsReborn.getInstance().setComments("origin-section.layer-orders", List.of("Priorities for different origin 'layers' to be selected in, higher priority layers are selected first."));
/* 191 */       OriginsReborn.getInstance().saveConfig();
/*     */     } 
/*     */     
/* 194 */     if (!OriginsReborn.getInstance().getConfig().contains("orb-of-origin.random.%s".formatted(new Object[] { layer }))) {
/* 195 */       OriginsReborn.getInstance().getConfig().set("orb-of-origin.random.%s".formatted(new Object[] { layer }, ), Boolean.valueOf(false));
/* 196 */       OriginsReborn.getInstance().setComments("orb-of-origin.random", List.of("Randomise origin instead of opening the selector upon using the orb"));
/* 197 */       OriginsReborn.getInstance().saveConfig();
/*     */     } 
/*     */     
/* 200 */     sortLayers();
/*     */     
/* 202 */     if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null)
/* 203 */       (new LayerPlaceholderExpansion(layer)).register(); 
/*     */   }
/*     */   
/*     */   private static JSONObject openJSONFile(File file) {
/*     */     
/* 208 */     try { Scanner scanner = new Scanner(file); 
/* 209 */       try { StringBuilder data = new StringBuilder();
/* 210 */         while (scanner.hasNextLine()) {
/* 211 */           data.append(scanner.nextLine());
/*     */         }
/*     */         
/* 214 */         try { JSONObject jSONObject = new JSONObject(data.toString());
/*     */ 
/*     */ 
/*     */           
/* 218 */           scanner.close(); return jSONObject; } catch (JSONException e) { JSONObject jSONObject = new JSONObject(); scanner.close(); return jSONObject; }  } catch (Throwable throwable) { try { scanner.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (IOException e)
/* 219 */     { throw new RuntimeException(e); }
/*     */      } public static void loadOrigin(File file, OriginsAddon addon) {
/*     */     String itemName;
/*     */     int max;
/*     */     String layer, displayName;
/* 224 */     if (!file.getName().toLowerCase().equals(file.getName())) {
/* 225 */       File lowercaseFile = new File(file.getParentFile(), file.getName().toLowerCase());
/* 226 */       if (!file.renameTo(lowercaseFile)) {
/* 227 */         OriginsReborn.getInstance().getLogger().warning("Origin %s failed to load - make sure file name is lowercase".formatted(new Object[] { file.getName() }));
/*     */         return;
/*     */       } 
/* 230 */       file = lowercaseFile;
/*     */     } 
/* 232 */     final JSONObject object = openJSONFile(file);
/* 233 */     String unchoosable = "false";
/* 234 */     if (object.has("unchoosable")) {
/* 235 */       unchoosable = String.valueOf(object.get("unchoosable"));
/*     */     }
/*     */     
/* 238 */     int cmd = 0;
/* 239 */     Object object1 = object.get("icon"); if (object1 instanceof JSONObject) { JSONObject jsonObject = (JSONObject)object1;
/* 240 */       itemName = jsonObject.getString("item");
/* 241 */       if (jsonObject.has("custom_model_data"))
/* 242 */         cmd = jsonObject.getInt("custom_model_data");  }
/*     */     else
/* 244 */     { itemName = object.getString("icon"); }
/* 245 */      Material material = Material.matchMaterial(itemName);
/* 246 */     if (material == null) {
/* 247 */       material = Material.AIR;
/*     */     }
/* 249 */     ItemStack icon = new ItemStack(material);
/* 250 */     ItemMeta meta = icon.getItemMeta();
/* 251 */     meta = OriginsReborn.getMVE().setCustomModelData(meta, cmd);
/* 252 */     icon.setItemMeta(meta);
/* 253 */     String name = file.getName().split("\\.")[0];
/* 254 */     StringBuilder formattedName = new StringBuilder();
/* 255 */     String[] parts = name.split("_");
/* 256 */     int num = 0;
/* 257 */     for (String part : parts) {
/* 258 */       formattedName.append(part.substring(0, 1).toUpperCase()).append(part.substring(1));
/* 259 */       num++;
/* 260 */       if (num < parts.length) formattedName.append(" "); 
/*     */     } 
/* 262 */     String permission = null;
/* 263 */     Integer cost = null;
/*     */     
/* 265 */     if (object.has("max"))
/* 266 */     { max = object.getInt("max"); }
/* 267 */     else { max = ((Integer)ConfigManager.getConfigValue(ConfigManager.Option.MAX_SAME_ORIGIN)).intValue(); }
/*     */     
/* 269 */     if (object.has("layer")) { layer = object.getString("layer"); }
/* 270 */     else { layer = "origin"; }
/* 271 */      if (object.has("permission")) permission = object.getString("permission"); 
/* 272 */     if (object.has("cost")) cost = Integer.valueOf(object.getInt("cost")); 
/* 273 */     int extraLayerPriority = 0;
/* 274 */     ConfigurationSection cs = OriginsReborn.getInstance().getConfig().getConfigurationSection("origin-selection.layers");
/* 275 */     if (cs != null) for (String s : cs.getValues(false).keySet()) {
/* 276 */         extraLayerPriority = Math.min(extraLayerPriority, cs.getInt(s) - 1);
/*     */       } 
/* 278 */     registerLayer(layer, extraLayerPriority, addon);
/*     */     
/* 280 */     if (object.has("name")) { displayName = object.getString("name"); }
/* 281 */     else { displayName = formattedName.toString(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 289 */     Origin origin = new Origin(formattedName.toString(), icon, object.getInt("order"), object.getInt("impact"), displayName, new ArrayList<Key>() {  }, object.getString("description"), addon, unchoosable, object.has("priority") ? object.getInt("priority") : 1, permission, cost, max, layer);
/* 290 */     String actualName = origin.getName().toLowerCase();
/* 291 */     Origin previouslyRegisteredOrigin = originNameMap.get(name.replace("_", " "));
/* 292 */     if (previouslyRegisteredOrigin != null) {
/* 293 */       if (previouslyRegisteredOrigin.getPriority() > origin.getPriority()) {
/*     */         return;
/*     */       }
/* 296 */       origins.remove(previouslyRegisteredOrigin);
/* 297 */       originNameMap.remove(name.replace("_", " "));
/* 298 */       originFileNameMap.remove(actualName);
/*     */     } 
/*     */     
/* 301 */     origins.add(origin);
/* 302 */     originNameMap.put(name.replace("_", " "), origin);
/* 303 */     originFileNameMap.put(actualName, origin);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static Origin getDefaultOrigin(String layer) {
/* 310 */     String originName = OriginsReborn.getInstance().getConfig().getString("origin-selection.default-origin.%s".formatted(new Object[] { layer }, ), "NONE");
/* 311 */     return originFileNameMap.getOrDefault(originName.replace("_", " "), null);
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Reborn-2.10.9-all.jar!\com\starshootercity\AddonLoader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */