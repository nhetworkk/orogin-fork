/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ import com.starshootercity.OriginsReborn;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityShootBowEvent;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class PoorShot implements VisibleAbility, Listener {
/*    */   public String description() {
/* 14 */     return "Your big hands are clumsy with a bow, so your arrows are slow and not very accurate.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 19 */     return "Clumsy Shot";
/*    */   }
/*    */   @NotNull
/*    */   public Key getKey() {
/* 23 */     return Key.key("fantasyorigins:poor_shot");
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onEntityShootBow(EntityShootBowEvent event) {
/* 28 */     runForAbility((Entity)event.getEntity(), player -> OriginsReborn.getMVE().launchArrow(event.getProjectile(), (Entity)player, 0.0F, event.getForce(), 2.4F));
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\PoorShot.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */