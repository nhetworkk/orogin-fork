/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.version.MVAttribute;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.attribute.AttributeInstance;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityDeathEvent;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class Leeching implements VisibleAbility, Listener {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 15 */     return Key.key("fantasyorigins:leeching");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 20 */     return "Upon killing a mob or player, you sap a portion of its health, healing you.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 25 */     return "Leeching";
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onEntityDeath(EntityDeathEvent event) {
/* 30 */     runForAbility((Entity)event.getEntity().getKiller(), player -> {
/*    */           AttributeInstance mH = player.getAttribute(MVAttribute.MAX_HEALTH.get());
/*    */           if (mH == null)
/*    */             return; 
/*    */           double maxHealth = mH.getValue();
/*    */           AttributeInstance mobMH = event.getEntity().getAttribute(MVAttribute.MAX_HEALTH.get());
/*    */           if (mobMH == null)
/*    */             return; 
/*    */           double mobMaxHealth = mobMH.getValue();
/*    */           player.setHealth(Math.min(maxHealth, player.getHealth() + mobMaxHealth / 5.0D));
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\Leeching.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */