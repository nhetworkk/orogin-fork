/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.AttributeModifierAbility;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.version.MVAttribute;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.attribute.Attribute;
/*    */ import org.bukkit.attribute.AttributeModifier;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class Elegy
/*    */   implements VisibleAbility, AttributeModifierAbility {
/*    */   public String description() {
/* 15 */     return "You become stronger when at less than 3 hearts.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 20 */     return "Elegy";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 25 */     return Key.key("fantasyorigins:elegy");
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Attribute getAttribute() {
/* 30 */     return MVAttribute.ATTACK_DAMAGE.get();
/*    */   }
/*    */ 
/*    */   
/*    */   public AttributeModifier.Operation getOperation() {
/* 35 */     return AttributeModifier.Operation.MULTIPLY_SCALAR_1;
/*    */   }
/*    */ 
/*    */   
/*    */   public double getAmount(Player player) {
/* 40 */     return (player.getHealth() <= 6.0D) ? 2.0D : 0.0D;
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\Elegy.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */