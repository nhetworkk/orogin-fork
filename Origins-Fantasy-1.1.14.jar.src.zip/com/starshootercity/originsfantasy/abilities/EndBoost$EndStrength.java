/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.AttributeModifierAbility;
/*    */ import com.starshootercity.version.MVAttribute;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.attribute.Attribute;
/*    */ import org.bukkit.attribute.AttributeModifier;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EndStrength
/*    */   implements AttributeModifierAbility
/*    */ {
/* 39 */   public static EndStrength endStrength = new EndStrength();
/*    */   
/*    */   @NotNull
/*    */   public Attribute getAttribute() {
/* 43 */     return MVAttribute.ATTACK_DAMAGE.get();
/*    */   }
/*    */ 
/*    */   
/*    */   public double getAmount(Player player) {
/* 48 */     return (player.getWorld().getEnvironment() == World.Environment.THE_END) ? 1.6D : 0.0D;
/*    */   }
/*    */ 
/*    */   
/*    */   public AttributeModifier.Operation getOperation() {
/* 53 */     return AttributeModifier.Operation.MULTIPLY_SCALAR_1;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 58 */     return Key.key("fantasyorigins:end_strength");
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\EndBoost$EndStrength.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */