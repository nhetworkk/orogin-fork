/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*    */ import org.bukkit.event.entity.EntityDamageEvent;
/*    */ import org.bukkit.event.entity.EntityPotionEffectEvent;
/*    */ import org.bukkit.potion.PotionEffectType;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class MagicResistance
/*    */   implements VisibleAbility, Listener {
/*    */   public String description() {
/* 17 */     return "You have an immunity to poison and harming potion effects.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 22 */     return "Iron Stomach";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 27 */     return Key.key("fantasyorigins:magic_resistance");
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onEntityDamage(EntityDamageEvent event) {
/* 32 */     if (event instanceof EntityDamageByEntityEvent) { EntityDamageByEntityEvent ev = (EntityDamageByEntityEvent)event;
/* 33 */       if (!(ev.getDamager() instanceof org.bukkit.entity.Projectile))
/*    */         return;  }
/* 35 */      runForAbility(event.getEntity(), player -> {
/*    */           if (event.getCause().equals(EntityDamageEvent.DamageCause.MAGIC))
/*    */             event.setCancelled(true); 
/*    */         });
/*    */   }
/*    */   @EventHandler
/*    */   public void onEntityPotionEffect(EntityPotionEffectEvent event) {
/* 42 */     if (event.getNewEffect() == null)
/* 43 */       return;  runForAbility(event.getEntity(), player -> {
/*    */           if (event.getNewEffect().getType().equals(PotionEffectType.POISON))
/*    */             event.setCancelled(true); 
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\MagicResistance.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */