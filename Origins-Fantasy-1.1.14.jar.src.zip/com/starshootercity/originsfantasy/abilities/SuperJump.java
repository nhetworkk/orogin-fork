/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class SuperJump
/*    */   implements VisibleAbility {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 11 */     return Key.key("fantasyorigins:super_jump");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 16 */     return "You've trained for your whole life, so can jump much higher than a regular horse.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 21 */     return "Powerful Jump";
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\SuperJump.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */