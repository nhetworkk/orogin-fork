/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.AttributeModifierAbility;
/*    */ import com.starshootercity.version.MVAttribute;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.attribute.Attribute;
/*    */ import org.bukkit.attribute.AttributeModifier;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WaterHealth
/*    */   implements AttributeModifierAbility
/*    */ {
/* 38 */   public static WaterHealth waterHealth = new WaterHealth();
/*    */   
/*    */   @NotNull
/*    */   public Attribute getAttribute() {
/* 42 */     return MVAttribute.MAX_HEALTH.get();
/*    */   }
/*    */ 
/*    */   
/*    */   public double getAmount(Player player) {
/* 47 */     if (player.isInWaterOrRainOrBubbleColumn()) {
/* 48 */       return 4.0D;
/*    */     }
/* 50 */     return 0.0D;
/*    */   }
/*    */ 
/*    */   
/*    */   public AttributeModifier.Operation getOperation() {
/* 55 */     return AttributeModifier.Operation.ADD_NUMBER;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 60 */     return Key.key("fantasyorigins:water_health");
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\OceansGrace$WaterHealth.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */