/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ import com.destroystokyo.paper.event.server.ServerTickEndEvent;
/*    */ import com.starshootercity.OriginsAddon;
/*    */ import com.starshootercity.OriginsReborn;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.originsfantasy.OriginsFantasy;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.LivingEntity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class WaterSensitive implements VisibleAbility, Listener {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 23 */     return Key.key("fantasyorigins:water_sensitive");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 28 */     return "You are hurt by water as its current drains your power.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 33 */     return "Water Sensitive";
/*    */   }
/*    */ 
/*    */   
/*    */   @EventHandler
/*    */   public void onServerTickEnd(ServerTickEndEvent event) {
/* 39 */     for (Player p : Bukkit.getOnlinePlayers()) {
/* 40 */       if (Bukkit.getCurrentTick() - ((Integer)this.lastWaterDamagedMap.getOrDefault(p, (V)Integer.valueOf(Bukkit.getCurrentTick() - 20))).intValue() < 20)
/* 41 */         continue;  runForAbility((Entity)p, player -> {
/*    */             if (player.isInWaterOrRainOrBubbleColumn() || OriginsReborn.getMVE().wasTouchingWater(player)) {
/*    */               OriginsReborn.getMVE().dealFreezeDamage((LivingEntity)player, ((Integer)getConfigOption((OriginsAddon)OriginsFantasy.getInstance(), "damage_amount", ConfigManager.SettingType.INTEGER)).intValue());
/*    */               this.lastWaterDamagedMap.put(player, Integer.valueOf(Bukkit.getCurrentTick()));
/*    */             } 
/*    */           });
/*    */     } 
/*    */   }
/*    */   
/* 50 */   private final String damageAmount = "damage_amount";
/*    */ 
/*    */   
/*    */   public void initialize(JavaPlugin plugin) {
/* 54 */     registerConfigOption((OriginsAddon)OriginsFantasy.getInstance(), "damage_amount", Collections.singletonList("Amount to damage the player by"), ConfigManager.SettingType.INTEGER, Integer.valueOf(1));
/*    */   }
/*    */   
/* 57 */   private final Map<Player, Integer> lastWaterDamagedMap = new HashMap<>();
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\WaterSensitive.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */