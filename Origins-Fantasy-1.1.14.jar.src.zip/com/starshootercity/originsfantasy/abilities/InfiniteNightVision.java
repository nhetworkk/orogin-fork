/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ 
/*    */ import com.destroystokyo.paper.event.server.ServerTickEndEvent;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.potion.PotionEffect;
/*    */ import org.bukkit.potion.PotionEffectType;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class InfiniteNightVision implements VisibleAbility, Listener {
/*    */   public String description() {
/* 17 */     return "You can see in the dark after generations of evolution.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 22 */     return "Dark Eyes";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 27 */     return Key.key("fantasyorigins:infinite_night_vision");
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onServerTickEnd(ServerTickEndEvent event) {
/* 32 */     if (event.getTickNumber() % 15 != 0)
/* 33 */       return;  for (Player p : Bukkit.getOnlinePlayers())
/* 34 */       runForAbility((Entity)p, player -> player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, 300, 0))); 
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\InfiniteNightVision.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */