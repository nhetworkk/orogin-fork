/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.AttributeModifierAbility;
/*    */ import com.starshootercity.version.MVAttribute;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.attribute.Attribute;
/*    */ import org.bukkit.attribute.AttributeModifier;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LandWeakness
/*    */   implements AttributeModifierAbility
/*    */ {
/* 38 */   public static LandWeakness landWeakness = new LandWeakness();
/*    */   
/*    */   @NotNull
/*    */   public Attribute getAttribute() {
/* 42 */     return MVAttribute.ATTACK_DAMAGE.get();
/*    */   }
/*    */ 
/*    */   
/*    */   public double getAmount(Player player) {
/* 47 */     return -0.4D;
/*    */   }
/*    */ 
/*    */   
/*    */   public AttributeModifier.Operation getOperation() {
/* 52 */     return AttributeModifier.Operation.MULTIPLY_SCALAR_1;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 57 */     return Key.key("fantasyorigins:land_weakness");
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\OceanWish$LandWeakness.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */