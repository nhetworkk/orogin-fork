/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.AttributeModifierAbility;
/*    */ import com.starshootercity.version.MVAttribute;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.attribute.Attribute;
/*    */ import org.bukkit.attribute.AttributeModifier;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LandHealth
/*    */   implements AttributeModifierAbility
/*    */ {
/* 62 */   public static LandHealth landHealth = new LandHealth();
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 66 */     return Key.key("fantasyorigins:land_health");
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Attribute getAttribute() {
/* 71 */     return MVAttribute.MAX_HEALTH.get();
/*    */   }
/*    */ 
/*    */   
/*    */   public double getAmount(Player player) {
/* 76 */     if (player.isInWaterOrRainOrBubbleColumn()) {
/* 77 */       return 0.0D;
/*    */     }
/* 79 */     return -12.0D;
/*    */   }
/*    */ 
/*    */   
/*    */   public AttributeModifier.Operation getOperation() {
/* 84 */     return AttributeModifier.Operation.ADD_NUMBER;
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\OceanWish$LandHealth.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */