/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import java.util.List;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityDamageEvent;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class FireResistant
/*    */   implements VisibleAbility, Listener {
/*    */   public String description() {
/* 15 */     return "Your stone skin makes you immune to fire.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 20 */     return "Heat Resistant";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 25 */     return Key.key("fantasyorigins:fire_resistant");
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onEntityDamage(EntityDamageEvent event) {
/* 30 */     runForAbility(event.getEntity(), player -> {
/*    */           if (List.of(EntityDamageEvent.DamageCause.HOT_FLOOR, EntityDamageEvent.DamageCause.FIRE_TICK, EntityDamageEvent.DamageCause.FIRE, EntityDamageEvent.DamageCause.LAVA).contains(event.getCause()))
/*    */             event.setCancelled(true); 
/*    */           player.setFireTicks(0);
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\FireResistant.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */