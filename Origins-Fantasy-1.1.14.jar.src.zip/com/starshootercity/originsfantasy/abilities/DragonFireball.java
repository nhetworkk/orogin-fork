/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ import com.destroystokyo.paper.MaterialTags;
/*    */ import com.starshootercity.OriginsAddon;
/*    */ import com.starshootercity.abilities.types.Ability;
/*    */ import com.starshootercity.abilities.types.TriggerableAbility;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.originsfantasy.OriginsFantasy;
/*    */ import com.starshootercity.util.TriggerManager;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import java.util.Collections;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class DragonFireball implements VisibleAbility, Listener, TriggerableAbility {
/*    */   public String description() {
/* 22 */     return "You can right click whilst holding a sword to launch a dragon's fireball, with a cooldown of %s seconds.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String modifyDescription(String description) {
/* 27 */     return description.formatted(new Object[] { getConfigOption("cooldown_time", ConfigManager.SettingType.INTEGER) });
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 32 */     return "Dragon's Fireball";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 37 */     return Key.key("fantasyorigins:dragon_fireball");
/*    */   }
/*    */   
/* 40 */   private final String cooldownTime = "cooldown_time";
/* 41 */   private final String fireballVelocity = "fireball_velocity";
/*    */ 
/*    */   
/*    */   public void initialize(JavaPlugin plugin) {
/* 45 */     registerConfigOption((OriginsAddon)OriginsFantasy.getInstance(), "cooldown_time", Collections.singletonList("The cooldown in seconds between each fireball"), ConfigManager.SettingType.INTEGER, Integer.valueOf(30));
/* 46 */     registerConfigOption((OriginsAddon)OriginsFantasy.getInstance(), "fireball_velocity", Collections.singletonList("The velocity the fireball should be given"), ConfigManager.SettingType.FLOAT, Float.valueOf(1.2F));
/*    */   }
/*    */ 
/*    */   
/*    */   @NotNull
/*    */   public TriggerableAbility.Trigger getTrigger() {
/* 52 */     return TriggerableAbility.Trigger.builder(TriggerableAbility.TriggerType.RIGHT_CLICK, (Ability)this)
/* 53 */       .addConditions(new TriggerableAbility.Condition[] { TriggerableAbility.Condition.HOLDING_SWORD
/* 54 */         }).build(event -> {
/*    */           int cooldown;
/*    */           if (event.block() != null && event.block().getType().isInteractable())
/*    */             return; 
/*    */           Player player = event.player();
/*    */           if (MaterialTags.SWORDS.isTagged(player.getInventory().getItemInMainHand().getType())) {
/*    */             cooldown = player.getCooldown(player.getInventory().getItemInMainHand().getType());
/*    */           } else {
/*    */             cooldown = player.getCooldown(player.getInventory().getItemInOffHand().getType());
/*    */           } 
/*    */           if (cooldown > 0)
/*    */             return; 
/*    */           for (Material material : MaterialTags.SWORDS.getValues())
/*    */             player.setCooldown(material, ((Integer)getConfigOption((OriginsAddon)OriginsFantasy.getInstance(), "cooldown_time", ConfigManager.SettingType.INTEGER)).intValue() * 20); 
/*    */           org.bukkit.entity.DragonFireball fireball = (org.bukkit.entity.DragonFireball)player.launchProjectile(org.bukkit.entity.DragonFireball.class);
/*    */           Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)OriginsFantasy.getInstance(), ());
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\DragonFireball.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */