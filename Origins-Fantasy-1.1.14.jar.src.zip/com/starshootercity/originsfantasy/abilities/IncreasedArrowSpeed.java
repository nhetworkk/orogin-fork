/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ import com.starshootercity.OriginsAddon;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.originsfantasy.OriginsFantasy;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import java.util.Collections;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityShootBowEvent;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class IncreasedArrowSpeed implements VisibleAbility, Listener {
/*    */   public String description() {
/* 19 */     return "Arrows you shoot are twice as fast than ones shot by a regular human.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 24 */     return "Masterful Speed";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 29 */     return Key.key("fantasyorigins:increased_arrow_speed");
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onEntityShootBow(EntityShootBowEvent event) {
/* 34 */     double v = ((Double)getConfigOption((OriginsAddon)OriginsFantasy.getInstance(), "arrow_speed_multiplier", ConfigManager.SettingType.DOUBLE)).doubleValue();
/* 35 */     runForAbility((Entity)event.getEntity(), player -> Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)OriginsFantasy.getInstance(), ()));
/*    */   }
/*    */   
/* 38 */   private final String arrowSpeedMultiplier = "arrow_speed_multiplier";
/*    */ 
/*    */   
/*    */   public void initialize(JavaPlugin plugin) {
/* 42 */     registerConfigOption((OriginsAddon)OriginsFantasy.getInstance(), "arrow_speed_multiplier", Collections.singletonList("Multiplier for the arrow's velocity"), ConfigManager.SettingType.DOUBLE, Double.valueOf(2.0D));
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\IncreasedArrowSpeed.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */