/*     */ package com.starshootercity.originsfantasy.abilities;
/*     */ 
/*     */ import com.starshootercity.abilities.types.Ability;
/*     */ import com.starshootercity.abilities.types.AttributeModifierAbility;
/*     */ import com.starshootercity.abilities.types.MultiAbility;
/*     */ import com.starshootercity.abilities.types.VisibleAbility;
/*     */ import com.starshootercity.version.MVAttribute;
/*     */ import java.util.List;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import org.bukkit.attribute.Attribute;
/*     */ import org.bukkit.attribute.AttributeModifier;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ public class OceanWish
/*     */   implements VisibleAbility, MultiAbility
/*     */ {
/*     */   public String description() {
/*  19 */     return "Your natural habitat is the ocean, so you're much weaker when you're not in the water.";
/*     */   }
/*     */ 
/*     */   
/*     */   public String title() {
/*  24 */     return "Ocean Wish";
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Key getKey() {
/*  29 */     return Key.key("fantasyorigins:ocean_wish");
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Ability> getAbilities() {
/*  34 */     return List.of(LandSlowness.landSlowness, LandHealth.landHealth, LandWeakness.landWeakness);
/*     */   }
/*     */   
/*     */   public static class LandWeakness implements AttributeModifierAbility {
/*  38 */     public static LandWeakness landWeakness = new LandWeakness();
/*     */     
/*     */     @NotNull
/*     */     public Attribute getAttribute() {
/*  42 */       return MVAttribute.ATTACK_DAMAGE.get();
/*     */     }
/*     */ 
/*     */     
/*     */     public double getAmount(Player player) {
/*  47 */       return -0.4D;
/*     */     }
/*     */ 
/*     */     
/*     */     public AttributeModifier.Operation getOperation() {
/*  52 */       return AttributeModifier.Operation.MULTIPLY_SCALAR_1;
/*     */     }
/*     */     
/*     */     @NotNull
/*     */     public Key getKey() {
/*  57 */       return Key.key("fantasyorigins:land_weakness");
/*     */     }
/*     */   }
/*     */   
/*     */   public static class LandHealth implements AttributeModifierAbility {
/*  62 */     public static LandHealth landHealth = new LandHealth();
/*     */     
/*     */     @NotNull
/*     */     public Key getKey() {
/*  66 */       return Key.key("fantasyorigins:land_health");
/*     */     }
/*     */     
/*     */     @NotNull
/*     */     public Attribute getAttribute() {
/*  71 */       return MVAttribute.MAX_HEALTH.get();
/*     */     }
/*     */ 
/*     */     
/*     */     public double getAmount(Player player) {
/*  76 */       if (player.isInWaterOrRainOrBubbleColumn()) {
/*  77 */         return 0.0D;
/*     */       }
/*  79 */       return -12.0D;
/*     */     }
/*     */ 
/*     */     
/*     */     public AttributeModifier.Operation getOperation() {
/*  84 */       return AttributeModifier.Operation.ADD_NUMBER;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class LandSlowness implements AttributeModifierAbility {
/*  89 */     public static LandSlowness landSlowness = new LandSlowness();
/*     */     
/*     */     @NotNull
/*     */     public Key getKey() {
/*  93 */       return Key.key("fantasyorigins:land_slowness");
/*     */     }
/*     */     
/*     */     @NotNull
/*     */     public Attribute getAttribute() {
/*  98 */       return MVAttribute.MOVEMENT_SPEED.get();
/*     */     }
/*     */ 
/*     */     
/*     */     public double getAmount(Player player) {
/* 103 */       if (player.isInWaterOrRainOrBubbleColumn()) {
/* 104 */         return 0.0D;
/*     */       }
/* 106 */       return -0.4D;
/*     */     }
/*     */ 
/*     */     
/*     */     public AttributeModifier.Operation getOperation() {
/* 111 */       return AttributeModifier.Operation.MULTIPLY_SCALAR_1;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\OceanWish.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */