/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.AttributeModifierAbility;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.attribute.Attribute;
/*    */ import org.bukkit.attribute.AttributeModifier;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class SmallBody
/*    */   implements VisibleAbility, AttributeModifierAbility {
/*    */   private final Attribute scale;
/*    */   
/*    */   public SmallBody(Attribute scale) {
/* 16 */     this.scale = scale;
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 21 */     return "You're only one block tall, half as tall as a regular human.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 26 */     return "Small Body";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 31 */     return Key.key("fantasyorigins:small_body");
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Attribute getAttribute() {
/* 36 */     return this.scale;
/*    */   }
/*    */ 
/*    */   
/*    */   public double getAmount(Player player) {
/* 41 */     return -0.5D;
/*    */   }
/*    */ 
/*    */   
/*    */   public AttributeModifier.Operation getOperation() {
/* 46 */     return AttributeModifier.Operation.MULTIPLY_SCALAR_1;
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\SmallBody.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */