/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ 
/*    */ import com.destroystokyo.paper.event.server.ServerTickEndEvent;
/*    */ import com.starshootercity.OriginsAddon;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.originsfantasy.OriginsFantasy;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import com.starshootercity.version.MVPotionEffectType;
/*    */ import java.util.Collections;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.bukkit.potion.PotionEffect;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class InfiniteHaste implements VisibleAbility, Listener {
/*    */   public String description() {
/* 22 */     return "You're well trained in mining, so are much faster than a regular human.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 27 */     return "Fast Miner";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 32 */     return Key.key("fantasyorigins:infinite_haste");
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onServerTickEnd(ServerTickEndEvent event) {
/* 37 */     if (event.getTickNumber() % 20 != 0)
/* 38 */       return;  for (Player p : Bukkit.getOnlinePlayers()) {
/* 39 */       runForAbility((Entity)p, player -> player.addPotionEffect(new PotionEffect(MVPotionEffectType.HASTE.get(), 30, ((Integer)getConfigOption((OriginsAddon)OriginsFantasy.getInstance(), "effect_level", ConfigManager.SettingType.INTEGER)).intValue())));
/*    */     }
/*    */   }
/*    */ 
/*    */   
/* 44 */   private final String effectLevel = "effect_level";
/*    */ 
/*    */   
/*    */   public void initialize(JavaPlugin plugin) {
/* 48 */     registerConfigOption((OriginsAddon)OriginsFantasy.getInstance(), "effect_level", Collections.singletonList("Level of the effect"), ConfigManager.SettingType.INTEGER, Integer.valueOf(1));
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\InfiniteHaste.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */