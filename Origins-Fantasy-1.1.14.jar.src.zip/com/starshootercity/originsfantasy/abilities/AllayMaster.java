/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ import com.starshootercity.OriginsReborn;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Allay;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.LivingEntity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.player.PlayerInteractEntityEvent;
/*    */ import org.bukkit.inventory.EquipmentSlot;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class AllayMaster implements VisibleAbility, Listener {
/*    */   public String description() {
/* 18 */     return "Your musical aura allows you to breed allays without playing music.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 23 */     return "Allay Master";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 28 */     return Key.key("fantasyorigins:allay_master");
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerInteractEntity(PlayerInteractEntityEvent event) {
/* 33 */     runForAbility((Entity)event.getPlayer(), player -> {
/*    */           Entity patt0$temp = event.getRightClicked();
/*    */           if (patt0$temp instanceof Allay) {
/*    */             Allay allay = (Allay)patt0$temp;
/*    */             ItemStack item = player.getInventory().getItem(event.getHand());
/*    */             if (item.getType() != Material.AMETHYST_SHARD)
/*    */               return; 
/*    */             if (!OriginsReborn.getMVE().duplicateAllay((LivingEntity)allay))
/*    */               return; 
/*    */             event.setCancelled(true);
/*    */             item.setAmount(item.getAmount() - 1);
/*    */             if (event.getHand() == EquipmentSlot.HAND) {
/*    */               player.swingMainHand();
/*    */             } else {
/*    */               player.swingOffHand();
/*    */             } 
/*    */             player.getInventory().setItem(event.getHand(), item);
/*    */           } 
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\AllayMaster.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */