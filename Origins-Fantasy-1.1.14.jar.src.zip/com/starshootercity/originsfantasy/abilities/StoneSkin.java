/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.SkinChangingAbility;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import java.awt.image.BufferedImage;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ public class StoneSkin
/*    */   implements SkinChangingAbility, VisibleAbility
/*    */ {
/*    */   public void modifySkin(BufferedImage image, Player player) {
/* 15 */     for (int x = 0; x < image.getWidth(); x++) {
/* 16 */       for (int y = 0; y < image.getHeight(); y++) {
/* 17 */         image.setRGB(x, y, grayscale(image.getRGB(x, y)));
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   public int grayscale(int decimalRGB) {
/* 23 */     int a = decimalRGB >> 24 & 0xFF;
/* 24 */     int r = decimalRGB >> 16 & 0xFF;
/* 25 */     int g = decimalRGB >> 8 & 0xFF;
/* 26 */     int b = decimalRGB & 0xFF;
/*    */     
/* 28 */     int grayscale = (int)Math.min(255.0D, Math.max(0.0D, 0.299D * r + 0.587D * g + 0.114D * b));
/*    */     
/* 30 */     return a << 24 | grayscale << 16 | grayscale << 8 | grayscale;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 35 */     return Key.key("fantasyorigins:stone_skin");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 40 */     return "Your skin is made of a dull gray stone.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 45 */     return "Stone Skin";
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\StoneSkin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */