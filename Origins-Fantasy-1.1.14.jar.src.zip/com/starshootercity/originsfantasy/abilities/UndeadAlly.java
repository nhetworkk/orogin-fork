/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import io.papermc.paper.tag.EntityTags;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.LivingEntity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.entity.Projectile;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*    */ import org.bukkit.event.entity.EntityTargetLivingEntityEvent;
/*    */ import org.bukkit.projectiles.ProjectileSource;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class UndeadAlly implements VisibleAbility, Listener {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 23 */     return Key.key("fantasyorigins:undead_ally");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 28 */     return "As an undead monster, other undead creatures will not attack you unprovoked.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 33 */     return "Undead Ally";
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onEntityTargetLivingEntity(EntityTargetLivingEntityEvent event) {
/* 38 */     if (EntityTags.UNDEADS.isTagged((Keyed)event.getEntityType())) {
/* 39 */       LivingEntity livingEntity = event.getTarget(); if (livingEntity instanceof Player) { Player p = (Player)livingEntity;
/* 40 */         runForAbility((Entity)p, player -> {
/*    */               if (!((List)this.attackedEntities.getOrDefault(player, new ArrayList<>())).contains(event.getEntity())) {
/*    */                 event.setCancelled(true);
/*    */               }
/*    */             }); }
/*    */     
/*    */     } 
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
/*    */     Player player;
/* 52 */     Entity entity = event.getDamager(); if (entity instanceof Player) { Player p = (Player)entity; }
/* 53 */     else { entity = event.getDamager(); if (entity instanceof Projectile) { Projectile projectile = (Projectile)entity; ProjectileSource projectileSource = projectile.getShooter(); if (projectileSource instanceof Player) { Player p = (Player)projectileSource; } else { return; }  } else { return; }
/*    */        }
/* 55 */      List<Entity> playerHitEntities = this.attackedEntities.getOrDefault(player, new ArrayList<>());
/* 56 */     playerHitEntities.add(event.getEntity());
/* 57 */     this.attackedEntities.put(player, playerHitEntities);
/*    */   }
/*    */   
/* 60 */   private final Map<Player, List<Entity>> attackedEntities = new HashMap<>();
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\UndeadAlly.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */