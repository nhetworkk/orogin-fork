/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.AttributeModifierAbility;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.version.MVAttribute;
/*    */ import io.papermc.paper.world.MoonPhase;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.attribute.Attribute;
/*    */ import org.bukkit.attribute.AttributeModifier;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class MoonStrength
/*    */   implements VisibleAbility, AttributeModifierAbility {
/*    */   public String description() {
/* 16 */     return "You're a worshipper of the moon, so on nights with a full moon you're stronger than normal.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 21 */     return "Moon's Blessing";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 26 */     return Key.key("fantasyorigins:moon_strength");
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Attribute getAttribute() {
/* 31 */     return MVAttribute.ATTACK_DAMAGE.get();
/*    */   }
/*    */ 
/*    */   
/*    */   public double getAmount(Player player) {
/* 36 */     if (!player.getWorld().isDayTime() && player.getWorld().getMoonPhase() == MoonPhase.FULL_MOON) {
/* 37 */       return 2.4D;
/*    */     }
/* 39 */     return 0.0D;
/*    */   }
/*    */ 
/*    */   
/*    */   public AttributeModifier.Operation getOperation() {
/* 44 */     return AttributeModifier.Operation.MULTIPLY_SCALAR_1;
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\MoonStrength.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */