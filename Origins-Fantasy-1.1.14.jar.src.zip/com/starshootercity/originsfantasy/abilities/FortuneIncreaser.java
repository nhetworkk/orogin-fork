/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ import com.destroystokyo.paper.MaterialTags;
/*    */ import com.starshootercity.OriginsAddon;
/*    */ import com.starshootercity.originsfantasy.OriginsFantasy;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import com.starshootercity.version.MVEnchantment;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Item;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.block.BlockBreakEvent;
/*    */ import org.bukkit.event.block.BlockDropItemEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class FortuneIncreaser implements VisibleAbility, Listener {
/*    */   public String description() {
/* 26 */     return "Your care and mastery in the art of extracting minerals results in a much higher yield from ores than other creatures.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 31 */     return "Careful Miner";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 36 */     return Key.key("fantasyorigins:fortune_increaser");
/*    */   }
/*    */   
/*    */   @EventHandler(priority = EventPriority.LOWEST)
/*    */   public void onBlockDropItem(BlockDropItemEvent event) {
/* 41 */     if (!MaterialTags.ORES.isTagged(event.getBlockState().getType()))
/*    */       return; 
/* 43 */     if (event.getPlayer().getInventory().getItemInMainHand().getItemMeta() == null)
/* 44 */       return;  runForAbility((Entity)event.getPlayer(), player -> {
/*    */           List<ItemStack> items = new ArrayList<>(this.blocks.getOrDefault(player, List.of()));
/*    */           List<ItemStack> otherItems = new ArrayList<>();
/*    */           for (Item item : event.getItems()) {
/*    */             otherItems.add(item.getItemStack());
/*    */           }
/*    */           event.getItems().clear();
/*    */           for (ItemStack i : otherItems) {
/*    */             for (int itemIndex = 0; itemIndex < items.size(); itemIndex++) {
/*    */               ItemStack item = items.get(itemIndex);
/*    */               if (item.getAmount() != 0) {
/*    */                 if (i.getType().equals(item.getType()) && i.getItemMeta().equals(item.getItemMeta())) {
/*    */                   int amount = item.getAmount() - i.getAmount();
/*    */                   item.setAmount(Math.max(0, amount));
/*    */                 } 
/*    */                 items.set(itemIndex, item);
/*    */               } 
/*    */             } 
/*    */           } 
/*    */           items.addAll(otherItems);
/*    */           items.removeIf(());
/*    */           for (ItemStack item : items)
/*    */             event.getItems().add(event.getBlock().getWorld().dropItem(event.getBlock().getLocation().clone().add(0.5D, 0.0D, 0.5D), item)); 
/*    */         });
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onBlockBreak(BlockBreakEvent event) {
/* 72 */     if (!MaterialTags.ORES.isTagged(event.getBlock().getType()))
/*    */       return; 
/* 74 */     if (event.getPlayer().getGameMode().equals(GameMode.CREATIVE))
/* 75 */       return;  ItemStack i = event.getPlayer().getInventory().getItemInMainHand().clone();
/* 76 */     if (i.getItemMeta() == null)
/* 77 */       return;  i.addUnsafeEnchantment(MVEnchantment.FORTUNE.get(), i.getEnchantmentLevel(MVEnchantment.FORTUNE.get()) + ((Integer)getConfigOption((OriginsAddon)OriginsFantasy.getInstance(), "fortune_increase", ConfigManager.SettingType.INTEGER)).intValue());
/* 78 */     this.blocks.put(event.getPlayer(), event.getBlock().getDrops(i, (Entity)event.getPlayer()));
/*    */   }
/*    */   
/* 81 */   private final Map<Player, Collection<ItemStack>> blocks = new HashMap<>();
/*    */   
/* 83 */   private final String fortuneIncrease = "fortune_increase";
/*    */ 
/*    */   
/*    */   public void initialize(JavaPlugin plugin) {
/* 87 */     registerConfigOption((OriginsAddon)OriginsFantasy.getInstance(), "fortune_increase", Collections.singletonList("Level to increase Fortune by"), ConfigManager.SettingType.INTEGER, Integer.valueOf(2));
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\FortuneIncreaser.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */