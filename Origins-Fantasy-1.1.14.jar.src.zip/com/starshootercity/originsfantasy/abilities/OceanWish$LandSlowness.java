/*     */ package com.starshootercity.originsfantasy.abilities;
/*     */ 
/*     */ import com.starshootercity.abilities.types.AttributeModifierAbility;
/*     */ import com.starshootercity.version.MVAttribute;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import org.bukkit.attribute.Attribute;
/*     */ import org.bukkit.attribute.AttributeModifier;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LandSlowness
/*     */   implements AttributeModifierAbility
/*     */ {
/*  89 */   public static LandSlowness landSlowness = new LandSlowness();
/*     */   
/*     */   @NotNull
/*     */   public Key getKey() {
/*  93 */     return Key.key("fantasyorigins:land_slowness");
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Attribute getAttribute() {
/*  98 */     return MVAttribute.MOVEMENT_SPEED.get();
/*     */   }
/*     */ 
/*     */   
/*     */   public double getAmount(Player player) {
/* 103 */     if (player.isInWaterOrRainOrBubbleColumn()) {
/* 104 */       return 0.0D;
/*     */     }
/* 106 */     return -0.4D;
/*     */   }
/*     */ 
/*     */   
/*     */   public AttributeModifier.Operation getOperation() {
/* 111 */     return AttributeModifier.Operation.MULTIPLY_SCALAR_1;
/*     */   }
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\OceanWish$LandSlowness.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */