/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ 
/*    */ import com.destroystokyo.paper.event.server.ServerTickEndEvent;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import com.starshootercity.version.MVAttribute;
/*    */ import java.util.Collections;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.attribute.AttributeInstance;
/*    */ import org.bukkit.entity.EnderCrystal;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class EndCrystalHealing
/*    */   implements VisibleAbility, Listener
/*    */ {
/*    */   private int crystalRange;
/*    */   
/*    */   public String description() {
/* 25 */     return "You can regenerate health from nearby End Crystals.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 30 */     return "Crystal Healer";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 35 */     return Key.key("fantasyorigins:end_crystal_healing");
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onServerTickEnd(ServerTickEndEvent event) {
/* 40 */     if (event.getTickNumber() % 5 != 0)
/* 41 */       return;  for (Player p : Bukkit.getOnlinePlayers()) {
/* 42 */       if (p.isDead())
/* 43 */         continue;  runForAbility((Entity)p, player -> {
/*    */             for (Entity entity : player.getWorld().getNearbyEntitiesByType(EnderCrystal.class, player.getLocation(), (this.crystalRange + 64), (this.crystalRange + 64), (this.crystalRange + 64))) {
/*    */               if (entity instanceof EnderCrystal) {
/*    */                 EnderCrystal crystal = (EnderCrystal)entity;
/*    */                 if (entity.getLocation().distance(player.getLocation()) > this.crystalRange) {
/*    */                   if (crystal.getBeamTarget() != null && crystal.getBeamTarget().distance(player.getLocation()) < 12.0D) {
/*    */                     crystal.setBeamTarget(null);
/*    */                   }
/*    */                   continue;
/*    */                 } 
/*    */                 crystal.setBeamTarget(player.getLocation().clone().subtract(0.0D, 1.0D, 0.0D));
/*    */                 AttributeInstance maxHealthAttr = player.getAttribute(MVAttribute.MAX_HEALTH.get());
/*    */                 if (maxHealthAttr == null) {
/*    */                   return;
/*    */                 }
/*    */                 double maxHealth = maxHealthAttr.getValue();
/*    */                 player.setHealth(Math.min(maxHealth, player.getHealth() + 1.0D));
/*    */               } 
/*    */             } 
/*    */           });
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void initialize(JavaPlugin plugin) {
/* 68 */     this.crystalRange = ((Integer)registerConfigOption(plugin, "crystal_range", Collections.singletonList("Range the end crystal effect should be"), ConfigManager.SettingType.INTEGER, Integer.valueOf(48))).intValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\EndCrystalHealing.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */