/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.AttributeModifierAbility;
/*    */ import com.starshootercity.version.MVAttribute;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.attribute.Attribute;
/*    */ import org.bukkit.attribute.AttributeModifier;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IncreasedCooldown
/*    */   implements AttributeModifierAbility
/*    */ {
/* 63 */   public static IncreasedCooldown increasedCooldown = new IncreasedCooldown();
/*    */   
/*    */   @NotNull
/*    */   public Attribute getAttribute() {
/* 67 */     return MVAttribute.ATTACK_SPEED.get();
/*    */   }
/*    */ 
/*    */   
/*    */   public double getAmount(Player player) {
/* 72 */     return -0.4D;
/*    */   }
/*    */ 
/*    */   
/*    */   public AttributeModifier.Operation getOperation() {
/* 77 */     return AttributeModifier.Operation.MULTIPLY_SCALAR_1;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 82 */     return Key.key("fantasyorigins:increased_cooldown");
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\HeavyBlow$IncreasedCooldown.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */