/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ 
/*    */ import com.starshootercity.OriginSwapper;
/*    */ import com.starshootercity.OriginsAddon;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.events.PlayerSwapOriginEvent;
/*    */ import com.starshootercity.originsfantasy.OriginsFantasy;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import java.util.Collections;
/*    */ import java.util.Random;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import net.kyori.adventure.text.Component;
/*    */ import net.kyori.adventure.text.format.NamedTextColor;
/*    */ import net.kyori.adventure.text.format.TextColor;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.LivingEntity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityDeathEvent;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class VampiricTransformation implements VisibleAbility, Listener {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 27 */     return Key.key("fantasyorigins:vampiric_transformation");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 32 */     return "You can transform other players into vampires by killing them.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 37 */     return "Vampiric Transformation";
/*    */   }
/*    */   
/* 40 */   private final Random random = new Random();
/*    */   
/*    */   @EventHandler
/*    */   public void onEntityDeath(EntityDeathEvent event) {
/* 44 */     LivingEntity livingEntity = event.getEntity(); if (livingEntity instanceof Player) { Player player = (Player)livingEntity;
/* 45 */       if (event.getEntity().getKiller() == null)
/* 46 */         return;  runForAbility((Entity)event.getEntity().getKiller(), pl -> {
/*    */             if (this.random.nextDouble() <= ((Float)getConfigOption((OriginsAddon)OriginsFantasy.getInstance(), "transformation_chance", ConfigManager.SettingType.FLOAT)).floatValue()) {
/*    */               OriginSwapper.setOrigin(player, OriginSwapper.getOrigin(pl, "origin"), PlayerSwapOriginEvent.SwapReason.DIED, false, "origin");
/*    */               player.sendMessage(Component.text("You have transformed into a Vampire!").color((TextColor)NamedTextColor.RED));
/*    */             } 
/*    */           }); }
/*    */   
/*    */   }
/*    */   
/* 55 */   private final String transformChance = "transformation_chance";
/*    */ 
/*    */   
/*    */   public void initialize(JavaPlugin plugin) {
/* 59 */     registerConfigOption((OriginsAddon)OriginsFantasy.getInstance(), "transformation_chance", Collections.singletonList("Chance (between 0 and 1) a player will transform into a vampire when killed by one"), ConfigManager.SettingType.FLOAT, Float.valueOf(1.0F));
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\VampiricTransformation.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */