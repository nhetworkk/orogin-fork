/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ import com.starshootercity.OriginsAddon;
/*    */ import com.starshootercity.OriginsReborn;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.originsfantasy.OriginsFantasy;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import java.util.Collections;
/*    */ import java.util.ListIterator;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.AbstractArrow;
/*    */ import org.bukkit.entity.Arrow;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerInteractEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class BowBurst implements VisibleAbility, Listener {
/*    */   public String description() {
/* 24 */     return "By casting a spell on any regular arrow, you can instantly shoot %s arrows at once using only one, but this disables your bow for %s seconds.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String modifyDescription(String description) {
/* 29 */     return description.formatted(new Object[] { getConfigOption((OriginsAddon)OriginsFantasy.getInstance(), "arrow_count", ConfigManager.SettingType.INTEGER), getConfigOption((OriginsAddon)OriginsFantasy.getInstance(), "cooldown_time", ConfigManager.SettingType.INTEGER) });
/*    */   }
/*    */   
/* 32 */   private final String arrowCount = "arrow_count";
/* 33 */   private final String cooldownTime = "cooldown_time";
/*    */ 
/*    */   
/*    */   public void initialize(JavaPlugin plugin) {
/* 37 */     registerConfigOption((OriginsAddon)OriginsFantasy.getInstance(), "arrow_count", Collections.singletonList("The number of arrows to fire"), ConfigManager.SettingType.INTEGER, Integer.valueOf(3));
/* 38 */     registerConfigOption((OriginsAddon)OriginsFantasy.getInstance(), "cooldown_time", Collections.singletonList("The time in seconds to disable the bow for"), ConfigManager.SettingType.INTEGER, Integer.valueOf(7));
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 43 */     return "Bow Burst";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 48 */     return Key.key("fantasyorigins:bow_burst");
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerInteract(PlayerInteractEvent event) {
/* 53 */     if (!event.getAction().isLeftClick())
/* 54 */       return;  if (event.getItem() == null || event.getItem().getType() != Material.BOW)
/* 55 */       return;  if (event.getPlayer().getCooldown(Material.BOW) > 0)
/* 56 */       return;  runForAbility((Entity)event.getPlayer(), player -> {
/*    */           if (player.getInventory().contains(Material.ARROW)) {
/*    */             ItemStack it = null;
/*    */             ListIterator<ItemStack> listIterator = player.getInventory().iterator();
/*    */             while (listIterator.hasNext()) {
/*    */               ItemStack item = listIterator.next();
/*    */               if (item != null && item.getType() == Material.ARROW) {
/*    */                 item.setAmount(item.getAmount() - 1);
/*    */                 it = item;
/*    */                 break;
/*    */               } 
/*    */             } 
/*    */             player.setCooldown(Material.BOW, ((Integer)getConfigOption((OriginsAddon)OriginsFantasy.getInstance(), "cooldown_time", ConfigManager.SettingType.INTEGER)).intValue() * 20);
/*    */             int count = ((Integer)getConfigOption((OriginsAddon)OriginsFantasy.getInstance(), "arrow_count", ConfigManager.SettingType.INTEGER)).intValue();
/*    */             int divergence = 0;
/*    */             Arrow arrow = null;
/*    */             for (int i = 0; i < count; i++) {
/*    */               if (arrow != null)
/*    */                 arrow.setPickupStatus(AbstractArrow.PickupStatus.CREATIVE_ONLY); 
/*    */               arrow = (Arrow)player.launchProjectile(Arrow.class);
/*    */               OriginsReborn.getMVE().setArrow(arrow, it);
/*    */               OriginsReborn.getMVE().launchArrow((Entity)arrow, (Entity)player, 0.0F, 3.0F, divergence);
/*    */               divergence = 15;
/*    */             } 
/*    */           } 
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\BowBurst.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */