/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.Ability;
/*    */ import com.starshootercity.abilities.types.AttributeModifierAbility;
/*    */ import com.starshootercity.abilities.types.MultiAbility;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.version.MVAttribute;
/*    */ import java.util.List;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.attribute.Attribute;
/*    */ import org.bukkit.attribute.AttributeModifier;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class HeavyBlow
/*    */   implements VisibleAbility, MultiAbility
/*    */ {
/*    */   public String description() {
/* 19 */     return "Your attacks are stronger than humans, but you have a longer attack cooldown.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 24 */     return "Heavy Blow";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 29 */     return Key.key("fantasyorigins:heavy_blow");
/*    */   }
/*    */ 
/*    */   
/*    */   public List<Ability> getAbilities() {
/* 34 */     return List.of(IncreasedDamage.increasedDamage, IncreasedCooldown.increasedCooldown);
/*    */   }
/*    */   
/*    */   public static class IncreasedDamage
/*    */     implements AttributeModifierAbility {
/* 39 */     public static IncreasedDamage increasedDamage = new IncreasedDamage();
/*    */     
/*    */     @NotNull
/*    */     public Attribute getAttribute() {
/* 43 */       return MVAttribute.ATTACK_DAMAGE.get();
/*    */     }
/*    */ 
/*    */     
/*    */     public double getAmount(Player player) {
/* 48 */       return 1.2D;
/*    */     }
/*    */ 
/*    */     
/*    */     public AttributeModifier.Operation getOperation() {
/* 53 */       return AttributeModifier.Operation.MULTIPLY_SCALAR_1;
/*    */     }
/*    */     
/*    */     @NotNull
/*    */     public Key getKey() {
/* 58 */       return Key.key("fantasyorigins:increased_damage");
/*    */     }
/*    */   }
/*    */   
/*    */   public static class IncreasedCooldown implements AttributeModifierAbility {
/* 63 */     public static IncreasedCooldown increasedCooldown = new IncreasedCooldown();
/*    */     
/*    */     @NotNull
/*    */     public Attribute getAttribute() {
/* 67 */       return MVAttribute.ATTACK_SPEED.get();
/*    */     }
/*    */ 
/*    */     
/*    */     public double getAmount(Player player) {
/* 72 */       return -0.4D;
/*    */     }
/*    */ 
/*    */     
/*    */     public AttributeModifier.Operation getOperation() {
/* 77 */       return AttributeModifier.Operation.MULTIPLY_SCALAR_1;
/*    */     }
/*    */     
/*    */     @NotNull
/*    */     public Key getKey() {
/* 82 */       return Key.key("fantasyorigins:increased_cooldown");
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\HeavyBlow.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */