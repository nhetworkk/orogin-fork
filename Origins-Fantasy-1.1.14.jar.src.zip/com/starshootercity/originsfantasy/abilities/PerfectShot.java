/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ import com.starshootercity.OriginsReborn;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityShootBowEvent;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class PerfectShot implements VisibleAbility, Listener {
/*    */   public String description() {
/* 14 */     return "You've trained with a bow for many years, and you shoot your arrows perfectly straight.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 19 */     return "Skilled Archer";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 24 */     return Key.key("fantasyorigins:perfect_shot");
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onEntityShootBow(EntityShootBowEvent event) {
/* 29 */     runForAbility((Entity)event.getEntity(), player -> OriginsReborn.getMVE().launchArrow(event.getProjectile(), (Entity)player, 0.0F, event.getForce(), 0.0F));
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\PerfectShot.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */