/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ import com.starshootercity.OriginsReborn;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.entity.Arrow;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityShootBowEvent;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class ArrowEffectBooster implements VisibleAbility, Listener {
/*    */   public String description() {
/* 15 */     return "Your connection to your bow and arrow enhances any potion effects placed on your arrows.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 20 */     return "Arrow Lord";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 25 */     return Key.key("fantasyorigins:arrow_effect_booster");
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onEntityShootBow(EntityShootBowEvent event) {
/* 30 */     runForAbility((Entity)event.getEntity(), player -> {
/*    */           Entity patt0$temp = event.getProjectile();
/*    */           if (patt0$temp instanceof Arrow) {
/*    */             Arrow arrow = (Arrow)patt0$temp;
/*    */             OriginsReborn.getMVE().boostArrow(arrow);
/*    */           } 
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\ArrowEffectBooster.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */