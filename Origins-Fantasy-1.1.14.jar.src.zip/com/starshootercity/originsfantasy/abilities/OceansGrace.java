/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.Ability;
/*    */ import com.starshootercity.abilities.types.AttributeModifierAbility;
/*    */ import com.starshootercity.abilities.types.MultiAbility;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.version.MVAttribute;
/*    */ import java.util.List;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.attribute.Attribute;
/*    */ import org.bukkit.attribute.AttributeModifier;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class OceansGrace
/*    */   implements VisibleAbility, MultiAbility
/*    */ {
/*    */   public String description() {
/* 19 */     return "You are a part of the water, so you have extra health and deal extra damage when in water or rain.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 24 */     return "Ocean's Grace";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 29 */     return Key.key("fantasyorigins:oceans_grace");
/*    */   }
/*    */ 
/*    */   
/*    */   public List<Ability> getAbilities() {
/* 34 */     return List.of(WaterStrength.waterStrength, WaterHealth.waterHealth);
/*    */   }
/*    */   
/*    */   public static class WaterHealth implements AttributeModifierAbility {
/* 38 */     public static WaterHealth waterHealth = new WaterHealth();
/*    */     
/*    */     @NotNull
/*    */     public Attribute getAttribute() {
/* 42 */       return MVAttribute.MAX_HEALTH.get();
/*    */     }
/*    */ 
/*    */     
/*    */     public double getAmount(Player player) {
/* 47 */       if (player.isInWaterOrRainOrBubbleColumn()) {
/* 48 */         return 4.0D;
/*    */       }
/* 50 */       return 0.0D;
/*    */     }
/*    */ 
/*    */     
/*    */     public AttributeModifier.Operation getOperation() {
/* 55 */       return AttributeModifier.Operation.ADD_NUMBER;
/*    */     }
/*    */     
/*    */     @NotNull
/*    */     public Key getKey() {
/* 60 */       return Key.key("fantasyorigins:water_health");
/*    */     }
/*    */   }
/*    */   
/*    */   public static class WaterStrength implements AttributeModifierAbility {
/* 65 */     public static WaterStrength waterStrength = new WaterStrength();
/*    */     
/*    */     @NotNull
/*    */     public Key getKey() {
/* 69 */       return Key.key("fantasyorigins:water_strength");
/*    */     }
/*    */     
/*    */     @NotNull
/*    */     public Attribute getAttribute() {
/* 74 */       return MVAttribute.ATTACK_DAMAGE.get();
/*    */     }
/*    */ 
/*    */     
/*    */     public double getAmount(Player player) {
/* 79 */       if (player.isInWaterOrRainOrBubbleColumn()) {
/* 80 */         return 1.4D;
/*    */       }
/* 82 */       return 0.0D;
/*    */     }
/*    */ 
/*    */     
/*    */     public AttributeModifier.Operation getOperation() {
/* 87 */       return AttributeModifier.Operation.MULTIPLY_SCALAR_1;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\OceansGrace.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */