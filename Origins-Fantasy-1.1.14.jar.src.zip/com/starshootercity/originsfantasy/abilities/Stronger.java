/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.AttributeModifierAbility;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.version.MVAttribute;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.attribute.Attribute;
/*    */ import org.bukkit.attribute.AttributeModifier;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class Stronger implements VisibleAbility, AttributeModifierAbility {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 15 */     return Key.key("fantasyorigins:stronger");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 20 */     return "Your vampiric nature makes you stronger than a regular human, making your physical attacks deal far more damage.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 25 */     return "Stronger";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Attribute getAttribute() {
/* 30 */     return MVAttribute.ATTACK_DAMAGE.get();
/*    */   }
/*    */ 
/*    */   
/*    */   public double getAmount(Player player) {
/* 35 */     return 1.8D;
/*    */   }
/*    */ 
/*    */   
/*    */   public AttributeModifier.Operation getOperation() {
/* 40 */     return AttributeModifier.Operation.MULTIPLY_SCALAR_1;
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\Stronger.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */