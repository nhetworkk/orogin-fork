/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.AttributeModifierAbility;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.version.MVAttribute;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.attribute.Attribute;
/*    */ import org.bukkit.attribute.AttributeModifier;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class DoubleHealth
/*    */   implements VisibleAbility, AttributeModifierAbility {
/*    */   public String description() {
/* 15 */     return "As you're larger than humans, you have more health as your body protects you from damage.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 20 */     return "Double Health";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 25 */     return Key.key("fantasyorigins:double_health");
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Attribute getAttribute() {
/* 30 */     return MVAttribute.MAX_HEALTH.get();
/*    */   }
/*    */ 
/*    */   
/*    */   public double getAmount(Player player) {
/* 35 */     return 20.0D;
/*    */   }
/*    */ 
/*    */   
/*    */   public AttributeModifier.Operation getOperation() {
/* 40 */     return AttributeModifier.Operation.ADD_NUMBER;
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\DoubleHealth.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */