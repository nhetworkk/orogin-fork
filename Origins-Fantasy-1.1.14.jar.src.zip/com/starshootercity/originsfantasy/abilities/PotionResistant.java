/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityPotionEffectEvent;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class PotionResistant implements VisibleAbility, Listener {
/*    */   public String description() {
/* 13 */     return "Potions have no effect on you as your body is made of stone.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 18 */     return "Potion Resistant";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 23 */     return Key.key("fantasyorigins:potion_resistant");
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onEntityPotionEffect(EntityPotionEffectEvent event) {
/* 28 */     if (event.getNewEffect() == null)
/* 29 */       return;  runForAbility(event.getEntity(), player -> event.setCancelled(true));
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\PotionResistant.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */