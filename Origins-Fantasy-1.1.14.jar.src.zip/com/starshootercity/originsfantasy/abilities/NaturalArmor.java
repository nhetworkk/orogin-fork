/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.AttributeModifierAbility;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.version.MVAttribute;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.attribute.Attribute;
/*    */ import org.bukkit.attribute.AttributeModifier;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class NaturalArmor
/*    */   implements VisibleAbility, AttributeModifierAbility {
/*    */   public String description() {
/* 15 */     return "Your tough and strong body gives you some natural defense against attacks.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 20 */     return "Natural Armor";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 25 */     return Key.key("fantasyorigins:natural_armor");
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Attribute getAttribute() {
/* 30 */     return MVAttribute.ARMOR.get();
/*    */   }
/*    */ 
/*    */   
/*    */   public double getAmount(Player player) {
/* 35 */     return 6.0D;
/*    */   }
/*    */ 
/*    */   
/*    */   public AttributeModifier.Operation getOperation() {
/* 40 */     return AttributeModifier.Operation.ADD_NUMBER;
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\NaturalArmor.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */