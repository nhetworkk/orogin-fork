/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.Ability;
/*    */ import com.starshootercity.abilities.types.AttributeModifierAbility;
/*    */ import com.starshootercity.abilities.types.MultiAbility;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.version.MVAttribute;
/*    */ import java.util.List;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.attribute.Attribute;
/*    */ import org.bukkit.attribute.AttributeModifier;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class EndBoost
/*    */   implements VisibleAbility, MultiAbility
/*    */ {
/*    */   public String description() {
/* 20 */     return "Your natural habitat is the end, so you have more health and are stronger when you are there.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 25 */     return "End Inhabitant";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 30 */     return Key.key("fantasyorigins:end_boost");
/*    */   }
/*    */ 
/*    */   
/*    */   public List<Ability> getAbilities() {
/* 35 */     return List.of(EndStrength.endStrength, EndHealth.endHealth);
/*    */   }
/*    */   
/*    */   public static class EndStrength implements AttributeModifierAbility {
/* 39 */     public static EndStrength endStrength = new EndStrength();
/*    */     
/*    */     @NotNull
/*    */     public Attribute getAttribute() {
/* 43 */       return MVAttribute.ATTACK_DAMAGE.get();
/*    */     }
/*    */ 
/*    */     
/*    */     public double getAmount(Player player) {
/* 48 */       return (player.getWorld().getEnvironment() == World.Environment.THE_END) ? 1.6D : 0.0D;
/*    */     }
/*    */ 
/*    */     
/*    */     public AttributeModifier.Operation getOperation() {
/* 53 */       return AttributeModifier.Operation.MULTIPLY_SCALAR_1;
/*    */     }
/*    */     
/*    */     @NotNull
/*    */     public Key getKey() {
/* 58 */       return Key.key("fantasyorigins:end_strength");
/*    */     }
/*    */   }
/*    */   
/*    */   public static class EndHealth implements AttributeModifierAbility {
/* 63 */     public static EndHealth endHealth = new EndHealth();
/*    */     
/*    */     @NotNull
/*    */     public Key getKey() {
/* 67 */       return Key.key("fantasyorigins:end_health");
/*    */     }
/*    */     
/*    */     @NotNull
/*    */     public Attribute getAttribute() {
/* 72 */       return MVAttribute.MAX_HEALTH.get();
/*    */     }
/*    */ 
/*    */     
/*    */     public double getAmount(Player player) {
/* 77 */       return (player.getWorld().getEnvironment() == World.Environment.THE_END) ? 20.0D : 0.0D;
/*    */     }
/*    */ 
/*    */     
/*    */     public AttributeModifier.Operation getOperation() {
/* 82 */       return AttributeModifier.Operation.ADD_NUMBER;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\EndBoost.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */