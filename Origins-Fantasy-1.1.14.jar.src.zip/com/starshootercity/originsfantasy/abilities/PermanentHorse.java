/*     */ package com.starshootercity.originsfantasy.abilities;
/*     */ import com.destroystokyo.paper.event.server.ServerTickEndEvent;
/*     */ import com.starshootercity.OriginSwapper;
/*     */ import com.starshootercity.events.PlayerSwapOriginEvent;
/*     */ import com.starshootercity.originsfantasy.OriginsFantasy;
/*     */ import com.starshootercity.util.AbilityRegister;
/*     */ import com.starshootercity.version.MVAttribute;
/*     */ import com.starshootercity.version.MVEntityDismountEvent;
/*     */ import com.starshootercity.version.MVEntityMountEvent;
/*     */ import java.util.Iterator;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.NamespacedKey;
/*     */ import org.bukkit.attribute.AttributeInstance;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Horse;
/*     */ import org.bukkit.entity.LivingEntity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.entity.EntityDamageEvent;
/*     */ import org.bukkit.event.entity.PlayerDeathEvent;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.player.PlayerBedEnterEvent;
/*     */ import org.bukkit.event.player.PlayerTeleportEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.persistence.PersistentDataType;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ public class PermanentHorse implements VisibleAbility, Listener {
/*     */   public String description() {
/*  36 */     return "You are half horse, half human.";
/*     */   }
/*     */ 
/*     */   
/*     */   public String title() {
/*  41 */     return "Half Horse";
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Key getKey() {
/*  46 */     return Key.key("fantasyorigins:permanent_horse");
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onEntityDismount(MVEntityDismountEvent event) {
/*  51 */     if (event.getEntity().isDead())
/*  52 */       return;  runForAbility(event.getEntity(), player -> {
/*     */           event.setCancelled(true);
/*     */           Entity vehicle = event.getDismounted().getVehicle();
/*     */           if (vehicle != null)
/*     */             vehicle.removePassenger(event.getDismounted()); 
/*     */         });
/*     */   }
/*     */   @EventHandler
/*     */   public void onPlayerTeleport(PlayerTeleportEvent event) {
/*  61 */     if (event.getPlayer().getPersistentDataContainer().has(this.teleportingKey))
/*  62 */       return;  runForAbility((Entity)event.getPlayer(), player -> {
/*     */           Entity e = player.getVehicle();
/*     */           if (e != null) {
/*     */             e.removePassenger((Entity)player);
/*     */             player.getPersistentDataContainer().set(this.teleportingKey, (PersistentDataType)OriginSwapper.BooleanPDT.BOOLEAN, Boolean.valueOf(true));
/*     */             event.setCancelled(true);
/*     */             Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)OriginsFantasy.getInstance(), ());
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onEntityMount(MVEntityMountEvent event) {
/*  80 */     runForAbility(event.getEntity(), player -> {
/*     */           if (!((String)event.getMount().getPersistentDataContainer().getOrDefault(this.key, PersistentDataType.STRING, "")).equals(event.getEntity().getUniqueId().toString())) {
/*     */             event.setCancelled(true);
/*     */             if (!(event.getMount() instanceof LivingEntity)) {
/*     */               Entity vehicle = player.getVehicle();
/*     */               if (vehicle != null)
/*     */                 event.getMount().addPassenger(vehicle); 
/*     */             } 
/*     */           } 
/*     */         });
/*     */   }
/*     */   @EventHandler
/*     */   public void onServerTickEnd(ServerTickEndEvent event) {
/*  93 */     if (event.getTickNumber() % 20 != 0)
/*  94 */       return;  for (Iterator<Player> iterator = Bukkit.getOnlinePlayers().iterator(); iterator.hasNext(); ) { Player p = iterator.next();
/*  95 */       if (p.isDead())
/*  96 */         continue;  runForAbility((Entity)p, player -> {
/*     */             if (player.getPersistentDataContainer().has(this.teleportingKey))
/*     */               return; 
/*     */             if (player.getVehicle() != null)
/*     */               return; 
/*     */             Horse horse = (Horse)player.getWorld().spawnEntity(player.getLocation(), EntityType.HORSE);
/*     */             AttributeInstance jump = horse.getAttribute(MVAttribute.JUMP_STRENGTH.get());
/*     */             AttributeInstance speed = horse.getAttribute(MVAttribute.MOVEMENT_SPEED.get());
/*     */             if (AbilityRegister.hasAbility(player, Key.key("fantasyorigins:super_jump")) && jump != null)
/*     */               jump.setBaseValue(1.0D); 
/*     */             if (AbilityRegister.hasAbility(player, Key.key("fantasyorigins:increased_speed")) && speed != null)
/*     */               speed.setBaseValue(0.4D); 
/*     */             horse.getPersistentDataContainer().set(this.key, PersistentDataType.STRING, player.getUniqueId().toString());
/*     */             horse.setTamed(true);
/*     */             horse.setStyle(Horse.Style.NONE);
/*     */             ItemStack saddle = new ItemStack(Material.SADDLE);
/*     */             ItemMeta meta = saddle.getItemMeta();
/*     */             meta.getPersistentDataContainer().set(this.key, (PersistentDataType)OriginSwapper.BooleanPDT.BOOLEAN, Boolean.valueOf(true));
/*     */             saddle.setItemMeta(meta);
/*     */             horse.getInventory().setSaddle(saddle);
/*     */             horse.addPassenger((Entity)player);
/*     */           }); }
/*     */   
/*     */   }
/*     */   @EventHandler
/*     */   public void onInventoryClick(InventoryClickEvent event) {
/* 122 */     if (event.getCurrentItem() == null)
/* 123 */       return;  if (event.getCurrentItem().getItemMeta() == null)
/* 124 */       return;  if (event.getCurrentItem().getItemMeta().getPersistentDataContainer().has(this.key)) event.setCancelled(true); 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerDeath(PlayerDeathEvent event) {
/* 129 */     runForAbility((Entity)event.getEntity(), player -> {
/*     */           Entity vehicle = player.getVehicle();
/*     */           if (vehicle != null && vehicle.getPersistentDataContainer().has(this.key))
/*     */             vehicle.remove(); 
/*     */         });
/*     */   }
/*     */   @EventHandler
/*     */   public void onPlayerSwapOrigin(PlayerSwapOriginEvent event) {
/* 137 */     Entity vehicle = event.getPlayer().getVehicle();
/* 138 */     if (vehicle != null && vehicle.getPersistentDataContainer().has(this.key)) vehicle.remove(); 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerBedEnter(PlayerBedEnterEvent event) {
/* 143 */     runForAbility((Entity)event.getPlayer(), player -> event.setUseBed(Event.Result.DENY));
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onEntityDamage(EntityDamageEvent event) {
/* 148 */     if (event.getEntity().getPersistentDataContainer().has(this.key)) {
/* 149 */       for (Entity entity : event.getEntity().getPassengers()) {
/* 150 */         if (entity instanceof LivingEntity) { LivingEntity livingEntity = (LivingEntity)entity;
/* 151 */           OriginsReborn.getMVE().transferDamageEvent(livingEntity, event); }
/*     */       
/*     */       } 
/* 154 */       event.setCancelled(true);
/*     */     } 
/*     */   }
/*     */   
/* 158 */   private final NamespacedKey key = new NamespacedKey((Plugin)OriginsFantasy.getInstance(), "mount-key");
/* 159 */   private final NamespacedKey teleportingKey = new NamespacedKey((Plugin)OriginsFantasy.getInstance(), "teleporting");
/*     */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\PermanentHorse.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */