/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ import com.destroystokyo.paper.MaterialTags;
/*    */ import com.destroystokyo.paper.event.server.ServerTickEndEvent;
/*    */ import com.starshootercity.OriginsAddon;
/*    */ import com.starshootercity.OriginsReborn;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import java.util.Iterator;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.block.Block;
/*    */ import org.bukkit.block.BlockFace;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class DaylightSensitive implements VisibleAbility, Listener {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 25 */     return Key.key("fantasyorigins:daylight_sensitive");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 30 */     return "Your greatest weakness is daylight, which causes you to burst into flames.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 35 */     return "Daylight Sensitive";
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onServerTickEnd(ServerTickEndEvent ignored) {
/* 40 */     for (Iterator<Player> iterator = Bukkit.getOnlinePlayers().iterator(); iterator.hasNext(); ) { Player p = iterator.next();
/* 41 */       runForAbility((Entity)p, player -> {
/*    */             Block block = player.getWorld().getHighestBlockAt(player.getLocation());
/*    */             while (MaterialTags.GLASS.isTagged(block) || (MaterialTags.GLASS_PANES.isTagged(block) && block.getY() >= player.getLocation().getY())) {
/*    */               block = block.getRelative(BlockFace.DOWN);
/*    */             }
/*    */             boolean height = (block.getY() < player.getLocation().getY());
/*    */             boolean isInOverworld = player.getWorld().getEnvironment().equals(World.Environment.NORMAL);
/*    */             boolean day = player.getWorld().isDayTime();
/*    */             if (!((Boolean)getConfigOption((OriginsAddon)OriginsReborn.getInstance(), "burn_with_helmet", ConfigManager.SettingType.BOOLEAN)).booleanValue()) {
/*    */               ItemStack helm = player.getInventory().getHelmet();
/*    */               if (helm != null && !helm.getType().isAir()) {
/*    */                 return;
/*    */               }
/*    */             } 
/*    */             if (height && isInOverworld && day && !player.isInWaterOrRainOrBubbleColumn()) {
/*    */               player.setFireTicks(Math.max(player.getFireTicks(), 60));
/*    */             }
/*    */           }); }
/*    */   
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 64 */   private final String burnWithHelmet = "burn_with_helmet";
/*    */ 
/*    */   
/*    */   public void initialize(JavaPlugin plugin) {
/* 68 */     registerConfigOption((OriginsAddon)OriginsReborn.getInstance(), "burn_with_helmet", List.of("Whether the player should burn even when wearing a helmet"), ConfigManager.SettingType.BOOLEAN, Boolean.valueOf(true));
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\DaylightSensitive.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */