/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ import com.starshootercity.OriginSwapper;
/*    */ import com.starshootercity.OriginsAddon;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.originsfantasy.OriginsFantasy;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import java.util.Collections;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.NamespacedKey;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*    */ import org.bukkit.event.entity.EntityShootBowEvent;
/*    */ import org.bukkit.persistence.PersistentDataType;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class IncreasedArrowDamage implements VisibleAbility, Listener {
/*    */   public String description() {
/* 21 */     return "All arrows you shoot deal increased damage.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 26 */     return "Piercing Shot";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 31 */     return Key.key("fantasyorigins:increased_arrow_damage");
/*    */   }
/*    */   
/* 34 */   private final NamespacedKey key = new NamespacedKey((Plugin)OriginsFantasy.getInstance(), "increased-arrow-damage-key");
/*    */   
/*    */   @EventHandler
/*    */   public void onEntityShootBow(EntityShootBowEvent event) {
/* 38 */     runForAbility((Entity)event.getEntity(), player -> event.getProjectile().getPersistentDataContainer().set(this.key, (PersistentDataType)OriginSwapper.BooleanPDT.BOOLEAN, Boolean.valueOf(true)));
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
/* 43 */     if (event.getDamager().getPersistentDataContainer().has(this.key)) {
/* 44 */       double v = ((Double)getConfigOption((OriginsAddon)OriginsFantasy.getInstance(), "arrow_damage_increase", ConfigManager.SettingType.DOUBLE)).doubleValue();
/* 45 */       event.setDamage(event.getDamage() + v);
/*    */     } 
/*    */   }
/*    */   
/* 49 */   private final String arrowDamageIncrease = "arrow_damage_increase";
/*    */ 
/*    */   
/*    */   public void initialize(JavaPlugin plugin) {
/* 53 */     registerConfigOption((OriginsAddon)OriginsFantasy.getInstance(), "arrow_damage_increase", Collections.singletonList("Amount to add to arrow damage"), ConfigManager.SettingType.DOUBLE, Double.valueOf(3.0D));
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\IncreasedArrowDamage.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */