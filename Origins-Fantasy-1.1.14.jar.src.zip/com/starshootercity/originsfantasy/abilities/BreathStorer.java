/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerInteractEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class BreathStorer implements VisibleAbility, Listener {
/*    */   public String description() {
/* 15 */     return "By right clicking using an empty bottle, you can store your own Dragon's Breath.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 20 */     return "Dragon's Breath";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 25 */     return Key.key("fantasyorigins:breath_storer");
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerInteract(PlayerInteractEvent event) {
/* 30 */     if (event.getItem() == null)
/* 31 */       return;  if (!event.getAction().isRightClick())
/* 32 */       return;  runForAbility((Entity)event.getPlayer(), player -> {
/*    */           if (event.getItem().getType() == Material.GLASS_BOTTLE) {
/*    */             event.getItem().setAmount(event.getItem().getAmount() - 1);
/*    */             for (ItemStack item : player.getInventory().addItem(new ItemStack[] { new ItemStack(Material.DRAGON_BREATH) }).values())
/*    */               player.getWorld().dropItemNaturally(player.getLocation(), item); 
/*    */           } 
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\BreathStorer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */