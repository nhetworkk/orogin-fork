/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.Ability;
/*    */ import com.starshootercity.abilities.types.AttributeModifierAbility;
/*    */ import com.starshootercity.abilities.types.MultiAbility;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.version.MVAttribute;
/*    */ import java.util.List;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.attribute.Attribute;
/*    */ import org.bukkit.attribute.AttributeModifier;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ public class SolidStance
/*    */   implements VisibleAbility, MultiAbility, AttributeModifierAbility
/*    */ {
/*    */   public String description() {
/* 20 */     return "You are immune to knockback.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 25 */     return "Solid Stance";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 30 */     return Key.key("fantasyorigins:solid_stance");
/*    */   }
/*    */ 
/*    */   
/*    */   public List<Ability> getAbilities() {
/* 35 */     return List.of();
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Attribute getAttribute() {
/* 40 */     return MVAttribute.KNOCKBACK_RESISTANCE.get();
/*    */   }
/*    */ 
/*    */   
/*    */   public double getAmount(Player player) {
/* 45 */     return 1000.0D;
/*    */   }
/*    */ 
/*    */   
/*    */   public AttributeModifier.Operation getOperation() {
/* 50 */     return AttributeModifier.Operation.ADD_NUMBER;
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\SolidStance.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */