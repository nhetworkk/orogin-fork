/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class IncreasedSpeed
/*    */   implements VisibleAbility {
/*    */   public String description() {
/* 10 */     return "From years of training for race after race, you're much faster than any normal horse.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 15 */     return "Dashmaster";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 20 */     return Key.key("fantasyorigins:increased_speed");
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\IncreasedSpeed.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */