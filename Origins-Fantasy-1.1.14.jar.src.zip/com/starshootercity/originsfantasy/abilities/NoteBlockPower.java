/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.version.MVPotionEffectType;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.block.NotePlayEvent;
/*    */ import org.bukkit.potion.PotionEffect;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class NoteBlockPower
/*    */   implements VisibleAbility, Listener {
/*    */   public String description() {
/* 17 */     return "You gain strength and speed when a nearby Note Block is played.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 22 */     return "Musically Attuned";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 27 */     return Key.key("fantasyorigins:note_block_power");
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onNotePlay(NotePlayEvent event) {
/* 32 */     for (Entity entity : event.getBlock().getLocation().getNearbyEntities(32.0D, 32.0D, 32.0D)) {
/* 33 */       if (entity instanceof Player) { Player p = (Player)entity;
/* 34 */         runForAbility((Entity)p, player -> {
/*    */               player.addPotionEffect(new PotionEffect(MVPotionEffectType.SPEED.get(), 600, 1));
/*    */               player.addPotionEffect(new PotionEffect(MVPotionEffectType.STRENGTH.get(), 600, 1));
/*    */             }); }
/*    */     
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\NoteBlockPower.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */