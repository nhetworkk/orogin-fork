/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import java.util.Random;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.Tag;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.EntityType;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityDeathEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class BardicIntuition implements VisibleAbility, Listener {
/*    */   public String description() {
/* 19 */     return "Your musical energy will sometimes cause a creeper to drop a music disc, even without a skeleton.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 24 */     return "Bardic Intuition";
/*    */   }
/*    */   
/* 27 */   private final Random random = new Random();
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 31 */     return Key.key("fantasyorigins:bardic_intuition");
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onEntityDeath(EntityDeathEvent event) {
/* 36 */     if (event.getEntity().getType() != EntityType.CREEPER)
/* 37 */       return;  if (event.getEntity().getKiller() == null)
/*    */       return; 
/* 39 */     if (this.random.nextDouble() > 0.25D)
/*    */       return; 
/* 41 */     Material disc = Tag.ITEMS_CREEPER_DROP_MUSIC_DISCS.getValues().stream().toList().get(this.random.nextInt(Tag.ITEMS_CREEPER_DROP_MUSIC_DISCS.getValues().size()));
/*    */     
/* 43 */     runForAbility((Entity)event.getEntity().getKiller(), player -> event.getDrops().add(new ItemStack(disc)));
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\BardicIntuition.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */