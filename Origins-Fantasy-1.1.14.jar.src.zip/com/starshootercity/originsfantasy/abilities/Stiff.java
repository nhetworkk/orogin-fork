/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.AttributeModifierAbility;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.version.MVAttribute;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.attribute.Attribute;
/*    */ import org.bukkit.attribute.AttributeModifier;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class Stiff implements VisibleAbility, AttributeModifierAbility {
/*    */   @NotNull
/*    */   public Attribute getAttribute() {
/* 15 */     return MVAttribute.MOVEMENT_SPEED.get();
/*    */   }
/*    */ 
/*    */   
/*    */   public double getAmount(Player player) {
/* 20 */     return -0.35D;
/*    */   }
/*    */ 
/*    */   
/*    */   public AttributeModifier.Operation getOperation() {
/* 25 */     return AttributeModifier.Operation.MULTIPLY_SCALAR_1;
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 30 */     return "Your stone body makes it harder to move, causing you to walk slower.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 35 */     return "Stiff";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 40 */     return Key.key("fantasyorigins:stiff");
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\Stiff.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */