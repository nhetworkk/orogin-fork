/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ import com.starshootercity.OriginsAddon;
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import com.starshootercity.originsfantasy.OriginsFantasy;
/*    */ import com.starshootercity.util.config.ConfigManager;
/*    */ import java.util.Collections;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerInteractEvent;
/*    */ import org.bukkit.inventory.EquipmentSlot;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.bukkit.potion.PotionEffect;
/*    */ import org.bukkit.potion.PotionEffectType;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class Chime implements VisibleAbility, Listener {
/*    */   public String description() {
/* 22 */     return "You can absorb the chime of amethyst shards to regenerate health.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 27 */     return "Chime";
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public Key getKey() {
/* 32 */     return Key.key("fantasyorigins:chime");
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerInteract(PlayerInteractEvent event) {
/* 37 */     runForAbility((Entity)event.getPlayer(), player -> {
/*    */           if (!event.getAction().isRightClick())
/*    */             return;  if (event.getItem() == null)
/*    */             return;  if (event.getItem().getType() == Material.AMETHYST_SHARD) {
/*    */             event.getItem().setAmount(event.getItem().getAmount() - 1); player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, ((Integer)getConfigOption((OriginsAddon)OriginsFantasy.getInstance(), "regeneration_time", ConfigManager.SettingType.INTEGER)).intValue(), 1));
/*    */             if (event.getHand() == null)
/*    */               return; 
/*    */             if (event.getHand() == EquipmentSlot.HAND) {
/*    */               player.swingMainHand();
/*    */             } else {
/*    */               player.swingOffHand();
/*    */             } 
/*    */           } 
/* 50 */         }); } private final String regenerationTime = "regeneration_time";
/*    */ 
/*    */   
/*    */   public void initialize(JavaPlugin plugin) {
/* 54 */     registerConfigOption((OriginsAddon)OriginsFantasy.getInstance(), "regeneration_time", Collections.singletonList("Time in ticks the regeneration effect should last"), ConfigManager.SettingType.INTEGER, Integer.valueOf(900));
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\Chime.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */