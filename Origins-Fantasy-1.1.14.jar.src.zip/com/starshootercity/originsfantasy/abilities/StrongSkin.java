/*    */ package com.starshootercity.originsfantasy.abilities;
/*    */ 
/*    */ import com.starshootercity.abilities.types.VisibleAbility;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityDamageEvent;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class StrongSkin implements VisibleAbility, Listener {
/*    */   @NotNull
/*    */   public Key getKey() {
/* 14 */     return Key.key("fantasyorigins:strong_skin");
/*    */   }
/*    */ 
/*    */   
/*    */   public String description() {
/* 19 */     return "You've got naturally thicker skin than regular humans, so arrows do a lot less damage.";
/*    */   }
/*    */ 
/*    */   
/*    */   public String title() {
/* 24 */     return "Thick Skin";
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onEntityDamage(EntityDamageEvent event) {
/* 29 */     if (event.getCause() == EntityDamageEvent.DamageCause.PROJECTILE)
/* 30 */       runForAbility(event.getEntity(), player -> event.setDamage(event.getDamage() / 4.0D)); 
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\abilities\StrongSkin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */