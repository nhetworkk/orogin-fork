/*    */ package com.starshootercity.originsfantasy;
/*    */ import com.starshootercity.abilities.types.Ability;
/*    */ import com.starshootercity.originsfantasy.abilities.BreathStorer;
/*    */ import com.starshootercity.originsfantasy.abilities.DragonFireball;
/*    */ import com.starshootercity.originsfantasy.abilities.EndBoost;
/*    */ import com.starshootercity.originsfantasy.abilities.FireResistant;
/*    */ import com.starshootercity.originsfantasy.abilities.HeavyBlow;
/*    */ import com.starshootercity.originsfantasy.abilities.OceanWish;
/*    */ import com.starshootercity.originsfantasy.abilities.OceansGrace;
/*    */ import java.util.List;
/*    */ import org.bukkit.attribute.Attribute;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class OriginsFantasy extends OriginsAddon {
/*    */   @NotNull
/*    */   public String getNamespace() {
/* 17 */     return "fantasyorigins";
/*    */   }
/*    */   
/*    */   private static OriginsFantasy instance;
/*    */   
/*    */   public static OriginsFantasy getInstance() {
/* 23 */     return instance;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public List<Ability> getRegisteredAbilities() {
/* 28 */     List<Ability> abilities = new ArrayList<>(List.of((Object[])new Ability[] { (Ability)new AllayMaster(), (Ability)new ArrowEffectBooster(), (Ability)new BardicIntuition(), (Ability)new BowBurst(), (Ability)new BreathStorer(), (Ability)new Chime(), (Ability)new DoubleHealth(), (Ability)new DragonFireball(), (Ability)new Elegy(), (Ability)new EndCrystalHealing(), (Ability)new EndBoost(), (Ability)new FortuneIncreaser(), (Ability)new IncreasedArrowDamage(), (Ability)new IncreasedArrowSpeed(), (Ability)new HeavyBlow(), (Ability)HeavyBlow.IncreasedCooldown.increasedCooldown, (Ability)HeavyBlow.IncreasedDamage.increasedDamage, (Ability)EndBoost.EndHealth.endHealth, (Ability)EndBoost.EndStrength.endStrength, (Ability)new IncreasedSpeed(), (Ability)new InfiniteHaste(), (Ability)new InfiniteNightVision(), (Ability)new OceanWish(), (Ability)OceanWish.LandWeakness.landWeakness, (Ability)OceanWish.LandHealth.landHealth, (Ability)OceanWish.LandSlowness.landSlowness, (Ability)new MagicResistance(), (Ability)new MoonStrength(), (Ability)new NaturalArmor(), (Ability)new NoteBlockPower(), (Ability)new PerfectShot(), (Ability)new PermanentHorse(), (Ability)new PoorShot(), (Ability)new StrongSkin(), (Ability)new SuperJump(), (Ability)new OceansGrace(), (Ability)OceansGrace.WaterHealth.waterHealth, (Ability)OceansGrace.WaterStrength.waterStrength, (Ability)new VampiricTransformation(), (Ability)new DaylightSensitive(), (Ability)new WaterSensitive(), (Ability)new Leeching(), (Ability)new Stronger(), (Ability)new UndeadAlly(), (Ability)new SolidStance(), (Ability)new StoneSkin(), (Ability)new Stiff(), (Ability)new FireResistant(), (Ability)new PotionResistant() }));
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 79 */     Attribute scale = MVAttribute.SCALE.get();
/* 80 */     if (scale != null) {
/* 81 */       abilities.add(new LargeBody(scale));
/* 82 */       abilities.add(new SmallBody(scale));
/*    */     } 
/* 84 */     return abilities;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onRegister() {
/* 89 */     instance = this;
/*    */     
/* 91 */     int pluginId = 25121;
/* 92 */     new Metrics((Plugin)this, pluginId);
/*    */   }
/*    */ }


/* Location:              C:\Users\NITRO 5\Downloads\1.21.11 plugins\Origins-Fantasy-1.1.14.jar!\com\starshootercity\originsfantasy\OriginsFantasy.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */